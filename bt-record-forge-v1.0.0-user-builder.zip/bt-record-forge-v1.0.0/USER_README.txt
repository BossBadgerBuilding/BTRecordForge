BT Record Forge 1.0.0
======================

BT Record Forge is a standalone Windows desktop application for building,
validating, costing, and exporting BattleTech unit and structure records.

INSTALL
-------
Run:

  BT-Record-Forge-Setup.exe

Follow the installer prompts, then launch BT Record Forge from the Start menu.
No source code, Node.js, Rust, Visual Studio, or other development tools are
required. The installer includes BT Record Forge's own fixed WebView2 runtime
inside the application installation.

USING BT RECORD FORGE
---------------------
The application supports BattleMechs and related variants, ProtoMechs, Combat
and Support Vehicles, Aerospace and Conventional Fighters, Small Craft,
DropShips, JumpShips, WarShips, Space Stations, Conventional Infantry,
Battle Armor, Buildings, Mobile Structures, Gun Emplacements, Handheld
Weapons, and Battlefield Support/Assets.

Depending on unit type, the application can calculate and validate mass,
construction costs, equipment placement, capacity, era/tech restrictions,
building footprints, Castle Brian open-space volumes, and related construction
data.

CUSTOM BUILDS AND LOCAL APP DATA
-------------------------------
BT Record Forge keeps its own files together in its installation folder:

  BT Record Forge.exe
  custom-builds\
  app-data\

Use Save Creation to write TRO-style PNG records into custom-builds\.

New custom designs export as TRO-style PNG images. The image is viewable as a
normal record sheet and also contains the complete editable design as embedded
machine-readable metadata. BT Record Forge can import these PNG files directly.

Older .btforge JSON design files can still be imported.

BT Record Forge keeps its own writable data inside the application folder.
Saved creations are stored in custom-builds\ beside the executable, and
application cache/configuration data are stored in app-data\ beside it.
It does not save BT Record Forge data into Documents or Downloads.

YOUR FILES
----------
BT Record Forge is self-contained. Creations, application cache, and local
application data stay inside the BT Record Forge installation folder.

Back up custom-builds\ before uninstalling or deleting the application folder
if you want to preserve your creations.

UNINSTALL
---------
Open Windows Settings > Apps > Installed apps, select BT Record Forge, and
choose Uninstall.

LICENSE
-------
BT Record Forge is distributed under the GNU General Public License,
version 3 or later. See LICENSE.txt for the full license text.
