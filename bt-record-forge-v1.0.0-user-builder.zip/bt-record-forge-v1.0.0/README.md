# BT Record Forge 1.0.0

BT Record Forge is a standalone Windows desktop application for constructing,
validating, costing, and exporting BattleTech unit and structure records.

## Functionality

BT Record Forge supports BattleMechs and related variants, ProtoMechs, Combat
and Support Vehicles, Aerospace and Conventional Fighters, Small Craft,
DropShips, JumpShips, WarShips, Space Stations, Conventional Infantry,
Battle Armor, Buildings, Mobile Structures, Gun Emplacements, Handheld
Weapons, and Battlefield Support/Assets.

Features include mass and C-bill calculation, construction and placement
validation, equipment capacity tracking, custom components, multi-hex building
footprints, Castle Brian open-space/interior structures, Environmental Sealing,
artwork, and TRO-style record export.

Custom designs export as normal PNG images with the complete editable design
embedded in a UTF-8 PNG `iTXt` block named `BTRecordForge`. Older `.btforge`
JSON files remain importable.

The installed application is self-contained. The launch executable is placed
directly in the BT Record Forge installation folder, with writable application
data kept beside it:

```text
BT Record Forge\
├─ BT Record Forge.exe
├─ custom-builds\
└─ app-data\
```

**Save Creation** writes TRO-style PNG records directly to `custom-builds`.
BT Record Forge does not redirect creations to Documents or Downloads.

## Build the normal-user release

On a Windows build machine with Node.js, Rust/MSVC, and Visual Studio Build
Tools installed, double-click:

```text
BUILD-USER-RELEASE.bat
```

The builder stages Microsoft's x64 **Fixed Version WebView2 Runtime** into the
application bundle, so the installed app uses its own WebView2 copy rather than
installing or depending on a shared BT Record Forge runtime path elsewhere on
the machine.

The resulting distribution is:

```text
BT-Record-Forge-v1.0.0-Windows-x64.zip
```

It contains only:

```text
BT-Record-Forge-Setup.exe
README.txt
LICENSE.txt
SHA256SUMS.txt
```

The installer is self-contained for normal users; they do not need this source
tree or any development tools.

## License

BT Record Forge is distributed under the GNU General Public License,
version 3 or later. See `LICENSE`.
