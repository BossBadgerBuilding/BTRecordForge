$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)

function Require-Command([string]$Name, [string]$Help) {
  if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
    Write-Host ""
    Write-Host "Missing prerequisite: $Name" -ForegroundColor Red
    Write-Host $Help -ForegroundColor Yellow
    exit 1
  }
}

Write-Host "BT Record Forge - User Release Builder" -ForegroundColor Cyan

Require-Command "node" "Install Node.js LTS from https://nodejs.org/"
Require-Command "npm" "Install Node.js LTS from https://nodejs.org/"
Require-Command "rustc" "Install Rust using https://rustup.rs/ and reopen PowerShell."
Require-Command "cargo" "Install Rust using https://rustup.rs/ and reopen PowerShell."

$rustHost = (& rustc -vV | Select-String "^host:").ToString()
if ($rustHost -notmatch "windows-msvc") {
  throw "Rust must use the Windows MSVC target. Current host: $rustHost"
}

if (-not (Test-Path "node_modules")) {
  Write-Host "Installing build dependencies..."
  npm install
  if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
Write-Host "Building standalone Windows installer..."
npm run tauri -- build --bundles nsis
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$nsis = Get-ChildItem "src-tauri\target\release\bundle\nsis\*.exe" |
  Sort-Object LastWriteTime -Descending |
  Select-Object -First 1

if (-not $nsis) {
  throw "Tauri completed but no NSIS installer was found."
}

$installer = Join-Path (Get-Location) "BT-Record-Forge-Setup.exe"
Copy-Item -Force $nsis.FullName $installer

$package = Get-Content ".\package.json" -Raw | ConvertFrom-Json
$version = $package.version
if (-not $version) {
  throw "Could not read version from package.json"
}

$stageRoot = Join-Path (Get-Location) "release-user"
$stageName = "BT-Record-Forge-v$version-Windows-x64"
$stage = Join-Path $stageRoot $stageName
$zipPath = Join-Path (Get-Location) "$stageName.zip"
$zipHashPath = "$zipPath.sha256"

if (Test-Path $stageRoot) { Remove-Item -Recurse -Force $stageRoot }
if (Test-Path $zipPath) { Remove-Item -Force $zipPath }
if (Test-Path $zipHashPath) { Remove-Item -Force $zipHashPath }

New-Item -ItemType Directory -Force -Path $stage | Out-Null

Copy-Item -Force $installer (Join-Path $stage "BT-Record-Forge-Setup.exe")
Copy-Item -Force ".\USER_README.txt" (Join-Path $stage "README.txt")
Copy-Item -Force ".\LICENSE" (Join-Path $stage "LICENSE.txt")

$installerHash = (Get-FileHash -Algorithm SHA256 $installer).Hash.ToLowerInvariant()
Set-Content `
  -Path (Join-Path $stage "SHA256SUMS.txt") `
  -Value "$installerHash  BT-Record-Forge-Setup.exe`r`n" `
  -Encoding ASCII `
  -NoNewline

Compress-Archive -Path "$stage\*" -DestinationPath $zipPath -CompressionLevel Optimal

$zipHash = (Get-FileHash -Algorithm SHA256 $zipPath).Hash.ToLowerInvariant()
Set-Content `
  -Path $zipHashPath `
  -Value "$zipHash  $([System.IO.Path]::GetFileName($zipPath))`r`n" `
  -Encoding ASCII `
  -NoNewline

Write-Host ""
Write-Host "User release complete." -ForegroundColor Green
Write-Host "Installer: .\BT-Record-Forge-Setup.exe"
Write-Host "User ZIP:  .\$([System.IO.Path]::GetFileName($zipPath))"
Write-Host "Checksum:  .\$([System.IO.Path]::GetFileName($zipHashPath))"
