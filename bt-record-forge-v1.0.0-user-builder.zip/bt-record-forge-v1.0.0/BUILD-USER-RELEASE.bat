@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File ".\scripts\package-user-release.ps1"
if errorlevel 1 (
  echo.
  echo User distribution build FAILED.
  pause
  exit /b 1
)
echo.
echo User distribution build complete.
pause
