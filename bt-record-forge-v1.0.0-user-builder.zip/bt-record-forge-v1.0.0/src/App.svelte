<script lang="ts">
  import { constructors } from "./lib/constructors";
  import HexFootprintEditor from "./lib/ui/HexFootprintEditor.svelte";
  import { BATTLEMECH_LOCATIONS } from "./lib/constructors/battlemechPlacement";
  import { getStructureProperties } from "./lib/constructors/structureRules";
  import { getRecordLayout, familySummaryKeys } from "./lib/print/recordLayouts";
  import {
    getBattleMechProperties,
    setBattleMechProperty
  } from "./lib/constructors/battlemechRules";
  import {
    getSupportVehicleProperties,
    setSupportVehicleProperty
  } from "./lib/constructors/supportVehicleRules";
  import {
    mergeComponents,
    parseCatalogDocument
  } from "./lib/catalog/catalog";
  import { seedComponents } from "./lib/data/seedCatalog";
  import { newId } from "./lib/core/id";
  import {
    imageFromFile,
    parseDesignFile,
    saveTroRecord
  } from "./lib/core/files";
  import type {
    ComponentDefinition,
    ConstructionValue,
    ConstructorId,
    Design,
    EmbeddedStructure
  } from "./lib/core/types";

  const allConstructors = constructors.all();
  let design: Design = constructors.get("mech.battlemech").create();
  let catalogComponents: ComponentDefinition[] = [...seedComponents];
  let catalogName = "Built-in equipment catalog";
  let catalogVersion = "1.0.0";
  let catalogWarnings: string[] = [];
  let selectedComponent = catalogComponents[0].id;
  let customName = "";
  let customMass = 0;
  let customCost = 0;
  let customSlots = 0;
  let fileError = "";
  let fileNotice = "";

  $: resolvedCatalogComponents = mergeComponents(
    catalogComponents,
    design.embeddedComponents ?? []
  );
  $: catalogMap = new Map(
    resolvedCatalogComponents.map((component) => [component.id, component])
  );
  $: activeConstructor = constructors.get(design.constructorId);
  $: recordLayout = getRecordLayout(activeConstructor);
  $: recordSummaryKeys = familySummaryKeys(recordLayout.family);
  $: result = activeConstructor.calculate(design, catalogMap);
  $: warningCount = result.validation.filter((x) => x.severity === "warning").length;
  $: errorCount = result.validation.filter((x) => x.severity === "error").length;
  $: mech = design.constructorId === "mech.battlemech"
    ? getBattleMechProperties(design)
    : null;
  $: supportVehicle = design.constructorId === "vehicle.support"
    ? getSupportVehicleProperties(design)
    : null;
  $: structureDesign =
    design.constructorId === "structure.building" ||
    design.constructorId === "structure.mobile";
  $: structureEquipmentComponents = structureDesign
    ? resolvedCatalogComponents.filter(
        (component) => component.id !== "toaue.enviro-vacuum-sealing.is-clan"
      )
    : resolvedCatalogComponents;
  $: if (
    structureEquipmentComponents.length &&
    !structureEquipmentComponents.some(
      (component) => component.id === selectedComponent
    )
  ) {
    selectedComponent = structureEquipmentComponents[0].id;
  }
  $: structure = structureDesign ? getStructureProperties(design) : null;
  $: isCastleBrian =
    !!structure &&
    structure.structureKind === "BUILDING" &&
    structure.buildingClassification === "CASTLE_BRIAN";
  $: openSpaceHostCells = isCastleBrian
    ? (design.footprint?.cells ?? []).filter((cell) => !!cell.openLevels?.length)
    : [];
  $: genericSchema =
    !mech && !structureDesign
      ? activeConstructor.editorSchema ?? null
      : null;
  $: placementOptions = mech
    ? BATTLEMECH_LOCATIONS.map((location) => ({
        id: location.id,
        label: location.label
      }))
    : structureDesign
      ? (design.footprint?.cells ?? []).map((cell) => ({
          id: `${cell.q},${cell.r}`,
          label: `Hex ${cell.q}, ${cell.r}`
        }))
      : activeConstructor.editorSchema?.placementLocations ?? [];

  function touch() {
    design = { ...design };
  }

  function changeConstructor(event: Event) {
    const id = (event.currentTarget as HTMLSelectElement).value as ConstructorId;
    design = constructors.get(id).create();
  }

  function setMechNumber(
    key:
      | "walkMP"
      | "jumpMP"
      | "armorTons"
      | "heatSinks"
      | "armorHead"
      | "armorCTFront"
      | "armorCTRear"
      | "armorLTFront"
      | "armorLTRear"
      | "armorRTFront"
      | "armorRTRear"
      | "armorLA"
      | "armorRA"
      | "armorLL"
      | "armorRL",
    value: number
  ) {
    setBattleMechProperty(design, key, value);
    touch();
  }

  function setMechString(
    key: "engineType" | "gyroType" | "cockpitType" | "heatSinkType" | "structureType" | "armorType",
    value: string
  ) {
    setBattleMechProperty(design, key, value);
    touch();
  }

  function setMechBoolean(
    key: "leftLowerArmActuator" | "leftHandActuator" | "rightLowerArmActuator" | "rightHandActuator",
    value: boolean
  ) {
    setBattleMechProperty(design, key, value);
    touch();
  }

  function parseCriticalSlotList(value: string): number[] {
    return value
      .split(",")
      .map((x) => Number(x.trim()))
      .filter((x) => Number.isFinite(x) && Number.isInteger(x));
  }

  function criticalSlotList(value: number[] | undefined): string {
    return (value ?? []).join(", ");
  }

  function changeCriticalSlots(id: string, value: string, split = false) {
    const slots = parseCriticalSlotList(value);
    design.components = design.components.map((item) =>
      item.id === id
        ? {
            ...item,
            placement: {
              ...(item.placement ?? {}),
              ...(split ? { splitCriticalSlots: slots } : { criticalSlots: slots })
            }
          }
        : item
    );
    touch();
  }

  function changeSplitLocation(id: string, location: string) {
    design.components = design.components.map((item) =>
      item.id === id
        ? {
            ...item,
            placement: {
              ...(item.placement ?? {}),
              splitLocation: location || undefined,
              ...(!location ? { splitCriticalSlots: [] } : {})
            }
          }
        : item
    );
    touch();
  }

  function setSupportNumber(key: "walkMP", value: number) {
    setSupportVehicleProperty(design, key, value);
    touch();
  }

  function setSupportString(
    key: "vehicleType" | "structuralTechRating" | "engineTechRating" | "engineType" | "role",
    value: string
  ) {
    setSupportVehicleProperty(design, key, value);
    touch();
  }

  function changeFootprint(next: NonNullable<Design["footprint"]>) {
    const castleBrian =
      design.chassis.properties.structureKind === "BUILDING" &&
      design.chassis.properties.buildingClassification === "CASTLE_BRIAN";
    const hasOpenSpace = next.cells.some((cell) => !!cell.openLevels?.length);

    design = {
      ...design,
      chassis: castleBrian
        ? {
            ...design.chassis,
            properties: {
              ...design.chassis.properties,
              openSpaceConstruction: hasOpenSpace
            }
          }
        : design.chassis,
      footprint: next
    };
  }

  function addEmbeddedStructure() {
    const host = openSpaceHostCells[0];
    if (!host) {
      fileError =
        "Mark at least one Castle Brian level as open space before adding an interior structure.";
      return;
    }

    const embedded: EmbeddedStructure = {
      id: newId("interior-structure"),
      name: `Interior Structure ${(design.embeddedStructures?.length ?? 0) + 1}`,
      buildingClassification: "STANDARD",
      constructionType: "LIGHT",
      originQ: host.q,
      originR: host.r,
      baseLevel: host.openLevels?.[0] ?? 1,
      footprint: {
        kind: "hex-footprint",
        cells: [
          {
            q: 0,
            r: 0,
            levels: 1,
            constructionFactor: 10,
            armor: 0
          }
        ]
      }
    };

    design = {
      ...design,
      embeddedStructures: [...(design.embeddedStructures ?? []), embedded]
    };
    fileError = "";
  }

  function patchEmbeddedStructure(
    id: string,
    patch: Partial<EmbeddedStructure>
  ) {
    design = {
      ...design,
      embeddedStructures: (design.embeddedStructures ?? []).map((item) =>
        item.id === id ? { ...item, ...patch } : item
      )
    };
  }

  function setEmbeddedClassification(id: string, value: string) {
    patchEmbeddedStructure(id, {
      buildingClassification:
        value as EmbeddedStructure["buildingClassification"]
    });
  }

  function setEmbeddedConstructionType(id: string, value: string) {
    patchEmbeddedStructure(id, {
      constructionType: value as EmbeddedStructure["constructionType"]
    });
  }

  function moveEmbeddedStructure(id: string, location: string) {
    const [originQ, originR] = location.split(",").map(Number);
    const host = openSpaceHostCells.find(
      (cell) => cell.q === originQ && cell.r === originR
    );
    patchEmbeddedStructure(id, {
      originQ,
      originR,
      baseLevel: host?.openLevels?.[0] ?? 1
    });
  }

  function removeEmbeddedStructure(id: string) {
    design = {
      ...design,
      embeddedStructures: (design.embeddedStructures ?? []).filter(
        (item) => item.id !== id
      )
    };
  }

  function setStructureField(
    key: string,
    value: string | number | boolean
  ) {
    design.chassis.properties[key] = value;
    touch();
  }

  function setGenericField(key: string, value: string | number | boolean) {
    design.chassis.properties[key] = value;
    touch();
  }

  function genericValue(key: string) {
    return design.chassis.properties[key];
  }

  function changePlacementLevel(id: string, level: number) {
    design.components = design.components.map((item) =>
      item.id === id
        ? {
            ...item,
            placement: {
              ...(item.placement ?? {}),
              level
            }
          }
        : item
    );
    touch();
  }

  function structureHexLevels(location?: string) {
    if (!location || !design.footprint) return 1;
    const [q, r] = location.split(",").map(Number);
    return design.footprint.cells.find(
      (cell) => cell.q === q && cell.r === r
    )?.levels ?? 1;
  }

  function addCustomComponent() {
    const name = customName.trim();
    if (!name) {
      fileError = "Custom component name is required.";
      return;
    }

    if (
      !Number.isFinite(customMass) ||
      customMass < 0 ||
      !Number.isFinite(customCost) ||
      customCost < 0 ||
      !Number.isFinite(customSlots) ||
      customSlots < 0
    ) {
      fileError = "Custom component mass, cost, and slots must be non-negative numbers.";
      return;
    }

    const id = `custom.${Date.now()}.${name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "") || "component"}`;

    const component: ComponentDefinition = {
      id,
      name,
      categories: ["custom"],
      mass: customMass,
      cost: customCost,
      slots: customSlots > 0 ? customSlots : undefined,
      availability: {
        techBases: ["INNER_SPHERE", "CLAN", "MIXED"],
        rulesLevel: design.rules.rulesLevel
      },
      sourceNote: "Embedded custom component."
    };

    design.embeddedComponents = [
      ...(design.embeddedComponents ?? []),
      component
    ];
    design.components = [
      ...design.components,
      {
        id: newId("installed"),
        componentId: id,
        quantity: 1
      }
    ];

    customName = "";
    customMass = 0;
    customCost = 0;
    customSlots = 0;
    fileError = "";
    touch();
  }

  function addComponent() {
    design.components = [
      ...design.components,
      {
        id: newId("installed"),
        componentId: selectedComponent,
        quantity: 1
      }
    ];
    touch();
  }

  function removeComponent(id: string) {
    design.components = design.components.filter((item) => item.id !== id);
    touch();
  }

  function changeQuantity(id: string, quantity: number) {
    design.components = design.components.map((item) =>
      item.id === id ? { ...item, quantity } : item
    );
    touch();
  }

  function changePlacement(id: string, location: string) {
    design.components = design.components.map((item) =>
      item.id === id
        ? {
            ...item,
            placement: {
              ...(item.placement ?? {}),
              location: location || undefined
            }
          }
        : item
    );
    touch();
  }

  async function handleImage(event: Event) {
    fileError = "";
    const input = event.currentTarget as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;

    try {
      design.image = await imageFromFile(file);
      touch();
    } catch (error) {
      fileError = error instanceof Error ? error.message : String(error);
    } finally {
      input.value = "";
    }
  }

  async function importCatalog(event: Event) {
    fileError = "";
    const input = event.currentTarget as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;

    try {
      const loaded = parseCatalogDocument(await file.text());
      catalogComponents = mergeComponents(
        seedComponents,
        loaded.document.components
      );
      catalogName = loaded.document.provenance.name;
      catalogVersion = loaded.document.provenance.version ?? "unversioned";
      catalogWarnings = loaded.warnings;

      if (!catalogComponents.some((component) => component.id === selectedComponent)) {
        selectedComponent = catalogComponents[0]?.id ?? "";
      }

      touch();
    } catch (error) {
      fileError = error instanceof Error ? error.message : String(error);
    } finally {
      input.value = "";
    }
  }

  async function importDesign(event: Event) {
    fileError = "";
    fileNotice = "";
    const input = event.currentTarget as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;

    try {
      design = await parseDesignFile(file);
      constructors.get(design.constructorId);
      fileNotice = `Loaded ${file.name}.`;
    } catch (error) {
      fileError = error instanceof Error ? error.message : String(error);
    } finally {
      input.value = "";
    }
  }

  async function saveCreation() {
    fileError = "";
    fileNotice = "";

    try {
      const saved = await saveTroRecord(design, {
        constructorName: activeConstructor.name,
        recordTitle: recordLayout.title,
        recordSubtitle: recordLayout.subtitle,
        result,
        components: catalogMap
      });
      fileNotice = `Saved ${saved.fileName} to ${saved.location}.`;
    } catch (error) {
      fileError = error instanceof Error ? error.message : String(error);
    }
  }

  function formatMoney(value: number) {
    return new Intl.NumberFormat("en-US", {
      maximumFractionDigits: 2
    }).format(value) + " C";
  }

  function componentValueLabel(value: ConstructionValue | undefined, suffix = "") {
    if (value === undefined) return "—";
    return typeof value === "number"
      ? `${value}${suffix}`
      : `formula${suffix ? ` ${suffix.trim()}` : ""}`;
  }

  function componentUsesSlots(component: ComponentDefinition | undefined) {
    if (!component || component.slots === undefined) return false;
    return typeof component.slots === "number"
      ? component.slots > 0
      : true;
  }

  function componentName(id: string) {
    return catalogMap.get(id)?.name ?? id;
  }

  function prettyKey(key: string) {
    return key
      .replace(/([a-z])([A-Z])/g, "$1 $2")
      .replaceAll("_", " ")
      .replace(/\b\w/g, (c) => c.toUpperCase());
  }
</script>

<svelte:head>
  <title>BT Record Forge</title>
</svelte:head>

<div class="app-shell">
  <header class="topbar no-print">
    <div>
      <h1>BT Record Forge</h1>
      <p>Offline BattleTech construction + record builder</p>
    </div>

    <div class="toolbar">
      <label class="button secondary">
        Import
        <input
          class="visually-hidden"
          type="file"
          accept=".png,.btforge,image/png,application/json"
          on:change={importDesign}
        />
      </label>
      <label class="button secondary">
        Load catalog
        <input
          class="visually-hidden"
          type="file"
          accept=".json,application/json"
          on:change={importCatalog}
        />
      </label>
      <button class="button primary" on:click={saveCreation}>
        Save Creation
      </button>
    </div>
  </header>

  {#if fileError}
    <div class="error-banner no-print">{fileError}</div>
  {/if}
  {#if fileNotice}
    <div class="notice-banner no-print">{fileNotice}</div>
  {/if}

  <div class="catalog-status no-print">
    <span><strong>Catalog:</strong> {catalogName} · {catalogVersion} · {resolvedCatalogComponents.length} components</span>
    {#if catalogWarnings.length}
      <span class="warn">{catalogWarnings.length} catalog warning(s)</span>
    {/if}
  </div>

  <main class="workspace">
    <section class="editor no-print">
      <div class="panel">
        <h2>Design</h2>

        <label>
          Constructor
          <select value={design.constructorId} on:change={changeConstructor}>
            {#each allConstructors as constructor}
              <option value={constructor.id}>{constructor.name}</option>
            {/each}
          </select>
        </label>

        <div class="constructor-meta">
          <span>{activeConstructor.family ?? "Construction"}</span>
          <strong>{activeConstructor.coverage ?? "VERIFIED_SLICE"}</strong>
        </div>
        <p class="muted">{activeConstructor.description}</p>

        <label>
          Name
          <input bind:value={design.identity.name} on:input={touch} />
        </label>

        <label>
          Model
          <input bind:value={design.identity.model} on:input={touch} />
        </label>

        <label>
          Description
          <input bind:value={design.identity.description} on:input={touch} placeholder="Optional role / description" />
        </label>

        <label>
          Notes
          <textarea bind:value={design.notes} on:input={touch} rows="3" placeholder="Construction notes, source notes, house-rule notes…"></textarea>
        </label>

        <div class="two">
          <label>
            Year
            <input
              type="number"
              min="0"
              bind:value={design.rules.year}
              on:input={touch}
            />
          </label>

          <label>
            Mass limit (tons)
            <input
              type="number"
              min="0"
              step="5"
              bind:value={design.chassis.massLimit}
              on:input={touch}
            />
          </label>
        </div>

        <div class="two">
          <label>
            Tech base
            <select
              bind:value={design.rules.techBase}
              on:change={touch}
            >
              <option value="INNER_SPHERE">Inner Sphere</option>
              <option value="CLAN">Clan</option>
              <option value="MIXED">Mixed</option>
            </select>
          </label>

          <label>
            Rules level
            <select
              bind:value={design.rules.rulesLevel}
              on:change={touch}
            >
              <option value="INTRODUCTORY">Introductory</option>
              <option value="STANDARD">Standard</option>
              <option value="ADVANCED">Advanced</option>
              <option value="EXPERIMENTAL">Experimental</option>
            </select>
          </label>
        </div>
      </div>

      {#if mech}
        <div class="panel">
          <h2>BattleMech chassis</h2>
          <p class="muted">
            Standard biped slice. Engine, gyro, cockpit, armor, heat-sink and jump-jet mass/cost are live.
          </p>

          <div class="two">
            <label>
              Walk MP
              <input
                type="number"
                min="1"
                step="1"
                value={mech.walkMP}
                on:input={(e) => setMechNumber("walkMP", Number(e.currentTarget.value))}
              />
            </label>

            <label>
              Jump MP
              <input
                type="number"
                min="0"
                step="1"
                value={mech.jumpMP}
                on:input={(e) => setMechNumber("jumpMP", Number(e.currentTarget.value))}
              />
            </label>
          </div>

          <label>
            Engine
            <select
              value={mech.engineType}
              on:change={(e) => setMechString("engineType", e.currentTarget.value)}
            >
              <option value="STANDARD_FUSION">Standard Fusion</option>
              <option value="LIGHT_FUSION">Light Fusion</option>
              <option value="IS_XL_FUSION">Inner Sphere XL Fusion</option>
              <option value="CLAN_XL_FUSION">Clan XL Fusion</option>
              <option value="COMPACT_FUSION">Compact Fusion</option>
            </select>
          </label>

          <div class="two">
            <label>
              Gyro
              <select
                value={mech.gyroType}
                on:change={(e) => setMechString("gyroType", e.currentTarget.value)}
              >
                <option value="STANDARD">Standard</option>
                <option value="XL">XL</option>
                <option value="COMPACT">Compact</option>
                <option value="HEAVY_DUTY">Heavy-Duty</option>
              </select>
            </label>

            <label>
              Cockpit
              <select
                value={mech.cockpitType}
                on:change={(e) => setMechString("cockpitType", e.currentTarget.value)}
              >
                <option value="STANDARD">Standard</option>
                <option value="SMALL">Small</option>
                <option value="TORSO_MOUNTED">Torso-Mounted</option>
                <option value="COMMAND_CONSOLE">Command Console</option>
              </select>
            </label>
          </div>

          <div class="two">
            <label>
              Internal structure
              <select
                value={mech.structureType}
                on:change={(e) => setMechString("structureType", e.currentTarget.value)}
              >
                <option value="STANDARD">Standard</option>
                <option value="ENDO_STEEL">Endo Steel</option>
                <option value="COMPOSITE">Composite</option>
                <option value="ENDO_COMPOSITE">Endo-Composite</option>
                <option value="REINFORCED">Reinforced</option>
              </select>
            </label>
            <label>
              Armor type
              <select
                value={mech.armorType}
                on:change={(e) => setMechString("armorType", e.currentTarget.value)}
              >
                <option value="STANDARD">Standard</option>
                <option value="IS_FERRO_FIBROUS">Ferro-Fibrous (IS)</option>
                <option value="CLAN_FERRO_FIBROUS">Ferro-Fibrous (Clan)</option>
                <option value="LIGHT_FERRO_FIBROUS">Light Ferro-Fibrous</option>
                <option value="HEAVY_FERRO_FIBROUS">Heavy Ferro-Fibrous</option>
                <option value="STEALTH">Stealth</option>
              </select>
            </label>
          </div>

          <fieldset class="actuator-options">
            <legend>Arm actuators</legend>
            <label><input type="checkbox" checked={mech.leftLowerArmActuator}
              on:change={(e) => setMechBoolean("leftLowerArmActuator", e.currentTarget.checked)} /> Left lower arm</label>
            <label><input type="checkbox" checked={mech.leftHandActuator}
              on:change={(e) => setMechBoolean("leftHandActuator", e.currentTarget.checked)} /> Left hand</label>
            <label><input type="checkbox" checked={mech.rightLowerArmActuator}
              on:change={(e) => setMechBoolean("rightLowerArmActuator", e.currentTarget.checked)} /> Right lower arm</label>
            <label><input type="checkbox" checked={mech.rightHandActuator}
              on:change={(e) => setMechBoolean("rightHandActuator", e.currentTarget.checked)} /> Right hand</label>
          </fieldset>

          <div class="two">
            <label>
              Armor tons
              <input
                type="number"
                min="0"
                step="0.5"
                value={mech.armorTons}
                on:input={(e) => setMechNumber("armorTons", Number(e.currentTarget.value))}
              />
            </label>

            <label>
              Heat sinks
              <input
                type="number"
                min="10"
                step="1"
                value={mech.heatSinks}
                on:input={(e) => setMechNumber("heatSinks", Number(e.currentTarget.value))}
              />
            </label>
          </div>

          <label>
            Heat sink type
            <select
              value={mech.heatSinkType}
              on:change={(e) => setMechString("heatSinkType", e.currentTarget.value)}
            >
              <option value="SINGLE">Single</option>
              <option value="DOUBLE">Double</option>
            </select>
          </label>

          <h3 class="subhead">Armor allocation</h3>
          <p class="muted">
            Torso front and rear share the same location maximum. Purchased-but-unallocated armor is allowed.
          </p>

          <div class="armor-grid">
            <label>
              Head
              <input type="number" min="0" step="1" value={mech.armorHead}
                on:input={(e) => setMechNumber("armorHead", Number(e.currentTarget.value))} />
            </label>
            <label>
              CT Front
              <input type="number" min="0" step="1" value={mech.armorCTFront}
                on:input={(e) => setMechNumber("armorCTFront", Number(e.currentTarget.value))} />
            </label>
            <label>
              CT Rear
              <input type="number" min="0" step="1" value={mech.armorCTRear}
                on:input={(e) => setMechNumber("armorCTRear", Number(e.currentTarget.value))} />
            </label>
            <label>
              LT Front
              <input type="number" min="0" step="1" value={mech.armorLTFront}
                on:input={(e) => setMechNumber("armorLTFront", Number(e.currentTarget.value))} />
            </label>
            <label>
              LT Rear
              <input type="number" min="0" step="1" value={mech.armorLTRear}
                on:input={(e) => setMechNumber("armorLTRear", Number(e.currentTarget.value))} />
            </label>
            <label>
              RT Front
              <input type="number" min="0" step="1" value={mech.armorRTFront}
                on:input={(e) => setMechNumber("armorRTFront", Number(e.currentTarget.value))} />
            </label>
            <label>
              RT Rear
              <input type="number" min="0" step="1" value={mech.armorRTRear}
                on:input={(e) => setMechNumber("armorRTRear", Number(e.currentTarget.value))} />
            </label>
            <label>
              Left Arm
              <input type="number" min="0" step="1" value={mech.armorLA}
                on:input={(e) => setMechNumber("armorLA", Number(e.currentTarget.value))} />
            </label>
            <label>
              Right Arm
              <input type="number" min="0" step="1" value={mech.armorRA}
                on:input={(e) => setMechNumber("armorRA", Number(e.currentTarget.value))} />
            </label>
            <label>
              Left Leg
              <input type="number" min="0" step="1" value={mech.armorLL}
                on:input={(e) => setMechNumber("armorLL", Number(e.currentTarget.value))} />
            </label>
            <label>
              Right Leg
              <input type="number" min="0" step="1" value={mech.armorRL}
                on:input={(e) => setMechNumber("armorRL", Number(e.currentTarget.value))} />
            </label>
          </div>
        </div>
      {/if}

      {#if supportVehicle}
        <div class="panel">
          <h2>Support Vehicle chassis</h2>
          <p class="muted">
            Motive/size chassis and engine mass rules are live, including structural and engine Tech Ratings.
          </p>

          <label>
            Vehicle type
            <select
              value={supportVehicle.vehicleType}
              on:change={(e) => setSupportString("vehicleType", e.currentTarget.value)}
            >
              <option value="WHEELED">Wheeled</option>
              <option value="TRACKED">Tracked</option>
              <option value="HOVERCRAFT">Hovercraft</option>
              <option value="VTOL">VTOL</option>
              <option value="WIGE">WiGE</option>
              <option value="NAVAL">Naval / Hydrofoil / Submarine</option>
              <option value="RAIL">Rail / MagLev Rail</option>
              <option value="FIXED_WING">Fixed-Wing</option>
              <option value="AIRSHIP">Airship</option>
              <option value="SATELLITE">Satellite</option>
            </select>
          </label>

          <div class="two">
            <label>
              Cruising / safe MP
              <input
                type="number"
                min="0"
                step="1"
                value={supportVehicle.walkMP}
                on:input={(e) => setSupportNumber("walkMP", Number(e.currentTarget.value))}
              />
            </label>

            <label>
              Role
              <select
                value={supportVehicle.role}
                on:change={(e) => setSupportString("role", e.currentTarget.value)}
              >
                <option value="civilian">Civilian</option>
                <option value="commercial">Commercial</option>
                <option value="industrial">Industrial</option>
                <option value="military">Military</option>
              </select>
            </label>
          </div>

          <label>
            Engine
            <select
              value={supportVehicle.engineType}
              on:change={(e) => setSupportString("engineType", e.currentTarget.value)}
            >
              <option value="ICE">Internal Combustion</option>
              <option value="FUSION">Fusion</option>
              <option value="FUEL_CELL">Fuel Cell</option>
              <option value="FISSION">Fission</option>
              <option value="MAGLEV">MagLev</option>
              <option value="STEAM">Steam</option>
              <option value="BATTERY">Battery</option>
              <option value="SOLAR">Solar</option>
              <option value="EXTERNAL">External Power</option>
              <option value="NONE">No Engine</option>
            </select>
          </label>

          <div class="two">
            <label>
              Structural Tech Rating
              <select
                value={supportVehicle.structuralTechRating}
                on:change={(e) => setSupportString("structuralTechRating", e.currentTarget.value)}
              >
                <option value="A">A</option>
                <option value="B">B</option>
                <option value="C">C</option>
                <option value="D">D</option>
                <option value="E">E</option>
                <option value="F">F</option>
              </select>
            </label>

            <label>
              Engine Tech Rating
              <select
                value={supportVehicle.engineTechRating}
                on:change={(e) => setSupportString("engineTechRating", e.currentTarget.value)}
              >
                <option value="A">A</option>
                <option value="B">B</option>
                <option value="C">C</option>
                <option value="D">D</option>
                <option value="E">E</option>
                <option value="F">F</option>
              </select>
            </label>
          </div>
        </div>
      {/if}


      {#if genericSchema}
        {#each genericSchema.sections as section}
          <div class="panel">
            <h2>{section.label}</h2>
            {#if section.description}
              <p class="muted">{section.description}</p>
            {/if}

            <div class="schema-grid">
              {#each section.fields as field}
                {#if field.kind === "number"}
                  <label>
                    {field.label}{field.unit ? ` (${field.unit})` : ""}
                    <input
                      type="number"
                      min={field.min}
                      max={field.max}
                      step={field.step ?? 1}
                      value={Number(genericValue(field.key) ?? field.defaultValue)}
                      on:input={(e) =>
                        setGenericField(field.key, Number(e.currentTarget.value))}
                    />
                    {#if field.help}<small>{field.help}</small>{/if}
                  </label>
                {:else if field.kind === "select"}
                  <label>
                    {field.label}
                    <select
                      value={String(genericValue(field.key) ?? field.defaultValue)}
                      on:change={(e) =>
                        setGenericField(field.key, e.currentTarget.value)}
                    >
                      {#each field.options ?? [] as option}
                        <option value={option.value}>{option.label}</option>
                      {/each}
                    </select>
                    {#if field.help}<small>{field.help}</small>{/if}
                  </label>
                {:else if field.kind === "boolean"}
                  <label class="check-field">
                    <input
                      type="checkbox"
                      checked={Boolean(genericValue(field.key))}
                      on:change={(e) =>
                        setGenericField(field.key, e.currentTarget.checked)}
                    />
                    <span>{field.label}</span>
                    {#if field.help}<small>{field.help}</small>{/if}
                  </label>
                {:else}
                  <label>
                    {field.label}
                    <input
                      value={String(genericValue(field.key) ?? field.defaultValue)}
                      on:input={(e) =>
                        setGenericField(field.key, e.currentTarget.value)}
                    />
                    {#if field.help}<small>{field.help}</small>{/if}
                  </label>
                {/if}
              {/each}
            </div>
          </div>
        {/each}
      {/if}

      {#if structureDesign && design.footprint}
        <div class="panel">
          <h2>Hex footprint</h2>
          <p class="muted">
            One map hex per occupied location. Levels are stored as a number on the hex instead of drawing duplicate stacked hexes.
          </p>

          {#if structure}
            <div class="schema-grid">
              {#if structure.structureKind === "BUILDING"}
                <label>
                  Building classification
                  <select
                    value={structure.buildingClassification}
                    on:change={(e) =>
                      setStructureField("buildingClassification", e.currentTarget.value)}
                  >
                    <option value="TENT">Tent</option>
                    <option value="HANGAR">Hangar</option>
                    <option value="STANDARD">Standard building</option>
                    <option value="FENCE">Fence</option>
                    <option value="WALL">Wall</option>
                    <option value="BRIDGE">Bridge</option>
                    <option value="GUN_EMPLACEMENT">Gun emplacement</option>
                    <option value="FORTRESS">Fortress</option>
                    <option value="CASTLE_BRIAN">Castle Brian</option>
                  </select>
                </label>
              {:else}
                <label>
                  Mobile structure type
                  <select
                    value={structure.mobileStructureType}
                    on:change={(e) =>
                      setStructureField("mobileStructureType", e.currentTarget.value)}
                  >
                    <option value="BUILDING">Building-type</option>
                    <option value="HANGAR">Hangar-type</option>
                    <option value="FORTRESS">Fortress-type</option>
                  </select>
                </label>
              {/if}

              <label>
                Construction class
                <select
                  value={structure.constructionType}
                  on:change={(e) =>
                    setStructureField("constructionType", e.currentTarget.value)}
                >
                  <option value="LIGHT">Light</option>
                  <option value="MEDIUM">Medium</option>
                  <option value="HEAVY">Heavy</option>
                  <option value="HARDENED">Hardened</option>
                  {#if structure.structureKind === "BUILDING"}
                    <option value="RAIL">Rail bridge</option>
                  {/if}
                </select>
              </label>

              <label class="check-field">
                <input
                  type="checkbox"
                  checked={structure.environmentalSealing}
                  on:change={(e) =>
                    setStructureField("environmentalSealing", e.currentTarget.checked)}
                />
                <span>Environmental sealing</span>
                <small>
                  Building/structure construction enhancement (×1.5 shell cost).
                </small>
              </label>

              <label>
                Additional / manual shell cost (C)
                <input
                  type="number"
                  min="0"
                  step="1"
                  value={structure.baseStructureCost}
                  on:input={(e) =>
                    setStructureField("baseStructureCost", Number(e.currentTarget.value))}
                />
              </label>

              {#if structure.structureKind === "MOBILE_STRUCTURE"}
                <label>
                  Motive type
                  <select
                    value={structure.motiveType}
                    on:change={(e) =>
                      setStructureField("motiveType", e.currentTarget.value)}
                  >
                    <option value="GROUND">Ground / tracked</option>
                    <option value="AIR">Air / VTOL</option>
                    <option value="NAVAL_SURFACE">Naval surface</option>
                    <option value="NAVAL_SUBMERSIBLE">Naval submersible</option>
                  </select>
                </label>

                <label>
                  Power system
                  <select
                    value={structure.powerSystem}
                    on:change={(e) =>
                      setStructureField("powerSystem", e.currentTarget.value)}
                  >
                    <option value="STEAM">Steam</option>
                    <option value="ICE">Internal combustion</option>
                    <option value="FUEL_CELL">Fuel cell</option>
                    <option value="FISSION">Fission</option>
                    <option value="FUSION">Fusion</option>
                  </select>
                </label>

                <label>
                  Maximum MP
                  <input
                    type="number"
                    min="0"
                    step="0.25"
                    value={structure.cruiseMP}
                    on:input={(e) =>
                      setStructureField("cruiseMP", Number(e.currentTarget.value))}
                  />
                </label>

                <label>
                  Desired range (km)
                  <input
                    type="number"
                    min="0"
                    step="100"
                    value={structure.desiredRangeKm}
                    on:input={(e) =>
                      setStructureField("desiredRangeKm", Number(e.currentTarget.value))}
                  />
                </label>

                <label>
                  Additional manual drive mass (t)
                  <input
                    type="number"
                    min="0"
                    step="0.5"
                    value={structure.motiveMass}
                    on:input={(e) =>
                      setStructureField("motiveMass", Number(e.currentTarget.value))}
                  />
                </label>

                <label>
                  Manual drive / motive cost (C)
                  <input
                    type="number"
                    min="0"
                    step="1"
                    value={structure.motiveCost}
                    on:input={(e) =>
                      setStructureField("motiveCost", Number(e.currentTarget.value))}
                  />
                </label>
              {/if}
            </div>
          {/if}

          <HexFootprintEditor
            footprint={design.footprint}
            onChange={changeFootprint}
            allowOpenSpace={isCastleBrian}
          />

          {#if isCastleBrian}
            <div class="castle-brian-space">
              <div class="castle-brian-head">
                <div>
                  <h3>Castle Brian open-space construction</h3>
                  <p class="muted">
                    Select a fortress hex above, then mark the specific vertical levels that are open volume.
                    Interior structures are anchored into those open levels and use a footprint relative to that anchor.
                  </p>
                </div>
                <div class="castle-brian-stat">
                  <span>Open level-hexes</span>
                  <strong>{result.derived?.openSpaceLevelHexes ?? 0}</strong>
                </div>
              </div>

              <div class="interior-structure-head">
                <div>
                  <h3>Interior structures</h3>
                  <p class="muted">
                    These are structures physically inside the Castle Brian's open-space volume.
                  </p>
                </div>
                <button
                  type="button"
                  class="button secondary"
                  disabled={!openSpaceHostCells.length}
                  on:click={addEmbeddedStructure}
                >
                  Add interior structure
                </button>
              </div>

              {#if !openSpaceHostCells.length}
                <p class="empty">
                  Mark at least one parent level as open space before placing an interior structure.
                </p>
              {/if}

              {#each design.embeddedStructures ?? [] as embedded (embedded.id)}
                <details class="interior-structure" open>
                  <summary>
                    <strong>{embedded.name}</strong>
                    <span>
                      {embedded.buildingClassification.replaceAll("_", " ")}
                      · anchor {embedded.originQ},{embedded.originR}
                      · level {embedded.baseLevel}
                    </span>
                  </summary>

                  <div class="schema-grid interior-fields">
                    <label>
                      Name
                      <input
                        value={embedded.name}
                        on:input={(e) =>
                          patchEmbeddedStructure(embedded.id, {
                            name: e.currentTarget.value
                          })}
                      />
                    </label>

                    <label>
                      Classification
                      <select
                        value={embedded.buildingClassification}
                        on:change={(e) =>
                          setEmbeddedClassification(
                            embedded.id,
                            e.currentTarget.value
                          )}
                      >
                        <option value="TENT">Tent</option>
                        <option value="HANGAR">Hangar</option>
                        <option value="STANDARD">Standard building</option>
                        <option value="FENCE">Fence</option>
                        <option value="WALL">Wall</option>
                        <option value="BRIDGE">Bridge</option>
                        <option value="GUN_EMPLACEMENT">Gun emplacement</option>
                        <option value="FORTRESS">Fortress</option>
                        <option value="CASTLE_BRIAN">Castle Brian</option>
                      </select>
                    </label>

                    <label>
                      Construction class
                      <select
                        value={embedded.constructionType}
                        on:change={(e) =>
                          setEmbeddedConstructionType(
                            embedded.id,
                            e.currentTarget.value
                          )}
                      >
                        <option value="LIGHT">Light</option>
                        <option value="MEDIUM">Medium</option>
                        <option value="HEAVY">Heavy</option>
                        <option value="HARDENED">Hardened</option>
                        <option value="RAIL">Rail</option>
                      </select>
                    </label>

                    <label>
                      Anchor open-space hex
                      <select
                        value={`${embedded.originQ},${embedded.originR}`}
                        on:change={(e) =>
                          moveEmbeddedStructure(embedded.id, e.currentTarget.value)}
                      >
                        {#each openSpaceHostCells as host}
                          <option value={`${host.q},${host.r}`}>
                            Hex {host.q}, {host.r} · open L{host.openLevels?.join(", L")}
                          </option>
                        {/each}
                      </select>
                    </label>

                    <label>
                      Base level
                      <input
                        type="number"
                        min="1"
                        step="1"
                        value={embedded.baseLevel}
                        on:input={(e) =>
                          patchEmbeddedStructure(embedded.id, {
                            baseLevel: Math.max(1, Math.floor(Number(e.currentTarget.value) || 1))
                          })}
                      />
                    </label>

                    <label class="wide">
                      Notes
                      <input
                        value={embedded.notes ?? ""}
                        placeholder="Optional"
                        on:input={(e) =>
                          patchEmbeddedStructure(embedded.id, {
                            notes: e.currentTarget.value || undefined
                          })}
                      />
                    </label>
                  </div>

                  <div class="interior-footprint">
                    <div>
                      <strong>Interior structure footprint</strong>
                      <span>
                        Relative hex 0,0 is placed at parent hex {embedded.originQ},{embedded.originR}.
                        Its level 1 begins at Castle Brian level {embedded.baseLevel}.
                      </span>
                    </div>
                    <HexFootprintEditor
                      footprint={embedded.footprint}
                      onChange={(next) =>
                        patchEmbeddedStructure(embedded.id, { footprint: next })}
                      radius={2}
                    />
                  </div>

                  <button
                    type="button"
                    class="text-button danger"
                    on:click={() => removeEmbeddedStructure(embedded.id)}
                  >
                    Remove interior structure
                  </button>
                </details>
              {/each}

              {#if design.embeddedStructures?.length}
                <p class="muted interior-note">
                  Interior structures are spatially validated against Castle Brian open-space levels.
                  Equipment and cost ledgers remain separate from the parent fortress record.
                </p>
              {/if}
            </div>
          {/if}

          <div class="structure-stats">
            <div>
              <span>Occupied hexes</span>
              <strong>{result.derived?.occupiedHexes ?? 0}</strong>
            </div>
            <div>
              <span>Max levels</span>
              <strong>{result.derived?.maxLevels ?? 0}</strong>
            </div>
            <div>
              <span>Total level-hexes</span>
              <strong>{result.derived?.totalLevelHexes ?? 0}</strong>
            </div>
          </div>
        </div>
      {/if}

      <div class="panel">
        <h2>Reference image</h2>

        {#if design.image}
          <img class="image-preview" src={design.image.dataUrl} alt="Design reference" />
          <div class="row">
            <span class="muted">{design.image.fileName}</span>
            <button
              class="text-button"
              on:click={() => {
                design.image = undefined;
                touch();
              }}
            >Remove</button>
          </div>
        {/if}

        <label class="button secondary upload">
          {design.image ? "Replace PNG/JPG" : "Add PNG/JPG"}
          <input
            class="visually-hidden"
            type="file"
            accept="image/png,image/jpeg"
            on:change={handleImage}
          />
        </label>
      </div>

      <div class="panel">
        <h2>Equipment / payload</h2>
        <p class="muted">
          Choose from the built-in equipment catalog, or define a custom component when a required item is unavailable.
        </p>

        <div class="add-component">
          <select bind:value={selectedComponent}>
            {#each structureEquipmentComponents as component}
              <option value={component.id}>{component.name}</option>
            {/each}
          </select>
          <button class="button primary" on:click={addComponent}>Add</button>
        </div>

        <details class="custom-part">
          <summary>Define custom / missing component</summary>
          <div class="custom-part-grid">
            <label class="wide">
              Name
              <input bind:value={customName} placeholder="Custom component" />
            </label>
            <label>
              Mass (t)
              <input type="number" min="0" step="0.001" bind:value={customMass} />
            </label>
            <label>
              Cost (C)
              <input type="number" min="0" step="1" bind:value={customCost} />
            </label>
            <label>
              Slots
              <input type="number" min="0" step="1" bind:value={customSlots} />
            </label>
            <button class="button secondary" type="button" on:click={addCustomComponent}>
              Add custom part
            </button>
          </div>
        </details>

        <div class="component-list">
          {#each design.components as installed (installed.id)}
            <div class="component-row">
              <div>
                <strong>{componentName(installed.componentId)}</strong>
                <span class="muted">
                  {componentValueLabel(catalogMap.get(installed.componentId)?.mass, " t")} each ·
                  {typeof catalogMap.get(installed.componentId)?.cost === "number"
                    ? formatMoney(catalogMap.get(installed.componentId)!.cost as number)
                    : "formula cost"}
                </span>
              </div>

              <label class="qty">
                Qty
                <input
                  type="number"
                  min="0.01"
                  step="1"
                  value={installed.quantity}
                  on:change={(e) =>
                    changeQuantity(
                      installed.id,
                      Number(e.currentTarget.value)
                    )}
                />
              </label>

              {#if placementOptions.length && (!mech || componentUsesSlots(catalogMap.get(installed.componentId)))}
                <label class="location-select">
                  {structureDesign ? "Hex" : "Location / arc"}
                  <select
                    value={installed.placement?.location ?? ""}
                    on:change={(e) => changePlacement(installed.id, e.currentTarget.value)}
                  >
                    <option value="">Unallocated</option>
                    {#each placementOptions as location}
                      <option value={location.id}>{location.label}</option>
                    {/each}
                  </select>
                </label>

                {#if structureDesign && installed.placement?.location}
                  <label class="qty">
                    Level
                    <input
                      type="number"
                      min="1"
                      max={structureHexLevels(installed.placement.location)}
                      step="1"
                      value={installed.placement?.level ?? 1}
                      on:change={(e) =>
                        changePlacementLevel(
                          installed.id,
                          Number(e.currentTarget.value)
                        )}
                    />
                  </label>
                {/if}

                {#if mech && installed.placement?.location && componentUsesSlots(catalogMap.get(installed.componentId))}
                  <label class="location-select">
                    Critical slots
                    <input
                      value={criticalSlotList(installed.placement?.criticalSlots)}
                      placeholder="e.g. 5, 6"
                      on:change={(e) => changeCriticalSlots(installed.id, e.currentTarget.value)}
                    />
                  </label>
                  <label class="location-select">
                    Split location
                    <select
                      value={installed.placement?.splitLocation ?? ""}
                      on:change={(e) => changeSplitLocation(installed.id, e.currentTarget.value)}
                    >
                      <option value="">No split</option>
                      {#each placementOptions as location}
                        <option value={location.id}>{location.label}</option>
                      {/each}
                    </select>
                  </label>
                  {#if installed.placement?.splitLocation}
                    <label class="location-select">
                      Split critical slots
                      <input
                        value={criticalSlotList(installed.placement?.splitCriticalSlots)}
                        placeholder="e.g. 1, 2"
                        on:change={(e) => changeCriticalSlots(installed.id, e.currentTarget.value, true)}
                      />
                    </label>
                  {/if}
                {/if}
              {/if}

              <button class="text-button danger" on:click={() => removeComponent(installed.id)}>
                Remove
              </button>
            </div>
          {:else}
            <p class="empty">No payload/components installed.</p>
          {/each}
        </div>
      </div>
    </section>

    <section class="record-sheet {recordLayout.cssClass}" data-record-family={recordLayout.family}>
      <div class="record-head">
        <div>
          <div class="eyebrow">{activeConstructor.name}</div>
          <h2>{design.identity.name || "Untitled"}</h2>
          {#if design.identity.model}
            <p class="model">{design.identity.model}</p>
          {/if}
          {#if design.identity.description}
            <p class="record-description">{design.identity.description}</p>
          {/if}
        </div>

        {#if design.image}
          <img class="record-image" src={design.image.dataUrl} alt="Design reference" />
        {/if}
      </div>

      <div class="family-record-banner">
        <strong>{recordLayout.title}</strong>
        <span>{recordLayout.subtitle}</span>
      </div>

      <div class="summary-grid">
        <div>
          <span>Year</span>
          <strong>{design.rules.year ?? "—"}</strong>
        </div>
        <div>
          <span>Tech base</span>
          <strong>{design.rules.techBase.replace("_", " ")}</strong>
        </div>
        {#if structureDesign}
          <div>
            <span>Footprint</span>
            <strong>{result.derived?.occupiedHexes ?? 0} hexes</strong>
          </div>
          <div>
            <span>Height</span>
            <strong>{result.derived?.maxLevels ?? 0} max levels</strong>
          </div>
        {:else}
          <div>
            <span>Mass</span>
            <strong>{result.mass.used.toFixed(2)} / {design.chassis.massLimit.toFixed(2)} t</strong>
          </div>
          <div>
            <span>C-bill cost</span>
            <strong>{formatMoney(result.cost.total)}</strong>
          </div>
        {/if}
      </div>

      <div class="status-line">
        <span class:ok={errorCount === 0} class:error={errorCount > 0}>
          {errorCount === 0 ? "Construction: passes implemented checks" : `${errorCount} construction error(s)`}
        </span>
        <span class:ok={warningCount === 0} class:warn={warningCount > 0}>
          {warningCount === 0 ? "Legality: no warnings" : `${warningCount} legality warning(s)`}
        </span>
      </div>

      {#if recordSummaryKeys.length}
        <section class="record-section family-summary">
          <h3>{recordLayout.family} record summary</h3>
          <div class="derived-grid">
            {#each recordSummaryKeys as key}
              {#if result.derived && result.derived[key] !== undefined}
                <div>
                  <span>{prettyKey(key)}</span>
                  <strong>{result.derived[key]}</strong>
                </div>
              {/if}
            {/each}
          </div>
        </section>
      {/if}

      {#if genericSchema}
        <section class="record-section">
          <h3>Constructor record</h3>
          <table>
            <tbody>
              {#each genericSchema.sections as section}
                {#each section.fields as field}
                  <tr>
                    <td>{field.label}</td>
                    <td>
                      {#if field.kind === "boolean"}
                        {Boolean(genericValue(field.key)) ? "Yes" : "No"}
                      {:else}
                        {String(genericValue(field.key) ?? field.defaultValue)}
                        {field.unit ?? ""}
                      {/if}
                    </td>
                  </tr>
                {/each}
              {/each}
            </tbody>
          </table>
        </section>
      {/if}

      {#if result.derived}
        <section class="record-section">
          <h3>Derived construction values</h3>
          <div class="derived-grid">
            {#each Object.entries(result.derived) as [key, value]}
              <div>
                <span>{prettyKey(key)}</span>
                <strong>{value}</strong>
              </div>
            {/each}
          </div>
        </section>
      {/if}

      {#if mech}
        <section class="record-section">
          <h3>Armor allocation</h3>
          <table>
            <thead>
              <tr>
                <th>Location</th>
                <th>Front / Main</th>
                <th>Rear</th>
              </tr>
            </thead>
            <tbody>
              <tr><td>Head</td><td>{mech.armorHead}</td><td>—</td></tr>
              <tr><td>Center Torso</td><td>{mech.armorCTFront}</td><td>{mech.armorCTRear}</td></tr>
              <tr><td>Left Torso</td><td>{mech.armorLTFront}</td><td>{mech.armorLTRear}</td></tr>
              <tr><td>Right Torso</td><td>{mech.armorRTFront}</td><td>{mech.armorRTRear}</td></tr>
              <tr><td>Left Arm</td><td>{mech.armorLA}</td><td>—</td></tr>
              <tr><td>Right Arm</td><td>{mech.armorRA}</td><td>—</td></tr>
              <tr><td>Left Leg</td><td>{mech.armorLL}</td><td>—</td></tr>
              <tr><td>Right Leg</td><td>{mech.armorRL}</td><td>—</td></tr>
            </tbody>
          </table>
        </section>
      {/if}


      {#if structureDesign && design.footprint}
        <section class="record-section">
          <h3>Structure footprint</h3>
          <p class="muted footprint-summary">
            One footprint grid is edited in the construction panel. Per-hex
            height, CF and armor are summarized here.
          </p>

          <table>
            <thead>
              <tr>
                <th>Hex</th>
                <th>Levels</th>
                <th>CF</th>
                <th>Armor</th>
                {#if isCastleBrian}<th>Open levels</th>{/if}
              </tr>
            </thead>
            <tbody>
              {#each [...design.footprint.cells].sort((a, b) => a.r - b.r || a.q - b.q) as cell}
                <tr>
                  <td>{cell.q}, {cell.r}</td>
                  <td>{cell.levels}</td>
                  <td>{cell.constructionFactor}</td>
                  <td>{cell.armor}</td>
                  {#if isCastleBrian}
                    <td>{cell.openLevels?.length ? cell.openLevels.join(", ") : "—"}</td>
                  {/if}
                </tr>
              {/each}
            </tbody>
          </table>
        </section>
      {/if}

      {#if isCastleBrian && design.embeddedStructures?.length}
        <section class="record-section">
          <h3>Castle Brian interior structures</h3>
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Type</th>
                <th>Anchor</th>
                <th>Base level</th>
                <th>Footprint</th>
              </tr>
            </thead>
            <tbody>
              {#each design.embeddedStructures as embedded}
                <tr>
                  <td>{embedded.name}</td>
                  <td>
                    {embedded.buildingClassification.replaceAll("_", " ")}
                    / {embedded.constructionType}
                  </td>
                  <td>{embedded.originQ}, {embedded.originR}</td>
                  <td>{embedded.baseLevel}</td>
                  <td>
                    {embedded.footprint.cells.length} hex{embedded.footprint.cells.length === 1 ? "" : "es"}
                  </td>
                </tr>
              {/each}
            </tbody>
          </table>
        </section>
      {/if}

      {#if design.components.length}
        <section class="record-section">
          <h3>Installed components</h3>
          <table>
            <thead>
              <tr>
                <th>Component</th>
                <th>Qty</th>
                <th>Location</th>
                <th>Level</th>
                {#if mech}<th>Criticals</th>{/if}
              </tr>
            </thead>
            <tbody>
              {#each design.components as installed}
                <tr>
                  <td>{componentName(installed.componentId)}</td>
                  <td>{installed.quantity}</td>
                  <td>{installed.placement?.location ?? "—"}</td>
                  <td>{installed.placement?.level ?? "—"}</td>
                  {#if mech}
                    <td>
                      {criticalSlotList(installed.placement?.criticalSlots)}
                      {#if installed.placement?.splitLocation}
                        / {installed.placement.splitLocation}: {criticalSlotList(installed.placement?.splitCriticalSlots)}
                      {/if}
                    </td>
                  {/if}
                </tr>
              {/each}
            </tbody>
          </table>
        </section>
      {/if}

      {#if result.validation.length}
        <section class="record-section">
          <h3>Validation & legality</h3>
          <div class="issues">
            {#each result.validation as issue}
              <div class="issue {issue.severity}">
                <strong>{issue.code.replaceAll("_", " ")}</strong>
                <span>{issue.message}</span>
              </div>
            {/each}
          </div>
        </section>
      {/if}

      <section class="record-section">
        <h3>Mass ledger</h3>
        <table>
          <thead>
            <tr>
              <th>Item</th>
              <th>Qty</th>
              <th>Each</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            {#each result.mass.entries as entry}
              <tr>
                <td>{entry.label}</td>
                <td>{entry.quantity}</td>
                <td>{entry.unitValue.toFixed(2)} t</td>
                <td>{entry.totalValue.toFixed(2)} t</td>
              </tr>
            {/each}
          </tbody>
          <tfoot>
            <tr>
              <th colspan="3">Used</th>
              <th>{result.mass.used.toFixed(2)} t</th>
            </tr>
            <tr>
              <th colspan="3">Remaining</th>
              <th>{(result.mass.remaining ?? 0).toFixed(2)} t</th>
            </tr>
          </tfoot>
        </table>
      </section>

      <section class="record-section">
        <h3>C-bill cost ledger</h3>
        <table>
          <thead>
            <tr>
              <th>Item</th>
              <th>Qty</th>
              <th>Each</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            {#each result.cost.entries as entry}
              <tr>
                <td>{entry.label}</td>
                <td>{entry.quantity}</td>
                <td>{formatMoney(entry.unitValue)}</td>
                <td>{formatMoney(entry.totalValue)}</td>
              </tr>
            {:else}
              <tr>
                <td colspan="4" class="muted">No priced components yet.</td>
              </tr>
            {/each}
          </tbody>
          <tfoot>
            <tr>
              <th colspan="3">Subtotal</th>
              <th>{formatMoney(result.cost.subtotal)}</th>
            </tr>
            {#each result.cost.modifiers as modifier}
              <tr>
                <th colspan="3">{modifier.label}</th>
                <th>× {modifier.multiplier.toFixed(3)}</th>
              </tr>
            {/each}
            <tr>
              <th colspan="3">Dry cost</th>
              <th>{formatMoney(result.cost.dryTotal)}</th>
            </tr>
            <tr>
              <th colspan="3">Total</th>
              <th>{formatMoney(result.cost.total)}</th>
            </tr>
          </tfoot>
        </table>
      </section>

      {#if result.locations && result.locations.length}
        <section class="record-section">
          <h3>Location critical capacity</h3>
          <table>
            <thead>
              <tr>
                <th>Location</th>
                <th>Fixed</th>
                <th>Equipment</th>
                <th>Used</th>
                <th>Free</th>
              </tr>
            </thead>
            <tbody>
              {#each result.locations as location}
                <tr>
                  <td>{location.label}</td>
                  <td>{location.reserved}</td>
                  <td>{location.equipmentUsed}</td>
                  <td>{location.used} / {location.capacity}</td>
                  <td>{location.remaining}</td>
                </tr>
              {/each}
            </tbody>
          </table>
        </section>
      {/if}

      {#if result.slots && result.slots.entries.length}
        <section class="record-section">
          <h3>Critical / slot ledger</h3>
          <table>
            <thead>
              <tr>
                <th>Reservation</th>
                <th>Slots</th>
              </tr>
            </thead>
            <tbody>
              {#each result.slots.entries as entry}
                <tr>
                  <td>{entry.label}</td>
                  <td>{entry.totalValue}</td>
                </tr>
              {/each}
            </tbody>
            <tfoot>
              <tr>
                <th>Tracked slots used</th>
                <th>{result.slots.used}</th>
              </tr>
            </tfoot>
          </table>
        </section>
      {/if}

      {#if design.notes}
        <section class="record-section">
          <h3>Design notes</h3>
          <p class="design-notes">{design.notes}</p>
        </section>
      {/if}

      <p class="record-note">
        Construction is intentionally permissive: era and tech-base conflicts are annotations,
        and validation errors do not prevent saving or printing.
      </p>
    </section>
  </main>
</div>
