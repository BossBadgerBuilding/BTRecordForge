import { calculateCommon } from "../core/calculation";
import {
  buildDesignValueContext,
  evaluateConstructionValue
} from "../core/valueExpression";
import type {
  ComponentDefinition,
  ConstructionResult,
  Design,
  HexFootprint,
  HexFootprintCell,
  LedgerEntry,
  ValidationIssue
} from "../core/types";

export type StructureKind = "BUILDING" | "MOBILE_STRUCTURE";
export type StructureClass = "LIGHT" | "MEDIUM" | "HEAVY" | "HARDENED" | "RAIL";
export type MobileStructureType = "BUILDING" | "HANGAR" | "FORTRESS";
export type MobileMotiveType =
  | "GROUND"
  | "AIR"
  | "NAVAL_SURFACE"
  | "NAVAL_SUBMERSIBLE";
export type MobilePowerSystem =
  | "STEAM"
  | "ICE"
  | "FUEL_CELL"
  | "FISSION"
  | "FUSION";
export type BuildingClassification =
  | "TENT"
  | "HANGAR"
  | "STANDARD"
  | "FENCE"
  | "WALL"
  | "BRIDGE"
  | "GUN_EMPLACEMENT"
  | "FORTRESS"
  | "CASTLE_BRIAN";

export interface StructureProperties {
  structureKind: StructureKind;
  constructionType: StructureClass;
  buildingClassification: BuildingClassification;
  mobileStructureType: MobileStructureType;
  motiveType: MobileMotiveType;
  powerSystem: MobilePowerSystem;
  cruiseMP: number;
  desiredRangeKm: number;
  motiveMass: number;
  motiveCost: number;
  baseStructureCost: number;
  environmentalSealing: boolean;
  heavyMetalSuperstructure: boolean;
  highLowCeilings: boolean;
  openSpaceConstruction: boolean;
  subsurfaceConstruction: boolean;
  tunnelConstruction: boolean;
  fuelStorageTons: number;
  largeDoorLevels: number;
  industrialElevatorTons: number;
  unspecifiedEquipmentHexes: number;
  automatedWeaponTons: number;
  mobileLinkages: number;
  turretCount: number;
  turretPayloadTons: number;
  pintlePayloadTons: number;
}

interface StructureBand {
  minCF: number;
  maxCF: number;
  maxHexes?: number;
  maxLevels?: number;
  minLevels?: number;
}

export const MOBILE_STRUCTURE_BANDS: Record<
  MobileStructureType,
  Partial<Record<StructureClass, StructureBand>>
> = {
  BUILDING: {
    LIGHT: { minCF: 1, maxCF: 15, maxHexes: 6, maxLevels: 5 },
    MEDIUM: { minCF: 16, maxCF: 40, maxHexes: 8, maxLevels: 8 },
    HEAVY: { minCF: 41, maxCF: 90, maxHexes: 10, maxLevels: 10 }
  },
  HANGAR: {
    LIGHT: { minCF: 1, maxCF: 8, maxHexes: 10, maxLevels: 7 },
    MEDIUM: { minCF: 9, maxCF: 20, maxHexes: 14, maxLevels: 10 },
    HEAVY: { minCF: 21, maxCF: 45, maxHexes: 18, maxLevels: 13 },
    HARDENED: { minCF: 46, maxCF: 75, maxHexes: 20, maxLevels: 14 }
  },
  FORTRESS: {
    MEDIUM: { minCF: 16, maxCF: 40, maxHexes: 12, maxLevels: 15 },
    HEAVY: { minCF: 41, maxCF: 90, maxHexes: 15, maxLevels: 20 },
    HARDENED: { minCF: 91, maxCF: 150, maxHexes: 20, maxLevels: 30 }
  }
};

/**
 * Tactical Operations: Advanced Rules, Building Classification and Type table.
 * For classes whose official table has no meaningful hex-length limit (walls,
 * fences and bridges), maxHexes is omitted.
 */
export const STATIC_BUILDING_BANDS: Record<
  BuildingClassification,
  Partial<Record<StructureClass, StructureBand>>
> = {
  TENT: {
    LIGHT: { minCF: 1, maxCF: 2, maxHexes: 1, maxLevels: 1 }
  },
  HANGAR: {
    LIGHT: { minCF: 1, maxCF: 8, maxHexes: 10, maxLevels: 7 },
    MEDIUM: { minCF: 9, maxCF: 16, maxHexes: 14, maxLevels: 10 },
    HEAVY: { minCF: 17, maxCF: 45, maxHexes: 18, maxLevels: 13 },
    HARDENED: { minCF: 46, maxCF: 75, maxHexes: 20, maxLevels: 14 }
  },
  STANDARD: {
    LIGHT: { minCF: 1, maxCF: 15, maxHexes: 6, maxLevels: 5 },
    MEDIUM: { minCF: 16, maxCF: 40, maxHexes: 8, maxLevels: 8 },
    HEAVY: { minCF: 41, maxCF: 90, maxHexes: 10, maxLevels: 10 }
  },
  FENCE: {
    LIGHT: { minCF: 1, maxCF: 1, maxLevels: 3 }
  },
  WALL: {
    LIGHT: { minCF: 1, maxCF: 15, maxLevels: 4 },
    MEDIUM: { minCF: 16, maxCF: 40, maxLevels: 6 },
    HEAVY: { minCF: 41, maxCF: 90, maxLevels: 8 },
    HARDENED: { minCF: 91, maxCF: 150, maxLevels: 10 }
  },
  BRIDGE: {
    LIGHT: { minCF: 1, maxCF: 15, maxLevels: 1 },
    MEDIUM: { minCF: 16, maxCF: 40, maxLevels: 1 },
    HEAVY: { minCF: 41, maxCF: 90, maxLevels: 1 },
    HARDENED: { minCF: 91, maxCF: 150, maxLevels: 1 },
    RAIL: { minCF: 151, maxCF: 650, maxLevels: 1 }
  },
  GUN_EMPLACEMENT: {
    LIGHT: { minCF: 1, maxCF: 15, maxHexes: 1, maxLevels: 1 },
    MEDIUM: { minCF: 16, maxCF: 40, maxHexes: 1, maxLevels: 1 },
    HEAVY: { minCF: 41, maxCF: 90, maxHexes: 1, maxLevels: 1 },
    HARDENED: { minCF: 91, maxCF: 150, maxHexes: 1, maxLevels: 1 }
  },
  FORTRESS: {
    MEDIUM: { minCF: 16, maxCF: 40, maxHexes: 12, maxLevels: 15 },
    HEAVY: { minCF: 41, maxCF: 90, maxHexes: 15, maxLevels: 20 },
    HARDENED: { minCF: 91, maxCF: 150, maxHexes: 20, maxLevels: 30 }
  },
  CASTLE_BRIAN: {
    HEAVY: { minCF: 35, maxCF: 90, maxHexes: 35, maxLevels: 10 },
    HARDENED: { minCF: 91, maxCF: 150, maxHexes: 70, maxLevels: 15 }
  }
};

export const MOBILE_MOTIVE_DATA: Record<
  MobileMotiveType,
  { maxMP: number; innerSphere: number; clan: number }
> = {
  GROUND: { maxMP: 2, innerSphere: 4.0, clan: 3.5 },
  AIR: { maxMP: 4, innerSphere: 5.0, clan: 4.0 },
  NAVAL_SURFACE: { maxMP: 3, innerSphere: 2.0, clan: 1.8 },
  NAVAL_SUBMERSIBLE: { maxMP: 4, innerSphere: 3.5, clan: 3.5 }
};

export const MOBILE_POWER_DATA: Record<
  MobilePowerSystem,
  {
    fuelPercentPer100Km: number;
    innerSphere: Record<MobileMotiveType, number>;
    clan: Record<MobileMotiveType, number>;
  }
> = {
  STEAM: {
    fuelPercentPer100Km: 4,
    innerSphere: {
      GROUND: 6,
      AIR: 6,
      NAVAL_SURFACE: 6,
      NAVAL_SUBMERSIBLE: 7
    },
    clan: {
      GROUND: 7,
      AIR: 7,
      NAVAL_SURFACE: 7,
      NAVAL_SUBMERSIBLE: 8
    }
  },
  ICE: {
    fuelPercentPer100Km: 2,
    innerSphere: {
      GROUND: 3,
      AIR: 3,
      NAVAL_SURFACE: 3,
      NAVAL_SUBMERSIBLE: 3.2
    },
    clan: {
      GROUND: 3,
      AIR: 3,
      NAVAL_SURFACE: 3,
      NAVAL_SUBMERSIBLE: 3
    }
  },
  FUEL_CELL: {
    fuelPercentPer100Km: 2,
    innerSphere: {
      GROUND: 4,
      AIR: 4.4,
      NAVAL_SURFACE: 4,
      NAVAL_SUBMERSIBLE: 5
    },
    clan: {
      GROUND: 4,
      AIR: 4.2,
      NAVAL_SURFACE: 4,
      NAVAL_SUBMERSIBLE: 4.4
    }
  },
  FISSION: {
    fuelPercentPer100Km: 0,
    innerSphere: {
      GROUND: 3,
      AIR: 3,
      NAVAL_SURFACE: 3,
      NAVAL_SUBMERSIBLE: 3
    },
    clan: {
      GROUND: 4,
      AIR: 4,
      NAVAL_SURFACE: 4,
      NAVAL_SUBMERSIBLE: 4
    }
  },
  FUSION: {
    fuelPercentPer100Km: 0,
    innerSphere: {
      GROUND: 2,
      AIR: 2,
      NAVAL_SURFACE: 2,
      NAVAL_SUBMERSIBLE: 2.2
    },
    clan: {
      GROUND: 1.8,
      AIR: 1.8,
      NAVAL_SURFACE: 1.8,
      NAVAL_SUBMERSIBLE: 2
    }
  }
};

const MOBILE_STRUCTURE_TYPE_MULTIPLIER: Record<MobileStructureType, number> = {
  HANGAR: 0.3,
  BUILDING: 0.5,
  FORTRESS: 1
};

const MOBILE_BASE_CREW: Record<
  MobileStructureType,
  Record<MobileMotiveType, number | null>
> = {
  HANGAR: {
    GROUND: 2,
    AIR: 3,
    NAVAL_SURFACE: 2,
    NAVAL_SUBMERSIBLE: 3
  },
  BUILDING: {
    GROUND: 3,
    AIR: 4,
    NAVAL_SURFACE: 3,
    NAVAL_SUBMERSIBLE: 4
  },
  FORTRESS: {
    GROUND: 4,
    AIR: null,
    NAVAL_SURFACE: 5,
    NAVAL_SUBMERSIBLE: 6
  }
};


export function defaultFootprint(): HexFootprint {
  return {
    kind: "hex-footprint",
    cells: [
      {
        q: 0,
        r: 0,
        levels: 1,
        constructionFactor: 10,
        armor: 0
      }
    ]
  };
}


export function getStructureProperties(design: Design): StructureProperties {
  const p = design.chassis.properties;
  const kind: StructureKind =
    p.structureKind === "MOBILE_STRUCTURE"
      ? "MOBILE_STRUCTURE"
      : "BUILDING";
  const buildingClassification = enumOr(
    p.buildingClassification,
    [
      "TENT",
      "HANGAR",
      "STANDARD",
      "FENCE",
      "WALL",
      "BRIDGE",
      "GUN_EMPLACEMENT",
      "FORTRESS",
      "CASTLE_BRIAN"
    ] as const,
    "STANDARD"
  );

  return {
    structureKind: kind,
    constructionType: enumOr(
      p.constructionType,
      ["LIGHT", "MEDIUM", "HEAVY", "HARDENED", "RAIL"] as const,
      "LIGHT"
    ),
    buildingClassification,
    mobileStructureType: enumOr(
      p.mobileStructureType,
      ["BUILDING", "HANGAR", "FORTRESS"] as const,
      "BUILDING"
    ),
    motiveType: enumOr(
      p.motiveType,
      ["GROUND", "AIR", "NAVAL_SURFACE", "NAVAL_SUBMERSIBLE"] as const,
      "GROUND"
    ),
    powerSystem: enumOr(
      p.powerSystem,
      ["STEAM", "ICE", "FUEL_CELL", "FISSION", "FUSION"] as const,
      "ICE"
    ),
    cruiseMP: numberOr(p.cruiseMP, kind === "MOBILE_STRUCTURE" ? 1 : 0),
    desiredRangeKm: numberOr(p.desiredRangeKm, 0),
    motiveMass: numberOr(p.motiveMass, 0),
    motiveCost: numberOr(p.motiveCost, 0),
    baseStructureCost: numberOr(p.baseStructureCost, 0),
    environmentalSealing: booleanOr(p.environmentalSealing, false),
    heavyMetalSuperstructure: booleanOr(p.heavyMetalSuperstructure, false),
    highLowCeilings: booleanOr(p.highLowCeilings, false),
    openSpaceConstruction:
      kind === "BUILDING" &&
      buildingClassification === "CASTLE_BRIAN" &&
      booleanOr(p.openSpaceConstruction, false),
    subsurfaceConstruction: booleanOr(p.subsurfaceConstruction, false),
    tunnelConstruction: booleanOr(p.tunnelConstruction, false),
    fuelStorageTons: Math.max(0, numberOr(p.fuelStorageTons, 0)),
    largeDoorLevels: Math.max(0, numberOr(p.largeDoorLevels, 0)),
    industrialElevatorTons: Math.max(0, numberOr(p.industrialElevatorTons, 0)),
    unspecifiedEquipmentHexes: Math.max(0, numberOr(p.unspecifiedEquipmentHexes, 0)),
    automatedWeaponTons: Math.max(0, numberOr(p.automatedWeaponTons, 0)),
    mobileLinkages: Math.max(0, Math.floor(numberOr(p.mobileLinkages, 0))),
    turretCount: Math.max(0, Math.floor(numberOr(p.turretCount, 0))),
    turretPayloadTons: Math.max(0, numberOr(p.turretPayloadTons, 0)),
    pintlePayloadTons: Math.max(0, numberOr(p.pintlePayloadTons, 0))
  };
}

export function calculateStructureDesign(
  design: Design,
  catalog: Map<string, ComponentDefinition>
): ConstructionResult {
  const footprint = design.footprint ?? {
    kind: "hex-footprint" as const,
    cells: []
  };
  const properties = getStructureProperties(design);

  const validation = validateFootprint(footprint);
  validation.push(...validateStructureComponentPlacement(design, footprint));
  validation.push(...validateCastleBrianOpenSpace(design, footprint, properties));

  const openSpaceLevelHexes = footprint.cells.reduce(
    (sum, cell) =>
      sum +
      new Set(
        (cell.openLevels ?? []).filter(
          (level) =>
            Number.isInteger(level) &&
            level >= 1 &&
            level <= safeWhole(cell.levels)
        )
      ).size,
    0
  );
  const hasOpenSpaceConstruction =
    properties.structureKind === "BUILDING" &&
    properties.buildingClassification === "CASTLE_BRIAN" &&
    (properties.openSpaceConstruction || openSpaceLevelHexes > 0);
  const interiorStructureCount = design.embeddedStructures?.length ?? 0;

  const occupiedHexes = footprint.cells.length;
  const totalLevelHexes = footprint.cells.reduce(
    (sum, cell) => sum + safeWhole(cell.levels),
    0
  );
  const maxLevels = footprint.cells.reduce(
    (maximum, cell) => Math.max(maximum, safeWhole(cell.levels)),
    0
  );
  const totalConstructionFactor = footprint.cells.reduce(
    (sum, cell) => sum + safeNonNegative(cell.constructionFactor),
    0
  );
  const totalArmor = footprint.cells.reduce(
    (sum, cell) => sum + safeNonNegative(cell.armor),
    0
  );
  const representativeCF = footprint.cells.reduce(
    (max, cell) => Math.max(max, safeNonNegative(cell.constructionFactor)),
    0
  );
  const environmentalSealingMass =
    properties.environmentalSealing &&
    properties.structureKind === "MOBILE_STRUCTURE"
      ? footprint.cells.reduce(
          (sum, cell) =>
            sum +
            Math.ceil(
              safeNonNegative(cell.constructionFactor) *
                0.1 *
                safeWhole(cell.levels)
            ),
          0
        )
      : 0;
  const linkageMass =
    properties.structureKind === "MOBILE_STRUCTURE"
      ? properties.mobileLinkages *
        Math.ceil(representativeCF * 0.5)
      : 0;
  const turretMechanismMass =
    properties.structureKind === "MOBILE_STRUCTURE"
      ? ceilHalf(properties.turretPayloadTons * 0.10)
      : 0;
  const pintleMechanismMass =
    properties.structureKind === "MOBILE_STRUCTURE"
      ? ceilKg(properties.pintlePayloadTons * 0.05)
      : 0;
  const specialEnhancementMass =
    environmentalSealingMass +
    linkageMass +
    turretMechanismMass +
    pintleMechanismMass;

  const techSide =
    design.rules.techBase === "CLAN" ? "clan" : "innerSphere";
  const armorPointsPerTon =
    design.rules.techBase === "CLAN" ? 20 : 16;

  const componentMassByHex = structureComponentMassByHex(
    design,
    catalog
  );

  let powerSystemWeight = 0;
  let motiveSystemWeight = 0;
  let fuelWeight = 0;
  let distributedPowerPerHex = 0;
  let distributedMotivePerHex = 0;
  let minimumCrew = 0;
  let maxMP = 0;

  if (properties.structureKind === "MOBILE_STRUCTURE") {
    const band =
      MOBILE_STRUCTURE_BANDS[properties.mobileStructureType][
        properties.constructionType
      ];
    validateBand(
      footprint,
      band,
      properties.constructionType,
      properties.mobileStructureType,
      validation
    );

    const motiveData = MOBILE_MOTIVE_DATA[properties.motiveType];
    maxMP = motiveData.maxMP;

    if (
      properties.mobileStructureType === "FORTRESS" &&
      properties.motiveType === "AIR"
    ) {
      validation.push({
        code: "MOVEMENT_INVALID",
        severity: "error",
        field: "chassis.properties.motiveType",
        message:
          "Fortress-type Mobile Structures may use Ground or Naval motive systems, but not Air."
      });
    }

    if (
      properties.cruiseMP < 0 ||
      properties.cruiseMP > maxMP ||
      !isQuarterPoint(properties.cruiseMP)
    ) {
      validation.push({
        code: "MOVEMENT_INVALID",
        severity: "error",
        field: "chassis.properties.cruiseMP",
        message:
          `${prettyMotive(properties.motiveType)} Mobile Structures may purchase up to ${maxMP} MP in quarter-point increments.`
      });
    }

    const powerData = MOBILE_POWER_DATA[properties.powerSystem];
    const powerMultiplier =
      powerData[techSide][properties.motiveType];
    const motiveMultiplier =
      motiveData[techSide];

    powerSystemWeight = ceilTon(
      totalLevelHexes *
      Math.max(0, properties.cruiseMP) *
      powerMultiplier
    );
    motiveSystemWeight = ceilTon(
      totalLevelHexes *
      motiveMultiplier *
      MOBILE_STRUCTURE_TYPE_MULTIPLIER[properties.mobileStructureType]
    );
    fuelWeight = ceilTon(
      (Math.max(0, properties.desiredRangeKm) / 100) *
      (powerData.fuelPercentPer100Km / 100) *
      powerSystemWeight
    );

    if (occupiedHexes > 0) {
      distributedPowerPerHex = ceilHalf(
        powerSystemWeight / occupiedHexes
      );
      distributedMotivePerHex = ceilHalf(
        motiveSystemWeight / occupiedHexes
      );
    }

    const baseCrew =
      MOBILE_BASE_CREW[properties.mobileStructureType][
        properties.motiveType
      ];
    if (baseCrew === null) {
      minimumCrew = 0;
    } else {
      const nonOfficerCrew = baseCrew * occupiedHexes;
      const enhancementCrew = properties.mobileLinkages * 8;
      const crewBeforeOfficers = nonOfficerCrew + enhancementCrew;
      const enhancedOfficers =
        crewBeforeOfficers <= 9
          ? occupiedHexes > 0 ? 1 : 0
          : Math.ceil(crewBeforeOfficers / 10);
      minimumCrew = crewBeforeOfficers + enhancedOfficers;
    }

    if (properties.turretCount > occupiedHexes) {
      validation.push({
        code: "LOCATION_OVER_CAPACITY",
        severity: "error",
        field: "chassis.properties.turretCount",
        message: `Mobile Structures may mount at most one turret per occupied hex (${occupiedHexes} for this design).`
      });
    }
    if (
      properties.mobileStructureType !== "FORTRESS" &&
      properties.turretPayloadTons >= 0.5
    ) {
      validation.push({
        code: "VALUE_INVALID",
        severity: "error",
        field: "chassis.properties.turretPayloadTons",
        message: "Building- and Hangar-type Mobile Structures may not mount Heavy weapons; Fortress construction is required."
      });
    }

    const armorValues = new Set(
      footprint.cells.map((cell) => safeWhole(cell.armor))
    );
    if (armorValues.size > 1) {
      validation.push({
        code: "VALUE_INVALID",
        severity: "error",
        field: "footprint.armor",
        message:
          "Mobile Structure armor must be assigned uniformly to every occupied hex."
      });
    }

    if (
      properties.mobileStructureType !== "FORTRESS" &&
      totalArmor > 0
    ) {
      validation.push({
        code: "ARMOR_OVER_LIMIT",
        severity: "error",
        field: "footprint.armor",
        message:
          "Only Fortress-type Mobile Structures may install armor."
      });
    }

    for (const cell of footprint.cells) {
      if (
        properties.mobileStructureType === "FORTRESS" &&
        cell.armor > cell.constructionFactor
      ) {
        validation.push({
          code: "ARMOR_OVER_LIMIT",
          severity: "error",
          field: `footprint.${hexKey(cell.q, cell.r)}.armor`,
          message:
            `Fortress Mobile Structure hex ${hexKey(cell.q, cell.r)} may not carry more armor points than its CF (${cell.constructionFactor}).`
        });
      }
    }
  } else {
    const band =
      STATIC_BUILDING_BANDS[properties.buildingClassification][
        properties.constructionType
      ];
    validateBand(
      footprint,
      band,
      properties.constructionType,
      properties.buildingClassification,
      validation
    );


    const canArmor = staticBuildingCanArmor(
      properties.buildingClassification
    );
    if (!canArmor && totalArmor > 0) {
      validation.push({
        code: "ARMOR_OVER_LIMIT",
        severity: "error",
        field: "footprint.armor",
        message:
          `${prettyBuilding(properties.buildingClassification)} buildings may not install armor under the advanced building rules.`
      });
    }

    const armorValues = new Set(
      footprint.cells.map((cell) => safeWhole(cell.armor))
    );
    if (totalArmor > 0 && armorValues.size > 1) {
      validation.push({
        code: "VALUE_INVALID",
        severity: "error",
        field: "footprint.armor",
        message:
          "Advanced building armor must be installed uniformly on every occupied hex."
      });
    }

    for (const cell of footprint.cells) {
      const maxArmor = staticBuildingMaxArmor(
        properties.buildingClassification,
        cell.constructionFactor
      );
      if (cell.armor > maxArmor) {
        validation.push({
          code: "ARMOR_OVER_LIMIT",
          severity: "error",
          field: `footprint.${hexKey(cell.q, cell.r)}.armor`,
          message:
            `${prettyBuilding(properties.buildingClassification)} hex ${hexKey(cell.q, cell.r)} has ${cell.armor} armor points; its current maximum is ${maxArmor}.`
        });
      }
    }
  }

  const capacityEntries: Array<{
    key: string;
    capacity: number;
    armorMass: number;
    componentMass: number;
    fixedDistributedMass: number;
    remaining: number;
  }> = [];

  for (const cell of footprint.cells) {
    const key = hexKey(cell.q, cell.r);
    const capacity =
      properties.structureKind === "MOBILE_STRUCTURE"
        ? mobileInternalCapacity(
            properties.mobileStructureType,
            cell.constructionFactor,
            cell.levels
          )
        : staticInternalCapacity(
            properties.buildingClassification,
            cell.constructionFactor,
            properties.buildingClassification === "CASTLE_BRIAN"
              ? Math.max(
                  0,
                  safeWhole(cell.levels) -
                    new Set(
                      (cell.openLevels ?? []).filter(
                        (level) =>
                          Number.isInteger(level) &&
                          level >= 1 &&
                          level <= safeWhole(cell.levels)
                      )
                    ).size
                )
              : cell.levels
          );

    const armorMass =
      cell.armor > 0
        ? Math.ceil(cell.armor / armorPointsPerTon)
        : 0;
    const componentMass = componentMassByHex.get(key) ?? 0;
    const fixedDistributedMass =
      properties.structureKind === "MOBILE_STRUCTURE"
        ? distributedPowerPerHex +
          distributedMotivePerHex +
          (occupiedHexes > 0 ? specialEnhancementMass / occupiedHexes : 0)
        : 0;

    const remaining =
      capacity -
      armorMass -
      componentMass -
      fixedDistributedMass;

    capacityEntries.push({
      key,
      capacity,
      armorMass,
      componentMass,
      fixedDistributedMass,
      remaining
    });

    if (remaining < -1e-9) {
      validation.push({
        code: "MASS_OVER_LIMIT",
        severity: "error",
        field: `footprint.${key}`,
        message:
          `Structure hex ${key} exceeds its internal capacity by ${Math.abs(remaining).toFixed(2)} tons.`
      });
    }
  }

  const totalInternalCapacity = capacityEntries.reduce(
    (sum, entry) => sum + entry.capacity,
    0
  );
  const totalArmorMass = capacityEntries.reduce(
    (sum, entry) => sum + entry.armorMass,
    0
  );
  const totalPlacedComponentMass = capacityEntries.reduce(
    (sum, entry) => sum + entry.componentMass,
    0
  );

  const totalDistributedSystemMass =
    properties.structureKind === "MOBILE_STRUCTURE"
      ? distributedPowerPerHex * occupiedHexes +
        distributedMotivePerHex * occupiedHexes
      : 0;

  const totalCapacityRemaining =
    totalInternalCapacity -
    totalDistributedSystemMass -
    specialEnhancementMass -
    totalArmorMass -
    totalPlacedComponentMass -
    fuelWeight;

  if (totalCapacityRemaining < -1e-9) {
    validation.push({
      code: "MASS_OVER_LIMIT",
      severity: "error",
      field: "footprint",
      message:
        `The structure exceeds its total internal capacity by ${Math.abs(totalCapacityRemaining).toFixed(2)} tons after power, motive, fuel, armor and placed components.`
    });
  }

  const massEntries: LedgerEntry[] = [
    ...(powerSystemWeight > 0
      ? [
          massLedgerEntry(
            "mobile-power",
            `${prettyPower(properties.powerSystem)} Power System`,
            powerSystemWeight,
            "engine"
          )
        ]
      : []),
    ...(motiveSystemWeight > 0
      ? [
          massLedgerEntry(
            "mobile-motive",
            `${prettyMotive(properties.motiveType)} Motive System`,
            motiveSystemWeight,
            "movement"
          )
        ]
      : []),
    ...(fuelWeight > 0
      ? [
          massLedgerEntry(
            "mobile-fuel",
            `Fuel for ${properties.desiredRangeKm.toLocaleString()} km range`,
            fuelWeight,
            "fuel"
          )
        ]
      : []),
    ...(totalArmorMass > 0
      ? [
          massLedgerEntry(
            "structure-armor",
            "Structure Armor",
            totalArmorMass,
            "armor"
          )
        ]
      : []),
    ...(environmentalSealingMass > 0
      ? [massLedgerEntry(
          "mobile-environmental-sealing",
          "Environmental Sealing",
          environmentalSealingMass,
          "enhancement"
        )]
      : []),
    ...(linkageMass > 0
      ? [massLedgerEntry(
          "mobile-linkage",
          `Mobile Structure Linkage (${properties.mobileLinkages})`,
          linkageMass,
          "enhancement"
        )]
      : []),
    ...(turretMechanismMass > 0
      ? [massLedgerEntry(
          "mobile-turret-mechanism",
          "Turret Mechanism",
          turretMechanismMass,
          "weapon-mount"
        )]
      : []),
    ...(pintleMechanismMass > 0
      ? [massLedgerEntry(
          "mobile-pintle-mechanism",
          "Pintle Mechanism",
          pintleMechanismMass,
          "weapon-mount"
        )]
      : []),
    ...(properties.motiveMass > 0
      ? [
          massLedgerEntry(
            "structure-additional-drive",
            "Additional manual drive / structure allocation",
            properties.motiveMass,
            "movement"
          )
        ]
      : [])
  ];


  const structureModificationMultiplier =
    (properties.environmentalSealing ? 1.5 : 1) *
    (properties.heavyMetalSuperstructure ? 1.25 : 1) *
    (properties.highLowCeilings ? 1.1 : 1) *
    (hasOpenSpaceConstruction ? 2.5 : 1) *
    (properties.subsurfaceConstruction ? 5 : 1) *
    (properties.tunnelConstruction ? 1.875 : 1);

  const automaticShellCost = footprint.cells.reduce(
    (sum, cell) =>
      sum +
      structureCostForCell(
        properties,
        safeWhole(cell.levels),
        safeNonNegative(cell.constructionFactor),
        structureModificationMultiplier
      ),
    0
  );
  const automaticPowerCost =
    properties.structureKind === "MOBILE_STRUCTURE"
      ? powerSystemWeight * structurePowerCostPerTon(properties.powerSystem)
      : 0;
  const automaticMotiveCost =
    properties.structureKind === "MOBILE_STRUCTURE"
      ? footprint.cells.reduce(
          (sum, cell) =>
            sum +
            structureMotiveCostFactor(properties.motiveType) *
              safeNonNegative(cell.constructionFactor) *
              Math.max(0, properties.cruiseMP),
          0
        )
      : 0;
  const automaticArmorCost =
    totalArmorMass *
    (design.rules.techBase === "CLAN" ? 15000 : 10000);
  const miscellaneousEquipmentCost =
    properties.fuelStorageTons * 100 +
    properties.largeDoorLevels * 10000 +
    properties.industrialElevatorTons * 15000 +
    properties.unspecifiedEquipmentHexes * representativeCF * 5000 +
    properties.automatedWeaponTons * 1000;

  const baseConstructionCost =
    automaticShellCost +
    automaticPowerCost +
    automaticMotiveCost +
    automaticArmorCost +
    miscellaneousEquipmentCost;
  const finalStructureCost =
    baseConstructionCost *
    (1 + representativeCF / 100);

  const costEntries: LedgerEntry[] = [
    ...(automaticShellCost > 0
      ? [costLedgerEntry(
          "structure-shell",
          "Structure Shell",
          automaticShellCost,
          "structure"
        )]
      : []),
    ...(automaticPowerCost > 0
      ? [costLedgerEntry(
          "structure-power",
          `${prettyPower(properties.powerSystem)} Engine / Generator`,
          automaticPowerCost,
          "engine"
        )]
      : []),
    ...(automaticMotiveCost > 0
      ? [costLedgerEntry(
          "structure-motive",
          `${prettyMotive(properties.motiveType)} Motive System`,
          automaticMotiveCost,
          "movement"
        )]
      : []),
    ...(automaticArmorCost > 0
      ? [costLedgerEntry(
          "structure-armor-cost",
          "Structure Armor",
          automaticArmorCost,
          "armor"
        )]
      : []),
    ...(miscellaneousEquipmentCost > 0
      ? [costLedgerEntry(
          "structure-special-equipment",
          "Structure Special Equipment",
          miscellaneousEquipmentCost,
          "equipment"
        )]
      : []),
    ...(properties.baseStructureCost > 0
      ? [costLedgerEntry(
          "structure-manual-shell",
          "Additional / manual structure construction cost",
          properties.baseStructureCost,
          "structure"
        )]
      : []),
    ...(properties.structureKind === "MOBILE_STRUCTURE" &&
        properties.motiveCost > 0
      ? [costLedgerEntry(
          "structure-manual-motive",
          "Additional manual drive / motive cost",
          properties.motiveCost,
          "movement"
        )]
      : [])
  ];

  return calculateCommon(design, catalog, {
    validation,
    massEntries,
    costEntries,
    costModifiers: [{ id: "structure-cf", label: `Construction Factor (${(1 + representativeCF / 100).toFixed(2)}×)`, multiplier: 1 + representativeCF / 100 }],
    enforceMassLimit: false,
    derived: {
      occupiedHexes,
      openSpaceLevelHexes,
      interiorStructureCount,
      totalLevelHexes,
      maxLevels,
      totalConstructionFactor,
      totalArmor,
      armorPointsPerTon,
      totalArmorMass,
      totalInternalCapacity,
      totalPlacedComponentMass,
      totalCapacityRemaining,
      footprintConnected:
        footprint.cells.length <= 1 || isConnected(footprint.cells),
      constructionType: properties.constructionType,
      buildingClassification:
        properties.structureKind === "BUILDING"
          ? prettyBuilding(properties.buildingClassification)
          : "",
      mobileStructureType:
        properties.structureKind === "MOBILE_STRUCTURE"
          ? prettyMobileType(properties.mobileStructureType)
          : "",
      motiveType:
        properties.structureKind === "MOBILE_STRUCTURE"
          ? prettyMotive(properties.motiveType)
          : "Static",
      maximumMP: maxMP,
      selectedMP: properties.cruiseMP,
      powerSystem:
        properties.structureKind === "MOBILE_STRUCTURE"
          ? prettyPower(properties.powerSystem)
          : "",
      powerSystemWeight,
      motiveSystemWeight,
      fuelWeight,
      environmentalSealingMass,
      linkageMass,
      turretMechanismMass,
      pintleMechanismMass,
      specialEnhancementMass,
      turretCount: properties.turretCount,
      mobileLinkages: properties.mobileLinkages,
      distributedPowerPerHex,
      distributedMotivePerHex,
      desiredRangeKm: properties.desiredRangeKm,
      minimumCrew,
      structureModificationMultiplier,
      automaticShellCost,
      automaticPowerCost,
      automaticMotiveCost,
      automaticArmorCost,
      miscellaneousEquipmentCost,
      finalStructureCost
    }
  });
}


function structureBaseCostPerLevel(properties: StructureProperties): number {
  const classification =
    properties.structureKind === "MOBILE_STRUCTURE"
      ? properties.mobileStructureType
      : properties.buildingClassification;

  switch (classification) {
    case "TENT": return 1000;
    case "HANGAR": return 8000;
    case "GUN_EMPLACEMENT": return 20000;
    case "FORTRESS": return 20000;
    case "CASTLE_BRIAN": return 1000000;
    case "WALL": return 5000;
    case "FENCE": return 800;
    case "BRIDGE": return 12000;
    default: return 10000;
  }
}

function structureCostForCell(
  properties: StructureProperties,
  levels: number,
  cf: number,
  modificationMultiplier: number
): number {
  const classification =
    properties.structureKind === "MOBILE_STRUCTURE"
      ? properties.mobileStructureType
      : properties.buildingClassification;
  const fixedOneLevel =
    classification === "FENCE" ||
    classification === "WALL" ||
    classification === "BRIDGE";
  const levelCount = fixedOneLevel ? 1 : Math.max(1, levels);
  return (
    structureBaseCostPerLevel(properties) *
    levelCount *
    cf *
    modificationMultiplier
  );
}

function structurePowerCostPerTon(power: MobilePowerSystem): number {
  switch (power) {
    case "STEAM": return 4000;
    case "ICE": return 5000;
    case "FUEL_CELL": return 7000;
    case "FISSION": return 15000;
    case "FUSION": return 10000;
  }
}

function structureMotiveCostFactor(motive: MobileMotiveType): number {
  switch (motive) {
    case "GROUND": return 10000;
    case "AIR": return 40000;
    case "NAVAL_SURFACE": return 20000;
    case "NAVAL_SUBMERSIBLE": return 35000;
  }
}

function validateBand(
  footprint: HexFootprint,
  band: StructureBand | undefined,
  constructionClass: StructureClass,
  structureLabel: string,
  validation: ValidationIssue[]
): void {
  if (!band) {
    validation.push({
      code: "VALUE_INVALID",
      severity: "error",
      field: "chassis.properties.constructionType",
      message:
        `${structureLabel.replaceAll("_", " ")} does not support the ${constructionClass} construction class.`
    });
    return;
  }

  if (
    band.maxHexes !== undefined &&
    footprint.cells.length > band.maxHexes
  ) {
    validation.push({
      code: "SIZE_LIMIT_EXCEEDED",
      severity: "error",
      field: "footprint",
      message:
        `${structureLabel.replaceAll("_", " ")} ${constructionClass} construction allows at most ${band.maxHexes} occupied hexes; this footprint has ${footprint.cells.length}.`
    });
  }

  for (const cell of footprint.cells) {
    const key = hexKey(cell.q, cell.r);
    if (
      cell.constructionFactor < band.minCF ||
      cell.constructionFactor > band.maxCF
    ) {
      validation.push({
        code: "CONSTRUCTION_FACTOR_INVALID",
        severity: "error",
        field: `footprint.${key}.constructionFactor`,
        message:
          `Hex ${key} CF ${cell.constructionFactor} is outside the ${band.minCF}-${band.maxCF} range for ${constructionClass} ${structureLabel.replaceAll("_", " ")} construction.`
      });
    }

    if (
      band.maxLevels !== undefined &&
      cell.levels > band.maxLevels
    ) {
      validation.push({
        code: "SIZE_LIMIT_EXCEEDED",
        severity: "error",
        field: `footprint.${key}.levels`,
        message:
          `Hex ${key} has ${cell.levels} levels; the current maximum is ${band.maxLevels}.`
      });
    }

    if (
      band.minLevels !== undefined &&
      cell.levels < band.minLevels
    ) {
      validation.push({
        code: "LEVEL_COUNT_INVALID",
        severity: "error",
        field: `footprint.${key}.levels`,
        message:
          `Hex ${key} requires at least ${band.minLevels} levels for this structure classification.`
      });
    }
  }
}

export function mobileInternalCapacity(
  structureType: MobileStructureType,
  cf: number,
  levels: number
): number {
  const safeCF = Math.max(0, cf);
  const safeLevels = Math.max(0, Math.floor(levels));
  if (structureType === "HANGAR") {
    return Math.min(
      safeCF * safeLevels * 3,
      300 * Math.ceil(safeLevels / 4)
    );
  }
  return safeCF * safeLevels;
}

export function staticInternalCapacity(
  classification: BuildingClassification,
  cf: number,
  levels: number
): number {
  const safeCF = Math.max(0, cf);
  const safeLevels = Math.max(0, Math.floor(levels));

  if (classification === "HANGAR") {
    return Math.min(
      safeCF * safeLevels * 3,
      600 * Math.ceil(safeLevels / 4)
    );
  }

  if (classification === "FENCE" || classification === "BRIDGE") {
    return 0;
  }

  if (classification === "CASTLE_BRIAN") {
    // TO:AR uses capital-scale structures; each CF point supports 10 tons
    // of internal equipment per level.
    return safeCF * safeLevels * 10;
  }

  return safeCF * safeLevels;
}

export function staticBuildingCanArmor(
  classification: BuildingClassification
): boolean {
  return (
    classification === "WALL" ||
    classification === "GUN_EMPLACEMENT" ||
    classification === "FORTRESS" ||
    classification === "CASTLE_BRIAN"
  );
}

export function staticBuildingMaxArmor(
  classification: BuildingClassification,
  cf: number
): number {
  if (classification === "CASTLE_BRIAN") return Math.max(0, cf * 2);
  if (staticBuildingCanArmor(classification)) return Math.max(0, cf);
  return 0;
}

export function validateCastleBrianOpenSpace(
  design: Design,
  footprint: HexFootprint,
  properties: StructureProperties = getStructureProperties(design)
): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  const parentCells = new Map(
    footprint.cells.map((cell) => [hexKey(cell.q, cell.r), cell] as const)
  );
  const hasTaggedOpenSpace = footprint.cells.some(
    (cell) => !!cell.openLevels?.length
  );
  const isCastleBrian =
    properties.structureKind === "BUILDING" &&
    properties.buildingClassification === "CASTLE_BRIAN";

  if (!isCastleBrian) {
    if (hasTaggedOpenSpace) {
      issues.push({
        code: "OPEN_SPACE_LEVEL_INVALID",
        severity: "error",
        field: "footprint.openLevels",
        message:
          "Per-level open-space construction is only available to Castle Brian structures."
      });
    }
    if (design.embeddedStructures?.length) {
      issues.push({
        code: "EMBEDDED_STRUCTURE_OUTSIDE_OPEN_SPACE",
        severity: "error",
        field: "embeddedStructures",
        message:
          "Interior structures may only be placed inside Castle Brian open-space construction."
      });
    }
    return issues;
  }

  if (properties.openSpaceConstruction && !hasTaggedOpenSpace) {
    issues.push({
      code: "OPEN_SPACE_LEVEL_INVALID",
      severity: "warning",
      field: "footprint.openLevels",
      message:
        "Open-space construction is enabled, but no Castle Brian levels are marked as open volume."
    });
  }

  const occupiedInteriorVolume = new Map<string, string>();

  for (const embedded of design.embeddedStructures ?? []) {
    if (!embedded.footprint?.cells?.length) {
      issues.push({
        code: "HEX_FOOTPRINT_EMPTY",
        severity: "error",
        field: `embeddedStructures.${embedded.id}.footprint`,
        message: `Interior structure "${embedded.name}" must occupy at least one hex.`
      });
      continue;
    }

    if (!Number.isInteger(embedded.baseLevel) || embedded.baseLevel < 1) {
      issues.push({
        code: "LEVEL_PLACEMENT_INVALID",
        severity: "error",
        field: `embeddedStructures.${embedded.id}.baseLevel`,
        message:
          `Interior structure "${embedded.name}" must begin on a positive whole-number Castle Brian level.`
      });
    }

    const childBand =
      STATIC_BUILDING_BANDS[embedded.buildingClassification]?.[
        embedded.constructionType
      ];
    validateBand(
      embedded.footprint,
      childBand,
      embedded.constructionType,
      `interior ${embedded.buildingClassification}`,
      issues
    );

    for (const childCell of embedded.footprint.cells) {
      const parentQ = embedded.originQ + childCell.q;
      const parentR = embedded.originR + childCell.r;
      const parentKey = hexKey(parentQ, parentR);
      const parentCell = parentCells.get(parentKey);

      for (
        let relativeLevel = 1;
        relativeLevel <= safeWhole(childCell.levels);
        relativeLevel++
      ) {
        const parentLevel = embedded.baseLevel + relativeLevel - 1;
        const volumeKey = `${parentKey}@${parentLevel}`;
        const isOpen =
          !!parentCell &&
          (parentCell.openLevels ?? []).includes(parentLevel);

        if (!isOpen) {
          issues.push({
            code: "EMBEDDED_STRUCTURE_OUTSIDE_OPEN_SPACE",
            severity: "error",
            field: `embeddedStructures.${embedded.id}.footprint`,
            message:
              `Interior structure "${embedded.name}" occupies parent hex ${parentKey}, level ${parentLevel}, which is not marked as Castle Brian open space.`
          });
          continue;
        }

        const existing = occupiedInteriorVolume.get(volumeKey);
        if (existing && existing !== embedded.id) {
          issues.push({
            code: "EMBEDDED_STRUCTURE_OVERLAP",
            severity: "error",
            field: `embeddedStructures.${embedded.id}.footprint`,
            message:
              `Interior structure "${embedded.name}" overlaps another interior structure at parent hex ${parentKey}, level ${parentLevel}.`
          });
        } else {
          occupiedInteriorVolume.set(volumeKey, embedded.id);
        }
      }
    }
  }

  return issues;
}

export function validateStructureComponentPlacement(
  design: Design,
  footprint: HexFootprint
): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  const cells = new Map(
    footprint.cells.map((cell) => [hexKey(cell.q, cell.r), cell] as const)
  );

  for (const installed of design.components) {
    const location = installed.placement?.location;

    if (!location) {
      issues.push({
        code: "UNALLOCATED_COMPONENT",
        severity: "warning",
        componentId: installed.componentId,
        message:
          `Installed component ${installed.componentId} has no structure hex assigned.`
      });
      continue;
    }

    const cell = cells.get(location);
    if (!cell) {
      issues.push({
        code: "INVALID_LOCATION",
        severity: "error",
        componentId: installed.componentId,
        message:
          `Installed component ${installed.componentId} references footprint hex ${location}, which is not occupied.`
      });
      continue;
    }

    const level = installed.placement?.level ?? 1;
    if (!Number.isInteger(level) || level < 1 || level > cell.levels) {
      issues.push({
        code: "LEVEL_PLACEMENT_INVALID",
        severity: "error",
        componentId: installed.componentId,
        message:
          `Installed component ${installed.componentId} is assigned to level ${level} of hex ${location}, but that hex has ${cell.levels} level(s).`
      });
    }
  }

  return issues;
}

export function validateFootprint(
  footprint: HexFootprint
): ValidationIssue[] {
  const issues: ValidationIssue[] = [];

  if (footprint.cells.length === 0) {
    issues.push({
      code: "HEX_FOOTPRINT_EMPTY",
      severity: "error",
      message: "The structure footprint must occupy at least one hex."
    });
    return issues;
  }

  const seen = new Set<string>();

  for (const cell of footprint.cells) {
    const key = hexKey(cell.q, cell.r);

    if (seen.has(key)) {
      issues.push({
        code: "HEX_DUPLICATE",
        severity: "error",
        field: `footprint.${key}`,
        message: `Hex ${key} appears more than once in the footprint.`
      });
    }
    seen.add(key);

    if (!Number.isInteger(cell.levels) || cell.levels < 1) {
      issues.push({
        code: "LEVEL_COUNT_INVALID",
        severity: "error",
        field: `footprint.${key}.levels`,
        message: `Hex ${key} must have at least one whole level.`
      });
    }

    const openLevels = cell.openLevels ?? [];
    const uniqueOpenLevels = new Set(openLevels);
    if (
      uniqueOpenLevels.size !== openLevels.length ||
      openLevels.some(
        (level) =>
          !Number.isInteger(level) ||
          level < 1 ||
          level > cell.levels
      )
    ) {
      issues.push({
        code: "OPEN_SPACE_LEVEL_INVALID",
        severity: "error",
        field: `footprint.${key}.openLevels`,
        message:
          `Hex ${key} open-space levels must be unique whole numbers between 1 and ${Math.max(1, cell.levels)}.`
      });
    }

    if (
      !Number.isFinite(cell.constructionFactor) ||
      cell.constructionFactor <= 0
    ) {
      issues.push({
        code: "CONSTRUCTION_FACTOR_INVALID",
        severity: "error",
        field: `footprint.${key}.constructionFactor`,
        message: `Hex ${key} must have a positive Construction Factor.`
      });
    }

    if (!Number.isFinite(cell.armor) || cell.armor < 0) {
      issues.push({
        code: "ARMOR_OVER_LIMIT",
        severity: "error",
        field: `footprint.${key}.armor`,
        message: `Hex ${key} cannot have negative armor.`
      });
    }
  }

  if (footprint.cells.length > 1 && !isConnected(footprint.cells)) {
    issues.push({
      code: "HEX_DISCONNECTED",
      severity: "warning",
      message:
        "The footprint contains disconnected hex groups. This is allowed for record editing but should be reviewed."
    });
  }

  return issues;
}

export function isConnected(cells: readonly HexFootprintCell[]): boolean {
  if (cells.length <= 1) return true;

  const occupied = new Set(cells.map((cell) => hexKey(cell.q, cell.r)));
  const visited = new Set<string>();
  const queue: Array<[number, number]> = [[cells[0].q, cells[0].r]];

  while (queue.length) {
    const [q, r] = queue.shift()!;
    const key = hexKey(q, r);
    if (visited.has(key)) continue;
    visited.add(key);

    for (const [dq, dr] of HEX_DIRECTIONS) {
      const neighbor: [number, number] = [q + dq, r + dr];
      const neighborKey = hexKey(neighbor[0], neighbor[1]);
      if (occupied.has(neighborKey) && !visited.has(neighborKey)) {
        queue.push(neighbor);
      }
    }
  }

  return visited.size === occupied.size;
}

export function hexKey(q: number, r: number): string {
  return `${q},${r}`;
}

export const HEX_DIRECTIONS = [
  [1, 0],
  [1, -1],
  [0, -1],
  [-1, 0],
  [-1, 1],
  [0, 1]
] as const;

function structureComponentMassByHex(
  design: Design,
  catalog: Map<string, ComponentDefinition>
): Map<string, number> {
  const result = new Map<string, number>();
  const context = buildDesignValueContext(design);

  for (const installed of design.components) {
    const location = installed.placement?.location;
    if (!location) continue;

    const component = catalog.get(installed.componentId);
    if (!component) continue;

    try {
      const unitMass = evaluateConstructionValue(
        component.mass,
        context
      );
      const total = unitMass * Math.max(0, installed.quantity);
      result.set(location, (result.get(location) ?? 0) + total);
    } catch {
      // calculateCommon reports the component formula failure.
    }
  }

  return result;
}

function massLedgerEntry(
  id: string,
  label: string,
  value: number,
  category: string
): LedgerEntry {
  return {
    id: `derived:${id}:mass`,
    label,
    quantity: 1,
    unitValue: value,
    totalValue: value,
    category
  };
}

function costLedgerEntry(
  id: string,
  label: string,
  value: number,
  category: string,
  explanation?: string
): LedgerEntry {
  return {
    id: `derived:${id}:cost`,
    label,
    quantity: 1,
    unitValue: value,
    totalValue: value,
    category,
    explanation
  };
}

function prettyBuilding(value: BuildingClassification): string {
  return {
    TENT: "Tent",
    HANGAR: "Hangar",
    STANDARD: "Standard Building",
    FENCE: "Fence",
    WALL: "Wall",
    BRIDGE: "Bridge",
    GUN_EMPLACEMENT: "Gun Emplacement",
    FORTRESS: "Fortress",
    CASTLE_BRIAN: "Castle Brian"
  }[value];
}

function prettyMobileType(value: MobileStructureType): string {
  return {
    BUILDING: "Building-type",
    HANGAR: "Hangar-type",
    FORTRESS: "Fortress-type"
  }[value];
}

function prettyMotive(value: MobileMotiveType): string {
  return {
    GROUND: "Ground",
    AIR: "Air",
    NAVAL_SURFACE: "Naval Surface",
    NAVAL_SUBMERSIBLE: "Naval Submersible"
  }[value];
}

function prettyPower(value: MobilePowerSystem): string {
  return {
    STEAM: "Steam",
    ICE: "Internal Combustion",
    FUEL_CELL: "Fuel Cell",
    FISSION: "Fission",
    FUSION: "Fusion"
  }[value];
}

function isQuarterPoint(value: number): boolean {
  return Number.isFinite(value) &&
    Math.abs(value * 4 - Math.round(value * 4)) < 1e-9;
}

function ceilTon(value: number): number {
  if (!Number.isFinite(value) || value <= 0) return 0;
  return Math.ceil(value - Number.EPSILON);
}

function ceilKg(value: number): number {
  return Math.ceil(Math.max(0, value) * 1000 - Number.EPSILON) / 1000;
}

function ceilHalf(value: number): number {
  if (!Number.isFinite(value) || value <= 0) return 0;
  return Math.ceil((value - Number.EPSILON) * 2) / 2;
}

function safeWhole(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.floor(value));
}

function safeNonNegative(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, value);
}

function numberOr(
  value: string | number | boolean | undefined,
  fallback: number
): number {
  return typeof value === "number" && Number.isFinite(value)
    ? value
    : fallback;
}

function enumOr<T extends string>(
  value: string | number | boolean | undefined,
  allowed: readonly T[],
  fallback: T
): T {
  return typeof value === "string" && allowed.includes(value as T)
    ? value as T
    : fallback;
}

function booleanOr(value: unknown, fallback: boolean): boolean {
  return typeof value === "boolean" ? value : fallback;
}
