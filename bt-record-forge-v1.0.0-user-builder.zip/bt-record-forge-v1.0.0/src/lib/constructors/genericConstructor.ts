import { calculateCommon } from "../core/calculation";
import { newId } from "../core/id";
import type {
  ComponentDefinition,
  ConstructorDefinition,
  ConstructorEditorSchema,
  ConstructorFamily,
  ConstructorId,
  ConstructorCoverage,
  ConstructionResult,
  CostModifier,
  Design,
  LedgerEntry,
  LocationSlotLedger,
  RulesLevel,
  TechBase,
  ValidationIssue
} from "../core/types";
import {
  buildDesignValueContext,
  evaluateConstructionValue
} from "../core/valueExpression";

export interface GenericCalculationContext {
  design: Design;
  catalog: Map<string, ComponentDefinition>;
  propertyNumber(key: string, fallback?: number): number;
  propertyString(key: string, fallback?: string): string;
  propertyBoolean(key: string, fallback?: boolean): boolean;
}

export interface GenericCalculatedSlice {
  massEntries?: LedgerEntry[];
  costEntries?: LedgerEntry[];
  slotEntries?: LedgerEntry[];
  costModifiers?: CostModifier[];
  validation?: ValidationIssue[];
  derived?: Record<string, string | number | boolean>;
}

export interface GenericConstructorSpec {
  id: ConstructorId;
  name: string;
  family: ConstructorFamily;
  description: string;
  coverage: ConstructorCoverage;
  defaultMass: number;
  techBase?: TechBase;
  rulesLevel?: RulesLevel;
  enforceMassLimit?: boolean;
  schema: ConstructorEditorSchema;
  calculateBase?: (ctx: GenericCalculationContext) => GenericCalculatedSlice;
}

export function makeGenericConstructor(
  spec: GenericConstructorSpec
): ConstructorDefinition {
  return {
    id: spec.id,
    name: spec.name,
    family: spec.family,
    description: spec.description,
    coverage: spec.coverage,
    editorSchema: spec.schema,

    create(): Design {
      const properties: Record<string, string | number | boolean> = {};

      for (const section of spec.schema.sections) {
        for (const field of section.fields) {
          properties[field.key] = field.defaultValue;
        }
      }

      return {
        format: "bt-record-forge",
        formatVersion: 1,
        id: newId("design"),
        constructorId: spec.id,
        identity: {
          name: `Untitled ${spec.name}`
        },
        rules: {
          year: 3050,
          techBase: spec.techBase ?? "INNER_SPHERE",
          rulesLevel: spec.rulesLevel ?? "STANDARD"
        },
        chassis: {
          massLimit: spec.defaultMass,
          properties
        },
        components: []
      };
    },

    calculate(
      design: Design,
      catalog: Map<string, ComponentDefinition>
    ): ConstructionResult {
      const ctx = buildContext(design, catalog);
      const slice = spec.calculateBase?.(ctx) ?? {};
      const validation: ValidationIssue[] = [
        ...(slice.validation ?? [])
      ];

      if (spec.coverage === "RECORD_ONLY" || spec.coverage === "PARTIAL_RULES") {
        validation.push({
          code: "RULES_IMPLEMENTATION_PARTIAL",
          severity: "info",
          message:
            spec.coverage === "RECORD_ONLY"
              ? `${spec.name} is record-capable, but its automatic construction formulas are not yet fully implemented. Entered mass/cost fields and catalog components are still totaled.`
              : `${spec.name} has a verified partial rules slice; remaining constructor-specific edge rules are still flagged as incomplete.`
        });
      }

      const massEntries = [...(slice.massEntries ?? [])];
      const costEntries = [...(slice.costEntries ?? [])];

      for (const section of spec.schema.sections) {
        for (const field of section.fields) {
          if (!field.ledger) continue;

          const raw = design.chassis.properties[field.key];
          if (typeof raw !== "number" || !Number.isFinite(raw) || raw < 0) {
            validation.push({
              code: "VALUE_INVALID",
              severity: "error",
              field: `chassis.properties.${field.key}`,
              message: `${field.label} must be a finite non-negative number.`
            });
            continue;
          }

          const entry: LedgerEntry = {
            id: `field:${field.key}:${field.ledger}`,
            label: field.label,
            quantity: 1,
            unitValue: raw,
            totalValue: raw,
            category: field.ledgerCategory ?? "misc",
            explanation: "Editable constructor ledger field."
          };

          if (field.ledger === "mass") {
            massEntries.push(entry);
          } else {
            costEntries.push(entry);
          }
        }
      }

      const result = calculateCommon(design, catalog, {
        massEntries,
        costEntries,
        slotEntries: slice.slotEntries,
        costModifiers: slice.costModifiers,
        validation,
        derived: slice.derived,
        enforceMassLimit: spec.enforceMassLimit !== false
      });

      const placement = buildGenericPlacementLedgers(
        design,
        catalog,
        spec.schema,
        slice.derived ?? {}
      );

      return {
        ...result,
        locations: placement.locations.length
          ? placement.locations
          : result.locations,
        validation: [...result.validation, ...placement.validation]
      };
    }
  };
}

function buildContext(
  design: Design,
  catalog: Map<string, ComponentDefinition>
): GenericCalculationContext {
  return {
    design,
    catalog,

    propertyNumber(key: string, fallback = 0): number {
      const value = design.chassis.properties[key];
      return typeof value === "number" && Number.isFinite(value)
        ? value
        : fallback;
    },

    propertyString(key: string, fallback = ""): string {
      const value = design.chassis.properties[key];
      return typeof value === "string" ? value : fallback;
    },

    propertyBoolean(key: string, fallback = false): boolean {
      const value = design.chassis.properties[key];
      return typeof value === "boolean" ? value : fallback;
    }
  };
}

export function massEntry(
  id: string,
  label: string,
  value: number,
  category: string,
  explanation?: string
): LedgerEntry {
  return {
    id: `derived:${id}:mass`,
    label,
    quantity: 1,
    unitValue: value,
    totalValue: value,
    category,
    explanation
  };
}

export function costEntry(
  id: string,
  label: string,
  value: number,
  category: string,
  explanation?: string
): LedgerEntry {
  return {
    id: `derived:${id}:cost`,
    label,
    quantity: 1,
    unitValue: value,
    totalValue: value,
    category,
    explanation
  };
}

export function ceilHalf(value: number): number {
  if (!Number.isFinite(value) || value <= 0) return 0;
  return Math.ceil((value - Number.EPSILON) * 2) / 2;
}

export function roundHalf(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.round(value * 2) / 2;
}

export function whole(value: number, minimum = 0): number {
  if (!Number.isFinite(value)) return minimum;
  return Math.max(minimum, Math.floor(value));
}


function buildGenericPlacementLedgers(
  design: Design,
  catalog: Map<string, ComponentDefinition>,
  schema: ConstructorEditorSchema,
  derived: Record<string, string | number | boolean>
): {
  locations: LocationSlotLedger[];
  validation: ValidationIssue[];
} {
  const definitions = schema.placementLocations ?? [];
  if (definitions.length === 0) {
    return { locations: [], validation: [] };
  }

  const byId = new Map(definitions.map((location) => [location.id, location]));
  const ledgers = new Map<string, LocationSlotLedger>();
  const validation: ValidationIssue[] = [];

  for (const location of definitions) {
    if (location.capacity === undefined) continue;
    ledgers.set(location.id, {
      id: location.id,
      label: location.label,
      capacity: location.capacity,
      reserved: 0,
      equipmentUsed: 0,
      used: 0,
      remaining: location.capacity,
      entries: []
    });
  }

  const valueContext = buildDesignValueContext(design, derived);

  for (const installed of design.components) {
    const component = catalog.get(installed.componentId);
    if (!component || component.slots === undefined) continue;

    let unitSlots = 0;
    try {
      unitSlots = evaluateConstructionValue(component.slots, valueContext);
    } catch {
      continue; // calculateCommon reports the formula error.
    }

    if (unitSlots <= 0) continue;

    const location = installed.placement?.location;
    if (!location) {
      validation.push({
        code: "UNALLOCATED_COMPONENT",
        severity: "warning",
        componentId: installed.componentId,
        message: `${component.name} uses slot/arc capacity but has no location assigned.`
      });
      continue;
    }

    if (!byId.has(location)) {
      validation.push({
        code: "INVALID_LOCATION",
        severity: "error",
        componentId: installed.componentId,
        message: `${component.name} is assigned to unknown location ${location}.`
      });
      continue;
    }

    const ledger = ledgers.get(location);
    if (!ledger) continue;

    const quantity = Math.max(0, installed.quantity);
    const used = unitSlots * quantity;
    ledger.equipmentUsed += used;
    ledger.entries.push({
      id: `equipment:${installed.id}`,
      label: component.name,
      quantity,
      unitValue: unitSlots,
      totalValue: used,
      category: "equipment",
      sourceComponentId: component.id
    });
  }

  for (const ledger of ledgers.values()) {
    ledger.used = ledger.reserved + ledger.equipmentUsed;
    ledger.remaining = ledger.capacity - ledger.used;
    if (ledger.remaining < 0) {
      validation.push({
        code: "LOCATION_OVER_CAPACITY",
        severity: "error",
        field: `location.${ledger.id}`,
        message: `${ledger.label} uses ${ledger.used} slots but its current constructor slice allows ${ledger.capacity}.`
      });
    }
  }

  return {
    locations: [...ledgers.values()],
    validation
  };
}
