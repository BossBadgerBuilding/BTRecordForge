import type {
  CostModifier,
  ConstructorDefinition,
  ConstructorEditorSchema,
  ValidationIssue
} from "../core/types";
import {
  costEntry,
  makeGenericConstructor,
  massEntry,
  roundHalf
} from "./genericConstructor";

type CapitalKind = "JUMPSHIP" | "WARSHIP" | "STATION";
export type DriveCore = "STANDARD" | "COMPACT" | "SUBCOMPACT" | "NONE";

const CAPITAL_ARCS = [
  { id: "NOSE", label: "Nose", capacity: 20 },
  { id: "FRS", label: "Forward Right Side", capacity: 20 },
  { id: "FLS", label: "Forward Left Side", capacity: 20 },
  { id: "RBS", label: "Right Broadside", capacity: 20 },
  { id: "LBS", label: "Left Broadside", capacity: 20 },
  { id: "ARS", label: "Aft Right Side", capacity: 20 },
  { id: "ALS", label: "Aft Left Side", capacity: 20 },
  { id: "AFT", label: "Aft", capacity: 20 },
  { id: "BODY", label: "Internal / Bay" }
];

const JUMPSHIP_ARCS = CAPITAL_ARCS.map((location) => ({
  ...location,
  capacity: location.id === "BODY" ? undefined : 12
}));

function schema(
  kind: CapitalKind,
  defaultMass: number
): ConstructorEditorSchema {
  const mobile = kind !== "STATION";
  const defaultDriveCore: DriveCore =
    kind === "WARSHIP" ? "COMPACT" :
    kind === "STATION" ? "NONE" :
    "STANDARD";

  const defaultCrew =
    kind === "JUMPSHIP"
      ? 6 + Math.ceil(defaultMass / 20000)
      : 45 + Math.ceil(defaultMass / 5000);

  return {
    sections: [
      {
        id: "hull",
        label:
          kind === "WARSHIP"
            ? "WarShip hull"
            : kind === "STATION"
              ? "Space Station hull"
              : "JumpShip hull",
        fields: [
          {
            key: "structuralIntegrity",
            label: "Structural Integrity",
            kind: "number",
            defaultValue: kind === "WARSHIP" ? 50 : 1,
            min: 1,
            step: 1
          },
          {
            key: "driveCoreType",
            label: "K-F drive core type",
            kind: "select",
            defaultValue: defaultDriveCore,
            options: [
              { value: "STANDARD", label: "Standard" },
              { value: "COMPACT", label: "Compact" },
              { value: "SUBCOMPACT", label: "Subcompact" },
              { value: "NONE", label: "No K-F drive core" }
            ]
          },
          {
            key: "primitive",
            label: "Primitive construction",
            kind: "boolean",
            defaultValue: false
          },
          {
            key: "jumpRange",
            label: "Primitive jump range",
            kind: "number",
            defaultValue: 30,
            min: 1,
            step: 1,
            help:
              "Only changes primitive K-F core mass. Standard modern cores ignore this value."
          },
          {
            key: "structureMass",
            label: "Hull / structure mass override",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 0.5,
            unit: "t",
            help:
              "Normally leave at 0. Structural Integrity mass is derived from unit type, SI and tonnage; a positive value is treated as an explicit legacy/refit override."
          },
          ...(mobile
            ? [
                {
                  key: "safeThrust",
                  label: "Safe thrust",
                  kind: "number" as const,
                  defaultValue: kind === "WARSHIP" ? 2 : 0,
                  min: 0,
                  step: 1
                }
              ]
            : []),
          ...(kind === "STATION"
            ? [
                {
                  key: "modularOrKFAdapter",
                  label: "Modular / K-F adapter construction",
                  kind: "boolean" as const,
                  defaultValue: false,
                  help:
                    "Current MegaMek treats this as a K-F adapter at 100,000 tons or less and modular construction above 100,000 tons."
                }
              ]
            : [])
        ]
      },
      {
        id: "jump",
        label: "Jump / drive systems",
        fields: [
          {
            key: "hasSail",
            label: "Energy collection sail",
            kind: "boolean",
            defaultValue: kind !== "STATION"
          },
          {
            key: "hasLFBattery",
            label: "Lithium-Fusion battery",
            kind: "boolean",
            defaultValue: false
          },
          {
            key: "fuelTons",
            label: "Fuel (before pumps)",
            kind: "number",
            defaultValue: kind === "WARSHIP" ? 2000 : 200,
            min: 0,
            step: 1,
            unit: "t"
          },
          {
            key: "heatSinks",
            label: "Total heat sinks (0 = engine-free minimum)",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 1
          },
          {
            key: "heatSinkType",
            label: "Heat sink type",
            kind: "select",
            defaultValue: "SINGLE",
            options: [
              { value: "SINGLE", label: "Single" },
              { value: "DOUBLE", label: "Double" }
            ]
          }
        ]
      },
      {
        id: "facilities",
        label: "Docking / gravity / escape systems",
        fields: [
          {
            key: "dockingCollars",
            label: "Docking collars",
            kind: "number",
            defaultValue: kind === "JUMPSHIP" ? 1 : 0,
            min: 0,
            step: 1
          },
          {
            key: "bayHardpointCost",
            label: "Hardpoint capacity consumed by special bays",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 1,
            help:
              "Use for Naval Repair Facilities / Drop Shuttle bays that reduce available docking hardpoints."
          },
          {
            key: "smallGravDecks",
            label: "Small grav decks",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 1,
            help: "50 tons and 5,000,000 C-bills each."
          },
          {
            key: "largeGravDecks",
            label: "Large grav decks",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 1,
            help: "100 tons and 10,000,000 C-bills each."
          },
          {
            key: "hugeGravDecks",
            label: "Huge grav decks",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 1,
            help: "500 tons and 40,000,000 C-bills each; intended for Space Stations."
          },
          {
            key: "lifeboats",
            label: "Lifeboats",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 1
          },
          {
            key: "escapePods",
            label: "Escape pods",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 1
          },
          {
            key: "bayCost",
            label: "Priced transport-bay cost",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 1,
            unit: "C",
            help:
              "Exclude quarters, infantry bays and Battle Armor bays; current MegaMek treats those as structural."
          },
          {
            key: "bayDoors",
            label: "Transport-bay doors",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 1,
            help: "1,000 C-bills per door."
          },
          {
            key: "hasHPG",
            label: "HPG",
            kind: "boolean",
            defaultValue: false,
            help: "Current capital-craft calculator prices an HPG at 1,000,000,000 C-bills."
          }
        ]
      },
      {
        id: "habitation",
        label: "Crew / cargo / facilities",
        fields: [
          {
            key: "crew",
            label: "Base crew",
            kind: "number",
            defaultValue: defaultCrew,
            min: 0,
            step: 1
          },
          {
            key: "passengers",
            label: "Passengers",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 1
          },
          {
            key: "arcsWithGuns",
            label: "Weapon arcs containing guns",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 1,
            help: "10,000 C-bills of gunnery control per armed arc."
          },
          {
            key: "equipmentCrewRequirement",
            label: "Additional equipment crew requirement",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 1,
            help:
              "Manual total for equipment whose crew requirement is not yet represented in the component catalog."
          },
          {
            key: "quartersMass",
            label: "Quarters / habitation mass",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 0.5,
            unit: "t",
            ledger: "mass",
            ledgerCategory: "quarters"
          },
          {
            key: "cargoMass",
            label: "Cargo mass",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 0.5,
            unit: "t",
            ledger: "mass",
            ledgerCategory: "cargo"
          },
          {
            key: "bayMass",
            label: "Transport / docking / bay allocation",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 0.5,
            unit: "t",
            ledger: "mass",
            ledgerCategory: "transport"
          }
        ]
      },
      {
        id: "protection",
        label: "Armor",
        fields: [
          {
            key: "armorType",
            label: "Capital armor type",
            kind: "select",
            defaultValue: "STANDARD",
            options: [
              { value: "STANDARD", label: "Standard" },
              { value: "IMPROVED_FERRO_ALUMINUM", label: "Improved Ferro-Aluminum" },
              { value: "FERRO_CARBIDE", label: "Ferro-Carbide" },
              { value: "LAMELLOR_FERRO_CARBIDE", label: "Lamellor Ferro-Carbide" }
            ]
          },
          {
            key: "armorMass",
            label: "Armor mass",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 0.5,
            unit: "t",
            ledger: "mass",
            ledgerCategory: "armor"
          },
          {
            key: "armorPoints",
            label: "Armor points",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 1,
            help:
              "Recorded directly; points-per-ton depends on the selected capital armor type."
          },
          {
            key: "armorCost",
            label: "Additional armor cost override",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 1,
            unit: "C",
            ledger: "cost",
            ledgerCategory: "armor",
            help: "Normally 0; published capital-armor pricing is calculated automatically."
          }
        ]
      },
      {
        id: "cost",
        label: "Remaining C-bill inputs",
        fields: [
          {
            key: "additionalSystemCost",
            label: "Additional manual system cost",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 1,
            unit: "C",
            ledger: "cost",
            ledgerCategory: "chassis"
          },
          {
            key: "facilityCost",
            label: "Additional facility cost",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 1,
            unit: "C",
            ledger: "cost",
            ledgerCategory: "facilities"
          }
        ]
      }
    ],
    placementLocations:
      kind === "JUMPSHIP" ? JUMPSHIP_ARCS : CAPITAL_ARCS
  };
}

function constructor(
  id: "aero.jumpship" | "aero.warship" | "aero.space-station",
  name: string,
  kind: CapitalKind,
  defaultMass: number
): ConstructorDefinition {
  return makeGenericConstructor({
    id,
    name,
    family: "Aerospace",
    description: `${name} construction/record worksheet.`,
    coverage: "RULES_IMPLEMENTED",
    defaultMass,
    rulesLevel: "ADVANCED",
    schema: schema(kind, defaultMass),

    calculateBase(ctx) {
      const unitMass = Math.max(0, ctx.design.chassis.massLimit);
      const year = ctx.design.rules.year ?? 2300;
      const primitive = ctx.propertyBoolean("primitive", false);
      const safeThrust =
        kind === "WARSHIP"
          ? Math.max(0, Math.floor(ctx.propertyNumber("safeThrust", 0)))
          : 0;
      const driveCore = normalizeDriveCore(
        ctx.propertyString(
          "driveCoreType",
          kind === "WARSHIP"
            ? "COMPACT"
            : kind === "STATION"
              ? "NONE"
              : "STANDARD"
        )
      );
      const jumpRange = Math.max(
        1,
        Math.floor(ctx.propertyNumber("jumpRange", 30))
      );
      const hasSail = ctx.propertyBoolean(
        "hasSail",
        kind !== "STATION"
      );
      const hasLF = ctx.propertyBoolean("hasLFBattery", false);
      const fuelTons = Math.max(0, ctx.propertyNumber("fuelTons", 0));
      const heatSinksEntered = Math.max(
        0,
        Math.floor(ctx.propertyNumber("heatSinks", 0))
      );
      const heatSinkType = ctx.propertyString("heatSinkType", "SINGLE");
      const si = Math.max(
        1,
        Math.floor(ctx.propertyNumber("structuralIntegrity", 1))
      );
      const maximumThrust = kind === "WARSHIP" ? Math.ceil(safeThrust * 1.5) : 0;
      const derivedStructureMass = capitalStructureMass(kind, unitMass, si);
      const structureOverride = Math.max(0, ctx.propertyNumber("structureMass", 0));
      const structureMass = structureOverride > 0 ? structureOverride : derivedStructureMass;
      const armorType = normalizeCapitalArmorType(
        ctx.propertyString("armorType", "STANDARD")
      );

      const engineMass = capitalEngineMass(
        unitMass,
        safeThrust,
        year,
        primitive,
        kind === "STATION" || (kind === "JUMPSHIP" && !primitive)
      );
      const controlsMass = capitalControlsMass(
        unitMass,
        year,
        primitive,
        kind
      );
      const primitiveSailAvailable = !primitive || year >= 2200;
      const sailMass = hasSail && primitiveSailAvailable
        ? capitalSailMass(unitMass, year, primitive, kind)
        : 0;
      const kfDriveMass = capitalKFDriveMass(
        unitMass,
        driveCore,
        primitive,
        jumpRange
      );
      const kfIntegrity = primitive && kind === "JUMPSHIP"
        ? Math.ceil(2 + kfDriveMass / 25000)
        : capitalKFIntegrity(kind, kfDriveMass);

      const fuelPumpMass = ceilTon(fuelTons * 0.02);
      const fuelMassWithPumps = fuelTons + fuelPumpMass;

      const freeHeatSinks = Math.floor(
        45 + Math.sqrt(engineMass * (primitive ? 1 : 2))
      );
      const heatSinks =
        heatSinksEntered === 0 ? freeHeatSinks : heatSinksEntered;
      const paidHeatSinkMass = Math.max(
        heatSinks - freeHeatSinks,
        0
      );

      const smallGrav = whole(ctx.propertyNumber("smallGravDecks", 0));
      const largeGrav = whole(ctx.propertyNumber("largeGravDecks", 0));
      const hugeGrav = whole(ctx.propertyNumber("hugeGravDecks", 0));
      const totalGravDecks = smallGrav + largeGrav + hugeGrav;
      const gravDeckMass =
        smallGrav * 50 + largeGrav * 100 + hugeGrav * 500;

      const lifeboats = whole(ctx.propertyNumber("lifeboats", 0));
      const escapePods = whole(ctx.propertyNumber("escapePods", 0));
      const escapeCraftMass = (lifeboats + escapePods) * 7;

      const dockingCollars = whole(
        ctx.propertyNumber("dockingCollars", 0)
      );
      const bayHardpointCost = whole(
        ctx.propertyNumber("bayHardpointCost", 0)
      );
      const hardpointMass = dockingCollars * 1000;
      const maximumDockingHardpoints =
        unitMass < 50000
          ? 0
          : Math.max(
              Math.ceil(unitMass / 50000) - bayHardpointCost,
              0
            );

      const lfBatteryMass = hasLF ? unitMass * 0.01 : 0;

      const maxArmorMass = capitalMaximumArmorMass(kind, structureMass);
      const armorMass = Math.max(
        0,
        ctx.propertyNumber("armorMass", 0)
      );
      const armorPointsPerTon = capitalArmorPointsPerTon(
        unitMass,
        armorType,
        ctx.design.rules.techBase === "CLAN"
      );
      const purchasedArmorPoints = Math.floor(armorMass * armorPointsPerTon + 1e-9);
      const freeArmorPerFacing = Math.max(0, Math.round(si / 10));
      const armorFacings = 6;
      const totalArmorPoints =
        purchasedArmorPoints + freeArmorPerFacing * armorFacings;
      const publishedArmorCost =
        armorMass * capitalArmorCostPerTon(armorType);

      const maxGravDecks = 3 + Math.ceil(unitMass / 100000);
      const minimumBaseCrew =
        kind === "JUMPSHIP"
          ? 6 + Math.ceil(unitMass / 20000)
          : 45 + Math.ceil(unitMass / 5000);
      const equipmentCrewRequirement = whole(
        ctx.propertyNumber("equipmentCrewRequirement", 0)
      );
      const minimumCrew =
        minimumBaseCrew + equipmentCrewRequirement;
      const crew = whole(ctx.propertyNumber("crew", 0));
      const passengers = whole(
        ctx.propertyNumber("passengers", 0)
      );
      const arcsWithGuns = whole(
        ctx.propertyNumber("arcsWithGuns", 0)
      );
      const bayCost = Math.max(
        0,
        ctx.propertyNumber("bayCost", 0)
      );
      const bayDoors = whole(
        ctx.propertyNumber("bayDoors", 0)
      );
      const hasHPG = ctx.propertyBoolean("hasHPG", false);

      const minTonnage = driveCoreMinTonnage(driveCore);
      const weightIncrement = driveCoreWeightIncrement(driveCore);
      const validation: ValidationIssue[] = [];

      if (kind !== "WARSHIP" && si !== 1 && !primitive) {
        validation.push({
          code: "VALUE_INVALID",
          severity: "error",
          field: "chassis.properties.structuralIntegrity",
          message: `${name} Structural Integrity is fixed at 1 under the standard advanced-aerospace construction rules.`
        });
      }
      if (
        kind === "WARSHIP" &&
        maximumThrust > 0 &&
        (si < maximumThrust || si > maximumThrust * 30)
      ) {
        validation.push({
          code: "VALUE_INVALID",
          severity: "error",
          field: "chassis.properties.structuralIntegrity",
          message: `WarShip SI must be from Maximum Thrust (${maximumThrust}) through 30 × Maximum Thrust (${maximumThrust * 30}).`
        });
      }
      if (primitive && kind !== "JUMPSHIP") {
        validation.push({
          code: "VALUE_INVALID",
          severity: "error",
          field: "chassis.properties.primitive",
          message: "The primitive construction path implemented here is the Interstellar Operations Primitive JumpShip path."
        });
      }
      if (primitive && (jumpRange < 15 || jumpRange > 30)) {
        validation.push({
          code: "VALUE_INVALID",
          severity: "error",
          field: "chassis.properties.jumpRange",
          message: "Primitive JumpShip jump range must be a whole value from 15 through 30 light-years."
        });
      }
      if (primitive && year < 2200 && hasSail) {
        validation.push({
          code: "VALUE_INVALID",
          severity: "error",
          field: "chassis.properties.hasSail",
          message: "Primitive JumpShips introduced before 2200 may not mount a jump sail."
        });
      }
      if (primitive && armorType !== "STANDARD") {
        validation.push({
          code: "ARMOR_TECH_INVALID",
          severity: "error",
          field: "chassis.properties.armorType",
          message: "Primitive JumpShips may only mount standard capital armor."
        });
      }

      if (unitMass < minTonnage) {
        validation.push({
          code: "SIZE_LIMIT_EXCEEDED",
          severity: "error",
          field: "chassis.massLimit",
          message:
            `${prettyDriveCore(driveCore)} requires at least ${minTonnage.toLocaleString()} tons; this vessel is ${unitMass.toLocaleString()} tons.`
        });
      }

      if (
        weightIncrement > 0 &&
        !isMultipleOf(unitMass, weightIncrement)
      ) {
        validation.push({
          code: "VALUE_INVALID",
          severity: "error",
          field: "chassis.massLimit",
          message:
            `${prettyDriveCore(driveCore)} vessels use ${weightIncrement.toLocaleString()}-ton construction increments; ${unitMass.toLocaleString()} tons is off-increment.`
        });
      }

      if (armorMass > maxArmorMass + 1e-9) {
        validation.push({
          code: "ARMOR_OVER_LIMIT",
          severity: "error",
          field: "chassis.properties.armorMass",
          message:
            `${armorMass.toLocaleString()} tons of armor exceeds the ${maxArmorMass.toLocaleString()}-ton maximum at SI ${si}.`
        });
      }

      if (crew < minimumCrew) {
        validation.push({
          code: "VALUE_INVALID",
          severity: "error",
          field: "chassis.properties.crew",
          message:
            `Crew ${crew} is below the current minimum of ${minimumCrew} (${minimumBaseCrew} base + ${equipmentCrewRequirement} equipment crew).`
        });
      }

      if (
        heatSinksEntered > 0 &&
        heatSinksEntered < freeHeatSinks
      ) {
        validation.push({
          code: "HEAT_SINK_INVALID",
          severity: "error",
          field: "chassis.properties.heatSinks",
          message:
            `This drive accounts for ${freeHeatSinks} weight-free heat sinks; total heat sinks cannot be lower than that value.`
        });
      }

      if (dockingCollars > maximumDockingHardpoints) {
        validation.push({
          code: "LOCATION_OVER_CAPACITY",
          severity: "error",
          field: "chassis.properties.dockingCollars",
          message:
            `${dockingCollars} docking collars exceed the current maximum of ${maximumDockingHardpoints} after special-bay hardpoint use.`
        });
      }

      if (totalGravDecks > maxGravDecks) {
        validation.push({
          code: "LOCATION_OVER_CAPACITY",
          severity: "error",
          field: "chassis.properties.smallGravDecks",
          message:
            `${totalGravDecks} gravity decks exceed the ${maxGravDecks}-deck maximum at this tonnage.`
        });
      }

      if (kind !== "STATION" && hugeGrav > 0) {
        validation.push({
          code: "VALUE_INVALID",
          severity: "error",
          field: "chassis.properties.hugeGravDecks",
          message:
            "Huge gravity decks are reserved for Space Stations in this construction slice."
        });
      }

      const maxBayDoors =
        kind === "WARSHIP"
          ? 8 + Math.ceil(unitMass / 100000)
          : kind === "STATION"
            ? 8 + Math.ceil(unitMass / 75000)
            : 7 + Math.ceil(unitMass / 50000);

      if (bayDoors > maxBayDoors) {
        validation.push({
          code: "LOCATION_OVER_CAPACITY",
          severity: "error",
          field: "chassis.properties.bayDoors",
          message:
            `${bayDoors} transport-bay doors exceed the current ${maxBayDoors}-door limit.`
        });
      }

      const commonCosts = capitalCommonCosts({
        unitMass,
        si,
        crew,
        passengers,
        arcsWithGuns,
        fuelTons,
        heatSinks,
        heatSinkType,
        lifeboats,
        escapePods,
        smallGrav,
        largeGrav,
        hugeGrav,
        dockingCollars,
        bayCost,
        bayDoors,
        hasHPG
      });

      const driveCosts = capitalDriveCosts({
        kind,
        unitMass,
        safeThrust,
        dockingCollars,
        kfIntegrity,
        hasLF,
        hasSail
      });

      const stationSpecial = kind === "STATION" &&
        ctx.propertyBoolean("modularOrKFAdapter", false);
      const priceMultiplier =
        kind === "JUMPSHIP"
          ? 1.25
          : kind === "WARSHIP"
            ? 2
            : stationSpecial
              ? unitMass > 100000 ? 50 : 20
              : 5;

      const costModifiers: CostModifier[] = [
        {
          id: "capital-final-price",
          label: `${name} final price multiplier`,
          multiplier: priceMultiplier,
          explanation:
            kind === "STATION"
              ? stationSpecial
                ? unitMass > 100000
                  ? "Modular Space Station multiplier."
                  : "Space Station K-F adapter multiplier."
                : "Standard Space Station multiplier."
              : `Current ${name} price multiplier.`
        }
      ];

      return {
        massEntries: [
          massEntry(
            "capital-structure",
            "Structural Integrity",
            structureMass,
            "structure",
            structureOverride > 0
              ? "Explicit structure-mass override."
              : "Derived from unit type, tonnage and Structural Integrity."
          ),
          ...(armorMass > 0
            ? [
                massEntry(
                  "capital-armor",
                  `${prettyCapitalArmor(armorType)} (${purchasedArmorPoints} purchased capital points)`,
                  armorMass,
                  "armor"
                )
              ]
            : []),
          ...(kfDriveMass > 0
            ? [
                massEntry(
                  "capital-kf-core",
                  `${prettyDriveCore(driveCore)}${primitive ? " (primitive range)" : ""}`,
                  kfDriveMass,
                  "drive"
                )
              ]
            : []),
          massEntry(
            "capital-engine",
            kind === "WARSHIP"
              ? "Maneuvering Engine"
              : "Station-Keeping Drive",
            engineMass,
            "engine"
          ),
          massEntry(
            "capital-controls",
            "Control Systems",
            controlsMass,
            "controls"
          ),
          ...(sailMass > 0
            ? [
                massEntry(
                  "capital-sail",
                  "Energy Collection Sail",
                  sailMass,
                  "drive"
                )
              ]
            : []),
          massEntry(
            "capital-fuel",
            "Fuel + Pumps",
            fuelMassWithPumps,
            "fuel",
            `${fuelTons.toLocaleString()} tons fuel + ${fuelPumpMass.toLocaleString()} tons pumps.`
          ),
          ...(paidHeatSinkMass > 0
            ? [
                massEntry(
                  "capital-heat-sinks",
                  "Heat Sinks above Engine-Free Allowance",
                  paidHeatSinkMass,
                  "heat"
                )
              ]
            : []),
          ...(gravDeckMass > 0
            ? [
                massEntry(
                  "capital-grav-decks",
                  "Gravity Decks",
                  gravDeckMass,
                  "habitation"
                )
              ]
            : []),
          ...(escapeCraftMass > 0
            ? [
                massEntry(
                  "capital-escape-craft",
                  "Lifeboats / Escape Pods",
                  escapeCraftMass,
                  "safety"
                )
              ]
            : []),
          ...(lfBatteryMass > 0
            ? [
                massEntry(
                  "capital-lf-battery",
                  "Lithium-Fusion Battery",
                  lfBatteryMass,
                  "drive"
                )
              ]
            : []),
          ...(hardpointMass > 0
            ? [
                massEntry(
                  "capital-docking-hardpoints",
                  "Docking Hardpoints",
                  hardpointMass,
                  "transport"
                )
              ]
            : [])
        ],
        costEntries: [
          costEntry("capital-bridge", "Bridge", commonCosts.bridge, "controls"),
          costEntry("capital-computer", "Computer", commonCosts.computer, "controls"),
          costEntry("capital-life-support", "Life Support", commonCosts.lifeSupport, "controls"),
          costEntry("capital-sensors", "Sensors", commonCosts.sensors, "controls"),
          costEntry("capital-fcs", "Fire Control Computer", commonCosts.fireControl, "controls"),
          costEntry("capital-gunnery", "Gunnery Control Systems", commonCosts.gunneryControl, "controls"),
          costEntry("capital-si", "Structural Integrity", commonCosts.structure, "structure"),
          ...(publishedArmorCost > 0
            ? [
                costEntry(
                  "capital-armor-cost",
                  prettyCapitalArmor(armorType),
                  publishedArmorCost,
                  "armor"
                )
              ]
            : []),
          ...(driveCosts.driveUnit > 0
            ? [costEntry("capital-drive-unit", "Drive Unit", driveCosts.driveUnit, "engine")]
            : []),
          costEntry("capital-engine-cost", kind === "WARSHIP" ? "Engine" : "Station-Keeping Engine", driveCosts.engine, "engine"),
          costEntry("capital-ecu", "Engine Control Unit", driveCosts.ecu, "engine"),
          ...(driveCosts.kfDrive > 0
            ? [costEntry("capital-kf-cost", "K-F Drive", driveCosts.kfDrive, "drive")]
            : []),
          ...(driveCosts.kfSupport > 0
            ? [costEntry("capital-kf-support", "K-F Drive Support System", driveCosts.kfSupport, "drive")]
            : []),
          costEntry("capital-attitude", "Attitude Thrusters", commonCosts.attitudeThrusters, "movement"),
          ...(commonCosts.dockingCollars > 0
            ? [costEntry("capital-docking-cost", "Docking Collars", commonCosts.dockingCollars, "transport")]
            : []),
          costEntry("capital-fuel-cost", "Fuel Tanks", commonCosts.fuelTanks, "fuel"),
          costEntry("capital-heat-cost", "Heat Sinks", commonCosts.heatSinks, "heat"),
          ...(commonCosts.escapeCraft > 0
            ? [costEntry("capital-escape-cost", "Lifeboats / Escape Pods", commonCosts.escapeCraft, "safety")]
            : []),
          ...(commonCosts.gravDecks > 0
            ? [costEntry("capital-grav-cost", "Gravity Decks", commonCosts.gravDecks, "habitation")]
            : []),
          ...(commonCosts.bays > 0
            ? [costEntry("capital-bays-cost", "Transport Bays / Doors", commonCosts.bays, "transport")]
            : []),
          ...(commonCosts.hpg > 0
            ? [costEntry("capital-hpg", "HPG", commonCosts.hpg, "communications")]
            : [])
        ],
        costModifiers,
        validation,
        derived: {
          weaponSlotsPerArc:
            kind === "JUMPSHIP" ? 12 : 20,
          driveCoreType: prettyDriveCore(driveCore),
          jumpRange,
          kfDriveMass,
          kfIntegrity,
          minimumTonnage: minTonnage,
          constructionWeightIncrement: weightIncrement,
          safeThrust,
          maximumThrust,
          structureMass,
          derivedStructureMass,
          structureMassOverride: structureOverride,
          engineMass,
          controlsMass,
          sailMass,
          fuelPumpMass,
          fuelMassWithPumps,
          freeHeatSinks,
          totalHeatSinks: heatSinks,
          paidHeatSinkMass,
          gravityDecks: totalGravDecks,
          maximumGravityDecks: maxGravDecks,
          gravityDeckMass: gravDeckMass,
          maximumGravityDeckDiameter:
            kind === "STATION" ? 1500 : 250,
          dockingCollars,
          maximumDockingHardpoints,
          dockingHardpointMass: hardpointMass,
          lfBatteryMass,
          escapeCraftMass,
          maximumArmorMass: maxArmorMass,
          armorType: prettyCapitalArmor(armorType),
          armorPointsPerTon,
          purchasedArmorPoints,
          siBonusArmorPointsPerLocation: freeArmorPerFacing,
          totalArmorPoints,
          minimumBaseCrew,
          equipmentCrewRequirement,
          minimumCrew,
          maxBayDoors,
          priceMultiplier,
          commonBaseCost:
            Object.values(commonCosts).reduce((sum, value) => sum + value, 0),
          driveBaseCost:
            Object.values(driveCosts).reduce((sum, value) => sum + value, 0)
        }
      };
    }
  });
}

export const jumpShipConstructor = constructor(
  "aero.jumpship",
  "JumpShip",
  "JUMPSHIP",
  100000
);

export const warShipConstructor = constructor(
  "aero.warship",
  "WarShip",
  "WARSHIP",
  500000
);

export const spaceStationConstructor = constructor(
  "aero.space-station",
  "Space Station",
  "STATION",
  100000
);


export type CapitalArmorType =
  | "STANDARD"
  | "IMPROVED_FERRO_ALUMINUM"
  | "FERRO_CARBIDE"
  | "LAMELLOR_FERRO_CARBIDE";

export function capitalStructureMass(
  kind: CapitalKind,
  mass: number,
  structuralIntegrity: number
): number {
  const safeMass = Math.max(0, mass);
  const si = Math.max(1, Math.floor(structuralIntegrity));
  if (kind === "STATION") return roundHalf(safeMass / 100);
  if (kind === "JUMPSHIP") return roundHalf(safeMass / 150);
  return roundHalf((si * safeMass) / 1000);
}

export function capitalMaximumArmorMass(
  kind: CapitalKind,
  structuralIntegrityMass: number
): number {
  const siMass = Math.max(0, structuralIntegrityMass);
  if (kind === "JUMPSHIP") return floorHalf(siMass / 12);
  if (kind === "STATION") return floorHalf(siMass / 3 + 60);
  return floorHalf(siMass / 50);
}

export function capitalArmorPointsPerTon(
  mass: number,
  armor: CapitalArmorType,
  clan: boolean
): number {
  const bracket = mass < 150000 ? 0 : mass < 250000 ? 1 : 2;
  const table: Record<CapitalArmorType, Array<[number, number]>> = {
    STANDARD: [[0.8, 1.0], [0.6, 0.7], [0.4, 0.5]],
    IMPROVED_FERRO_ALUMINUM: [[1.0, 1.2], [0.8, 0.9], [0.6, 0.7]],
    FERRO_CARBIDE: [[1.2, 1.4], [1.0, 1.1], [0.8, 0.9]],
    LAMELLOR_FERRO_CARBIDE: [[1.4, 1.6], [1.2, 1.3], [1.0, 1.1]]
  };
  return table[armor][bracket][clan ? 1 : 0];
}

export function capitalArmorCostPerTon(armor: CapitalArmorType): number {
  switch (armor) {
    case "IMPROVED_FERRO_ALUMINUM": return 50000;
    case "FERRO_CARBIDE": return 75000;
    case "LAMELLOR_FERRO_CARBIDE": return 100000;
    default: return 10000;
  }
}

function normalizeCapitalArmorType(value: string): CapitalArmorType {
  if (
    value === "IMPROVED_FERRO_ALUMINUM" ||
    value === "FERRO_CARBIDE" ||
    value === "LAMELLOR_FERRO_CARBIDE"
  ) {
    return value;
  }
  return "STANDARD";
}

function prettyCapitalArmor(armor: CapitalArmorType): string {
  return {
    STANDARD: "Standard Capital Armor",
    IMPROVED_FERRO_ALUMINUM: "Improved Ferro-Aluminum",
    FERRO_CARBIDE: "Ferro-Carbide",
    LAMELLOR_FERRO_CARBIDE: "Lamellor Ferro-Carbide"
  }[armor];
}

export function capitalEngineMass(
  mass: number,
  safeThrust: number,
  year: number,
  primitive: boolean,
  stationKeeping: boolean
): number {
  if (stationKeeping) {
    return roundHalf(mass * 0.012);
  }
  const multiplier = primitive
    ? primitiveEngineMultiplier(year)
    : 0.06;
  return roundHalf(mass * safeThrust * multiplier);
}

export function primitiveEngineMultiplier(year: number): number {
  if (year >= 2300) return 0.06;
  if (year >= 2251) return 0.066;
  if (year >= 2201) return 0.084;
  if (year >= 2151) return 0.102;
  return 0.12;
}

export function capitalControlsMass(
  mass: number,
  year: number,
  primitive: boolean,
  kind: CapitalKind
): number {
  if (primitive) {
    return ceilTon(mass * primitiveControlMultiplier(year));
  }
  return ceilTon(
    mass * (kind === "STATION" ? 0.001 : 0.0025)
  );
}

export function primitiveControlMultiplier(year: number): number {
  if (year >= 2300) return 0.0025;
  if (year >= 2251) return 0.00275;
  if (year >= 2201) return 0.0035;
  if (year >= 2151) return 0.005;
  return 0.00625;
}

export function capitalSailMass(
  mass: number,
  year: number,
  primitive: boolean,
  kind: CapitalKind
): number {
  if (primitive) {
    if (year < 2230) return Math.ceil(mass / 2000) + 300;
    if (year < 2260) return Math.ceil(mass / 4000) + 150;
    if (year < 2300) return Math.ceil(mass / 8000) + 75;
    return Math.ceil(mass / 20000) + 30;
  }

  if (kind === "WARSHIP") {
    return Math.ceil(mass / 20000) + 30;
  }
  return Math.ceil(mass / 7500) + 30;
}

export function capitalKFDriveMass(
  mass: number,
  core: DriveCore,
  primitive: boolean,
  jumpRange = 30
): number {
  if (core === "NONE") return 0;

  const pct = primitive
    ? 0.05 + 0.03 * Math.max(1, jumpRange)
    : core === "COMPACT"
      ? 0.4525
      : core === "SUBCOMPACT"
        ? 0.5
        : 0.95;

  return Math.ceil(mass * pct - Number.EPSILON);
}

export function capitalKFIntegrity(
  kind: CapitalKind,
  driveMass: number
): number {
  if (driveMass <= 0 || kind === "STATION") return 0;
  return kind === "WARSHIP"
    ? Math.ceil(2 + driveMass / 25000)
    : Math.ceil(1.2 + driveMass / 60000);
}

export function driveCoreMinTonnage(core: DriveCore): number {
  switch (core) {
    case "COMPACT":
      return 100000;
    case "SUBCOMPACT":
      return 5000;
    case "NONE":
      return 2000;
    default:
      return 50000;
  }
}

export function driveCoreWeightIncrement(core: DriveCore): number {
  switch (core) {
    case "COMPACT":
      return 10000;
    case "SUBCOMPACT":
      return 100;
    case "NONE":
      return 500;
    default:
      return 1000;
  }
}

interface CapitalCommonCostInput {
  unitMass: number;
  si: number;
  crew: number;
  passengers: number;
  arcsWithGuns: number;
  fuelTons: number;
  heatSinks: number;
  heatSinkType: string;
  lifeboats: number;
  escapePods: number;
  smallGrav: number;
  largeGrav: number;
  hugeGrav: number;
  dockingCollars: number;
  bayCost: number;
  bayDoors: number;
  hasHPG: boolean;
}

export function capitalCommonCosts(input: CapitalCommonCostInput) {
  return {
    bridge: 200000 + 10 * input.unitMass,
    computer: 200000,
    lifeSupport: 5000 * (input.crew + input.passengers),
    sensors: 80000,
    fireControl: 100000,
    gunneryControl: 10000 * input.arcsWithGuns,
    structure: 100000 * input.si,
    attitudeThrusters: 25000,
    dockingCollars: 100000 * input.dockingCollars,
    fuelTanks: 200 * input.fuelTons * 1.02,
    heatSinks:
      (input.heatSinkType === "DOUBLE" ? 6000 : 2000) *
      input.heatSinks,
    escapeCraft: 5000 * (input.lifeboats + input.escapePods),
    gravDecks:
      5000000 * input.smallGrav +
      10000000 * input.largeGrav +
      40000000 * input.hugeGrav,
    bays: input.bayCost + input.bayDoors * 1000,
    hpg: input.hasHPG ? 1000000000 : 0
  };
}

interface CapitalDriveCostInput {
  kind: CapitalKind;
  unitMass: number;
  safeThrust: number;
  dockingCollars: number;
  kfIntegrity: number;
  hasLF: boolean;
  hasSail: boolean;
}

export function capitalDriveCosts(input: CapitalDriveCostInput) {
  if (input.kind === "STATION") {
    return {
      driveUnit: 0,
      engine: 1000 * input.unitMass * 0.012,
      ecu: 1000,
      kfDrive: 0,
      kfSupport: 0
    };
  }

  if (input.kind === "WARSHIP") {
    let kfDrive =
      60000000 + 75000000 * input.dockingCollars +
      25000000 + 5000000 * input.dockingCollars +
      50000000 +
      50000 * input.kfIntegrity +
      (input.hasSail ? 50000 * (30 + input.unitMass / 20000) : 0) +
      500000 + 200000 * input.dockingCollars;

    kfDrive *= 5;
    if (input.hasLF) kfDrive *= 3;

    return {
      driveUnit:
        500 * input.safeThrust * (input.unitMass / 100),
      engine:
        1000 * input.safeThrust * input.unitMass * 0.06,
      ecu: 1000,
      kfDrive,
      kfSupport:
        20000000 * (50 + input.unitMass / 10000)
    };
  }

  let kfDrive =
    60000000 + 75000000 * input.dockingCollars +
    25000000 + 5000000 * input.dockingCollars +
    50000000 +
    50000 * input.kfIntegrity +
    (input.hasSail ? 50000 * (30 + input.unitMass / 7500) : 0) +
    500000 + 200000 * input.dockingCollars;

  if (input.hasLF) kfDrive *= 3;

  return {
    driveUnit: 0,
    engine: 1000 * input.unitMass * 0.012,
    ecu: 1000,
    kfDrive,
    kfSupport: 10000000 * (input.unitMass / 10000)
  };
}

function normalizeDriveCore(value: string): DriveCore {
  if (
    value === "COMPACT" ||
    value === "SUBCOMPACT" ||
    value === "NONE"
  ) {
    return value;
  }
  return "STANDARD";
}

function prettyDriveCore(core: DriveCore): string {
  return {
    STANDARD: "Standard K-F drive core",
    COMPACT: "Compact K-F drive core",
    SUBCOMPACT: "Subcompact K-F drive core",
    NONE: "No K-F drive core"
  }[core];
}

function ceilTon(value: number): number {
  if (!Number.isFinite(value) || value <= 0) return 0;
  return Math.ceil(value - Number.EPSILON);
}

function floorHalf(value: number): number {
  if (!Number.isFinite(value) || value <= 0) return 0;
  return Math.floor((value + Number.EPSILON) * 2) / 2;
}

function whole(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.floor(value));
}

function isMultipleOf(value: number, increment: number): boolean {
  if (increment <= 0) return true;
  const quotient = value / increment;
  return Math.abs(quotient - Math.round(quotient)) < 1e-9;
}
