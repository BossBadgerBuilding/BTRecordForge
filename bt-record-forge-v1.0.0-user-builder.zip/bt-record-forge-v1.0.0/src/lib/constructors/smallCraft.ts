import type {
  CostModifier,
  ConstructorDefinition,
  ConstructorEditorSchema,
  ValidationIssue
} from "../core/types";
import {
  ceilHalf,
  costEntry,
  makeGenericConstructor,
  massEntry
} from "./genericConstructor";

const SMALL_CRAFT_LOCATIONS = [
  { id: "NOSE", label: "Nose", capacity: 12 },
  { id: "RW", label: "Right Wing / Side", capacity: 12 },
  { id: "LW", label: "Left Wing / Side", capacity: 12 },
  { id: "AFT", label: "Aft", capacity: 12 },
  { id: "BODY", label: "Body / Internal" }
];

const DROPSHIP_LOCATIONS = [
  { id: "NOSE", label: "Nose", capacity: 12 },
  { id: "FR", label: "Forward Right", capacity: 12 },
  { id: "FL", label: "Forward Left", capacity: 12 },
  { id: "AR", label: "Aft Right", capacity: 12 },
  { id: "AL", label: "Aft Left", capacity: 12 },
  { id: "AFT", label: "Aft", capacity: 12 },
  { id: "BODY", label: "Body / Internal" }
];

function commonSchema(dropShip: boolean): ConstructorEditorSchema {
  return {
    sections: [
      {
        id: "hull",
        label: dropShip ? "DropShip hull" : "Small Craft hull",
        fields: [
          {
            key: "configuration",
            label: "Configuration",
            kind: "select",
            defaultValue: "AERODYNE",
            options: [
              { value: "AERODYNE", label: "Aerodyne" },
              { value: "SPHEROID", label: "Spheroid" }
            ]
          },
          {
            key: "safeThrust",
            label: "Safe thrust",
            kind: "number",
            defaultValue: dropShip ? 3 : 4,
            min: 0,
            step: 1
          },
          {
            key: "primitive",
            label: "Primitive construction",
            kind: "boolean",
            defaultValue: false
          },
          {
            key: "designType",
            label: "Design type",
            kind: "select",
            defaultValue: "CIVILIAN",
            options: [
              { value: "CIVILIAN", label: "Civilian" },
              { value: "MILITARY", label: "Military" }
            ]
          },
          {
            key: "structuralIntegrity",
            label: "Structural Integrity",
            kind: "number",
            defaultValue: dropShip ? 8 : 6,
            min: 1,
            step: 1
          },
          {
            key: "structureMass",
            label: "Structure / hull mass",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 0.5,
            unit: "t",
            ledger: "mass",
            ledgerCategory: "structure",
            help: "Editable until the complete hull-structure formula is ported."
          }
        ]
      },
      {
        id: "systems",
        label: "Flight systems",
        fields: [
          {
            key: "fuelTons",
            label: "Fuel",
            kind: "number",
            defaultValue: dropShip ? 50 : 10,
            min: 0,
            step: 0.5,
            unit: "t",
            help: "Fuel pumps are added automatically."
          },
          {
            key: "heatSinks",
            label: "Heat sinks",
            kind: "number",
            defaultValue: 10,
            min: 0,
            step: 1
          },
          {
            key: "heatSinkType",
            label: "Heat sink type",
            kind: "select",
            defaultValue: "SINGLE",
            options: [
              { value: "SINGLE", label: "Single" },
              { value: "DOUBLE", label: "Double" }
            ]
          },
          {
            key: "armorTons",
            label: "Armor mass",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 0.5,
            unit: "t",
            ledger: "mass",
            ledgerCategory: "armor"
          },
          {
            key: "armorType",
            label: "Armor type",
            kind: "select",
            defaultValue: "STANDARD",
            options: [
              { value: "STANDARD", label: "Standard" },
              { value: "LIGHT_FERRO_ALUMINUM", label: "Light Ferro-Aluminum (IS)" },
              { value: "IS_FERRO_ALUMINUM", label: "Ferro-Aluminum (IS)" },
              { value: "CLAN_FERRO_ALUMINUM", label: "Ferro-Aluminum (Clan)" },
              { value: "HEAVY_FERRO_ALUMINUM", label: "Heavy Ferro-Aluminum (IS)" }
            ]
          }
        ]
      },
      {
        id: "crew",
        label: "Crew / escape craft",
        fields: [
          {
            key: "crew",
            label: "Crew",
            kind: "number",
            defaultValue: dropShip ? 5 : 3,
            min: 0,
            step: 1
          },
          {
            key: "passengers",
            label: "Passengers",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 1
          },
          {
            key: "arcsWithGuns",
            label: "Weapon arcs containing guns",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 1,
            help:
              "Used by the current large-craft gunnery-control C-bill calculation."
          },
          {
            key: "lifeboats",
            label: "Lifeboats",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 1
          },
          {
            key: "escapePods",
            label: "Escape pods",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 1
          },
          {
            key: "quartersMass",
            label: "Crew / passenger accommodations",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 0.5,
            unit: "t",
            ledger: "mass",
            ledgerCategory: "quarters"
          },
          {
            key: "cargoMass",
            label: "Cargo allocation",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 0.5,
            unit: "t",
            ledger: "mass",
            ledgerCategory: "cargo"
          }
        ]
      },
      {
        id: "transport",
        label: "Transport bays / doors",
        description: "Bay masses and capacities follow the TechManual transport-bay table. Unit-carrying bays require doors; crew/passenger and infantry-bay C-bill costs are structural for Small Craft and DropShips.",
        fields: [
          { key: "mechCubicles", label: "’Mech cubicles", kind: "number", defaultValue: 0, min: 0, step: 1 },
          { key: "fighterCubicles", label: "Fighter cubicles", kind: "number", defaultValue: 0, min: 0, step: 1 },
          { key: "protoMechPoints", label: "ProtoMech bays (5 cubicles)", kind: "number", defaultValue: 0, min: 0, step: 1 },
          { key: "smallCraftCubicles", label: "Small Craft cubicles", kind: "number", defaultValue: 0, min: 0, step: 1 },
          { key: "lightVehicleCubicles", label: "Light vehicle cubicles", kind: "number", defaultValue: 0, min: 0, step: 1 },
          { key: "heavyVehicleCubicles", label: "Heavy vehicle cubicles", kind: "number", defaultValue: 0, min: 0, step: 1 },
          { key: "superHeavyVehicleCubicles", label: "Super-heavy vehicle cubicles", kind: "number", defaultValue: 0, min: 0, step: 1 },
          { key: "footInfantryBays", label: "Foot infantry bays (28 troops)", kind: "number", defaultValue: 0, min: 0, step: 1 },
          { key: "jumpInfantryBays", label: "Jump infantry bays (28 troops)", kind: "number", defaultValue: 0, min: 0, step: 1 },
          { key: "motorizedInfantryBays", label: "Motorized infantry bays (28 troops)", kind: "number", defaultValue: 0, min: 0, step: 1 },
          { key: "mechanizedInfantryBays", label: "Mechanized infantry bays (5 troops)", kind: "number", defaultValue: 0, min: 0, step: 1 },
          { key: "battleArmorBays", label: "Battle Armor bays (1 trooper)", kind: "number", defaultValue: 0, min: 0, step: 1 },
          { key: "bayDoors", label: "Transport-bay doors", kind: "number", defaultValue: 0, min: 0, step: 1, help: "At least one door is required for each unit-carrying bay; each door costs 1,000 C-bills." }
        ]
      },
      {
        id: "cost",
        label: "Supplemental C-bill inputs",
        fields: [
          {
            key: "additionalSystemCost",
            label: "Additional custom system cost",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 1,
            unit: "C",
            ledger: "cost",
            ledgerCategory: "chassis"
          },
          {
            key: "accommodationCost",
            label: "Additional custom accommodation cost",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 1,
            unit: "C",
            ledger: "cost",
            ledgerCategory: "quarters"
          },
          ...(dropShip
            ? [
                {
                  key: "dockingCollarType",
                  label: "Docking collar",
                  kind: "select" as const,
                  defaultValue: "STANDARD",
                  options: [
                    { value: "STANDARD", label: "Standard K-F Boom" },
                    { value: "PROTOTYPE", label: "Prototype K-F Boom" },
                    { value: "NONE", label: "No Boom / Collar" }
                  ]
                },
              ]
            : [])
        ]
      }
    ],
    placementLocations: dropShip ? DROPSHIP_LOCATIONS : SMALL_CRAFT_LOCATIONS
  };
}

function engineMultiplier(year: number, clan: boolean, dropShip: boolean): number {
  if (clan) return 0.061;

  if (dropShip) {
    if (year >= 2500) return 0.065;
    if (year >= 2351) return 0.0715;
    if (year >= 2300) return 0.0845;
    if (year >= 2251) return 0.091;
    if (year >= 2201) return 0.1104;
    if (year >= 2151) return 0.117;
    return 0.13;
  }

  if (year >= 2500) return 0.065;
  if (year >= 2400) return 0.078;
  if (year >= 2300) return 0.091;
  if (year >= 2251) return 0.0975;
  if (year >= 2201) return 0.1105;
  if (year >= 2151) return 0.1235;
  return 0.143;
}

function controlMultiplier(year: number, primitive: boolean, dropShip: boolean): number {
  if (!primitive) return 0.0075;

  if (dropShip) {
    if (year >= 2500) return 0.0075;
    if (year >= 2351) return 0.009;
    if (year >= 2300) return 0.00975;
    if (year >= 2251) return 0.0105;
    if (year >= 2201) return 0.012;
    if (year >= 2151) return 0.0135;
    return 0.015;
  }

  if (year >= 2500) return 0.0075;
  if (year >= 2400) return 0.00825;
  if (year >= 2300) return 0.00975;
  if (year >= 2251) return 0.01125;
  if (year >= 2201) return 0.01275;
  if (year >= 2151) return 0.01245;
  return 0.01575;
}

function aerospaceArmorPointsPerTon(
  dropShip: boolean,
  configuration: string,
  mass: number,
  clan: boolean,
  armorType: string
): number {
  let standardClan = 20;
  let standardIS = 16;
  if (dropShip) {
    const spheroid = configuration === "SPHEROID";
    const tier =
      spheroid
        ? mass >= 65000 ? 5 : mass >= 50000 ? 4 : mass >= 35000 ? 3 : mass >= 20000 ? 2 : mass >= 12500 ? 1 : 0
        : mass >= 25000 ? 5 : mass >= 17500 ? 4 : mass >= 12500 ? 3 : mass >= 9500 ? 2 : mass >= 6000 ? 1 : 0;
    const clanStd = [20, 17, 14, 12, 10, 7] as const;
    const isStd = [16, 14, 12, 10, 8, 6] as const;
    standardClan = clanStd[tier];
    standardIS = isStd[tier];
  }
  if (armorType === "STANDARD") return clan ? standardClan : standardIS;
  if (armorType === "CLAN_FERRO_ALUMINUM") return clan ? standardClan * 1.2 : 0;
  if (clan) return 0;
  if (armorType === "LIGHT_FERRO_ALUMINUM") return standardIS * 1.06;
  if (armorType === "IS_FERRO_ALUMINUM") return standardIS * 1.12;
  if (armorType === "HEAVY_FERRO_ALUMINUM") return standardIS * 1.24;
  return standardIS;
}

function aerospaceArmorCostPerTon(armorType: string): number {
  if (armorType === "LIGHT_FERRO_ALUMINUM") return 15000;
  if (armorType === "HEAVY_FERRO_ALUMINUM") return 25000;
  if (armorType === "IS_FERRO_ALUMINUM" || armorType === "CLAN_FERRO_ALUMINUM") return 20000;
  return 10000;
}

function makeCraft(dropShip: boolean): ConstructorDefinition {
  return makeGenericConstructor({
    id: dropShip ? "aero.dropship" : "aero.small-craft",
    name: dropShip ? "DropShip" : "Small Craft",
    family: "Aerospace",
    description: dropShip
      ? "Aerodyne or spheroid DropShip construction record."
      : "Aerodyne or spheroid Small Craft construction record.",
    coverage: "RULES_IMPLEMENTED",
    defaultMass: dropShip ? 5000 : 200,
    schema: commonSchema(dropShip),

    calculateBase(ctx) {
      const mass = ctx.design.chassis.massLimit;
      const safeThrust = Math.max(0, Math.floor(ctx.propertyNumber("safeThrust", 0)));
      const year = ctx.design.rules.year ?? 2500;
      const clan = ctx.design.rules.techBase === "CLAN";
      const primitive = ctx.propertyBoolean("primitive", false);
      const configuration = ctx.propertyString("configuration", "AERODYNE");
      const military = ctx.propertyString("designType", "CIVILIAN") === "MILITARY";
      const si = Math.max(1, Math.floor(ctx.propertyNumber("structuralIntegrity", 1)));
      const fuelTons = Math.max(0, ctx.propertyNumber("fuelTons", 0));
      const heatSinks = Math.max(0, Math.floor(ctx.propertyNumber("heatSinks", 0)));
      const armorTons = Math.max(0, ctx.propertyNumber("armorTons", 0));
      const armorType = ctx.propertyString("armorType", "STANDARD");
      const armorPointsPerTon = aerospaceArmorPointsPerTon(
        dropShip,
        configuration,
        mass,
        clan,
        armorType
      );
      const paidArmorPoints = armorPointsPerTon > 0
        ? Math.floor(armorTons * armorPointsPerTon)
        : 0;
      const crew = Math.max(0, Math.floor(ctx.propertyNumber("crew", 0)));
      const lifeboats = Math.max(0, Math.floor(ctx.propertyNumber("lifeboats", 0)));
      const escapePods = Math.max(0, Math.floor(ctx.propertyNumber("escapePods", 0)));

      const engineMass = ceilHalf(
        mass * safeThrust * engineMultiplier(year, clan, dropShip)
      );
      const controlRaw =
        mass * controlMultiplier(year, primitive, dropShip);
      const controlsMass = dropShip
        ? Math.ceil(controlRaw - Number.EPSILON)
        : ceilHalf(controlRaw);

      const pumpAdjustedFuelMass = ceilHalf(fuelTons * 1.02);
      const escapeCraftMass = (lifeboats + escapePods) * 7;

      const freeHeatSinks = configuration === "SPHEROID"
        ? primitive
          ? Math.floor(Math.sqrt(engineMass * 1.3))
          : military && dropShip
            ? Math.floor(Math.sqrt(engineMass * 6.8))
            : Math.floor(Math.sqrt(engineMass * 1.6))
        : primitive
          ? Math.floor(engineMass / 75)
          : military && dropShip
            ? Math.floor(engineMass / 20)
            : Math.floor(engineMass / 60);

      const paidHeatSinkMass = Math.max(0, heatSinks - freeHeatSinks);

      const maxArmorTons = configuration === "SPHEROID"
        ? Math.floor((si * 3.6) * 2) / 2
        : Math.floor((si * 4.5) * 2) / 2;

      const bonusArmorPoints = 4 * si;
      const armorPoints = paidArmorPoints + bonusArmorPoints;
      const validation: ValidationIssue[] = [];
      if (armorPointsPerTon <= 0) {
        validation.push({
          code: "TECH_BASE_ILLEGAL",
          severity: "error",
          field: "chassis.properties.armorType",
          message: `${armorType.replaceAll("_", " ")} is not available to the selected technology base.`
        });
      }

      if (armorTons > maxArmorTons) {
        validation.push({
          code: "ARMOR_OVER_LIMIT",
          severity: "error",
          field: "chassis.properties.armorTons",
          message:
            `${armorTons} tons of armor exceeds the ${maxArmorTons}-ton ${configuration.toLowerCase()} maximum at SI ${si}.`
        });
      }

      const minimumCrew = dropShip
        ? 3 + Math.ceil(mass / 5000) + (military ? 1 : 0)
        : 3;

      if (crew < minimumCrew) {
        validation.push({
          code: "VALUE_INVALID",
          severity: "error",
          field: "chassis.properties.crew",
          message: `Crew ${crew} is below the current minimum-crew slice of ${minimumCrew}.`
        });
      }

      const maxBayDoors = 7 + Math.ceil(mass / 50000);
      const bayCounts = {
        mech: Math.max(0, Math.floor(ctx.propertyNumber("mechCubicles", 0))),
        fighter: Math.max(0, Math.floor(ctx.propertyNumber("fighterCubicles", 0))),
        proto: Math.max(0, Math.floor(ctx.propertyNumber("protoMechPoints", 0))),
        smallCraft: Math.max(0, Math.floor(ctx.propertyNumber("smallCraftCubicles", 0))),
        lightVehicle: Math.max(0, Math.floor(ctx.propertyNumber("lightVehicleCubicles", 0))),
        heavyVehicle: Math.max(0, Math.floor(ctx.propertyNumber("heavyVehicleCubicles", 0))),
        superHeavyVehicle: Math.max(0, Math.floor(ctx.propertyNumber("superHeavyVehicleCubicles", 0))),
        footInfantry: Math.max(0, Math.floor(ctx.propertyNumber("footInfantryBays", 0))),
        jumpInfantry: Math.max(0, Math.floor(ctx.propertyNumber("jumpInfantryBays", 0))),
        motorizedInfantry: Math.max(0, Math.floor(ctx.propertyNumber("motorizedInfantryBays", 0))),
        mechanizedInfantry: Math.max(0, Math.floor(ctx.propertyNumber("mechanizedInfantryBays", 0))),
        battleArmor: Math.max(0, Math.floor(ctx.propertyNumber("battleArmorBays", 0)))
      };
      const transportBayMass =
        bayCounts.mech * 150 +
        bayCounts.fighter * 150 +
        bayCounts.proto * 50 +
        bayCounts.smallCraft * 200 +
        bayCounts.lightVehicle * 50 +
        bayCounts.heavyVehicle * 100 +
        bayCounts.superHeavyVehicle * 200 +
        bayCounts.footInfantry * 5 +
        bayCounts.jumpInfantry * 6 +
        bayCounts.motorizedInfantry * 7 +
        bayCounts.mechanizedInfantry * 8 +
        bayCounts.battleArmor * 2;
      const unitCarryingBayCount =
        bayCounts.mech + bayCounts.fighter + bayCounts.proto + bayCounts.smallCraft +
        bayCounts.lightVehicle + bayCounts.heavyVehicle + bayCounts.superHeavyVehicle;
      const bayDoors = Math.max(0, Math.floor(ctx.propertyNumber("bayDoors", 0)));

      const passengers = Math.max(
        0,
        Math.floor(ctx.propertyNumber("passengers", 0))
      );
      const arcsWithGuns = Math.max(
        0,
        Math.floor(ctx.propertyNumber("arcsWithGuns", 0))
      );
      const heatSinkType = ctx.propertyString(
        "heatSinkType",
        "SINGLE"
      );
      const heatSinkCost =
        (heatSinkType === "DOUBLE" ? 6000 : 2000) * heatSinks;

      const bridgeCost = 200000 + 10 * mass;
      const computerCost = 200000;
      const lifeSupportCost = 5000 * (crew + passengers);
      const sensorsCost = 80000;
      const fireControlCost = 100000;
      const gunneryControlCost = 10000 * arcsWithGuns;
      const structureCost = 100000 * si;
      const attitudeThrusterCost = 25000;
      const landingGearCost = 10 * mass;
      const engineCost = engineMass * 1000;
      const driveUnitCost = (500 * safeThrust * mass) / 100;
      const fuelTankCost = 200 * pumpAdjustedFuelMass;

      const dockingCollarType = ctx.propertyString(
        "dockingCollarType",
        "STANDARD"
      );
      const dockingCollarCost = dropShip
        ? dockingCollarType === "PROTOTYPE"
          ? 1010000
          : dockingCollarType === "NONE"
            ? 0
            : 10000
        : 0;
      const baysAndDoorsCost = bayDoors * 1000;
      const escapeCraftCost = dropShip
        ? 5000 * (lifeboats + escapePods)
        : 0;

      if (bayDoors > maxBayDoors) {
        validation.push({
          code: "LOCATION_OVER_CAPACITY",
          severity: "error",
          field: "chassis.properties.bayDoors",
          message:
            `${bayDoors} transport-bay doors exceed the current ${maxBayDoors}-door construction limit at ${mass} tons.`
        });
      }

      if (bayDoors < unitCarryingBayCount) {
        validation.push({
          code: "VALUE_INVALID",
          severity: "error",
          field: "chassis.properties.bayDoors",
          message: `${unitCarryingBayCount} unit-carrying transport bay(s) require at least one bay door each; only ${bayDoors} door(s) are assigned.`
        });
      }

      const priceMultiplier = dropShip
        ? configuration === "SPHEROID"
          ? 28
          : 36
        : 1 + mass / 50;
      const costModifiers: CostModifier[] = [
        {
          id: dropShip
            ? "dropship-final-price"
            : "small-craft-final-price",
          label: dropShip
            ? `${configuration === "SPHEROID" ? "Spheroid" : "Aerodyne"} DropShip final multiplier`
            : "Small Craft weight multiplier",
          multiplier: priceMultiplier,
          explanation: dropShip
            ? "Current DropShip price multiplier."
            : `(1 + ${mass}/50).`
        }
      ];

      return {
        massEntries: [
          massEntry("craft-engine", "Drive engine", engineMass, "engine"),
          massEntry("craft-controls", "Controls", controlsMass, "controls"),
          massEntry("craft-fuel", "Fuel + pumps", pumpAdjustedFuelMass, "fuel"),
          massEntry("craft-escape", "Lifeboats / escape pods", escapeCraftMass, "safety"),
          massEntry("craft-heat", "Heat sinks above free allowance", paidHeatSinkMass, "heat"),
          massEntry("craft-transport-bays", "Transport bays / cubicles", transportBayMass, "transport")
        ],
        costEntries: [
          costEntry("craft-bridge", "Bridge", bridgeCost, "controls"),
          costEntry("craft-computer", "Computer", computerCost, "controls"),
          costEntry(
            "craft-life-support-cost",
            "Life Support",
            lifeSupportCost,
            "controls"
          ),
          costEntry("craft-sensors", "Sensors", sensorsCost, "controls"),
          costEntry(
            "craft-fire-control",
            "Fire Control Computer",
            fireControlCost,
            "controls"
          ),
          costEntry(
            "craft-gunnery-control",
            "Gunnery Control Systems",
            gunneryControlCost,
            "controls"
          ),
          costEntry(
            "craft-structure-cost",
            "Structural Integrity",
            structureCost,
            "structure"
          ),
          costEntry(
            "craft-attitude-thruster",
            "Attitude Thruster",
            attitudeThrusterCost,
            "movement"
          ),
          costEntry(
            "craft-landing-gear",
            "Landing Gear",
            landingGearCost,
            "movement"
          ),
          costEntry("craft-engine-cost", "Engine", engineCost, "engine"),
          costEntry("craft-drive-unit", "Drive Unit", driveUnitCost, "engine"),
          costEntry("craft-fuel-tanks", "Fuel Tanks", fuelTankCost, "fuel"),
          costEntry(
            "craft-armor-cost",
            "Armor",
            armorTons * aerospaceArmorCostPerTon(armorType),
            "armor"
          ),
          costEntry(
            "craft-heat-sink-cost",
            "Heat Sinks",
            heatSinkCost,
            "heat"
          ),
          ...(dockingCollarCost > 0
            ? [
                costEntry(
                  "dropship-docking-collar",
                  "Docking Collar",
                  dockingCollarCost,
                  "transport"
                )
              ]
            : []),
          ...(baysAndDoorsCost > 0
            ? [
                costEntry(
                  "dropship-bays",
                  "Transport Bays / Doors",
                  baysAndDoorsCost,
                  "transport"
                )
              ]
            : []),
          ...(escapeCraftCost > 0
            ? [
                costEntry(
                  "dropship-escape-cost",
                  "Lifeboats / Escape Pods",
                  escapeCraftCost,
                  "safety"
                )
              ]
            : [])
        ],
        costModifiers,
        validation,
        derived: {
          safeThrust,
          maximumThrust: Math.ceil(safeThrust * 1.5),
          engineMass,
          controlsMass,
          fuelMassWithPumps: pumpAdjustedFuelMass,
          freeHeatSinks,
          paidHeatSinkMass,
          maxArmorTons,
          armorType,
          armorPointsPerTon,
          paidArmorPoints,
          bonusArmorPoints,
          armorPoints,
          minimumCrew,
          maxBayDoors,
          transportBayMass,
          unitCarryingBayCount,
          bayDoors,
          passengers,
          arcsWithGuns,
          bridgeCost,
          computerCost,
          lifeSupportCost,
          sensorsCost,
          fireControlCost,
          gunneryControlCost,
          structureCost,
          attitudeThrusterCost,
          landingGearCost,
          engineCost,
          driveUnitCost,
          fuelTankCost,
          heatSinkCost,
          dockingCollarCost,
          baysAndDoorsCost,
          escapeCraftCost,
          priceMultiplier,
          weaponSlotsPerArc: 12
        }
      };
    }
  });
}

export const smallCraftConstructor = makeCraft(false);
export const dropShipConstructor = makeCraft(true);
