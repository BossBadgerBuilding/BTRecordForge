import type {
  CostModifier,
  ConstructorDefinition,
  ConstructorEditorSchema,
  ValidationIssue
} from "../core/types";
import {
  fusionEngineBaseWeight
} from "./battlemechRules";
import {
  ceilHalf,
  costEntry,
  makeGenericConstructor,
  massEntry,
  roundHalf
} from "./genericConstructor";

const AERO_LOCATIONS = [
  { id: "NOSE", label: "Nose", capacity: 5 },
  { id: "RW", label: "Right Wing", capacity: 5 },
  { id: "LW", label: "Left Wing", capacity: 5 },
  { id: "AFT", label: "Aft", capacity: 5 },
  { id: "FUSELAGE", label: "Fuselage" }
];

const aerospaceSchema: ConstructorEditorSchema = {
  sections: [
    {
      id: "flight",
      label: "Aerospace Fighter chassis",
      description:
        "Safe thrust drives engine rating. The verified slice also checks the current fighter armor ceiling and standard five weapon slots per firing arc.",
      fields: [
        {
          key: "safeThrust",
          label: "Safe thrust",
          kind: "number",
          defaultValue: 5,
          min: 1,
          step: 1
        },
        {
          key: "primitive",
          label: "Primitive construction",
          kind: "boolean",
          defaultValue: false
        },
        {
          key: "omni",
          label: "OmniFighter",
          kind: "boolean",
          defaultValue: false
        },
        {
          key: "cockpitType",
          label: "Cockpit",
          kind: "select",
          defaultValue: "STANDARD",
          options: [
            { value: "STANDARD", label: "Standard" },
            { value: "SMALL", label: "Small" },
            { value: "COMMAND_CONSOLE", label: "Command Console" },
            { value: "PRIMITIVE", label: "Primitive" }
          ]
        },
        {
          key: "engineType",
          label: "Engine",
          kind: "select",
          defaultValue: "STANDARD_FUSION",
          options: [
            { value: "STANDARD_FUSION", label: "Standard Fusion (auto mass)" },
            { value: "XL_FUSION", label: "XL Fusion (manual mass for now)" },
            { value: "LIGHT_FUSION", label: "Light Fusion (manual mass for now)" },
            { value: "OTHER", label: "Other / special (manual mass)" }
          ]
        },
        {
          key: "manualEngineMass",
          label: "Manual engine mass",
          kind: "number",
          defaultValue: 0,
          min: 0,
          step: 0.5,
          unit: "t",
          help:
            "Used only for Other/special engines. Standard, XL and Light fusion mass are derived automatically."
        },
        {
          key: "manualEngineBaseCost",
          label: "Other engine base-cost factor",
          kind: "number",
          defaultValue: 0,
          min: 0,
          step: 1,
          unit: "C",
          help:
            "Only used for Other/special engines. Standard Fusion = 5,000; XL = 20,000; Light = 15,000."
        }
      ]
    },
    {
      id: "payload",
      label: "Fuel / armor / heat",
      fields: [
        {
          key: "fuelTons",
          label: "Fuel",
          kind: "number",
          defaultValue: 5,
          min: 0,
          step: 0.5,
          unit: "t",
          ledger: "mass",
          ledgerCategory: "fuel"
        },
        {
          key: "armorTons",
          label: "Armor mass",
          kind: "number",
          defaultValue: 4,
          min: 0,
          step: 0.5,
          unit: "t",
          ledger: "mass",
          ledgerCategory: "armor"
        },
        {
          key: "armorPoints",
          label: "Armor points",
          kind: "number",
          defaultValue: 80,
          min: 0,
          step: 1
        },
        {
          key: "heatSinks",
          label: "Heat sinks",
          kind: "number",
          defaultValue: 10,
          min: 0,
          step: 1
        },
        {
          key: "heatSinkType",
          label: "Heat sink type",
          kind: "select",
          defaultValue: "SINGLE",
          options: [
            { value: "SINGLE", label: "Single" },
            { value: "DOUBLE", label: "Double" }
          ]
        }
      ]
    },
    {
      id: "cost",
      label: "Remaining C-bill inputs",
      fields: [
        {
          key: "structuralCost",
          label: "Additional manual system cost",
          kind: "number",
          defaultValue: 0,
          min: 0,
          step: 1,
          unit: "C",
          ledger: "cost",
          ledgerCategory: "chassis",
          help:
            "Optional catch-all. Common fighter cockpit/life-support/sensors/structure/flight/engine/fuel/heat costs are now derived."
        },
        {
          key: "armorCost",
          label: "Armor cost (selected armor type)",
          kind: "number",
          defaultValue: 0,
          min: 0,
          step: 1,
          unit: "C",
          ledger: "cost",
          ledgerCategory: "armor"
        }
      ]
    }
  ],
  placementLocations: AERO_LOCATIONS
};

export const aerospaceFighterConstructor: ConstructorDefinition =
  makeGenericConstructor({
    id: "aero.aerospace-fighter",
    name: "Aerospace Fighter",
    family: "Aerospace",
    description: "Aerospace fighter construction record.",
    coverage: "PARTIAL_RULES",
    defaultMass: 50,
    schema: aerospaceSchema,

    calculateBase(ctx) {
      const mass = ctx.design.chassis.massLimit;
      const safeThrust = Math.max(0, Math.floor(ctx.propertyNumber("safeThrust", 0)));
      const primitive = ctx.propertyBoolean("primitive", false);
      const engineType = ctx.propertyString("engineType", "STANDARD_FUSION");
      const armorPoints = Math.max(0, Math.floor(ctx.propertyNumber("armorPoints", 0)));
      const heatSinks = Math.max(0, Math.floor(ctx.propertyNumber("heatSinks", 0)));

      let engineRating = mass * Math.max(0, safeThrust - 2);
      if (primitive) {
        engineRating = Math.ceil((engineRating * 1.2) / 5) * 5;
      }

      const validation: ValidationIssue[] = [];
      const maxArmorPoints = Math.floor(mass * 8);

      if (armorPoints > maxArmorPoints) {
        validation.push({
          code: "ARMOR_OVER_LIMIT",
          severity: "error",
          field: "chassis.properties.armorPoints",
          message:
            `${armorPoints} armor points exceed the ${maxArmorPoints}-point Aerospace Fighter ceiling at ${mass} tons.`
        });
      }

      let engineMass = ctx.propertyNumber("manualEngineMass", 0);
      let engineMassSource = "manual";
      const baseFusionMass = fusionEngineBaseWeight(engineRating);

      if (engineType === "STANDARD_FUSION") {
        engineMass = baseFusionMass;
        engineMassSource = "standard fusion engine table";
      } else if (engineType === "XL_FUSION") {
        engineMass = ceilHalf(baseFusionMass * 0.5);
        engineMassSource = "XL fusion = 0.5 × standard fusion";
      } else if (engineType === "LIGHT_FUSION") {
        engineMass = ceilHalf(baseFusionMass * 0.75);
        engineMassSource = "Light fusion = 0.75 × standard fusion";
      }

      if (
        engineType !== "OTHER" &&
        engineMass <= 0 &&
        engineRating > 0
      ) {
        validation.push({
          code: "ENGINE_RATING_INVALID",
          severity: "error",
          field: "chassis.properties.safeThrust",
          message:
            `Engine rating ${engineRating} is outside the currently ported fusion-engine table.`
        });
      } else if (
        engineType === "OTHER" &&
        engineMass <= 0 &&
        engineRating > 0
      ) {
        validation.push({
          code: "RULES_IMPLEMENTATION_PARTIAL",
          severity: "info",
          field: "chassis.properties.manualEngineMass",
          message:
            "Other/special fighter engine mass requires Manual engine mass."
        });
      }

      const structureMass = ceilHalf(mass / 10);
      const cockpitType = ctx.propertyString("cockpitType", "STANDARD");
      const controlsMass = cockpitWeight(cockpitType);
      const heatSinkMass = Math.max(0, heatSinks - 10);
      const structuralIntegrity = Math.max(
        Math.floor(mass / 10),
        safeThrust
      );
      const fuelTons = Math.max(
        0,
        ctx.propertyNumber("fuelTons", 0)
      );
      const engineBaseCost = fighterEngineBaseCost(
        engineType,
        ctx.propertyNumber("manualEngineBaseCost", 0)
      );
      const engineCost =
        engineRating > 0 && engineBaseCost > 0
          ? (engineBaseCost * engineRating * mass) / 75
          : 0;
      if (
        engineType === "OTHER" &&
        engineRating > 0 &&
        engineBaseCost <= 0
      ) {
        validation.push({
          code: "COST_INCOMPLETE",
          severity: "info",
          field: "chassis.properties.manualEngineBaseCost",
          message:
            "Other/special engine C-bill cost requires an engine base-cost factor."
        });
      }

      const heatSinkType = ctx.propertyString(
        "heatSinkType",
        "SINGLE"
      );
      const heatSinkCost =
        (heatSinkType === "DOUBLE" ? 6000 : 2000) * heatSinks;
      const omni = ctx.propertyBoolean("omni", false);
      const priceMultiplier = aeroPriceMultiplier(mass, omni);
      const costModifiers: CostModifier[] = [
        {
          id: "aero-final-price",
          label: "Aerospace Fighter final price multiplier",
          multiplier: priceMultiplier,
          explanation:
            `${omni ? "Omni 1.25 × " : ""}(1 + ${mass}/200).`
        }
      ];

      return {
        massEntries: [
          massEntry(
            "aero-structure",
            "Standard Aerospace Structure",
            structureMass,
            "structure"
          ),
          massEntry(
            "aero-engine",
            `Engine (${engineRating})`,
            engineMass,
            "engine",
            engineMassSource
          ),
          massEntry(
            "aero-controls",
            `${prettyCockpit(cockpitType)} Cockpit / Controls`,
            controlsMass,
            "controls"
          ),
          massEntry(
            "aero-extra-heat-sinks",
            "Heat sinks above free engine allowance",
            heatSinkMass,
            "heat"
          )
        ],
        costEntries: [
          costEntry("aero-cockpit", "Cockpit", 200000, "controls"),
          costEntry("aero-life-support", "Life Support", 50000, "controls"),
          costEntry("aero-sensors", "Sensors", 2000 * mass, "controls"),
          costEntry(
            "aero-structure-cost",
            "Structure",
            50000 * structuralIntegrity,
            "structure"
          ),
          costEntry(
            "aero-flight-systems",
            "Additional Flight Systems",
            25000 + 10 * mass,
            "controls"
          ),
          costEntry("aero-engine-cost", "Engine", engineCost, "engine"),
          costEntry("aero-fuel-cost", "Fuel Tanks", fuelTons * 200, "fuel"),
          costEntry(
            "aero-heat-sink-cost",
            "Heat Sinks",
            heatSinkCost,
            "heat"
          )
        ],
        costModifiers,
        validation,
        derived: {
          safeThrust,
          maximumThrust: Math.ceil(safeThrust * 1.5),
          engineRating,
          structureMass,
          structuralIntegrity,
          engineMass,
          engineBaseCost,
          engineCost,
          controlsMass,
          fuelCost: fuelTons * 200,
          heatSinkCost,
          priceMultiplier,
          maxArmorPoints,
          weaponSlotsPerArc: 5
        }
      };
    }
  });

const conventionalSchema: ConstructorEditorSchema = {
  sections: [
    {
      id: "flight",
      label: "Conventional Fighter chassis",
      fields: [
        {
          key: "safeThrust",
          label: "Safe thrust",
          kind: "number",
          defaultValue: 5,
          min: 1,
          step: 1
        },
        {
          key: "primitive",
          label: "Primitive construction",
          kind: "boolean",
          defaultValue: false
        },
        {
          key: "vstol",
          label: "VSTOL equipment",
          kind: "boolean",
          defaultValue: false
        },
        {
          key: "engineType",
          label: "Engine",
          kind: "select",
          defaultValue: "ICE",
          options: [
            { value: "ICE", label: "Internal Combustion" },
            { value: "FUSION", label: "Fusion" },
            { value: "FISSION", label: "Fission" },
            { value: "OTHER", label: "Other" }
          ]
        },
        {
          key: "engineMass",
          label: "Engine mass",
          kind: "number",
          defaultValue: 5,
          min: 0,
          step: 0.5,
          unit: "t",
          ledger: "mass",
          ledgerCategory: "engine"
        },
        {
          key: "manualEngineBaseCost",
          label: "Other/Fission engine base-cost factor",
          kind: "number",
          defaultValue: 0,
          min: 0,
          step: 1,
          unit: "C",
          help:
            "ICE defaults to 1,250 and Fusion to 5,000. Enter a factor for Fission/Other engines until those engine types are fully ported."
        }
      ]
    },
    {
      id: "payload",
      label: "Fuel / armor",
      fields: [
        {
          key: "fuelTons",
          label: "Fuel",
          kind: "number",
          defaultValue: 2,
          min: 0,
          step: 0.5,
          unit: "t",
          ledger: "mass",
          ledgerCategory: "fuel"
        },
        {
          key: "armorTons",
          label: "Armor mass",
          kind: "number",
          defaultValue: 1,
          min: 0,
          step: 0.5,
          unit: "t",
          ledger: "mass",
          ledgerCategory: "armor"
        },
        {
          key: "armorPoints",
          label: "Armor points",
          kind: "number",
          defaultValue: 20,
          min: 0,
          step: 1
        },
        {
          key: "heatSinks",
          label: "Heat sinks",
          kind: "number",
          defaultValue: 0,
          min: 0,
          step: 1
        },
        {
          key: "heatSinkType",
          label: "Heat sink type",
          kind: "select",
          defaultValue: "SINGLE",
          options: [
            { value: "SINGLE", label: "Single" },
            { value: "DOUBLE", label: "Double" }
          ]
        }
      ]
    },
    {
      id: "cost",
      label: "Remaining C-bill inputs",
      fields: [
        {
          key: "baseCost",
          label: "Additional manual system cost",
          kind: "number",
          defaultValue: 0,
          min: 0,
          step: 1,
          unit: "C",
          ledger: "cost",
          ledgerCategory: "chassis",
          help:
            "Common cockpit/life-support/sensors/structure/flight/engine/fuel/heat costs are derived."
        },
        {
          key: "armorCost",
          label: "Armor cost (selected armor type)",
          kind: "number",
          defaultValue: 0,
          min: 0,
          step: 1,
          unit: "C",
          ledger: "cost",
          ledgerCategory: "armor"
        }
      ]
    }
  ],
  placementLocations: AERO_LOCATIONS
};

export const conventionalFighterConstructor: ConstructorDefinition =
  makeGenericConstructor({
    id: "aero.conventional-fighter",
    name: "Conventional Fighter",
    family: "Aerospace",
    description: "Conventional atmospheric fighter construction record.",
    coverage: "PARTIAL_RULES",
    defaultMass: 30,
    schema: conventionalSchema,

    calculateBase(ctx) {
      const mass = ctx.design.chassis.massLimit;
      const safeThrust = Math.max(0, Math.floor(ctx.propertyNumber("safeThrust", 0)));
      const primitive = ctx.propertyBoolean("primitive", false);
      const engineType = ctx.propertyString("engineType", "ICE");
      const armorPoints = Math.max(0, Math.floor(ctx.propertyNumber("armorPoints", 0)));
      const heatSinks = Math.max(
        0,
        Math.floor(ctx.propertyNumber("heatSinks", 0))
      );

      let engineRating = mass * safeThrust;
      if (primitive) {
        engineRating = Math.ceil((engineRating * 1.2) / 5) * 5;
      }

      const maxArmorPoints = Math.floor(mass);
      const validation: ValidationIssue[] = [];

      if (armorPoints > maxArmorPoints) {
        validation.push({
          code: "ARMOR_OVER_LIMIT",
          severity: "error",
          field: "chassis.properties.armorPoints",
          message:
            `${armorPoints} armor points exceed the ${maxArmorPoints}-point Conventional Fighter ceiling at ${mass} tons.`
        });
      }

      const structureMass = ceilHalf(mass / 10);
      const controlsMass = roundHalf(mass * 0.10);
      const vstolMass = ctx.propertyBoolean("vstol", false)
        ? ceilHalf(mass * 0.05)
        : 0;

      const structuralIntegrity = Math.max(
        Math.floor(mass / 10),
        safeThrust
      );
      const fuelTons = Math.max(
        0,
        ctx.propertyNumber("fuelTons", 0)
      );
      const manualBaseCost = Math.max(
        0,
        ctx.propertyNumber("manualEngineBaseCost", 0)
      );
      const engineBaseCost =
        engineType === "ICE"
          ? 1250
          : engineType === "FUSION"
            ? 5000
            : manualBaseCost;
      const engineCost =
        engineRating > 0 && engineBaseCost > 0
          ? (engineBaseCost * engineRating * mass) / 75
          : 0;

      if (
        (engineType === "FISSION" || engineType === "OTHER") &&
        engineRating > 0 &&
        engineBaseCost <= 0
      ) {
        validation.push({
          code: "COST_INCOMPLETE",
          severity: "info",
          field: "chassis.properties.manualEngineBaseCost",
          message:
            `${engineType === "FISSION" ? "Fission" : "Other"} engine C-bill cost requires an engine base-cost factor.`
        });
      }

      const heatSinkType = ctx.propertyString(
        "heatSinkType",
        "SINGLE"
      );
      const heatSinkCost =
        (heatSinkType === "DOUBLE" ? 6000 : 2000) * heatSinks;
      const priceMultiplier = aeroPriceMultiplier(mass, false);
      const costModifiers: CostModifier[] = [
        {
          id: "conventional-fighter-final-price",
          label: "Conventional Fighter final price multiplier",
          multiplier: priceMultiplier,
          explanation: `(1 + ${mass}/200).`
        }
      ];

      return {
        massEntries: [
          massEntry(
            "conv-structure",
            "Standard Fighter Structure",
            structureMass,
            "structure"
          ),
          massEntry(
            "conv-controls",
            "Controls",
            controlsMass,
            "controls"
          ),
          ...(vstolMass > 0
            ? [
                massEntry(
                  "conv-vstol",
                  "VSTOL Equipment",
                  vstolMass,
                  "movement"
                )
              ]
            : [])
        ],
        costEntries: [
          costEntry("conv-cockpit", "Cockpit", 200000, "controls"),
          costEntry("conv-life-support", "Life Support", 50000, "controls"),
          costEntry("conv-sensors", "Sensors", 2000 * mass, "controls"),
          costEntry(
            "conv-structure-cost",
            "Structure",
            50000 * structuralIntegrity,
            "structure"
          ),
          costEntry(
            "conv-flight-systems",
            "Additional Flight Systems",
            25000 + 10 * mass,
            "controls"
          ),
          costEntry("conv-engine-cost", "Engine", engineCost, "engine"),
          costEntry("conv-fuel-cost", "Fuel Tanks", fuelTons * 200, "fuel"),
          costEntry(
            "conv-heat-sink-cost",
            "Heat Sinks",
            heatSinkCost,
            "heat"
          )
        ],
        costModifiers,
        validation,
        derived: {
          safeThrust,
          maximumThrust: Math.ceil(safeThrust * 1.5),
          engineRating,
          structuralIntegrity,
          engineBaseCost,
          engineCost,
          fuelCost: fuelTons * 200,
          heatSinkCost,
          priceMultiplier,
          maxArmorPoints,
          structureMass,
          controlsMass,
          vstolMass,
          weaponSlotsPerArc: 5
        }
      };
    }
  });

export function aeroPriceMultiplier(
  mass: number,
  omni: boolean
): number {
  return (omni ? 1.25 : 1) * (1 + mass / 200);
}

export function fighterEngineBaseCost(
  engineType: string,
  manualBaseCost = 0
): number {
  switch (engineType) {
    case "STANDARD_FUSION":
      return 5000;
    case "XL_FUSION":
      return 20000;
    case "LIGHT_FUSION":
      return 15000;
    default:
      return Math.max(0, manualBaseCost);
  }
}

function cockpitWeight(value: string): number {
  switch (value) {
    case "SMALL": return 2;
    case "COMMAND_CONSOLE": return 6;
    case "PRIMITIVE": return 5;
    default: return 3;
  }
}

function prettyCockpit(value: string): string {
  return {
    STANDARD: "Standard",
    SMALL: "Small",
    COMMAND_CONSOLE: "Command Console",
    PRIMITIVE: "Primitive"
  }[value] ?? value;
}
