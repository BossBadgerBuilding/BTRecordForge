import type {
  ConstructorDefinition,
  ConstructorEditorSchema,
  ValidationIssue
} from "../core/types";
import {
  costEntry,
  makeGenericConstructor,
  massEntry
} from "./genericConstructor";

const INFANTRY_LOCATIONS = [
  { id: "FORMATION", label: "Formation" },
  { id: "SQUAD", label: "Squad / Platoon Equipment" },
  { id: "FIELD_GUNS", label: "Field Guns" },
  { id: "TRANSPORT", label: "Transport / Motive Equipment" }
];

const INFANTRY_ARMOR = {
  NONE: { label: "None", cost: 0, tech: "BOTH" },
  ABLATIVE_STANDARD: { label: "Ablative, Standard", cost: 1000, tech: "BOTH" },
  ABLATIVE_CONCEALED: { label: "Ablative, Concealed", cost: 1500, tech: "IS" },
  ABLATIVE_FLAK_STANDARD: { label: "Ablative/Flak, Standard", cost: 800, tech: "BOTH" },
  ABLATIVE_FLAK_CONCEALED: { label: "Ablative/Flak, Concealed", cost: 1400, tech: "IS" },
  BALLISTIC_PLATE_STANDARD: { label: "Ballistic Plate, Standard", cost: 1600, tech: "BOTH" },
  BALLISTIC_PLATE_CONCEALED: { label: "Ballistic Plate, Concealed", cost: 2880, tech: "IS" },
  CLOTHING: { label: "Clothing, Fatigues/Civilian", cost: 25, tech: "BOTH" },
  LEATHER: { label: "Clothing, Leather/Synthetic Hide", cost: 100, tech: "BOTH" },
  LIGHT_CLOTHING: { label: "Clothing, Light", cost: 15, tech: "BOTH" },
  ENGINEERING_SUIT: { label: "Engineering Suit", cost: 7500, tech: "BOTH" },
  ENVIRONMENT_SUIT_LIGHT: { label: "Environment Suit, Light", cost: 200, tech: "BOTH" },
  ENVIRONMENT_SUIT_HOSTILE: { label: "Environment Suit, Hostile", cost: 10000, tech: "BOTH" },
  ENVIRONMENT_SUIT_MARINE: { label: "Environment Suit, Marine", cost: 15000, tech: "BOTH" },
  FLAK_STANDARD: { label: "Flak, Standard", cost: 150, tech: "BOTH" },
  FLAK_CONCEALED: { label: "Flak, Concealed", cost: 225, tech: "IS" },
  HEATSUIT: { label: "Heatsuit", cost: 100, tech: "BOTH" },
  MECHWARRIOR_COMBAT: { label: "MechWarrior Combat Suit", cost: 20000, tech: "BOTH" },
  MECHWARRIOR_COOLING: { label: "MechWarrior Cooling Suit", cost: 5000, tech: "BOTH" },
  MECHWARRIOR_VEST: { label: "MechWarrior Cooling Vest", cost: 200, tech: "BOTH" },
  MYOMER_SUIT: { label: "Myomer Suit", cost: 5800, tech: "IS" },
  MYOMER_VEST: { label: "Myomer Vest", cost: 1800, tech: "IS" },
  PARKA: { label: "Parka", cost: 50, tech: "BOTH" },
  NEO_CHAINMAIL: { label: "Neo-Chainmail", cost: 920, tech: "IS" },
  SNOWSUIT: { label: "Snowsuit", cost: 70, tech: "BOTH" },
  SPACESUIT: { label: "Spacesuit", cost: 5000, tech: "BOTH" },
  SPACESUIT_COMBAT: { label: "Spacesuit, Combat", cost: 7000, tech: "BOTH" },
  KIT_CAPELLAN: { label: "Faction Kit: Capellan Confederation", cost: 450, tech: "IS" },
  KIT_CLAN: { label: "Faction Kit: Clan", cost: 5560, tech: "CLAN" },
  KIT_COMSTAR: { label: "Faction Kit: ComStar", cost: 4280, tech: "IS" },
  KIT_DRACONIS: { label: "Faction Kit: Draconis Combine", cost: 360, tech: "IS" },
  KIT_FEDERATED_SUNS: { label: "Faction Kit: Federated Suns", cost: 750, tech: "IS" },
  KIT_FEDCOM_3030: { label: "Faction Kit: Federated Suns/Commonwealth (3030+)", cost: 1040, tech: "IS" },
  KIT_FEDERATED_SUNS_3067: { label: "Faction Kit: Federated Suns (3067+)", cost: 2080, tech: "IS" },
  KIT_FRR: { label: "Faction Kit: Free Rasalhague Republic", cost: 360, tech: "IS" },
  KIT_FWL: { label: "Faction Kit: Free Worlds League", cost: 950, tech: "IS" },
  KIT_FWL_3035: { label: "Faction Kit: Free Worlds League (3035+)", cost: 1830, tech: "IS" },
  KIT_LYRAN: { label: "Faction Kit: Lyran Alliance/Commonwealth", cost: 650, tech: "IS" },
  KIT_LYRAN_3060: { label: "Faction Kit: Lyran Alliance (3060+)", cost: 730, tech: "IS" },
  KIT_CANOPUS: { label: "Faction Kit: Magistracy of Canopus", cost: 400, tech: "IS" },
  KIT_MARIAN: { label: "Faction Kit: Marian Hegemony", cost: 1580, tech: "IS" },
  KIT_TAURIAN: { label: "Faction Kit: Taurian Concordat/Calderon", cost: 370, tech: "IS" },
  KIT_WOB: { label: "Faction Kit: Word of Blake", cost: 4300, tech: "IS" },
  KIT_GENERIC: { label: "Faction Kit: Other Periphery/Generic", cost: 330, tech: "BOTH" },
  DEST: { label: "DEST Infiltration Suit", cost: 50000, tech: "IS" },
  SNEAK_ONE: { label: "Sneak Suit (One system)", cost: 7000, tech: "BOTH" },
  SNEAK_TWO: { label: "Sneak Suit (Two systems)", cost: 21000, tech: "BOTH" },
  SNEAK_THREE: { label: "Sneak Suit (Three systems)", cost: 28000, tech: "BOTH" }
} as const;

const infantrySchema: ConstructorEditorSchema = {
  sections: [
    {
      id: "formation",
      label: "Conventional Infantry",
      fields: [
        {
          key: "troopers",
          label: "Troopers in platoon",
          kind: "number",
          defaultValue: 28,
          min: 1,
          step: 1
        },
        {
          key: "squadSize",
          label: "Squad size",
          kind: "number",
          defaultValue: 7,
          min: 1,
          step: 1
        },
        {
          key: "motiveType",
          label: "Base motive type",
          kind: "select",
          defaultValue: "FOOT",
          options: [
            { value: "FOOT", label: "Foot / Jump / Motorized / Other" },
            { value: "HOVER", label: "Hover" },
            { value: "SUBMARINE", label: "Submarine / SCUBA" },
            { value: "WHEELED", label: "Wheeled" },
            { value: "TRACKED", label: "Tracked" },
            { value: "UMU", label: "UMU" },
            { value: "VTOL", label: "VTOL" }
          ]
        },
        {
          key: "alternateMotiveLimit",
          label: "Microlite / alternate UMU limit",
          kind: "boolean",
          defaultValue: false,
          help:
            "Applies the smaller alternate squad/platoon limits used by microlites or multiple UMUs."
        },
        {
          key: "engineeringOrMountain",
          label: "Engineering / mountain platoon",
          kind: "boolean",
          defaultValue: false
        },
        {
          key: "costMotive",
          label: "Cost motive system",
          kind: "select",
          defaultValue: "FOOT",
          options: [
            { value: "FOOT", label: "Foot" },
            { value: "MOTORIZED", label: "Motorized" },
            { value: "JUMP", label: "Jump" },
            { value: "MECHANIZED", label: "Mechanized (Hover/Wheeled/Tracked)" }
          ]
        },
        {
          key: "antiMechTraining",
          label: "Anti-'Mech training",
          kind: "boolean",
          defaultValue: false
        },
        {
          key: "specialization",
          label: "Specialized infantry",
          kind: "select",
          defaultValue: "NONE",
          options: [
            { value: "NONE", label: "None" },
            { value: "COMBAT_ENGINEERS", label: "Combat Engineers" },
            { value: "MARINES", label: "Marines" },
            { value: "MOUNTAIN", label: "Mountain Troops" },
            { value: "PARATROOPS", label: "Paratroops" },
            { value: "SCUBA_STANDARD", label: "SCUBA (Standard)" },
            { value: "SCUBA_MOTORIZED", label: "SCUBA (Motorized)" },
            { value: "XCT", label: "Xenoplanetary Condition-Trained" }
          ]
        },
        {
          key: "primaryWeaponName",
          label: "Primary weapon / kit",
          kind: "text",
          defaultValue: ""
        },
        {
          key: "secondaryWeaponName",
          label: "Secondary weapon / kit",
          kind: "text",
          defaultValue: ""
        },
        {
          key: "primaryWeaponActualCost",
          label: "Primary weapon actual C-bill cost",
          kind: "number",
          defaultValue: 0,
          min: 0,
          step: 1,
          unit: "C",
          help:
            "Used by the current InfantryCostCalculator square-root weapon pricing formula."
        },
        {
          key: "secondaryWeaponActualCost",
          label: "Secondary weapon actual C-bill cost",
          kind: "number",
          defaultValue: 0,
          min: 0,
          step: 1,
          unit: "C"
        },
        {
          key: "secondaryWeaponsPerSquad",
          label: "Secondary weapons / squad",
          kind: "number",
          defaultValue: 0,
          min: 0,
          step: 1
        }
      ]
    },
    {
      id: "ledger",
      label: "Construction ledger",
      description:
        "Formation mass remains editable. Weapon/armor base cost is now partially derived from explicit prices; motive/training/specialization details stay in the price multiplier.",
      fields: [
        {
          key: "formationMass",
          label: "Formation mass",
          kind: "number",
          defaultValue: 0,
          min: 0,
          step: 0.001,
          unit: "t",
          ledger: "mass",
          ledgerCategory: "personnel"
        },
        {
          key: "infantryArmor",
          label: "Infantry armor / kit",
          kind: "select",
          defaultValue: "NONE",
          options: Object.entries(INFANTRY_ARMOR).map(([value, row]) => ({
            value,
            label: `${row.label} (${row.cost.toLocaleString()} C/trooper)`
          }))
        },
        {
          key: "priceMultiplier",
          label: "Infantry price multiplier",
          kind: "number",
          defaultValue: 1,
          min: 0,
          step: 0.01,
          help:
            "Optional custom multiplier applied after the official motive/training/specialization multipliers."
        },
        {
          key: "fieldGunCost",
          label: "Field-gun total cost",
          kind: "number",
          defaultValue: 0,
          min: 0,
          step: 1,
          unit: "C"
        },
        {
          key: "mountedInfantry",
          label: "Include mount cost",
          kind: "boolean",
          defaultValue: false,
          help:
            "Current MegaMek infantry mount cost is 5,000 C-bills times formation weight."
        },
        {
          key: "augmentationCostPerTrooper",
          label: "Augmentation cost / trooper",
          kind: "number",
          defaultValue: 0,
          min: 0,
          step: 1,
          unit: "C"
        },
        {
          key: "formationCost",
          label: "Additional manual formation cost",
          kind: "number",
          defaultValue: 0,
          min: 0,
          step: 1,
          unit: "C",
          ledger: "cost",
          ledgerCategory: "personnel"
        }
      ]
    }
  ],
  placementLocations: INFANTRY_LOCATIONS
};

export const infantryConstructor: ConstructorDefinition =
  makeGenericConstructor({
    id: "infantry.conventional",
    name: "Conventional Infantry",
    family: "Infantry",
    description: "Conventional infantry platoon construction record.",
    coverage: "RULES_IMPLEMENTED",
    defaultMass: 0,
    enforceMassLimit: false,
    schema: infantrySchema,

    calculateBase(ctx) {
      const troopers = Math.max(
        1,
        Math.floor(ctx.propertyNumber("troopers", 1))
      );
      const squadSize = Math.max(
        1,
        Math.floor(ctx.propertyNumber("squadSize", 1))
      );
      const motive = ctx.propertyString("motiveType", "FOOT");
      const alt = ctx.propertyBoolean("alternateMotiveLimit", false);
      const engineering = ctx.propertyBoolean(
        "engineeringOrMountain",
        false
      );
      const maxSquad = infantryMaxSquadSize(motive, alt);
      const maxPlatoon = infantryMaxPlatoonSize(
        motive,
        alt,
        engineering
      );
      const validation: ValidationIssue[] = [];

      if (squadSize > maxSquad) {
        validation.push({
          code: "VALUE_INVALID",
          severity: "error",
          field: "chassis.properties.squadSize",
          message:
            `${prettyInfantryMotive(motive)} infantry squads are limited to ${maxSquad} troopers with the selected construction options.`
        });
      }

      if (troopers > maxPlatoon) {
        validation.push({
          code: "VALUE_INVALID",
          severity: "error",
          field: "chassis.properties.troopers",
          message:
            `${prettyInfantryMotive(motive)} infantry platoons are limited to ${maxPlatoon} troopers with the selected construction options.`
        });
      }

      const secondaryPerSquad = Math.max(
        0,
        Math.floor(ctx.propertyNumber("secondaryWeaponsPerSquad", 0))
      );
      if (secondaryPerSquad > squadSize) {
        validation.push({
          code: "VALUE_INVALID",
          severity: "error",
          field: "chassis.properties.secondaryWeaponsPerSquad",
          message:
            `Secondary weapons per squad (${secondaryPerSquad}) cannot exceed squad size (${squadSize}).`
        });
      }

      const squadCount = Math.ceil(troopers / squadSize);
      const primaryTroopers = Math.min(
        troopers,
        Math.max(0, squadSize - secondaryPerSquad) * squadCount
      );
      const secondaryTroopers = Math.max(
        0,
        troopers - primaryTroopers
      );

      const primaryActualCost = Math.max(
        0,
        ctx.propertyNumber("primaryWeaponActualCost", 0)
      );
      const secondaryActualCost = Math.max(
        0,
        ctx.propertyNumber("secondaryWeaponActualCost", 0)
      );
      const primarySyntheticCost =
        primaryActualCost > 0 ? Math.sqrt(primaryActualCost) * 2000 : 0;
      const secondarySyntheticCost =
        secondaryActualCost > 0 ? Math.sqrt(secondaryActualCost) * 2000 : 0;
      const weaponsCost =
        primaryTroopers * primarySyntheticCost +
        secondaryTroopers * secondarySyntheticCost;
      const infantryArmorKey = ctx.propertyString("infantryArmor", "NONE") as keyof typeof INFANTRY_ARMOR;
      const infantryArmor = INFANTRY_ARMOR[infantryArmorKey] ?? INFANTRY_ARMOR.NONE;
      const armorCost = troopers * infantryArmor.cost;
      if (
        (infantryArmor.tech === "IS" && ctx.design.rules.techBase === "CLAN") ||
        (infantryArmor.tech === "CLAN" && ctx.design.rules.techBase === "INNER_SPHERE")
      ) {
        validation.push({
          code: "TECH_BASE_ILLEGAL",
          severity: "error",
          field: "chassis.properties.infantryArmor",
          message: `${infantryArmor.label} is not available to the selected technology base.`
        });
      }
      const customMultiplier = Math.max(
        0,
        ctx.propertyNumber("priceMultiplier", 1)
      );
      const costMotive = ctx.propertyString("costMotive", "FOOT");
      const motiveMultiplier =
        costMotive === "MOTORIZED" ? 1.6 :
        costMotive === "JUMP" ? 2.6 :
        costMotive === "MECHANIZED" ? 3.2 : 1;
      const antiMechMultiplier =
        ctx.propertyBoolean("antiMechTraining", false) ? 5 : 1;
      const specialization = ctx.propertyString("specialization", "NONE");
      const specializationMultiplier = ({
        NONE: 1,
        COMBAT_ENGINEERS: 5,
        MARINES: 3,
        MOUNTAIN: 2,
        PARATROOPS: 3,
        SCUBA_STANDARD: 2,
        SCUBA_MOTORIZED: 2.5,
        XCT: 1.5
      } as Record<string, number>)[specialization] ?? 1;
      const priceMultiplier =
        motiveMultiplier * antiMechMultiplier *
        specializationMultiplier * customMultiplier;
      const baseCostAfterMultiplier =
        (weaponsCost + armorCost) * priceMultiplier;
      const fieldGunCost = Math.max(
        0,
        ctx.propertyNumber("fieldGunCost", 0)
      );
      const formationMass = Math.max(
        0,
        ctx.propertyNumber("formationMass", 0)
      );
      const mountCost = ctx.propertyBoolean("mountedInfantry", false)
        ? 5000 * formationMass
        : 0;
      const augmentationCost =
        troopers *
        Math.max(0, ctx.propertyNumber("augmentationCostPerTrooper", 0));

      return {
        costEntries: [
          costEntry(
            "infantry-weapons-armor",
            "Weapons + armor after infantry price multiplier",
            baseCostAfterMultiplier,
            "personnel",
            `(${weaponsCost.toFixed(2)} C weapons + ${armorCost.toFixed(2)} C armor) × ${priceMultiplier}.`
          ),
          ...(fieldGunCost > 0
            ? [
                costEntry(
                  "infantry-field-guns",
                  "Field Guns",
                  fieldGunCost,
                  "weapon"
                )
              ]
            : []),
          ...(mountCost > 0
            ? [
                costEntry(
                  "infantry-mount",
                  "Infantry Mount",
                  mountCost,
                  "transport"
                )
              ]
            : []),
          ...(augmentationCost > 0
            ? [
                costEntry(
                  "infantry-augmentations",
                  "Augmentations",
                  augmentationCost,
                  "personnel"
                )
              ]
            : [])
        ],
        validation,
        derived: {
          troopers,
          squadSize,
          squads: squadCount,
          primaryTroopers,
          secondaryTroopers,
          primarySyntheticWeaponCost: primarySyntheticCost,
          secondarySyntheticWeaponCost: secondarySyntheticCost,
          weaponsCost,
          armorType: infantryArmor.label,
          armorCostPerTrooper: infantryArmor.cost,
          armorCost,
          priceMultiplier,
          motiveCostMultiplier: motiveMultiplier,
          antiMechTrainingMultiplier: antiMechMultiplier,
          specialization,
          specializationMultiplier,
          mountCost,
          augmentationCost,
          motiveType: prettyInfantryMotive(motive),
          maximumSquadSize: maxSquad,
          maximumPlatoonSize: maxPlatoon
        }
      };
    }
  });

export function infantryMaxSquadSize(
  motive: string,
  alternate: boolean
): number {
  switch (motive) {
    case "HOVER":
    case "SUBMARINE":
      return 5;
    case "WHEELED":
      return 6;
    case "TRACKED":
      return 7;
    case "UMU":
      return alternate ? 6 : 10;
    case "VTOL":
      return alternate ? 2 : 4;
    default:
      return 10;
  }
}

export function infantryMaxPlatoonSize(
  motive: string,
  alternate: boolean,
  engineeringOrMountain: boolean
): number {
  let max: number;
  switch (motive) {
    case "UMU":
      max = alternate ? 12 : 30;
      break;
    case "HOVER":
    case "SUBMARINE":
      max = 20;
      break;
    case "WHEELED":
      max = 24;
      break;
    case "TRACKED":
      max = 28;
      break;
    case "VTOL":
      max = infantryMaxSquadSize(motive, alternate) * 4;
      break;
    default:
      max = 30;
      break;
  }
  return engineeringOrMountain ? Math.min(max, 20) : max;
}

function prettyInfantryMotive(value: string): string {
  return {
    FOOT: "Foot/standard",
    HOVER: "Hover",
    SUBMARINE: "Submarine/SCUBA",
    WHEELED: "Wheeled",
    TRACKED: "Tracked",
    UMU: "UMU",
    VTOL: "VTOL"
  }[value] ?? value;
}

const BA_LOCATIONS = [
  { id: "SUIT", label: "Suit / Body" },
  { id: "LEFT_ARM", label: "Left Arm" },
  { id: "RIGHT_ARM", label: "Right Arm" },
  { id: "BODY", label: "Body Mount" },
  { id: "TURRET", label: "Turret" }
];

const BA_CLASS = {
  ULTRALIGHT: {
    index: 0,
    label: "PA(L) / Ultra-Light",
    maxMass: 0.4,
    maxArmor: 2
  },
  LIGHT: {
    index: 1,
    label: "Light",
    maxMass: 0.75,
    maxArmor: 6
  },
  MEDIUM: {
    index: 2,
    label: "Medium",
    maxMass: 1.0,
    maxArmor: 10
  },
  HEAVY: {
    index: 3,
    label: "Heavy",
    maxMass: 1.5,
    maxArmor: 14
  },
  ASSAULT: {
    index: 4,
    label: "Assault",
    maxMass: 2.0,
    maxArmor: 18
  }
} as const;

const IS_CHASSIS = [0.08, 0.1, 0.175, 0.3, 0.55] as const;
const CLAN_CHASSIS = [0.13, 0.15, 0.25, 0.4, 0.7] as const;
const EXTRA_GROUND_MP = [0.025, 0.03, 0.04, 0.08, 0.16] as const;
const JUMP_MP_MASS = [0.025, 0.025, 0.05, 0.125, 0.25] as const;
const VTOL_MP_MASS = [0.03, 0.04, 0.06, 0, 0] as const;
const UMU_MP_MASS = [0.045, 0.045, 0.085, 0.16, 0.25] as const;

const battleArmorSchema: ConstructorEditorSchema = {
  sections: [
    {
      id: "suit",
      label: "Battle Armor suit",
      fields: [
        {
          key: "weightClass",
          label: "Weight class",
          kind: "select",
          defaultValue: "MEDIUM",
          options: [
            { value: "ULTRALIGHT", label: "PA(L) / Ultra-Light" },
            { value: "LIGHT", label: "Light" },
            { value: "MEDIUM", label: "Medium" },
            { value: "HEAVY", label: "Heavy" },
            { value: "ASSAULT", label: "Assault" }
          ]
        },
        {
          key: "chassisType",
          label: "Chassis type",
          kind: "select",
          defaultValue: "BIPED",
          options: [
            { value: "BIPED", label: "Biped" },
            { value: "QUAD", label: "Quad" }
          ]
        },
        {
          key: "troopers",
          label: "Troopers / suits",
          kind: "number",
          defaultValue: 4,
          min: 1,
          step: 1
        },
        {
          key: "groundMP",
          label: "Ground MP",
          kind: "number",
          defaultValue: 2,
          min: 0,
          step: 1
        },
        {
          key: "secondaryMotive",
          label: "Secondary motive system",
          kind: "select",
          defaultValue: "NONE",
          options: [
            { value: "NONE", label: "None" },
            { value: "JUMP", label: "Jump Jets" },
            { value: "VTOL", label: "VTOL" },
            { value: "UMU", label: "UMU" }
          ]
        },
        {
          key: "secondaryMP",
          label: "Jump / VTOL / UMU MP",
          kind: "number",
          defaultValue: 0,
          min: 0,
          step: 1
        },
        {
          key: "armorPointsPerSuit",
          label: "Standard armor points / suit",
          kind: "number",
          defaultValue: 8,
          min: 0,
          step: 1
        },
        {
          key: "armorType",
          label: "Battle Armor armor type",
          kind: "select",
          defaultValue: "STANDARD",
          options: [
            { value: "STANDARD", label: "Standard" },
            { value: "STANDARD_ADVANCED", label: "Standard (Advanced, IS)" },
            { value: "STANDARD_PROTOTYPE", label: "Standard (Prototype, IS)" },
            { value: "STEALTH_BASIC", label: "Stealth (Basic)" },
            { value: "STEALTH_STANDARD", label: "Stealth (Standard)" },
            { value: "STEALTH_IMPROVED", label: "Stealth (Improved)" },
            { value: "STEALTH_PROTOTYPE", label: "Stealth (Prototype, IS)" },
            { value: "FIRE_RESISTANT", label: "Fire Resistant (Clan)" },
            { value: "MIMETIC", label: "Mimetic (IS)" }
          ]
        },
        {
          key: "leftManipulator",
          label: "Left manipulator",
          kind: "select",
          defaultValue: "NONE",
          options: [
            { value: "NONE", label: "None" }, { value: "ARMORED_GLOVE", label: "Armored Glove" },
            { value: "BASIC", label: "Basic Manipulator" }, { value: "BASIC_MINE", label: "Basic (Mine Clearance)" },
            { value: "BATTLE_CLAW", label: "Battle Claw" }, { value: "BATTLE_CLAW_MAGNETS", label: "Battle Claw (Magnets)" },
            { value: "BATTLE_CLAW_VIBRO", label: "Battle Claw (Vibro)" }, { value: "HEAVY_CLAW", label: "Heavy Battle Claw" },
            { value: "HEAVY_CLAW_MAGNETS", label: "Heavy Claw (Magnets)" }, { value: "HEAVY_CLAW_VIBRO", label: "Heavy Claw (Vibro)" },
            { value: "SALVAGE_ARM", label: "Salvage Arm" }, { value: "INDUSTRIAL_DRILL", label: "Industrial Drill" },
            { value: "CARGO_LIFTER", label: "Cargo Lifter" }, { value: "MODULAR_ADAPTOR", label: "Modular Equipment Adaptor" }
          ]
        },
        {
          key: "rightManipulator",
          label: "Right manipulator",
          kind: "select",
          defaultValue: "NONE",
          options: [
            { value: "NONE", label: "None" }, { value: "ARMORED_GLOVE", label: "Armored Glove" },
            { value: "BASIC", label: "Basic Manipulator" }, { value: "BASIC_MINE", label: "Basic (Mine Clearance)" },
            { value: "BATTLE_CLAW", label: "Battle Claw" }, { value: "BATTLE_CLAW_MAGNETS", label: "Battle Claw (Magnets)" },
            { value: "BATTLE_CLAW_VIBRO", label: "Battle Claw (Vibro)" }, { value: "HEAVY_CLAW", label: "Heavy Battle Claw" },
            { value: "HEAVY_CLAW_MAGNETS", label: "Heavy Claw (Magnets)" }, { value: "HEAVY_CLAW_VIBRO", label: "Heavy Claw (Vibro)" },
            { value: "SALVAGE_ARM", label: "Salvage Arm" }, { value: "INDUSTRIAL_DRILL", label: "Industrial Drill" },
            { value: "CARGO_LIFTER", label: "Cargo Lifter" }, { value: "MODULAR_ADAPTOR", label: "Modular Equipment Adaptor" }
          ]
        },
        {
          key: "turretCapacity",
          label: "Turret capacity (slots)",
          kind: "number",
          defaultValue: 0,
          min: 0,
          step: 1
        },
        {
          key: "modularTurret",
          label: "Modular turret mount",
          kind: "boolean",
          defaultValue: false
        }
      ]
    },
    {
      id: "cost",
      label: "Battle Armor C-bill inputs",
      description:
        "Chassis, motive, armor, manipulators, Clan multiplier and optional training are derived from TechManual.",
      fields: [
        {
          key: "augmentationCostPerSuit",
          label: "Augmentation cost / suit",
          kind: "number",
          defaultValue: 0,
          min: 0,
          step: 1,
          unit: "C"
        },
        {
          key: "additionalCostPerSuit",
          label: "Additional custom cost / suit",
          kind: "number",
          defaultValue: 0,
          min: 0,
          step: 1,
          unit: "C"
        },
        {
          key: "includeTraining",
          label: "Include training / Clan structure pricing",
          kind: "boolean",
          defaultValue: false
        }
      ]
    }
  ],
  placementLocations: BA_LOCATIONS
};

export const battleArmorConstructor: ConstructorDefinition =
  makeGenericConstructor({
    id: "infantry.battle-armor",
    name: "Battle Armor",
    family: "Infantry",
    description: "Battle Armor suit/squad construction record.",
    coverage: "RULES_IMPLEMENTED",
    defaultMass: 1,
    schema: battleArmorSchema,

    calculateBase(ctx) {
      const rawClass = ctx.propertyString("weightClass", "MEDIUM");
      const classKey =
        rawClass === "PA_L" ? "LIGHT" : rawClass;
      const cls =
        BA_CLASS[classKey as keyof typeof BA_CLASS] ?? BA_CLASS.MEDIUM;
      const index = cls.index;
      const quad = ctx.propertyString("chassisType", "BIPED") === "QUAD";
      const troopers = Math.max(
        1,
        Math.floor(ctx.propertyNumber("troopers", 1))
      );
      const groundMP = Math.max(
        0,
        Math.floor(ctx.propertyNumber("groundMP", 0))
      );
      const motive = ctx.propertyString("secondaryMotive", "NONE");
      const secondaryMP = Math.max(
        0,
        Math.floor(ctx.propertyNumber("secondaryMP", 0))
      );
      const armorPoints = Math.max(
        0,
        Math.floor(ctx.propertyNumber("armorPointsPerSuit", 0))
      );
      const turretCapacity = Math.max(
        0,
        Math.floor(ctx.propertyNumber("turretCapacity", 0))
      );
      const modularTurret = ctx.propertyBoolean("modularTurret", false);
      const validation: ValidationIssue[] = [];

      const chassisMass =
        ctx.design.rules.techBase === "CLAN"
          ? CLAN_CHASSIS[index]
          : IS_CHASSIS[index];

      const freeGroundMP = quad ? 2 : 1;
      const groundMPMass =
        Math.max(0, groundMP - freeGroundMP) *
        EXTRA_GROUND_MP[index];

      const secondaryMassPerMP =
        motive === "VTOL"
          ? VTOL_MP_MASS[index]
          : motive === "UMU"
            ? UMU_MP_MASS[index]
            : motive === "JUMP"
              ? JUMP_MP_MASS[index]
              : 0;
      const secondaryMotiveMass =
        motive === "NONE" ? 0 : secondaryMP * secondaryMassPerMP;

      const armorType = ctx.propertyString("armorType", "STANDARD");
      const armorSpec = baArmorSpec(armorType, ctx.design.rules.techBase);
      const armorKgPerPoint = armorSpec.kg;
      const armorMass = armorPoints * armorKgPerPoint / 1000;
      if (!armorSpec.legal) {
        validation.push({
          code: "TECH_BASE_MISMATCH",
          severity: "error",
          field: "chassis.properties.armorType",
          message: `${armorType.replaceAll("_", " ")} is not available to ${ctx.design.rules.techBase} Battle Armor.`
        });
      }
      const leftManipulator = ctx.propertyString("leftManipulator", "NONE");
      const rightManipulator = ctx.propertyString("rightManipulator", "NONE");
      if (quad && (leftManipulator !== "NONE" || rightManipulator !== "NONE")) {
        validation.push({
          code: "MANIPULATOR_ILLEGAL",
          severity: "error",
          message: "Quad Battle Armor may not mount manipulators."
        });
      }
      for (const manip of [leftManipulator, rightManipulator]) {
        const spec = baManipulatorSpec(manip);
        if (spec.paired && leftManipulator !== rightManipulator) {
          validation.push({
            code: "MANIPULATOR_PAIR_REQUIRED",
            severity: "error",
            message: `${manip.replaceAll("_", " ")} must be mounted as a matched pair.`
          });
        }
      }
      const manipulatorMass =
        (baManipulatorSpec(leftManipulator).kg +
          baManipulatorSpec(rightManipulator).kg) / 1000;

      const turretMass =
        turretCapacity > 0
          ? turretCapacity * 0.01 + 0.03 + (modularTurret ? 0.02 : 0)
          : 0;

      const structureMass =
        chassisMass + groundMPMass + secondaryMotiveMass;

      const maxWalk = (index >= 3 ? 2 : 3) + (quad ? 2 : 0);
      const maxSecondary =
        motive === "VTOL"
          ? quad || index > 2 ? 0 : 7 - index
          : motive === "UMU"
            ? quad ? 0 : Math.min(5, 6 - index)
            : motive === "JUMP"
              ? quad ? 0 : maxWalk
              : 0;

      if (groundMP > maxWalk) {
        validation.push({
          code: "MOVEMENT_INVALID",
          severity: "error",
          field: "chassis.properties.groundMP",
          message:
            `${cls.label} ${quad ? "quad" : "biped"} Battle Armor is limited to ${maxWalk} ground MP in the current verifier slice.`
        });
      }

      if (secondaryMP > maxSecondary) {
        validation.push({
          code: "MOVEMENT_INVALID",
          severity: "error",
          field: "chassis.properties.secondaryMP",
          message:
            `${cls.label} ${quad ? "quad" : "biped"} Battle Armor using ${prettyBAMotive(motive)} is limited to ${maxSecondary} MP.`
        });
      }

      if (motive === "VTOL" && secondaryMassPerMP <= 0 && secondaryMP > 0) {
        validation.push({
          code: "MOVEMENT_INVALID",
          severity: "error",
          field: "chassis.properties.secondaryMotive",
          message:
            `${cls.label} Battle Armor cannot use the VTOL motive system in this construction slice.`
        });
      }

      if (armorPoints > cls.maxArmor) {
        validation.push({
          code: "ARMOR_OVER_LIMIT",
          severity: "error",
          field: "chassis.properties.armorPointsPerSuit",
          message:
            `${armorPoints} armor points exceed the ${cls.maxArmor}-point maximum for ${cls.label} Battle Armor.`
        });
      }

      const suitMassLimit = ctx.design.chassis.massLimit;
      if (suitMassLimit > cls.maxMass + 1e-9) {
        validation.push({
          code: "SIZE_LIMIT_EXCEEDED",
          severity: "error",
          field: "chassis.massLimit",
          message:
            `${cls.label} Battle Armor is limited to ${cls.maxMass} tons per suit; the record limit is ${suitMassLimit} tons.`
        });
      }

      const fixedPerSuitMass =
        structureMass + armorMass + manipulatorMass + turretMass;

      const chassisCost = baChassisCost(classKey);
      const secondaryMotiveCost = baSecondaryMotiveCost(
        classKey,
        motive,
        secondaryMP
      );
      const groundMovementCost =
        25000 * Math.max(0, groundMP - 1);
      const armorCost = armorPoints * armorSpec.cost;
      const manipulatorCost =
        baManipulatorSpec(leftManipulator).cost +
        baManipulatorSpec(rightManipulator).cost;
      const augmentationCost = Math.max(
        0,
        ctx.propertyNumber("augmentationCostPerSuit", 0)
      );
      const additionalCost = Math.max(
        0,
        ctx.propertyNumber("additionalCostPerSuit", 0)
      );
      const includeTraining = ctx.propertyBoolean(
        "includeTraining",
        false
      );
      const clanStructureMultiplier =
        ctx.design.rules.techBase === "CLAN" ? 1.1 : 1;
      const preTrainingCost =
        chassisCost +
        secondaryMotiveCost +
        groundMovementCost +
        manipulatorCost +
        armorCost +
        augmentationCost;
      const pricedStructureCost =
        preTrainingCost * clanStructureMultiplier;
      const trainingCost = includeTraining
        ? ctx.design.rules.techBase === "CLAN"
          ? 200000
          : 150000
        : 0;

      return {
        massEntries: [
          massEntry(
            "ba-structure",
            `Battle Armor chassis + motive systems (${cls.label})`,
            structureMass,
            "structure"
          ),
          massEntry(
            "ba-armor",
            `${armorType.replaceAll("_", " ")} Battle Armor (${armorPoints} points; ${armorSpec.slots} slots)`,
            armorMass,
            "armor"
          ),
          ...(manipulatorMass > 0 ? [
            massEntry("ba-manipulators", "Manipulators", manipulatorMass, "equipment")
          ] : []),
          ...(turretMass > 0
            ? [
                massEntry(
                  "ba-turret",
                  modularTurret ? "Modular Turret Mount" : "Turret Mount",
                  turretMass,
                  "equipment"
                )
              ]
            : [])
        ],
        costEntries: [
          costEntry(
            "ba-priced-structure",
            "Chassis / motive / ground / manipulators / armor / augmentations",
            pricedStructureCost,
            "chassis",
            includeTraining && clanStructureMultiplier > 1
              ? "Includes current 1.1 Clan structure multiplier."
              : undefined
          ),
          ...(trainingCost > 0
            ? [
                costEntry(
                  "ba-training",
                  "Training",
                  trainingCost,
                  "crew"
                )
              ]
            : []),
          ...(additionalCost > 0
            ? [
                costEntry(
                  "ba-additional",
                  "Additional manual per-suit cost",
                  additionalCost,
                  "misc"
                )
              ]
            : [])
        ],
        costModifiers: [
          {
            id: "ba-troopers",
            label: "Battle Armor squad size",
            multiplier: troopers,
            explanation:
              "Current BattleArmorCostCalculator multiplies per-suit additive cost by squad size."
          }
        ],
        validation,
        derived: {
          weightClass: cls.label,
          maximumSuitMass: cls.maxMass,
          troopers,
          freeGroundMP,
          maximumGroundMP: maxWalk,
          secondaryMotive: prettyBAMotive(motive),
          maximumSecondaryMP: maxSecondary,
          chassisMass,
          groundMPMass,
          secondaryMotiveMass,
          armorType,
          armorKgPerPoint,
          armorSlots: armorSpec.slots,
          armorMass,
          leftManipulator,
          rightManipulator,
          manipulatorMass,
          maximumArmorPoints: cls.maxArmor,
          turretMass,
          fixedMassPerSuit: fixedPerSuitMass,
          fixedFormationMass: fixedPerSuitMass * troopers,
          chassisCostPerSuit: chassisCost,
          secondaryMotiveCostPerSuit: secondaryMotiveCost,
          groundMovementCostPerSuit: groundMovementCost,
          armorCostPerSuit: armorCost,
          manipulatorCostPerSuit: manipulatorCost,
          augmentationCostPerSuit: augmentationCost,
          clanStructureMultiplier,
          trainingCostPerSuit: trainingCost,
          pricedBaseCostPerSuit:
            pricedStructureCost + trainingCost + additionalCost
        }
      };
    }
  });


export function baChassisCost(weightClass: string): number {
  switch (weightClass) {
    case "MEDIUM":
      return 100000;
    case "HEAVY":
      return 200000;
    case "ASSAULT":
      return 400000;
    default:
      return 50000;
  }
}

export function baSecondaryMotiveCost(
  weightClass: string,
  motive: string,
  mp: number
): number {
  const movement = Math.max(0, Math.floor(mp));
  switch (weightClass) {
    case "MEDIUM":
      return movement * (motive === "VTOL" ? 100000 : 75000);
    case "HEAVY":
      return movement * (motive === "UMU" ? 100000 : 150000);
    case "ASSAULT":
      return movement * (motive === "UMU" ? 150000 : 300000);
    default:
      return movement * 50000;
  }
}

function prettyBAMotive(value: string): string {
  return {
    NONE: "None",
    JUMP: "Jump Jets",
    VTOL: "VTOL",
    UMU: "UMU"
  }[value] ?? value;
}

interface BAArmorSpec { kg:number; slots:number; cost:number; legal:boolean }
function baArmorSpec(type:string, tech:string):BAArmorSpec {
  const clan=tech==="CLAN";
  const rows:Record<string,{clan:number|null;is:number|null;slots:number;cost:number}>={
    STANDARD:{clan:25,is:50,slots:0,cost:10000},
    STANDARD_ADVANCED:{clan:null,is:40,slots:5,cost:12500},
    STANDARD_PROTOTYPE:{clan:null,is:100,slots:4,cost:10000},
    STEALTH_BASIC:{clan:30,is:55,slots:3,cost:12000},
    STEALTH_STANDARD:{clan:35,is:60,slots:4,cost:15000},
    STEALTH_IMPROVED:{clan:35,is:60,slots:5,cost:20000},
    STEALTH_PROTOTYPE:{clan:null,is:100,slots:4,cost:50000},
    FIRE_RESISTANT:{clan:30,is:null,slots:5,cost:10000},
    MIMETIC:{clan:null,is:50,slots:7,cost:15000}
  };
  const row=rows[type]??rows.STANDARD;
  const kg=clan?row.clan:row.is;
  return {kg:kg??0,slots:row.slots,cost:row.cost,legal:kg!==null};
}
interface BAManipSpec { kg:number; cost:number; paired:boolean }
function baManipulatorSpec(type:string):BAManipSpec {
  return ({
    NONE:{kg:0,cost:0,paired:false},ARMORED_GLOVE:{kg:0,cost:2500,paired:false},
    BASIC:{kg:0,cost:5000,paired:false},BASIC_MINE:{kg:15,cost:7500,paired:true},
    BATTLE_CLAW:{kg:15,cost:10000,paired:false},BATTLE_CLAW_MAGNETS:{kg:35,cost:12500,paired:true},
    BATTLE_CLAW_VIBRO:{kg:50,cost:15000,paired:false},HEAVY_CLAW:{kg:20,cost:25000,paired:false},
    HEAVY_CLAW_MAGNETS:{kg:40,cost:31250,paired:true},HEAVY_CLAW_VIBRO:{kg:60,cost:30000,paired:false},
    SALVAGE_ARM:{kg:30,cost:50000,paired:false},INDUSTRIAL_DRILL:{kg:30,cost:2500,paired:false},
    CARGO_LIFTER:{kg:30,cost:500,paired:true},MODULAR_ADAPTOR:{kg:10,cost:10000,paired:false}
  } as Record<string,BAManipSpec>)[type]??{kg:0,cost:0,paired:false};
}
