import type {
  ConstructorDefinition,
  ConstructorEditorSchema
} from "../core/types";
import { makeGenericConstructor } from "./genericConstructor";

function simpleSchema(
  label: string,
  locations: Array<{ id: string; label: string }>
): ConstructorEditorSchema {
  return {
    sections: [
      {
        id: "record",
        label,
        fields: [
          {
            key: "baseMass",
            label: "Base / chassis mass",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 0.001,
            unit: "t",
            ledger: "mass",
            ledgerCategory: "structure"
          },
          {
            key: "armorMass",
            label: "Armor / protection mass",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 0.001,
            unit: "t",
            ledger: "mass",
            ledgerCategory: "armor"
          },
          {
            key: "baseCost",
            label: "Base C-bill cost",
            kind: "number",
            defaultValue: 0,
            min: 0,
            step: 1,
            unit: "C",
            ledger: "cost",
            ledgerCategory: "chassis"
          }
        ]
      }
    ],
    placementLocations: locations
  };
}

export const gunEmplacementConstructor: ConstructorDefinition =
  makeGenericConstructor({
    id: "emplacement.gun",
    name: "Gun Emplacement",
    family: "Miscellaneous",
    description: "Fixed gun emplacement / turret record.",
    coverage: "RECORD_ONLY",
    defaultMass: 20,
    schema: simpleSchema("Gun emplacement", [
      { id: "BODY", label: "Emplacement Body" },
      { id: "TURRET", label: "Turret" },
      { id: "MAGAZINE", label: "Magazine / Ammo" }
    ])
  });

export const handheldWeaponConstructor: ConstructorDefinition =
  makeGenericConstructor({
    id: "weapon.handheld",
    name: "Handheld Weapon",
    family: "Miscellaneous",
    description: "Handheld 'Mech-scale weapon construction record.",
    coverage: "RECORD_ONLY",
    defaultMass: 5,
    schema: simpleSchema("Handheld weapon", [
      { id: "FRAME", label: "Frame" },
      { id: "WEAPON", label: "Weapon Mount" },
      { id: "AMMO", label: "Ammo / Stores" }
    ])
  });

export const battlefieldSupportAssetConstructor: ConstructorDefinition =
  makeGenericConstructor({
    id: "battlefield-support.asset",
    name: "Battlefield Support / Asset",
    family: "Miscellaneous",
    description: "Battlefield Support / Asset record for current-era abstract support units.",
    coverage: "RECORD_ONLY",
    defaultMass: 0,
    enforceMassLimit: false,
    rulesLevel: "STANDARD",
    schema: {
      sections: [
        {
          id: "asset",
          label: "Battlefield Support / Asset",
          fields: [
            {
              key: "assetType",
              label: "Asset type",
              kind: "text",
              defaultValue: ""
            },
            {
              key: "sizeOrScale",
              label: "Size / scale",
              kind: "text",
              defaultValue: ""
            },
            {
              key: "movement",
              label: "Movement / mobility",
              kind: "text",
              defaultValue: ""
            },
            {
              key: "recordMass",
              label: "Record mass (if applicable)",
              kind: "number",
              defaultValue: 0,
              min: 0,
              step: 0.001,
              unit: "t",
              ledger: "mass",
              ledgerCategory: "record"
            },
            {
              key: "recordCost",
              label: "C-bill cost",
              kind: "number",
              defaultValue: 0,
              min: 0,
              step: 1,
              unit: "C",
              ledger: "cost",
              ledgerCategory: "record"
            }
          ]
        }
      ],
      placementLocations: [
        { id: "ASSET", label: "Asset" },
        { id: "PAYLOAD", label: "Payload" }
      ]
    }
  });
