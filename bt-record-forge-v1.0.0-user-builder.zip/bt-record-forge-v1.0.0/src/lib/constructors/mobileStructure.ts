import { newId } from "../core/id";
import type {
  ComponentDefinition,
  ConstructorDefinition,
  ConstructionResult,
  Design
} from "../core/types";
import {
  calculateStructureDesign,
  defaultFootprint
} from "./structureRules";

export const mobileStructureConstructor: ConstructorDefinition = {
  id: "structure.mobile",
  name: "Mobile Structure",
  family: "Structures",
  coverage: "RULES_IMPLEMENTED",
  description: "Multi-hex mobile-structure construction record.",

  create(): Design {
    return {
      format: "bt-record-forge",
      formatVersion: 1,
      id: newId("design"),
      constructorId: "structure.mobile",
      identity: { name: "Untitled Mobile Structure" },
      rules: {
        year: 3050,
        techBase: "INNER_SPHERE",
        rulesLevel: "ADVANCED"
      },
      chassis: {
        massLimit: 0,
        properties: {
          structureKind: "MOBILE_STRUCTURE",
          constructionType: "LIGHT",
          mobileStructureType: "BUILDING",
          motiveType: "GROUND",
          powerSystem: "ICE",
          cruiseMP: 1,
          desiredRangeKm: 0,
          motiveMass: 0,
          motiveCost: 0,
          baseStructureCost: 0,
          environmentalSealing: false,
          heavyMetalSuperstructure: false,
          highLowCeilings: false,
          openSpaceConstruction: false,
          subsurfaceConstruction: false,
          tunnelConstruction: false,
          fuelStorageTons: 0,
          largeDoorLevels: 0,
          industrialElevatorTons: 0,
          unspecifiedEquipmentHexes: 0,
          automatedWeaponTons: 0,
          mobileLinkages: 0,
          turretCount: 0,
          turretPayloadTons: 0,
          pintlePayloadTons: 0
        }
      },
      footprint: defaultFootprint(),
      components: []
    };
  },

  calculate(
    design: Design,
    catalog: Map<string, ComponentDefinition>
  ): ConstructionResult {
    return calculateStructureDesign(design, catalog);
  }
};
