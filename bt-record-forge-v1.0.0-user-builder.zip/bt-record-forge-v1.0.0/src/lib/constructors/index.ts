import { ConstructorRegistry } from "../core/registry";
import { battleMechConstructor } from "./battlemech";
import {
  primitiveMechConstructor,
  omniMechConstructor,
  industrialMechConstructor,
  quadMechConstructor,
  tripodMechConstructor,
  superheavyMechConstructor,
  lamConstructor,
  quadVeeConstructor
} from "./mekVariants";
import { protoMechConstructor } from "./protomech";
import { combatVehicleConstructor } from "./combatVehicle";
import { supportVehicleConstructor } from "./supportVehicle";
import {
  aerospaceFighterConstructor,
  conventionalFighterConstructor
} from "./fighters";
import {
  smallCraftConstructor,
  dropShipConstructor
} from "./smallCraft";
import {
  jumpShipConstructor,
  warShipConstructor,
  spaceStationConstructor
} from "./advancedAerospace";
import {
  infantryConstructor,
  battleArmorConstructor
} from "./personnel";
import { buildingConstructor } from "./building";
import { mobileStructureConstructor } from "./mobileStructure";
import {
  gunEmplacementConstructor,
  handheldWeaponConstructor,
  battlefieldSupportAssetConstructor
} from "./miscConstructors";

export const constructors = new ConstructorRegistry()
  .register(battleMechConstructor)
  .register(primitiveMechConstructor)
  .register(omniMechConstructor)
  .register(industrialMechConstructor)
  .register(quadMechConstructor)
  .register(tripodMechConstructor)
  .register(superheavyMechConstructor)
  .register(lamConstructor)
  .register(quadVeeConstructor)
  .register(protoMechConstructor)
  .register(combatVehicleConstructor)
  .register(supportVehicleConstructor)
  .register(aerospaceFighterConstructor)
  .register(conventionalFighterConstructor)
  .register(smallCraftConstructor)
  .register(dropShipConstructor)
  .register(jumpShipConstructor)
  .register(warShipConstructor)
  .register(spaceStationConstructor)
  .register(infantryConstructor)
  .register(battleArmorConstructor)
  .register(buildingConstructor)
  .register(mobileStructureConstructor)
  .register(gunEmplacementConstructor)
  .register(handheldWeaponConstructor)
  .register(battlefieldSupportAssetConstructor);
