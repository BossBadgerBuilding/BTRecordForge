import type { CostModifier, ConstructorEditorSchema, ConstructorDefinition, ValidationIssue } from "../core/types";
import { ceilHalf, costEntry, makeGenericConstructor, massEntry } from "./genericConstructor";
import { sumComponentMassByLocation } from "./componentMath";

type VehicleMode="TRACKED"|"WHEELED"|"HOVER"|"VTOL"|"WIGE"|"NAVAL"|"HYDROFOIL"|"SUBMARINE";
type EngineType=
 |"FUSION"|"XL"|"LIGHT"|"COMPACT"|"XXL"|"ICE"|"FUEL_CELL"|"FISSION"
 |"LARGE_ICE"|"LARGE_FUSION"|"LARGE_LIGHT"|"LARGE_XL"|"LARGE_XXL";
type ArmorType="STANDARD"|"LIGHT_FERRO"|"IS_FERRO"|"CLAN_FERRO"|"HEAVY_FERRO";

const LOCATIONS=[
 {id:"FRONT",label:"Front"},{id:"RIGHT",label:"Right Side"},{id:"LEFT",label:"Left Side"},
 {id:"REAR",label:"Rear"},{id:"TURRET",label:"Turret"},{id:"TURRET2",label:"Front / Second Turret"},
 {id:"BODY",label:"Body"},{id:"ROTOR",label:"Rotor"}
];
const ENGINE_ICE=[1,1,1,1,2,2,2,2,3,3,3,4,4,4,5,5,6,6,6,7,7,8,8,8,9,9,10,10,11,11,12,12,12,14,14,15,15,16,17,17,18,19,20,20,21,22,23,24,25,26,27,28,29,31,32,33,35,36,38,39,41,43,45,47,49,51,54,57,59,63,66,69,73,77,82,87,92,98,105] as const;
const ENGINE_FUEL_CELL=[1,1,1,1,1.5,1.5,1.5,1.5,2,2,2,2.5,2.5,2.5,3,3,4,4,4,4.5,4.5,5,5,5,5.5,5.5,6,6,7,7,7.5,7.5,7.5,8.5,8.5,9,9,10,10.5,10.5,11,11.5,12,12,13,13.5,14,14.5,15,16,16.5,17,17.5,19,19.5,20,21,22,23,23.5,25,26,27,28.5,29.5,31,32.5,34.5,35.5,38,40,41.5,44,46.5,49.5,52.5,55.5,59,63] as const;
const ENGINE_FISSION=[5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5.5,5.5,5.5,6.5,6.5,7,7,7,8,8,9,9,10,10,10.5,10.5,10.5,12.5,12.5,13.5,13.5,14,15,15,16,17,17.5,17.5,18.5,19.5,20.5,21,22,23,24,24.5,25.5,27.5,28,29,31,31.5,33.5,34.5,36,38,39.5,41.5,43,45,47.5,50,52,55.5,58,60.5,64,67.5,72,76.5,80.5,86,92] as const;
const ENGINE_COMPACT=[1,1,1,1,1.5,1.5,1.5,1.5,2.5,2.5,2.5,3,3,3,4,4,4.5,4.5,4.5,5.5,5.5,6,6,6,7,7,7.5,7.5,8.5,8.5,9,9,9,10.5,10.5,11.5,11.5,12,13,13,13.5,14.5,15,15,16,16.5,17.5,18,19,19.5,20.5,21,22,23.5,24,25,26.5,27,28.5,29.5,31,32.5,34,35.5,37,38.5,40.5,43,44.5,47.5,49.5,52,55,58,61.5,65.5,69,73.5,79] as const;
const ENGINE_FUSION=[0.5,0.5,0.5,0.5,1,1,1,1,1.5,1.5,1.5,2,2,2,2.5,2.5,3,3,3,3.5,3.5,4,4,4,4.5,4.5,5,5,5.5,5.5,6,6,6,7,7,7.5,7.5,8,8.5,8.5,9,9.5,10,10,10.5,11,11.5,12,12.5,13,13.5,14,14.5,15.5,16,16.5,17.5,18,19,19.5,20.5,21.5,22.5,23.5,24.5,25.5,27,28.5,29.5,31.5,33,34.5,36.5,38.5,41,43.5,46,49,52.5] as const;
const ENGINE_LIGHT=[0.5,0.5,0.5,0.5,1,1,1,1,1.5,1.5,1.5,1.5,1.5,1.5,2,2,2.5,2.5,2.5,3,3,3,3,3,3.5,3.5,4,4,4.5,4.5,4.5,4.5,4.5,5.5,5.5,6,6,6,6.5,6.5,7,7.5,7.5,7.5,8,8.5,9,9,9.5,10,10.5,10.5,11,12,12,12.5,13.5,13.5,14.5,15,15.5,16.5,17,18,18.5,19.5,20.5,21.5,22.5,24,25,26,27.5,29,31,33,34.5,37,39.5] as const;
const ENGINE_XL=[0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,1,1,1,1,1,1,1.5,1.5,1.5,1.5,1.5,1.5,2,2,2,2,2.5,2.5,2.5,2.5,3,3,3,3,3,3,3.5,3.5,4,4,4.5,4.5,4.5,4.5,5,5,5.5,5.5,6,6,6.5,6.5,7,7,7.5,7.5,8,8,9,9,9.5,9.5,10.5,10.5,11.5,11.5,12.5,12.5,13.5,13.5,15,15,16.5,16.5,18.5,18.5,20.5,20.5,23,23,26.5] as const;

const schema:ConstructorEditorSchema={sections:[
 {id:"chassis",label:"Combat Vehicle chassis",description:"TechManual engine, armor, crew and cost matrices with Tactical Operations chassis modifications.",fields:[
  {key:"movementMode",label:"Motive type",kind:"select",defaultValue:"TRACKED",options:[
   {value:"TRACKED",label:"Tracked"},{value:"WHEELED",label:"Wheeled"},{value:"HOVER",label:"Hover"},
   {value:"VTOL",label:"VTOL"},{value:"WIGE",label:"WiGE"},{value:"NAVAL",label:"Naval / Displacement Hull"},
   {value:"HYDROFOIL",label:"Hydrofoil"},{value:"SUBMARINE",label:"Submarine"}]},
  {key:"cruiseMP",label:"Cruising MP",kind:"number",defaultValue:4,min:0,step:1},
  {key:"superheavy",label:"Superheavy chassis",kind:"boolean",defaultValue:false},
  {key:"omni",label:"Omni vehicle",kind:"boolean",defaultValue:false},
  {key:"engineType",label:"Engine type",kind:"select",defaultValue:"FUSION",options:[
   {value:"FUSION",label:"Standard Fusion"},{value:"XL",label:"XL Fusion"},{value:"LIGHT",label:"Light Fusion"},
   {value:"COMPACT",label:"Compact Fusion"},{value:"ICE",label:"Internal Combustion"},
   {value:"FUEL_CELL",label:"Fuel Cell (advanced)"},{value:"FISSION",label:"Fission (advanced)"},
   {value:"XXL",label:"XXL Fusion (advanced)"},{value:"LARGE_ICE",label:"Large ICE (405–500)"},
   {value:"LARGE_FUSION",label:"Large Fusion (405–500)"},{value:"LARGE_LIGHT",label:"Large Light Fusion (405–500)"},
   {value:"LARGE_XL",label:"Large XL Fusion (405–500)"},{value:"LARGE_XXL",label:"Large XXL Fusion (405–500)"}]},
  {key:"armorType",label:"Armor type",kind:"select",defaultValue:"STANDARD",options:[
   {value:"STANDARD",label:"Standard"},{value:"LIGHT_FERRO",label:"Light Ferro-Fibrous (IS)"},
   {value:"IS_FERRO",label:"Ferro-Fibrous (IS)"},{value:"CLAN_FERRO",label:"Ferro-Fibrous (Clan)"},
   {value:"HEAVY_FERRO",label:"Heavy Ferro-Fibrous (IS)"}]},
  {key:"armorPoints",label:"Armor points",kind:"number",defaultValue:40,min:0,step:1},
  {key:"heatSinks",label:"Heat sinks",kind:"number",defaultValue:0,min:0,step:1},
  {key:"powerAmplifierTons",label:"Power amplifier mass",kind:"number",defaultValue:0,min:0,step:0.5,unit:"t"},
  {key:"chassisModifications",label:"Advanced chassis modifications",kind:"text",defaultValue:"",help:"Comma-separated: FLOTATION_HULL, LIMITED_AMPHIBIOUS, FULLY_AMPHIBIOUS, DUNE_BUGGY, ENVIRONMENTAL_SEALING."}
 ]},
 {id:"extras",label:"Additional constructor costs",fields:[
  {key:"chassisCost",label:"Other chassis/system cost",kind:"number",defaultValue:0,min:0,step:1,unit:"C",ledger:"cost",ledgerCategory:"chassis"}
 ]}
],placementLocations:LOCATIONS};

export const combatVehicleConstructor:ConstructorDefinition=makeGenericConstructor({
 id:"vehicle.combat",name:"Combat Vehicle",family:"Vehicles",
 description:"Tracked, wheeled, hover, VTOL, WiGE and naval Combat Vehicle construction.",
 coverage:"RULES_IMPLEMENTED",defaultMass:50,schema,
 calculateBase(ctx){
  const mass=ctx.design.chassis.massLimit;
  const mode=ctx.propertyString("movementMode","TRACKED") as VehicleMode;
  const superheavy=ctx.propertyBoolean("superheavy",false);
  const cruise=Math.max(0,Math.floor(ctx.propertyNumber("cruiseMP",0)));
  const engineType=ctx.propertyString("engineType","FUSION") as EngineType;
  const armorType=ctx.propertyString("armorType","STANDARD") as ArmorType;
  const armorPoints=Math.max(0,Math.floor(ctx.propertyNumber("armorPoints",0)));
  const heatSinks=Math.max(0,Math.floor(ctx.propertyNumber("heatSinks",0)));
  const amps=Math.max(0,ctx.propertyNumber("powerAmplifierTons",0));
  const validation:ValidationIssue[]=[];
  const maxTonnage=vehicleMaxTonnage(mode,superheavy);
  if(mass>maxTonnage) validation.push({code:"SIZE_LIMIT_EXCEEDED",severity:"error",field:"chassis.massLimit",message:`${prettyMode(mode)} ${superheavy?"superheavy ":""}Combat Vehicles are limited to ${maxTonnage} tons.`});

  const suspension=suspensionFactor(mode,mass);
  const rawRating=mass*cruise-suspension;
  const largeEngine=engineType.startsWith("LARGE_");
  const ratingCeiling=largeEngine?500:400;
  const engineRating=Math.min(ratingCeiling,Math.max(10,Math.ceil(rawRating/5)*5));
  if(rawRating>ratingCeiling) validation.push({code:"ENGINE_RATING_INVALID",severity:"error",message:`Required Engine Rating ${rawRating} exceeds ${ratingCeiling} for ${prettyEngine(engineType)}.`});
  if(largeEngine && engineRating<405) validation.push({code:"ENGINE_RATING_INVALID",severity:"error",message:"Large engines use ratings 405 through 500."});
  if(!largeEngine && rawRating>400) validation.push({code:"ENGINE_RATING_INVALID",severity:"error",message:"Ratings above 400 require a Large Engine type."});
  let engineMass=engineTableWeight(engineType,engineRating);
  if(["FUSION","XL","LIGHT","COMPACT","XXL","FISSION","LARGE_FUSION","LARGE_LIGHT","LARGE_XL","LARGE_XXL"].includes(engineType)) engineMass=ceilHalf(engineMass*1.5);
  if(mode==="HOVER") engineMass=Math.max(engineMass,ceilHalf(mass*.2));

  const structureMass=ceilHalf(mass*(superheavy&&mode!=="NAVAL"&&mode!=="SUBMARINE"?.20:.10));
  const controlsMass=ceilHalf(mass/20);
  const liftingMass=["HOVER","VTOL","HYDROFOIL","SUBMARINE","WIGE"].includes(mode)?ceilHalf(mass/10):0;

  const armorMultiplier=armorData(armorType).multiplier;
  const armorMass=armorPoints?ceilHalf(armorPoints/(16*armorMultiplier)):0;
  const armorLimit=Math.floor(mass*3.5+40);
  if(armorPoints>armorLimit) validation.push({code:"ARMOR_OVER_LIMIT",severity:"error",field:"chassis.properties.armorPoints",message:`${armorPoints} armor points exceed the ${armorLimit}-point vehicle maximum.`});
  if(ctx.design.rules.techBase==="CLAN"&&["LIGHT_FERRO","IS_FERRO","HEAVY_FERRO"].includes(armorType)) validation.push({code:"TECH_BASE_MISMATCH",severity:"error",message:`${armorType} is Inner Sphere armor.`});
  if(ctx.design.rules.techBase==="INNER_SPHERE"&&armorType==="CLAN_FERRO") validation.push({code:"TECH_BASE_MISMATCH",severity:"error",message:"Clan ferro-fibrous armor requires Clan or Mixed technology."});

  const turretEquipmentMass=sumComponentMassByLocation(ctx.design,ctx.catalog,["TURRET"]);
  const turret2EquipmentMass=sumComponentMassByLocation(ctx.design,ctx.catalog,["TURRET2"]);
  const turretMass=turretEquipmentMass>0?ceilHalf(turretEquipmentMass/10):0;
  const turret2Mass=turret2EquipmentMass>0?ceilHalf(turret2EquipmentMass/10):0;

  let modMass=0, modDirectCost=0; const mods=parseMods(ctx.propertyString("chassisModifications",""));
  const costModifiers:CostModifier[]=[];
  for(const mod of mods){
   if(mod==="FLOTATION_HULL"){if(!["HOVER","WIGE","VTOL"].includes(mode)) illegalMod(validation,mod); costModifiers.push({id:"cv-flotation",label:"Flotation hull cost multiplier",multiplier:1.25,explanation:"Tactical Operations 1.25 × total cost."});}
   else if(mod==="LIMITED_AMPHIBIOUS"){if(!["TRACKED","WHEELED"].includes(mode)) illegalMod(validation,mod); modMass+=ceilHalf(mass/25); modDirectCost+=10000*structureMass;}
   else if(mod==="FULLY_AMPHIBIOUS"){if(!["TRACKED","WHEELED"].includes(mode)) illegalMod(validation,mod); modMass+=ceilHalf(mass/10); modDirectCost+=10000*structureMass;}
   else if(mod==="DUNE_BUGGY"){if(mode!=="WHEELED") illegalMod(validation,mod); modDirectCost+=10*mass*mass;}
   else if(mod==="ENVIRONMENTAL_SEALING"){if(mode!=="SUBMARINE")modMass+=ceilHalf(mass/10); costModifiers.push({id:"cv-enviro",label:"Environmental sealing cost multiplier",multiplier:1.25,explanation:"Tactical Operations 1.25 × total cost."});}
   else validation.push({code:"CHASSIS_MOD_UNKNOWN",severity:"error",message:`Unknown Combat Vehicle chassis modification ${mod}.`});
  }

  const engineCost=engineCostFor(engineType,engineRating,mass);
  const armorCost=armorMass*armorData(armorType).costPerTon;
  const freeSinks=["FUSION","XL","LIGHT","COMPACT","XXL","LARGE_FUSION","LARGE_LIGHT","LARGE_XL","LARGE_XXL"].includes(engineType)?10:engineType==="FUEL_CELL"?1:engineType==="FISSION"?5:0;
  const heatCost=Math.max(0,heatSinks-freeSinks)*2000;
  if(ctx.propertyBoolean("omni",false)) costModifiers.push({id:"cv-omni",label:"Omni conversion",multiplier:1.25,explanation:"TechManual Omni conversion multiplier."});
  costModifiers.push({id:"cv-tonnage",label:"Combat Vehicle motive/tonnage multiplier",multiplier:combatVehiclePriceMultiplier(mass,mode),explanation:`${prettyMode(mode)} final cost formula.`});

  const crew=Math.ceil(mass/15);
  return{
   massEntries:[
    massEntry("vehicle-structure","Vehicle Internal Structure",structureMass,"structure"),
    massEntry("vehicle-engine",`${prettyEngine(engineType)} (${engineRating})`,engineMass,"engine"),
    massEntry("vehicle-controls","Control Systems",controlsMass,"controls"),
    ...(liftingMass?[massEntry("vehicle-lift",mode==="VTOL"?"Rotors":"Lift/Dive Equipment",liftingMass,"movement")]:[]),
    ...(armorMass?[massEntry("vehicle-armor",`${prettyArmor(armorType)} (${armorPoints} points)`,armorMass,"armor")]:[]),
    ...(turretMass?[massEntry("vehicle-turret","Turret Mechanism",turretMass,"structure")]:[]),
    ...(turret2Mass?[massEntry("vehicle-turret2","Second Turret Mechanism",turret2Mass,"structure")]:[]),
    ...(modMass?[massEntry("vehicle-chassis-mods","Chassis Modifications",modMass,"structure")]:[]),
    ...(amps?[massEntry("vehicle-amps","Power Amplifiers",amps,"equipment")]:[])
   ],
   costEntries:[
    costEntry("vehicle-structure","Internal Structure",structureMass*10000,"structure"),
    costEntry("vehicle-engine",prettyEngine(engineType),engineCost,"engine"),
    costEntry("vehicle-controls","Control Systems",controlsMass*10000,"controls"),
    ...(liftingMass?[costEntry("vehicle-lift",mode==="VTOL"?"Rotors":"Lift/Dive Equipment",liftingMass*(mode==="VTOL"?40000:20000),"movement")]:[]),
    ...(armorMass?[costEntry("vehicle-armor",prettyArmor(armorType),armorCost,"armor")]:[]),
    ...(turretMass?[costEntry("vehicle-turret","Turret",turretMass*5000,"structure")]:[]),
    ...(turret2Mass?[costEntry("vehicle-turret2","Second Turret",turret2Mass*5000,"structure")]:[]),
    ...(heatCost?[costEntry("vehicle-heat","Heat Sinks",heatCost,"heat")]:[]),
    ...(amps?[costEntry("vehicle-amps","Power Amplifiers",amps*20000,"equipment")]:[]),
    ...(modDirectCost?[costEntry("vehicle-chassis-mods","Chassis Modifications",modDirectCost,"structure")]:[])
   ],
   costModifiers,validation,derived:{
    motiveType:prettyMode(mode),cruiseMP:cruise,flankMP:Math.ceil(cruise*1.5),suspensionFactor:suspension,
    engineRating,engineMass,engineItemSlotsLost:engineSlotsLost(engineType,ctx.design.rules.techBase),
    armorType:prettyArmor(armorType),armorPoints,armorMass,armorPointLimit:armorLimit,armorItemSlots:armorData(armorType).slots,
    structureMass,controlsMass,liftingMass,crew,advancedChassisModifications:mods.join(", ")||"None",
    finalPriceMultiplier:combatVehiclePriceMultiplier(mass,mode)
   }
  };
 }
});

function suspensionFactor(mode:VehicleMode,m:number):number{
 if(mode==="TRACKED")return 0;if(mode==="WHEELED")return 20;if(mode==="NAVAL"||mode==="SUBMARINE")return 30;
 if(mode==="HOVER"){if(m<=10)return 40;if(m<=20)return 85;if(m<=30)return 130;if(m<=40)return 175;return 235;}
 if(mode==="HYDROFOIL"){if(m<=10)return 60;if(m<=20)return 105;if(m<=30)return 150;if(m<=40)return 195;if(m<=50)return 255;if(m<=60)return 300;if(m<=70)return 345;if(m<=80)return 390;if(m<=90)return 435;return 480;}
 if(mode==="VTOL"){if(m<=10)return 50;if(m<=20)return 95;return 140;}
 if(mode==="WIGE"){if(m<=15)return 45;if(m<=30)return 80;if(m<=45)return 115;return 140;}return 0;
}
const LARGE_ENGINE_ROWS:Record<number,readonly [number,number,number,number,number]>={
405:[113,56.5,42.5,28.5,19],410:[122,61,46,30.5,20.5],415:[133,66.5,50,33.5,22.5],
420:[145,72.5,54.5,36.5,24.5],425:[159,79.5,60,40,26.5],430:[175,87.5,66,44,29.5],
435:[194,97,73,48.5,32.5],440:[215,107.5,81,54,36],445:[239,119.5,90,60,40],
450:[267,133.5,100.5,67,44.5],455:[300,150,112.5,75,50],460:[337,168.5,126.5,84.5,56.5],
465:[380,190,142.5,95,63.5],470:[429,214.5,161,107.5,71.5],475:[486,243,182.5,121.5,81],
480:[551,275.5,207,138,92],485:[626,313,235,156.5,104.5],490:[712,356,267,178,119],
495:[811,405.5,304.5,203,135.5],500:[925,462.5,347,231.5,154.5]
};
function engineTableWeight(type:EngineType,rating:number):number{
 if(type.startsWith("LARGE_")){
  const row=LARGE_ENGINE_ROWS[rating]; if(!row)return 0;
  return type==="LARGE_ICE"?row[0]:type==="LARGE_FUSION"?row[1]:type==="LARGE_LIGHT"?row[2]:type==="LARGE_XL"?row[3]:row[4];
 }
 const idx=Math.max(0,Math.min(78,Math.round((rating-10)/5)));
 const standard=ENGINE_FUSION[idx]??0;
 if(type==="XXL") return ceilHalf(standard/3);
 const table=type==="ICE"?ENGINE_ICE:type==="FUEL_CELL"?ENGINE_FUEL_CELL:type==="FISSION"?ENGINE_FISSION:type==="COMPACT"?ENGINE_COMPACT:type==="LIGHT"?ENGINE_LIGHT:type==="XL"?ENGINE_XL:ENGINE_FUSION;
 return table[idx]??0;
}
function engineCostFor(t:EngineType,r:number,m:number):number{
 const base=t==="ICE"?1250:t==="FUSION"?5000:t==="LIGHT"?15000:t==="XL"?20000:t==="COMPACT"?10000:
  t==="FUEL_CELL"?3500:t==="FISSION"?7500:t==="XXL"?100000:t==="LARGE_ICE"?2500:
  t==="LARGE_FUSION"?10000:t==="LARGE_LIGHT"?30000:t==="LARGE_XL"?40000:200000;
 return base*r*m/75;
}
function engineSlotsLost(t:EngineType,tech:string):number{
 if(t==="LIGHT")return 1;if(t==="XL")return tech==="CLAN"?1:2;if(t==="XXL")return tech==="CLAN"?2:4;
 if(t==="LARGE_ICE"||t==="LARGE_FUSION")return 1;if(t==="LARGE_LIGHT")return 2;
 if(t==="LARGE_XL")return tech==="CLAN"?2:3;if(t==="LARGE_XXL")return tech==="CLAN"?3:5;return 0;
}
function armorData(t:ArmorType):{multiplier:number;slots:number;costPerTon:number}{return{
 STANDARD:{multiplier:1,slots:0,costPerTon:10000},LIGHT_FERRO:{multiplier:1.06,slots:1,costPerTon:15000},
 IS_FERRO:{multiplier:1.12,slots:2,costPerTon:20000},CLAN_FERRO:{multiplier:1.2,slots:1,costPerTon:20000},
 HEAVY_FERRO:{multiplier:1.24,slots:3,costPerTon:25000}}[t];}
export function vehicleMaxTonnage(mode:VehicleMode,superheavy:boolean):number{switch(mode){case"WHEELED":case"WIGE":return superheavy?160:80;case"HOVER":return superheavy?100:50;case"VTOL":return superheavy?60:30;case"NAVAL":case"SUBMARINE":return superheavy?555:300;case"HYDROFOIL":return 100;default:return superheavy?200:100;}}
export function combatVehiclePriceMultiplier(m:number,mode:VehicleMode):number{switch(mode){case"HOVER":case"SUBMARINE":return 1+m/50;case"HYDROFOIL":return 1+m/75;case"NAVAL":case"WHEELED":return 1+m/200;case"TRACKED":return 1+m/100;case"VTOL":return 1+m/30;case"WIGE":return 1+m/25;default:return 1;}}
function parseMods(v:string):string[]{return [...new Set(v.split(/[,;\n]+/).map(x=>x.trim().toUpperCase().replace(/[\s-]+/g,"_")).filter(Boolean))];}
function illegalMod(v:ValidationIssue[],m:string){v.push({code:"CHASSIS_MOD_ILLEGAL",severity:"error",message:`${m} is not legal for this motive type.`});}
function prettyMode(m:VehicleMode):string{return{TRACKED:"Tracked",WHEELED:"Wheeled",HOVER:"Hover",VTOL:"VTOL",WIGE:"WiGE",NAVAL:"Naval",HYDROFOIL:"Hydrofoil",SUBMARINE:"Submarine"}[m];}
function prettyEngine(t:EngineType):string{return{FUSION:"Standard Fusion",XL:"XL Fusion",LIGHT:"Light Fusion",COMPACT:"Compact Fusion",XXL:"XXL Fusion",ICE:"Internal Combustion",FUEL_CELL:"Fuel Cell",FISSION:"Fission",LARGE_ICE:"Large ICE",LARGE_FUSION:"Large Fusion",LARGE_LIGHT:"Large Light Fusion",LARGE_XL:"Large XL Fusion",LARGE_XXL:"Large XXL Fusion"}[t];}
function prettyArmor(t:ArmorType):string{return{STANDARD:"Standard",LIGHT_FERRO:"Light Ferro-Fibrous",IS_FERRO:"IS Ferro-Fibrous",CLAN_FERRO:"Clan Ferro-Fibrous",HEAVY_FERRO:"Heavy Ferro-Fibrous"}[t];}
