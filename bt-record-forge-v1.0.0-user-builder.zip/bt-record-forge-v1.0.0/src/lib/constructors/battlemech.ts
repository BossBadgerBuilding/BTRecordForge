import { calculateCommon } from "../core/calculation";
import { newId } from "../core/id";
import type {
  ComponentDefinition,
  ConstructorDefinition,
  ConstructionResult,
  Design
} from "../core/types";
import { calculateBattleMechBase } from "./battlemechRules";
import { applyBattleMechPlacement } from "./battlemechPlacement";

export const battleMechConstructor: ConstructorDefinition = {
  id: "mech.battlemech",
  family: "Meks",
  coverage: "PARTIAL_RULES",
  name: "BattleMech",
  description: "Standard biped BattleMech construction record.",

  create(): Design {
    return {
      format: "bt-record-forge",
      formatVersion: 1,
      id: newId("design"),
      constructorId: "mech.battlemech",
      identity: { name: "Untitled BattleMech" },
      rules: {
        year: 3050,
        techBase: "INNER_SPHERE",
        rulesLevel: "STANDARD"
      },
      chassis: {
        massLimit: 50,
        properties: {
          configuration: "biped",
          structure: "standard",
          walkMP: 4,
          jumpMP: 0,
          engineType: "STANDARD_FUSION",
          gyroType: "STANDARD",
          cockpitType: "STANDARD",
          armorTons: 8,
          heatSinks: 10,
          heatSinkType: "SINGLE",
          armorHead: 9,
          armorCTFront: 21,
          armorCTRear: 6,
          armorLTFront: 15,
          armorLTRear: 4,
          armorRTFront: 15,
          armorRTRear: 4,
          armorLA: 13,
          armorRA: 13,
          armorLL: 14,
          armorRL: 14
        }
      },
      components: []
    };
  },

  calculate(
    design: Design,
    catalog: Map<string, ComponentDefinition>
  ): ConstructionResult {
    const base = calculateBattleMechBase(design);

    const result = calculateCommon(design, catalog, {
      massEntries: base.massEntries,
      costEntries: base.costEntries,
      slotEntries: base.slotEntries,
      costModifiers: base.modifiers,
      validation: base.validation,
      derived: base.derived
    });

    return applyBattleMechPlacement(result, design, catalog);
  }
};
