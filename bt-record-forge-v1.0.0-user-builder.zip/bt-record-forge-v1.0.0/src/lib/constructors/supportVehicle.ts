import { calculateCommon } from "../core/calculation";
import { newId } from "../core/id";
import type {
  ComponentDefinition,
  ConstructorDefinition,
  ConstructionResult,
  Design
} from "../core/types";
import { calculateSupportVehicleBase } from "./supportVehicleRules";

export const supportVehicleConstructor: ConstructorDefinition = {
  id: "vehicle.support",
  family: "Vehicles",
  coverage: "RULES_IMPLEMENTED",
  name: "Support Vehicle",
  description: "Civilian or military Support Vehicle construction record.",
  editorSchema: {
    sections: [
      {
        id: "support-details",
        label: "Support Vehicle armor, chassis modifications & crew",
        description: "Official TechManual matrices. Chassis modifications are comma-separated canonical names, e.g. ARMORED, OFF_ROAD, ENVIRONMENTAL_SEALING.",
        fields: [
          { key: "chassisModifications", label: "Chassis modifications", kind: "text", defaultValue: "" },
          { key: "armorBAR", label: "Barrier Armor Rating (0 = none)", kind: "number", defaultValue: 0, min: 0, max: 10, step: 1 },
          { key: "armorTechRating", label: "Armor Tech Rating", kind: "select", defaultValue: "D", options: [
            { value: "A", label: "A" }, { value: "B", label: "B" }, { value: "C", label: "C" },
            { value: "D", label: "D" }, { value: "E", label: "E" }, { value: "F", label: "F" }
          ]},
          { key: "armorPoints", label: "Armor points", kind: "number", defaultValue: 0, min: 0, step: 1 },
          { key: "heatSinks", label: "Heat sinks", kind: "number", defaultValue: 0, min: 0, step: 1 },
          { key: "powerAmplifierTons", label: "Power amplifier mass", kind: "number", defaultValue: 0, min: 0, step: 0.5, unit: "t" },
          { key: "turretTons", label: "Turret mechanism mass", kind: "number", defaultValue: 0, min: 0, step: 0.5, unit: "t" },
          { key: "fireControl", label: "Fire-control system", kind: "select", defaultValue: "NONE", options: [
            { value: "NONE", label: "None (+2)" }, { value: "BASIC", label: "Basic (+1)" }, { value: "ADVANCED", label: "Advanced (+0)" }
          ]},
          { key: "communicationsTons", label: "Communications equipment", kind: "number", defaultValue: 0, min: 0, step: 1, unit: "t" },
          { key: "fieldKitchens", label: "Field kitchens", kind: "number", defaultValue: 0, min: 0, step: 1 },
          { key: "mashTheaters", label: "MASH theaters", kind: "number", defaultValue: 0, min: 0, step: 1 },
          { key: "lightWeapons", label: "Crew-served light weapons", kind: "number", defaultValue: 0, min: 0, step: 1 },
          { key: "mediumWeapons", label: "Crew-served medium weapons", kind: "number", defaultValue: 0, min: 0, step: 1 },
          { key: "heavyWeaponTons", label: "Heavy weapon mass for core gunner minimum", kind: "number", defaultValue: 0, min: 0, step: 0.5, unit: "t" },
          { key: "weaponTons", label: "Advanced-unit total weapon mass", kind: "number", defaultValue: 0, min: 0, step: 0.5, unit: "t", help: "Used by Large Airship/Naval and Rail/Satellite advanced crew matrices." },
          { key: "weaponFacings", label: "Advanced-unit armed facings", kind: "number", defaultValue: 0, min: 0, step: 1 },
          { key: "flightDecks", label: "Flight decks", kind: "number", defaultValue: 0, min: 0, step: 1 },
          { key: "helipads", label: "Helipads", kind: "number", defaultValue: 0, min: 0, step: 1 },
          { key: "mobileFieldBases", label: "Mobile field bases", kind: "number", defaultValue: 0, min: 0, step: 1 },
          { key: "unmanned", label: "Unmanned satellite", kind: "boolean", defaultValue: false }
        ]
      }
    ],
    placementLocations: [
      { id: "FRONT", label: "Front" },
      { id: "RIGHT", label: "Right" },
      { id: "LEFT", label: "Left" },
      { id: "REAR", label: "Rear" },
      { id: "TURRET", label: "Turret" },
      { id: "BODY", label: "Body / Internal" }
    ]
  },

  create(): Design {
    return {
      format: "bt-record-forge",
      formatVersion: 1,
      id: newId("design"),
      constructorId: "vehicle.support",
      identity: { name: "Untitled Civilian Support Vehicle" },
      rules: {
        year: 3050,
        techBase: "INNER_SPHERE",
        rulesLevel: "STANDARD"
      },
      chassis: {
        massLimit: 20,
        properties: {
          vehicleType: "WHEELED",
          walkMP: 4,
          structuralTechRating: "D",
          engineTechRating: "D",
          engineType: "ICE",
          role: "civilian",
          chassisModifications: "",
          armorBAR: 0,
          armorTechRating: "D",
          armorPoints: 0,
          heatSinks: 0,
          powerAmplifierTons: 0,
          turretTons: 0,
          communicationsTons: 0,
          fieldKitchens: 0,
          mashTheaters: 0,
          lightWeapons: 0,
          mediumWeapons: 0,
          heavyWeaponTons: 0,
          weaponTons: 0,
          weaponFacings: 0,
          flightDecks: 0,
          helipads: 0,
          mobileFieldBases: 0,
          unmanned: false,
          fireControl: "NONE"
        }
      },
      components: []
    };
  },

  calculate(
    design: Design,
    catalog: Map<string, ComponentDefinition>
  ): ConstructionResult {
    const base = calculateSupportVehicleBase(design);

    return calculateCommon(design, catalog, {
      massEntries: base.massEntries,
      costEntries: base.costEntries,
      costModifiers: base.costModifiers,
      validation: base.validation,
      derived: base.derived
    });
  }
};
