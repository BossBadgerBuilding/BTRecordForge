import type {
  ComponentDefinition,
  ConstructorDefinition,
  ConstructorEditorSchema,
  Design,
  ValidationIssue
} from "../core/types";
import {
  buildDesignValueContext,
  evaluateConstructionValue
} from "../core/valueExpression";
import { fusionEngineBaseWeight } from "./battlemechRules";
import {
  costEntry,
  makeGenericConstructor,
  massEntry
} from "./genericConstructor";

const MAX_ARMOR_FACTOR = [
  15, 17, 22, 24, 33, 35, 40, 42, 51, 53, 58, 60, 65, 67
] as const;

const schema: ConstructorEditorSchema = {
  sections: [
    {
      id: "chassis",
      label: "ProtoMech chassis",
      description:
        "Structure, controls, fusion engine, standard ProtoMech armor and heat-sink mass are derived automatically.",
      fields: [
        {
          key: "configuration",
          label: "Configuration",
          kind: "select",
          defaultValue: "BIPED",
          options: [
            { value: "BIPED", label: "Biped" },
            { value: "QUAD", label: "Quad" },
            { value: "GLIDER", label: "Glider" }
          ]
        },
        {
          key: "walkMP",
          label: "Walk MP",
          kind: "number",
          defaultValue: 4,
          min: 0,
          step: 1
        },
        {
          key: "jumpMP",
          label: "Jump MP",
          kind: "number",
          defaultValue: 0,
          min: 0,
          step: 1,
          help:
            "Jump/UMU equipment itself remains catalog equipment; this value is used for record/cost calculations."
        },
        {
          key: "hasMainGun",
          label: "Main gun location",
          kind: "boolean",
          defaultValue: false
        },
        {
          key: "heatSinks",
          label: "ProtoMech heat sinks",
          kind: "number",
          defaultValue: 0,
          min: 0,
          step: 1
        },
        {
          key: "armorPoints",
          label: "Standard ProtoMech armor points",
          kind: "number",
          defaultValue: 20,
          min: 0,
          step: 1
        }
      ]
    },
    {
      id: "cost",
      label: "Cost controls",
      fields: [
        {
          key: "priceMultiplier",
          label: "Final price multiplier",
          kind: "number",
          defaultValue: 1,
          min: 0,
          step: 0.01,
          help:
            "Structural/equipment C-bill entries are automatic. Leave at 1 unless the selected rules/data source requires a final unit price multiplier."
        }
      ]
    }
  ],
  placementLocations: [
    { id: "HEAD", label: "Head", capacity: 0 },
    { id: "TORSO", label: "Torso", capacity: 6 },
    { id: "LA", label: "Left Arm", capacity: 1 },
    { id: "RA", label: "Right Arm", capacity: 1 },
    { id: "LEGS", label: "Legs", capacity: 0 },
    { id: "MAINGUN", label: "Main Gun", capacity: 2 },
    { id: "BODY", label: "Body / Slot-free systems" }
  ]
};

export const protoMechConstructor: ConstructorDefinition =
  makeGenericConstructor({
    id: "protomech.standard",
    name: "ProtoMech",
    family: "ProtoMechs",
    description: "ProtoMech construction record.",
    coverage: "PARTIAL_RULES",
    defaultMass: 5,
    techBase: "CLAN",
    schema,

    calculateBase(ctx) {
      const mass = ctx.design.chassis.massLimit;
      const configuration = ctx.propertyString("configuration", "BIPED");
      const quad = configuration === "QUAD";
      const glider = configuration === "GLIDER";
      const ultra = mass > 9;
      const walkMP = Math.max(0, Math.floor(ctx.propertyNumber("walkMP", 0)));
      const jumpMP = Math.max(0, Math.floor(ctx.propertyNumber("jumpMP", 0)));
      const hasMainGun = ctx.propertyBoolean("hasMainGun", false);
      const heatSinks = Math.max(
        0,
        Math.floor(ctx.propertyNumber("heatSinks", 0))
      );
      const armorPoints = Math.max(
        0,
        Math.floor(ctx.propertyNumber("armorPoints", 0))
      );
      const validation: ValidationIssue[] = [];

      if (mass < 2 || mass > 15) {
        validation.push({
          code: "SIZE_LIMIT_EXCEEDED",
          severity: "error",
          field: "chassis.massLimit",
          message:
            `ProtoMechs must be from 2 through 15 tons; this record is ${mass} tons.`
        });
      }

      const minimumWalk = glider ? 4 : quad ? 3 : 1;
      if (walkMP < minimumWalk) {
        validation.push({
          code: "MOVEMENT_INVALID",
          severity: "error",
          field: "chassis.properties.walkMP",
          message:
            `${configurationLabel(configuration)} ProtoMechs require at least ${minimumWalk} Walking MP in the current verifier slice.`
        });
      }

      let moveFactor = Math.ceil(walkMP * 1.5);
      if (quad || glider) moveFactor -= 2;
      let engineRating = Math.floor(moveFactor * mass);
      if (engineRating > 40 && engineRating % 5 !== 0) {
        engineRating += 5 - (engineRating % 5);
      }

      const engineMass =
        engineRating < 40
          ? ceilKilo(engineRating * 0.025)
          : fusionEngineBaseWeight(engineRating);

      if (engineRating > 400 || engineMass <= 0) {
        validation.push({
          code: "ENGINE_RATING_INVALID",
          severity: "error",
          field: "chassis.properties.walkMP",
          message:
            `ProtoMech engine rating ${engineRating} is outside the currently supported fusion-engine table.`
        });
      }

      const structureMass = ceilKilo(mass * 0.10);
      const controlsMass = ultra ? 0.75 : 0.5;
      const heatSinkMass = heatSinks * 0.25;
      const armorMass = armorPoints * 0.05;

      const maxArmorPoints = maxArmorFactor(mass, hasMainGun);
      if (armorPoints > maxArmorPoints) {
        validation.push({
          code: "ARMOR_OVER_LIMIT",
          severity: "error",
          field: "chassis.properties.armorPoints",
          message:
            `${armorPoints} ProtoMech armor points exceed the ${maxArmorPoints}-point maximum for this tonnage${hasMainGun ? " with a main-gun location" : ""}.`
        });
      }

      validateProtoLocations(
        ctx.design,
        ctx.catalog,
        configuration,
        ultra,
        hasMainGun,
        validation
      );

      const structureCostRate = glider ? 600 : quad ? 500 : 400;
      const cockpitCost = ultra ? 800000 : 500000;
      const structuralCosts = [
        costEntry("proto-cockpit", "ProtoMech Cockpit", cockpitCost, "controls"),
        costEntry("proto-life-support", "Life Support", 75000, "controls"),
        costEntry("proto-sensors", "Sensors", 2000 * mass, "controls"),
        costEntry("proto-musculature", "Musculature", 2000 * mass, "structure"),
        costEntry(
          "proto-structure",
          "Internal Structure",
          structureCostRate * mass,
          "structure"
        ),
        costEntry("proto-arm-actuators", "Arm Actuators", 2 * 180 * mass, "structure"),
        costEntry("proto-leg-actuators", "Leg Actuators", 540 * mass, "structure"),
        costEntry(
          "proto-engine",
          "ProtoMech Fusion Engine",
          (5000 * engineRating * mass) / 75,
          "engine"
        ),
        costEntry(
          "proto-jump",
          "Jump Jets / jump allowance",
          mass * jumpMP * jumpMP * 200,
          "movement"
        ),
        costEntry("proto-heatsinks", "ProtoMech Heat Sinks", heatSinks * 2000, "heat"),
        costEntry("proto-armor", "Standard ProtoMech Armor", armorPoints * 625, "armor")
      ];

      const priceMultiplier = Math.max(
        0,
        ctx.propertyNumber("priceMultiplier", 1)
      );

      return {
        massEntries: [
          massEntry("proto-structure", "ProtoMech Structure", structureMass, "structure"),
          massEntry(
            "proto-engine",
            `ProtoMech Fusion Engine (${engineRating})`,
            engineMass,
            "engine"
          ),
          massEntry("proto-controls", "Controls", controlsMass, "controls"),
          massEntry("proto-heatsinks", "ProtoMech Heat Sinks", heatSinkMass, "heat"),
          massEntry("proto-armor", `Standard Armor (${armorPoints} points)`, armorMass, "armor")
        ],
        costEntries: structuralCosts,
        costModifiers:
          priceMultiplier === 1
            ? []
            : [{
                id: "proto-price-multiplier",
                label: "ProtoMech price multiplier",
                multiplier: priceMultiplier,
                explanation: "User-selected final unit price multiplier."
              }],
        validation,
        derived: {
          configuration: configurationLabel(configuration),
          ultraHeavy: ultra,
          walkMP,
          runMP: Math.ceil(walkMP * 1.5),
          jumpMP,
          minimumWalkMP: minimumWalk,
          engineRating,
          engineMass,
          structureMass,
          controlsMass,
          heatSinkMass,
          armorMass,
          maxArmorPoints,
          torsoSlots: protoSlotLimit("TORSO", quad, ultra),
          armSlotsEach: protoSlotLimit("LA", quad, ultra),
          mainGunSlots: hasMainGun
            ? protoSlotLimit("MAINGUN", quad, ultra)
            : 0,
          torsoEquipmentMassLimit: protoWeightLimit("TORSO", quad, ultra),
          armEquipmentMassLimitEach: protoWeightLimit("LA", quad, ultra)
        }
      };
    }
  });

export function maxArmorFactor(weight: number, mainGun: boolean): number {
  const weightIndex = Math.max(0, Math.floor(weight) - 2);
  const base =
    MAX_ARMOR_FACTOR[Math.min(weightIndex, MAX_ARMOR_FACTOR.length - 1)];
  return base + (mainGun ? (weight > 9 ? 6 : 3) : 0);
}

export function protoEngineRating(
  walkMP: number,
  tonnage: number,
  quadOrGlider: boolean
): number {
  let moveFactor = Math.ceil(walkMP * 1.5);
  if (quadOrGlider) moveFactor -= 2;
  let rating = Math.floor(moveFactor * tonnage);
  if (rating > 40 && rating % 5 !== 0) {
    rating += 5 - (rating % 5);
  }
  return rating;
}

function validateProtoLocations(
  design: Design,
  catalog: Map<string, ComponentDefinition>,
  configuration: string,
  ultra: boolean,
  hasMainGun: boolean,
  validation: ValidationIssue[]
): void {
  const quad = configuration === "QUAD";
  const context = buildDesignValueContext(design);
  const slotUse = new Map<string, number>();
  const weightUse = new Map<string, number>();

  for (const installed of design.components) {
    const component = catalog.get(installed.componentId);
    if (!component) continue;

    const location = installed.placement?.location;
    if (!location) continue;

    if (location === "MAINGUN" && !hasMainGun) {
      validation.push({
        code: "INVALID_LOCATION",
        severity: "error",
        componentId: installed.componentId,
        message: `${component.name} is assigned to Main Gun, but this ProtoMech has no main-gun location.`
      });
      continue;
    }

    const quantity = Math.max(0, installed.quantity);
    try {
      const mass = evaluateConstructionValue(component.mass, context) * quantity;
      weightUse.set(location, (weightUse.get(location) ?? 0) + mass);

      const slotFree =
        component.attributes?.protomechNoSlot === true ||
        ["ammo", "jump-jet", "umu"].some((category) =>
          component.categories.includes(category)
        );

      if (!slotFree && component.slots !== undefined) {
        const slots =
          evaluateConstructionValue(component.slots, context) * quantity;
        slotUse.set(location, (slotUse.get(location) ?? 0) + slots);
      }
    } catch {
      // Generic calculation owns formula evaluation errors.
    }
  }

  for (const [location, used] of slotUse) {
    const limit = protoSlotLimit(location, quad, ultra);
    if (used > limit) {
      validation.push({
        code: "LOCATION_OVER_CAPACITY",
        severity: "error",
        field: `location.${location}`,
        message:
          `${locationLabel(location)} uses ${used} ProtoMech equipment slots; its current maximum is ${limit}.`
      });
    }
  }

  for (const [location, used] of weightUse) {
    const limit = protoWeightLimit(location, quad, ultra);
    if (Number.isFinite(limit) && used > limit + 1e-9) {
      validation.push({
        code: "LOCATION_OVER_CAPACITY",
        severity: "error",
        field: `location.${location}`,
        message:
          `${locationLabel(location)} carries ${used.toFixed(3)} tons of equipment; its current ProtoMech location limit is ${limit.toFixed(3)} tons.`
      });
    }
  }
}

function protoSlotLimit(location: string, quad: boolean, ultra: boolean): number {
  switch (location) {
    case "TORSO": {
      let slots = ultra ? 3 : 2;
      if (quad) slots *= 2;
      return slots;
    }
    case "LA":
    case "RA":
      return quad ? 0 : 1;
    case "MAINGUN":
      return quad && ultra ? 2 : 1;
    default:
      return 0;
  }
}

function protoWeightLimit(location: string, quad: boolean, ultra: boolean): number {
  switch (location) {
    case "TORSO":
      return quad ? (ultra ? 8 : 5) : (ultra ? 4 : 2);
    case "LA":
    case "RA":
      return quad ? 0 : ultra ? 1 : 0.5;
    case "MAINGUN":
      return Number.POSITIVE_INFINITY;
    default:
      return 0;
  }
}

function ceilKilo(value: number): number {
  if (!Number.isFinite(value) || value <= 0) return 0;
  return Math.ceil((value - Number.EPSILON) * 1000) / 1000;
}

function configurationLabel(value: string): string {
  return {
    BIPED: "Biped",
    QUAD: "Quad",
    GLIDER: "Glider"
  }[value] ?? value;
}

function locationLabel(value: string): string {
  return {
    HEAD: "Head",
    TORSO: "Torso",
    LA: "Left Arm",
    RA: "Right Arm",
    LEGS: "Legs",
    MAINGUN: "Main Gun",
    BODY: "Body"
  }[value] ?? value;
}
