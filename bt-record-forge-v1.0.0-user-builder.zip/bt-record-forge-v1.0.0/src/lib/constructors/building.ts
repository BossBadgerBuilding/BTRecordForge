import { newId } from "../core/id";
import type {
  ComponentDefinition,
  ConstructorDefinition,
  ConstructionResult,
  Design
} from "../core/types";
import {
  calculateStructureDesign,
  defaultFootprint
} from "./structureRules";

export const buildingConstructor: ConstructorDefinition = {
  id: "structure.building",
  name: "Building",
  family: "Structures",
  coverage: "RULES_IMPLEMENTED",
  description: "Fixed multi-hex building/advanced-structure record.",

  create(): Design {
    return {
      format: "bt-record-forge",
      formatVersion: 1,
      id: newId("design"),
      constructorId: "structure.building",
      identity: { name: "Untitled Building" },
      rules: {
        year: 3050,
        techBase: "INNER_SPHERE",
        rulesLevel: "STANDARD"
      },
      chassis: {
        massLimit: 0,
        properties: {
          structureKind: "BUILDING",
          constructionType: "LIGHT",
          buildingClassification: "STANDARD",
          baseStructureCost: 0,
          environmentalSealing: false,
          heavyMetalSuperstructure: false,
          highLowCeilings: false,
          openSpaceConstruction: false,
          subsurfaceConstruction: false,
          tunnelConstruction: false,
          fuelStorageTons: 0,
          largeDoorLevels: 0,
          industrialElevatorTons: 0,
          unspecifiedEquipmentHexes: 0,
          automatedWeaponTons: 0,
          mobileLinkages: 0,
          turretCount: 0,
          turretPayloadTons: 0,
          pintlePayloadTons: 0
        }
      },
      footprint: defaultFootprint(),
      components: []
    };
  },

  calculate(
    design: Design,
    catalog: Map<string, ComponentDefinition>
  ): ConstructionResult {
    return calculateStructureDesign(design, catalog);
  }
};
