import { calculateCommon } from "../core/calculation";
import { newId } from "../core/id";
import type {
  ComponentDefinition,
  ConstructorDefinition,
  ConstructorEditorSchema,
  ConstructorId,
  ConstructionResult,
  CostModifier,
  Design,
  LedgerEntry,
  ValidationIssue,
  ValidationCode
} from "../core/types";
import {
  calculateBattleMechBase,
  fusionEngineBaseWeight
} from "./battlemechRules";
import { applyBattleMechPlacement } from "./battlemechPlacement";

const LOCATIONS = [
  { id: "HEAD", label: "Head" },
  { id: "CT", label: "Center Torso" },
  { id: "LT", label: "Left Torso" },
  { id: "RT", label: "Right Torso" },
  { id: "LA", label: "Left Arm / Front Limb" },
  { id: "RA", label: "Right Arm / Front Limb" },
  { id: "LL", label: "Left Leg / Rear Limb" },
  { id: "RL", label: "Right Leg / Rear Limb" },
  { id: "CL", label: "Center Leg (Tripod)" },
  { id: "BODY", label: "Body / Conversion Equipment" }
];

const commonFields = [
  { key: "walkMP", label: "Walk MP", kind: "number" as const, defaultValue: 4, min: 1, step: 1 },
  { key: "jumpMP", label: "Jump MP", kind: "number" as const, defaultValue: 0, min: 0, step: 1 },
  {
    key: "structureType", label: "Internal Structure", kind: "select" as const, defaultValue: "STANDARD",
    options: [
      { value: "STANDARD", label: "Standard" },
      { value: "ENDO_STEEL", label: "Endo Steel" },
      { value: "COMPOSITE", label: "Composite" },
      { value: "ENDO_COMPOSITE", label: "Endo-Composite" },
      { value: "REINFORCED", label: "Reinforced" }
    ]
  },
  {
    key: "engineType", label: "Engine", kind: "select" as const, defaultValue: "STANDARD_FUSION",
    options: [
      { value: "STANDARD_FUSION", label: "Standard Fusion" },
      { value: "LIGHT_FUSION", label: "Light Fusion" },
      { value: "IS_XL_FUSION", label: "Inner Sphere XL Fusion" },
      { value: "CLAN_XL_FUSION", label: "Clan XL Fusion" },
      { value: "COMPACT_FUSION", label: "Compact Fusion" }
    ]
  },
  {
    key: "gyroType", label: "Gyro", kind: "select" as const, defaultValue: "STANDARD",
    options: [
      { value: "STANDARD", label: "Standard" },
      { value: "XL", label: "XL" },
      { value: "COMPACT", label: "Compact" },
      { value: "HEAVY_DUTY", label: "Heavy-Duty" }
    ]
  },
  {
    key: "cockpitType", label: "Cockpit", kind: "select" as const, defaultValue: "STANDARD",
    options: [
      { value: "STANDARD", label: "Standard" },
      { value: "SMALL", label: "Small" },
      { value: "TORSO_MOUNTED", label: "Torso-Mounted" },
      { value: "COMMAND_CONSOLE", label: "Command Console" }
    ]
  },
  { key: "armorTons", label: "Armor", kind: "number" as const, defaultValue: 8, min: 0, step: 0.5, unit: "t" },
  { key: "heatSinks", label: "Heat Sinks", kind: "number" as const, defaultValue: 10, min: 0, step: 1 },
  {
    key: "heatSinkType", label: "Heat Sink Type", kind: "select" as const, defaultValue: "SINGLE",
    options: [{ value: "SINGLE", label: "Single" }, { value: "DOUBLE", label: "Double" }]
  }
];

function schema(extra: ConstructorEditorSchema["sections"][number]["fields"] = []): ConstructorEditorSchema {
  return {
    sections: [
      { id: "core", label: "Core chassis", fields: commonFields },
      ...(extra.length ? [{ id: "variant", label: "Variant systems", fields: extra }] : [])
    ],
    placementLocations: LOCATIONS
  };
}

function createBase(id: ConstructorId, name: string, mass: number): Design {
  return {
    format: "bt-record-forge",
    formatVersion: 1,
    id: newId("design"),
    constructorId: id,
    identity: { name: `Untitled ${name}` },
    rules: { year: 3150, techBase: "INNER_SPHERE", rulesLevel: "ADVANCED" },
    chassis: {
      massLimit: mass,
      properties: {
        configuration: "biped",
        structureType: "STANDARD",
        armorType: "STANDARD",
        walkMP: mass > 100 ? 3 : 4,
        jumpMP: 0,
        engineType: "STANDARD_FUSION",
        gyroType: "STANDARD",
        cockpitType: "STANDARD",
        armorTons: Math.max(1, Math.min(12, mass * 0.16)),
        heatSinks: 10,
        heatSinkType: "SINGLE",
        leftLowerArmActuator: true,
        leftHandActuator: true,
        rightLowerArmActuator: true,
        rightHandActuator: true,
        armorHead: mass > 100 ? 12 : 9,
        armorCTFront: 0, armorCTRear: 0,
        armorLTFront: 0, armorLTRear: 0,
        armorRTFront: 0, armorRTRear: 0,
        armorLA: 0, armorRA: 0, armorLL: 0, armorRL: 0
      }
    },
    components: []
  };
}

function massEntry(id: string, label: string, totalValue: number, category = "special"): LedgerEntry {
  return { id, label, quantity: 1, unitValue: totalValue, totalValue, category };
}
function costEntry(id: string, label: string, totalValue: number, category = "special"): LedgerEntry {
  return { id, label, quantity: 1, unitValue: totalValue, totalValue, category };
}
function issue(code: ValidationCode, field: string, message: string, severity: "error"|"warning" = "error"): ValidationIssue {
  return { code, field, message, severity };
}
function replaceEntry(entries: LedgerEntry[], id: string, replacement: LedgerEntry): void {
  const at = entries.findIndex((x) => x.id === id);
  if (at >= 0) entries[at] = replacement;
  else entries.push(replacement);
}
function removeEntry(entries: LedgerEntry[], id: string): void {
  const at = entries.findIndex((x) => x.id === id);
  if (at >= 0) entries.splice(at, 1);
}
function roundHalf(v: number): number { return Math.ceil((v - Number.EPSILON) * 2) / 2; }
function roundWhole(v: number): number { return Math.ceil(v - Number.EPSILON); }
function ceil5(v: number): number { return Math.ceil(v / 5) * 5; }

type VariantAdjust = (
  design: Design,
  base: ReturnType<typeof calculateBattleMechBase>
) => { placement?: boolean; extraModifiers?: CostModifier[]; derived?: Record<string,string|number|boolean> } | void;

function makeVariant(
  id: ConstructorId,
  name: string,
  mass: number,
  description: string,
  extraFields: ConstructorEditorSchema["sections"][number]["fields"],
  adjust: VariantAdjust,
  init?: (design: Design) => void
): ConstructorDefinition {
  return {
    id, name, family: "Meks", coverage: "RULES_IMPLEMENTED", description,
    editorSchema: schema(extraFields),
    create() {
      const d = createBase(id, name, mass);
      init?.(d);
      return d;
    },
    calculate(design: Design, catalog: Map<string, ComponentDefinition>): ConstructionResult {
      const base = calculateBattleMechBase(design);
      const rawAdjusted = adjust(design, base);
      const adjusted: { placement?: boolean; extraModifiers?: CostModifier[]; derived?: Record<string,string|number|boolean> } =
        rawAdjusted && typeof rawAdjusted === "object" ? rawAdjusted : {};
      const result = calculateCommon(design, catalog, {
        massEntries: base.massEntries,
        costEntries: base.costEntries,
        slotEntries: base.slotEntries,
        costModifiers: [...base.modifiers, ...(adjusted.extraModifiers ?? [])],
        validation: base.validation,
        derived: { ...base.derived, ...(adjusted.derived ?? {}) }
      });
      return adjusted.placement === false ? result : applyBattleMechPlacement(result, design, catalog);
    }
  };
}

export const primitiveMechConstructor = makeVariant(
  "mech.primitive", "Primitive BattleMech", 50,
  "Interstellar Operations primitive BattleMech construction with enlarged engine rating, primitive cockpit and restricted core technologies.",
  [],
  (design, base) => {
    const mass = design.chassis.massLimit;
    const walk = Math.max(1, Math.floor(Number(design.chassis.properties.walkMP ?? 1)));
    const normalRating = mass * walk;
    const primitiveRating = ceil5(normalRating * 1.2);
    const engineMass = fusionEngineBaseWeight(primitiveRating);
    replaceEntry(base.massEntries, "engine", massEntry("engine", `Primitive Standard Fusion Engine (${primitiveRating})`, engineMass, "engine"));
    replaceEntry(base.costEntries, "engine", costEntry("engine", `Primitive Standard Fusion Engine (${primitiveRating})`, 5000 * primitiveRating * mass / 75, "engine"));
    replaceEntry(base.massEntries, "cockpit", massEntry("cockpit", "Primitive BattleMech Cockpit", 5, "controls"));
    if (design.rules.techBase !== "INNER_SPHERE") base.validation.push(issue("TECH_BASE_CONFLICT","rules.techBase","Primitive 'Mechs use Inner Sphere technology."));
    if (mass < 10 || mass > 100 || mass % 5 !== 0) base.validation.push(issue("SIZE_LIMIT_EXCEEDED","chassis.massLimit","Primitive 'Mechs must weigh 10–100 tons in 5-ton increments."));
    if (String(design.chassis.properties.structureType) !== "STANDARD") base.validation.push(issue("TECH_BASE_CONFLICT","chassis.properties.structureType","Primitive 'Mechs may only use standard internal structure."));
    if (String(design.chassis.properties.engineType) !== "STANDARD_FUSION") base.validation.push(issue("TECH_BASE_CONFLICT","chassis.properties.engineType","This primitive constructor implements the published standard-fusion primitive engine path; select Standard Fusion."));
    if (String(design.chassis.properties.cockpitType) !== "STANDARD") base.validation.push(issue("TECH_BASE_CONFLICT","chassis.properties.cockpitType","Primitive 'Mechs use the 5-ton primitive cockpit."));
    return { derived: { primitiveEngineRating: primitiveRating, primitiveCockpitMass: 5 } };
  },
  (d) => { d.rules.year = 2500; d.chassis.properties.cockpitType = "STANDARD"; }
);

export const omniMechConstructor = makeVariant(
  "mech.omni", "OmniMech", 50,
  "BattleMech construction with an explicit Omni base-configuration/pod-space record.",
  [
    { key: "podSpaceTons", label: "Omni pod space reserved", kind: "number", defaultValue: 10, min: 0, step: 0.5, unit: "t",
      help: "Informational reservation within the completed configuration; fixed core systems remain invariant between configurations." }
  ],
  (design, base) => {
    const podSpace = Math.max(0, Number(design.chassis.properties.podSpaceTons ?? 0));
    const coreMass = base.massEntries.reduce((n,e)=>n+e.totalValue,0);
    if (podSpace > Math.max(0, design.chassis.massLimit - coreMass)) {
      base.validation.push(issue("MASS_OVER_LIMIT","chassis.properties.podSpaceTons","Reserved Omni pod space exceeds mass remaining after fixed core systems."));
    }
    return { derived: { omniPodSpaceReserved: podSpace, omniFixedCoreMass: coreMass } };
  }
);

export const industrialMechConstructor = makeVariant(
  "mech.industrial", "IndustrialMech", 50,
  "TechManual IndustrialMech construction with doubled standard structure, industrial engines, cockpit, sealing and Industrial TSM.",
  [
    {
      key: "industrialEngineType", label: "Industrial Engine", kind: "select", defaultValue: "ICE",
      options: [
        { value: "ICE", label: "Internal Combustion" }, { value: "FUEL_CELL", label: "Fuel Cell" },
        { value: "FISSION", label: "Fission" }, { value: "FUSION", label: "Fusion" }
      ]
    },
    { key: "environmentalSealing", label: "Environmental Sealing", kind: "boolean", defaultValue: false },
    { key: "industrialTSM", label: "Industrial TSM", kind: "boolean", defaultValue: false }
  ],
  (design, base) => {
    const mass = design.chassis.massLimit;
    const rating = mass * Math.max(1, Math.floor(Number(design.chassis.properties.walkMP ?? 1)));
    const baseFusion = fusionEngineBaseWeight(rating);
    const engineType = String(design.chassis.properties.industrialEngineType ?? "ICE");
    const mult: Record<string,number> = { ICE: 2, FUEL_CELL: 1.2, FISSION: 1.75, FUSION: 1 };
    const costBase: Record<string,number> = { ICE: 1250, FUEL_CELL: 4000, FISSION: 7500, FUSION: 5000 };
    const engineMass = roundHalf(baseFusion * (mult[engineType] ?? 2));
    const structureMass = roundHalf(mass * 0.2);
    replaceEntry(base.massEntries, "structure", massEntry("structure","IndustrialMech Internal Structure",structureMass,"structure"));
    replaceEntry(base.costEntries, "structure", costEntry("structure","IndustrialMech Internal Structure",300*mass,"structure"));
    replaceEntry(base.massEntries, "engine", massEntry("engine",`${engineType.replace("_"," ")} Engine (${rating})`,engineMass,"engine"));
    replaceEntry(base.costEntries, "engine", costEntry("engine",`${engineType.replace("_"," ")} Engine (${rating})`,(costBase[engineType] ?? 1250)*rating*mass/75,"engine"));
    replaceEntry(base.massEntries, "cockpit", massEntry("cockpit","IndustrialMech Cockpit",3,"controls"));
    replaceEntry(base.costEntries, "cockpit", costEntry("cockpit","IndustrialMech Cockpit",100000,"controls"));
    replaceEntry(base.costEntries, "myomer", costEntry("myomer","Industrial Musculature",2000*mass,"structure"));
    if (Boolean(design.chassis.properties.environmentalSealing)) {
      base.costEntries.push(costEntry("industrial-sealing","Environmental Sealing",225*mass,"structure"));
      base.slotEntries.push(massEntry("industrial-sealing-crits","Environmental Sealing critical slots",8,"slots"));
    }
    if (Boolean(design.chassis.properties.industrialTSM)) {
      base.slotEntries.push(massEntry("industrial-tsm-crits","Industrial TSM critical slots",12,"slots"));
      if (design.rules.techBase === "CLAN") base.validation.push(issue("TECH_BASE_CONFLICT","chassis.properties.industrialTSM","Industrial TSM is an Inner Sphere technology."));
    }
    if (rating < 10 || rating > 400) base.validation.push(issue("ENGINE_RATING_INVALID","chassis.properties.walkMP","IndustrialMech engine rating must be 10–400."));
    return { placement: false, derived: { industrialEngineRating: rating, industrialEngineMass: engineMass, industrialStructureMass: structureMass } };
  },
  (d) => {
    d.chassis.properties.engineType="STANDARD_FUSION";
    d.chassis.properties.industrialEngineType="ICE";
    d.chassis.properties.walkMP=3;
    d.chassis.properties.armorTons=5;
  }
);

export const quadMechConstructor = makeVariant(
  "mech.quad", "QuadMech", 55,
  "Four-legged BattleMech construction using the standard BattleMech chassis rules with quad actuator topology.",
  [],
  (design, base) => {
    const mass = design.chassis.massLimit;
    removeEntry(base.slotEntries, "arm-actuators");
    replaceEntry(base.slotEntries, "leg-actuators", massEntry("leg-actuators","Four complete leg actuator sets",16,"slots"));
    replaceEntry(base.costEntries, "actuators", costEntry("actuators","Quad leg actuators",4*(150+80+120)*mass,"structure"));
    return { placement: false, derived: { configuration: "Quad", legActuatorSets: 4 } };
  }
);

export const tripodMechConstructor = makeVariant(
  "mech.tripod", "TripodMech", 100,
  "Interstellar Operations tripod construction with third-leg structure, 10% structure mass increase and dedicated multi-crew cockpit.",
  [
    { key: "armorCL", label: "Center Leg Armor", kind: "number", defaultValue: 0, min: 0, step: 1 }
  ],
  (design, base) => {
    const mass = design.chassis.massLimit;
    const isSuperheavy = mass > 100;
    const oldStructure = base.massEntries.find(e=>e.id==="structure")?.totalValue ?? mass*.1;
    const structureMass = roundHalf(oldStructure*1.1);
    replaceEntry(base.massEntries,"structure",massEntry("structure",`${isSuperheavy?"Superheavy ":""}Tripod Internal Structure`,structureMass,"structure"));
    const oldStructureCost = base.costEntries.find(e=>e.id==="structure")?.totalValue ?? mass*400;
    replaceEntry(base.costEntries,"structure",costEntry("structure","Tripod Internal Structure",oldStructureCost*1.2,"structure"));
    const cockpitMass = isSuperheavy ? 5 : 4;
    replaceEntry(base.massEntries,"cockpit",massEntry("cockpit",`${isSuperheavy?"Superheavy ":""}Tripod Cockpit`,cockpitMass,"controls"));
    const armorCL = Math.max(0, Number(design.chassis.properties.armorCL ?? 0));
    if (!isSuperheavy && mass > 100) base.validation.push(issue("SIZE_LIMIT_EXCEEDED","chassis.massLimit","Standard tripods top out at 100 tons; heavier tripods use superheavy construction."));
    return { placement:false, derived:{ configuration:"Tripod", tripodCockpitCrew:isSuperheavy?3:2, tripodCockpitMass:cockpitMass, centerLegArmor:armorCL, tripodStructureMass:structureMass } };
  }
);

const SUPERHEAVY_STRUCTURE: Record<number,{ct:number;st:number;arm:number;leg:number}> = {
  105:{ct:32,st:22,arm:17,leg:22},110:{ct:33,st:23,arm:18,leg:23},115:{ct:35,st:24,arm:19,leg:24},
  120:{ct:36,st:25,arm:20,leg:25},125:{ct:38,st:26,arm:21,leg:26},130:{ct:39,st:27,arm:21,leg:27},
  135:{ct:41,st:28,arm:22,leg:28},140:{ct:42,st:29,arm:23,leg:29},145:{ct:44,st:31,arm:24,leg:31},
  150:{ct:45,st:32,arm:25,leg:32},155:{ct:47,st:33,arm:26,leg:33},160:{ct:48,st:34,arm:26,leg:34},
  165:{ct:50,st:35,arm:27,leg:35},170:{ct:51,st:36,arm:28,leg:36},175:{ct:53,st:37,arm:29,leg:37},
  180:{ct:54,st:38,arm:30,leg:38},185:{ct:56,st:39,arm:31,leg:39},190:{ct:57,st:40,arm:31,leg:40},
  195:{ct:59,st:41,arm:32,leg:41},200:{ct:60,st:42,arm:33,leg:42}
};

export const superheavyMechConstructor = makeVariant(
  "mech.superheavy", "Superheavy BattleMech", 120,
  "Interstellar Operations 105–200 ton superheavy BattleMech construction with dedicated structure types and compressed critical scale.",
  [
    {
      key:"superheavyStructure", label:"Superheavy Structure", kind:"select", defaultValue:"STANDARD",
      options:[{value:"STANDARD",label:"Standard"},{value:"ENDO_COMPOSITE",label:"Endo-Composite"},{value:"ENDO_STEEL",label:"Endo Steel"}]
    }
  ],
  (design, base) => {
    const mass=design.chassis.massLimit;
    const type=String(design.chassis.properties.superheavyStructure ?? "STANDARD");
    const frac:Record<string,number>={STANDARD:.20,ENDO_COMPOSITE:.15,ENDO_STEEL:.10};
    const crits:Record<string,number>={STANDARD:0,ENDO_COMPOSITE:4,ENDO_STEEL:7};
    const cpt:Record<string,number>={STANDARD:400,ENDO_COMPOSITE:6400,ENDO_STEEL:3200};
    const structureMass=roundHalf(mass*(frac[type]??.20));
    replaceEntry(base.massEntries,"structure",massEntry("structure",`Superheavy ${type.replace("_"," ")} Structure`,structureMass,"structure"));
    replaceEntry(base.costEntries,"structure",costEntry("structure",`Superheavy ${type.replace("_"," ")} Structure`,mass*(cpt[type]??400),"structure"));
    removeEntry(base.slotEntries,"structure-crits");
    if ((crits[type]??0)>0) base.slotEntries.push(massEntry("structure-crits","Superheavy structure critical slots",crits[type],"slots"));
    replaceEntry(base.massEntries,"cockpit",massEntry("cockpit","Superheavy Cockpit",4,"controls"));
    if (design.rules.techBase !== "INNER_SPHERE") base.validation.push(issue("TECH_BASE_CONFLICT","rules.techBase","Superheavy 'Mechs use Inner Sphere technology under these rules."));
    if (mass<105 || mass>200 || mass%5!==0) base.validation.push(issue("SIZE_LIMIT_EXCEEDED","chassis.massLimit","Superheavy 'Mechs must weigh 105–200 tons in 5-ton increments."));
    const boxes=SUPERHEAVY_STRUCTURE[mass];
    return { placement:false, derived:{
      superheavy:true, superheavyStructureMass:structureMass, superheavyStructureCriticalSlots:crits[type]??0,
      structureHead:4, structureCT:boxes?.ct??0, structureSideTorso:boxes?.st??0, structureArm:boxes?.arm??0, structureLeg:boxes?.leg??0,
      maximumHeadArmor:12, criticalCompression:"2 standard critical slots per superheavy slot"
    }};
  },
  (d)=>{ d.rules.techBase="INNER_SPHERE"; d.chassis.properties.superheavyStructure="STANDARD"; d.chassis.properties.cockpitType="STANDARD"; }
);

export const lamConstructor = makeVariant(
  "mech.lam", "Land-Air 'Mech", 50,
  "Interstellar Operations standard and bimodal Land-Air 'Mech construction with conversion mass, bomb bays and prohibited-technology validation.",
  [
    { key:"lamMode",label:"LAM Type",kind:"select",defaultValue:"STANDARD",options:[{value:"STANDARD",label:"Standard (3-mode)"},{value:"BIMODAL",label:"Bimodal"}] },
    { key:"bombBays",label:"Bomb Bays",kind:"number",defaultValue:0,min:0,max:20,step:1 }
  ],
  (design,base)=>{
    const mass=design.chassis.massLimit;
    const mode=String(design.chassis.properties.lamMode??"STANDARD");
    const conversionMass=roundWhole(mass*(mode==="BIMODAL"?.15:.10));
    const bays=Math.max(0,Math.floor(Number(design.chassis.properties.bombBays??0)));
    base.massEntries.push(massEntry("lam-conversion",`${mode==="BIMODAL"?"Bimodal":"Standard"} LAM Conversion Equipment`,conversionMass,"special"));
    base.massEntries.push(massEntry("lam-bomb-bays",`LAM Bomb Bays (${bays})`,bays,"equipment"));
    if (bays>0) base.slotEntries.push(massEntry("lam-bomb-bay-crits","LAM Bomb Bay critical slots",bays,"slots"));
    const st=String(design.chassis.properties.structureType??"STANDARD");
    const et=String(design.chassis.properties.engineType??"STANDARD_FUSION");
    const gt=String(design.chassis.properties.gyroType??"STANDARD");
    const at=String(design.chassis.properties.armorType??"STANDARD");
    if (!["STANDARD_FUSION","COMPACT_FUSION"].includes(et)) base.validation.push(issue("TECH_BASE_CONFLICT","chassis.properties.engineType","LAMs may only use standard or compact fusion engines."));
    if (!["STANDARD","COMPACT","HEAVY_DUTY"].includes(gt)) base.validation.push(issue("TECH_BASE_CONFLICT","chassis.properties.gyroType","LAMs may only use standard, compact or heavy-duty gyros."));
    if (st==="ENDO_STEEL" || st==="ENDO_COMPOSITE") base.validation.push(issue("TECH_BASE_CONFLICT","chassis.properties.structureType","LAMs may not use internal structures that require critical slots."));
    if (at!=="STANDARD") base.validation.push(issue("TECH_BASE_CONFLICT","chassis.properties.armorType","This LAM constructor rejects armor types that require critical slots; use standard armor."));
    if (bays>20) base.validation.push(issue("LOCATION_OVER_CAPACITY","chassis.properties.bombBays","LAMs may mount at most 20 bomb bays."));
    return { derived:{lamType:mode,conversionEquipmentMass:conversionMass,bombBays:bays} };
  },
  (d)=>{ d.rules.techBase="INNER_SPHERE"; d.chassis.properties.lamMode="STANDARD"; d.chassis.properties.bombBays=0; }
);

export const quadVeeConstructor = makeVariant(
  "mech.quadvee", "QuadVee", 55,
  "Interstellar Operations Clan QuadVee construction with conversion gear, dedicated cockpit, tracked/wheeled motive systems and conversion cost.",
  [
    { key:"quadVeeMotive",label:"Vehicle Mode",kind:"select",defaultValue:"TRACKED",options:[{value:"TRACKED",label:"Tracked"},{value:"WHEELED",label:"Wheeled"}] }
  ],
  (design,base)=>{
    const mass=design.chassis.massLimit;
    const motive=String(design.chassis.properties.quadVeeMotive??"TRACKED");
    const conversionMass=roundWhole(mass*.10);
    const motiveMass=roundHalf(mass*(motive==="WHEELED"?.15:.10));
    base.massEntries.push(massEntry("quadvee-conversion","QuadVee Conversion Equipment",conversionMass,"special"));
    base.massEntries.push(massEntry("quadvee-motive",`QuadVee ${motive==="WHEELED"?"Wheels":"Tracks"}`,motiveMass,"movement"));
    base.slotEntries.push(massEntry("quadvee-conversion-crits","Conversion Equipment (four legs)",4,"slots"));
    base.slotEntries.push(massEntry("quadvee-motive-crits",`${motive==="WHEELED"?"Wheels":"Tracks"} (four legs)`,4,"slots"));
    replaceEntry(base.massEntries,"cockpit",massEntry("cockpit","QuadVee 2-Crew Cockpit",4,"controls"));
    removeEntry(base.slotEntries,"arm-actuators");
    replaceEntry(base.slotEntries,"leg-actuators",massEntry("leg-actuators","Four complete leg actuator sets",16,"slots"));
    replaceEntry(base.costEntries,"actuators",costEntry("actuators","QuadVee leg actuators",4*(150+80+120)*mass,"structure"));
    if (design.rules.techBase!=="CLAN") base.validation.push(issue("TECH_BASE_CONFLICT","rules.techBase","QuadVees can only be built with Clan technology."));
    if (mass<20 || mass>100 || mass%5!==0) base.validation.push(issue("SIZE_LIMIT_EXCEEDED","chassis.massLimit","QuadVees use standard BattleMech weight limits and cannot be superheavy."));
    return {
      placement:false,
      extraModifiers:[{id:"quadvee-conversion-cost",label:"QuadVee conversion cost",multiplier:1.5,explanation:"Conversion cost adds 50% of weapons, equipment and structure cost before the final 'Mech multiplier."}],
      derived:{quadVee:true,quadVeeMotive:motive,conversionEquipmentMass:conversionMass,motiveSystemMass:motiveMass,cockpitCrew:2}
    };
  },
  (d)=>{ d.rules.techBase="CLAN"; d.chassis.properties.quadVeeMotive="TRACKED"; }
);
