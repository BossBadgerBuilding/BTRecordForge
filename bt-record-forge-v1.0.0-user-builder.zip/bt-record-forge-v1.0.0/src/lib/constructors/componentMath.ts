import type {
  ComponentDefinition,
  Design,
  InstalledComponent
} from "../core/types";
import {
  buildDesignValueContext,
  evaluateConstructionValue
} from "../core/valueExpression";

export function installedComponentMass(
  design: Design,
  catalog: Map<string, ComponentDefinition>,
  installed: InstalledComponent,
  derived: Record<string, string | number | boolean> = {}
): number {
  const definition = catalog.get(installed.componentId);
  if (!definition) return 0;

  try {
    const unitMass = evaluateConstructionValue(
      definition.mass,
      buildDesignValueContext(design, derived)
    );
    return unitMass * Math.max(0, installed.quantity);
  } catch {
    return 0;
  }
}

export function sumComponentMassByLocation(
  design: Design,
  catalog: Map<string, ComponentDefinition>,
  locations: readonly string[],
  derived: Record<string, string | number | boolean> = {}
): number {
  const allowed = new Set(locations);
  return design.components.reduce((sum, installed) => {
    if (!installed.placement?.location) return sum;
    if (!allowed.has(installed.placement.location)) return sum;
    return sum + installedComponentMass(design, catalog, installed, derived);
  }, 0);
}
