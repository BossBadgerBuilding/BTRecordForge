import type {
  CostModifier,
  Design,
  LedgerEntry,
  ValidationIssue
} from "../core/types";

export type SupportVehicleType =
  | "AIRSHIP" | "FIXED_WING" | "HOVERCRAFT" | "NAVAL"
  | "TRACKED" | "VTOL" | "WHEELED" | "WIGE" | "RAIL" | "SATELLITE";
export type SupportSizeClass = "SMALL" | "MEDIUM" | "LARGE";
export type TechRating = "A" | "B" | "C" | "D" | "E" | "F";
export type SupportEngineType =
  | "ICE" | "FUSION" | "FUEL_CELL" | "FISSION" | "MAGLEV"
  | "STEAM" | "BATTERY" | "SOLAR" | "EXTERNAL" | "NONE";

export interface SupportVehicleProperties {
  vehicleType: SupportVehicleType;
  walkMP: number;
  structuralTechRating: TechRating;
  engineTechRating: TechRating;
  engineType: SupportEngineType;
  role: string;
  chassisModifications: string;
  armorBAR: number;
  armorTechRating: TechRating;
  armorPoints: number;
  heatSinks: number;
  powerAmplifierTons: number;
  turretTons: number;
  communicationsTons: number;
  fieldKitchens: number;
  mashTheaters: number;
  lightWeapons: number;
  mediumWeapons: number;
  heavyWeaponTons: number;
  weaponTons: number;
  weaponFacings: number;
  flightDecks: number;
  helipads: number;
  mobileFieldBases: number;
  unmanned: boolean;
  fireControl: "NONE" | "BASIC" | "ADVANCED";
}

interface SupportTypeData {
  chassis: readonly [number, number, number];
  engine: readonly [number, number, number];
  mediumLimit: number;
  largeLimit: number;
}

export const SUPPORT_TYPE_DATA: Record<SupportVehicleType, SupportTypeData> = {
  AIRSHIP: { chassis: [0.20,0.25,0.30], engine: [0.004,0.008,0.012], mediumLimit: 300, largeLimit: 1000 },
  FIXED_WING: { chassis: [0.08,0.10,0.15], engine: [0.005,0.010,0.015], mediumLimit: 100, largeLimit: 200 },
  HOVERCRAFT: { chassis: [0.20,0.25,0.30], engine: [0.0025,0.004,0.008], mediumLimit: 50, largeLimit: 100 },
  NAVAL: { chassis: [0.12,0.15,0.17], engine: [0.004,0.007,0.009], mediumLimit: 300, largeLimit: 100000 },
  TRACKED: { chassis: [0.13,0.15,0.25], engine: [0.006,0.013,0.025], mediumLimit: 100, largeLimit: 200 },
  VTOL: { chassis: [0.20,0.25,0.30], engine: [0.002,0.0025,0.004], mediumLimit: 30, largeLimit: 60 },
  WHEELED: { chassis: [0.12,0.15,0.18], engine: [0.0025,0.0075,0.015], mediumLimit: 80, largeLimit: 160 },
  WIGE: { chassis: [0.12,0.15,0.17], engine: [0.003,0.005,0.006], mediumLimit: 80, largeLimit: 240 },
  RAIL: { chassis: [0.15,0.20,0.30], engine: [0.003,0.004,0.005], mediumLimit: 300, largeLimit: 600 },
  SATELLITE: { chassis: [0.08,0.12,0.16], engine: [0.10,0.10,0.10], mediumLimit: 100, largeLimit: 300 }
};

export const STRUCTURE_TECH_MULTIPLIER: Record<TechRating, number> = {
  A:1.60, B:1.30, C:1.15, D:1.00, E:0.85, F:0.66
};
export const SUPPORT_ENGINE_MULTIPLIER: Record<SupportEngineType, Record<TechRating, number>> = {
  ICE:       { A:0, B:2.0, C:2.0, D:1.5, E:1.3, F:1.0 },
  FUSION:    { A:0, B:0, C:1.5, D:1.0, E:0.75, F:0.5 },
  FUEL_CELL: { A:0, B:0, C:1.2, D:1.0, E:0.9, F:0.7 },
  FISSION:   { A:0, B:0, C:1.75, D:1.5, E:1.4, F:1.3 },
  MAGLEV:    { A:0, B:0, C:0.8, D:0.7, E:0.6, F:0.5 },
  STEAM:     { A:4.0, B:3.5, C:3.0, D:2.8, E:2.8, F:2.5 },
  BATTERY:   { A:0, B:0, C:1.5, D:1.2, E:1.0, F:0.8 },
  SOLAR:     { A:0, B:0, C:5.0, D:4.5, E:4.0, F:3.5 },
  EXTERNAL:  { A:0, B:1.4, C:1.0, D:0.8, E:0.7, F:0.6 },
  NONE:      { A:0, B:0, C:0, D:0, E:0, F:0 }
};
export const SUPPORT_ENGINE_COST_MULTIPLIER: Record<SupportEngineType, number> = {
  ICE:1, FUSION:2, FUEL_CELL:1.4, FISSION:3, MAGLEV:2.5,
  STEAM:0.8, BATTERY:1.2, SOLAR:1.6, EXTERNAL:1, NONE:0
};
export const SUPPORT_STRUCTURE_COST_MULTIPLIER: Record<TechRating, number> = {
  A:0.50, B:0.75, C:1.00, D:1.25, E:1.50, F:2.00
};

interface ChassisModRule {
  weight: number;
  cost: number;
  minTech: TechRating;
  legal?: (type: SupportVehicleType, size: SupportSizeClass) => boolean;
}
export const SUPPORT_CHASSIS_MODS: Record<string, ChassisModRule> = {
  AMPHIBIOUS: { weight:1.75, cost:1.25, minTech:"C", legal:t => !["HOVERCRAFT","NAVAL","AIRSHIP","FIXED_WING"].includes(t) },
  ARMORED: { weight:1.5, cost:2.0, minTech:"A", legal:t => t !== "AIRSHIP" },
  BICYCLE: { weight:0.75, cost:0.75, minTech:"A", legal:(t,s)=>s==="SMALL" && (t==="WHEELED" || t==="HOVERCRAFT") },
  CONVERTIBLE: { weight:1.1, cost:1.1, minTech:"A", legal:t=>["WHEELED","TRACKED","HOVERCRAFT"].includes(t) },
  DUNE_BUGGY: { weight:1.5, cost:1.25, minTech:"B", legal:t=>t==="WHEELED" },
  ENVIRONMENTAL_SEALING: { weight:2, cost:1.75, minTech:"C" },
  HYDROFOIL: { weight:1.7, cost:1.1, minTech:"B", legal:t=>t==="NAVAL" },
  MONOCYCLE: { weight:0.5, cost:1.3, minTech:"B", legal:(t,s)=>s==="SMALL" && (t==="WHEELED" || t==="HOVERCRAFT") },
  OFF_ROAD: { weight:1.5, cost:1.2, minTech:"B", legal:t=>t==="WHEELED" },
  OMNI: { weight:1, cost:1, minTech:"E" },
  PROP: { weight:1.2, cost:0.75, minTech:"B", legal:t=>t==="FIXED_WING" },
  SNOWMOBILE: { weight:1.75, cost:1.3, minTech:"B", legal:t=>["WHEELED","TRACKED"].includes(t) },
  STOL: { weight:1.5, cost:1.5, minTech:"C", legal:t=>t==="FIXED_WING" },
  SUBMERSIBLE: { weight:1.8, cost:3.5, minTech:"B", legal:t=>t==="NAVAL" },
  TRACTOR: { weight:1.2, cost:1.1, minTech:"A", legal:t=>["WHEELED","TRACKED","NAVAL","RAIL"].includes(t) },
  TRAILER: { weight:0.8, cost:0.75, minTech:"A", legal:t=>["WHEELED","TRACKED","RAIL"].includes(t) },
  ULTRA_LIGHT: { weight:0.5, cost:1.5, minTech:"D", legal:(_t,s)=>s==="SMALL" },
  VSTOL: { weight:2, cost:2, minTech:"C", legal:t=>t==="FIXED_WING" }
};

const ARMOR_KG_PER_POINT: Record<number, Record<TechRating, number | null>> = {
  2:{A:40,B:25,C:16,D:13,E:12,F:11}, 3:{A:60,B:38,C:24,D:19,E:17,F:16},
  4:{A:80,B:50,C:32,D:26,E:23,F:21}, 5:{A:100,B:63,C:40,D:32,E:28,F:26},
  6:{A:130,B:75,C:48,D:38,E:34,F:32}, 7:{A:180,B:88,C:56,D:45,E:40,F:37},
  8:{A:230,B:120,C:64,D:51,E:45,F:42}, 9:{A:null,B:180,C:100,D:57,E:51,F:47},
  10:{A:null,B:250,C:150,D:63,E:56,F:52}
};
const ARMORED_REQUIRED = new Set(["5:A","6:A","6:B","7:A","7:B","7:C","8:A","8:B","8:C","8:D","9:B","9:C","9:D","9:E","10:B","10:C","10:D","10:E","10:F"]);

export function getSupportVehicleProperties(design: Design): SupportVehicleProperties {
  const p = design.chassis.properties;
  return {
    vehicleType: enumOr(p.vehicleType, ["AIRSHIP","FIXED_WING","HOVERCRAFT","NAVAL","TRACKED","VTOL","WHEELED","WIGE","RAIL","SATELLITE"] as const, "WHEELED"),
    walkMP: numberOr(p.walkMP,4),
    structuralTechRating: enumOr(p.structuralTechRating, ["A","B","C","D","E","F"] as const, "D"),
    engineTechRating: enumOr(p.engineTechRating, ["A","B","C","D","E","F"] as const, "D"),
    engineType: enumOr(p.engineType, ["ICE","FUSION","FUEL_CELL","FISSION","MAGLEV","STEAM","BATTERY","SOLAR","EXTERNAL","NONE"] as const, "ICE"),
    role: typeof p.role === "string" ? p.role : "civilian",
    chassisModifications: typeof p.chassisModifications === "string" ? p.chassisModifications : "",
    armorBAR: numberOr(p.armorBAR, 0),
    armorTechRating: enumOr(p.armorTechRating, ["A","B","C","D","E","F"] as const, "D"),
    armorPoints: numberOr(p.armorPoints, 0),
    heatSinks: numberOr(p.heatSinks, 0),
    powerAmplifierTons: numberOr(p.powerAmplifierTons, 0),
    turretTons: numberOr(p.turretTons, 0),
    communicationsTons: numberOr(p.communicationsTons, 0),
    fieldKitchens: numberOr(p.fieldKitchens, 0),
    mashTheaters: numberOr(p.mashTheaters, 0),
    lightWeapons: numberOr(p.lightWeapons, 0),
    mediumWeapons: numberOr(p.mediumWeapons, 0),
    heavyWeaponTons: numberOr(p.heavyWeaponTons, 0),
    weaponTons: numberOr(p.weaponTons, 0),
    weaponFacings: numberOr(p.weaponFacings, 0),
    flightDecks: numberOr(p.flightDecks, 0),
    helipads: numberOr(p.helipads, 0),
    mobileFieldBases: numberOr(p.mobileFieldBases, 0),
    unmanned: typeof p.unmanned === "boolean" ? p.unmanned : false,
    fireControl: enumOr(p.fireControl, ["NONE","BASIC","ADVANCED"] as const, "NONE")
  };
}

export function setSupportVehicleProperty(design: Design, key: keyof SupportVehicleProperties, value: string | number | boolean): void {
  design.chassis.properties[key] = value;
}
export function supportSizeClass(mass:number,type:SupportVehicleType):SupportSizeClass {
  const d=SUPPORT_TYPE_DATA[type]; if(mass<5)return"SMALL"; if(mass<=d.mediumLimit)return"MEDIUM"; return"LARGE";
}

export function calculateSupportVehicleBase(design: Design): {
  massEntries: LedgerEntry[]; costEntries: LedgerEntry[]; costModifiers: CostModifier[];
  validation: ValidationIssue[]; derived: Record<string,string|number|boolean>;
} {
  const mass=Math.max(0,design.chassis.massLimit), p=getSupportVehicleProperties(design), data=SUPPORT_TYPE_DATA[p.vehicleType];
  const sizeClass=supportSizeClass(mass,p.vehicleType), sizeIndex=sizeClass==="SMALL"?0:sizeClass==="MEDIUM"?1:2;
  const validation:ValidationIssue[]=[];
  if(mass>data.largeLimit) validation.push({code:"SIZE_LIMIT_EXCEEDED",severity:"error",field:"chassis.massLimit",message:`${prettyType(p.vehicleType)} Support Vehicles are limited to ${data.largeLimit.toLocaleString()} tons.`});
  const mp=Math.max(0,p.walkMP);
  if((p.vehicleType!=="AIRSHIP" && !Number.isInteger(mp)) || mp<0) validation.push({code:"MOVEMENT_INVALID",severity:"error",field:"chassis.properties.walkMP",message:"Support Vehicle Cruising/Safe Thrust is invalid."});

  const mods=parseMods(p.chassisModifications), modSet=new Set(mods);
  if(modSet.has("ARMORED")&&modSet.has("ULTRA_LIGHT")) validation.push({code:"CHASSIS_MOD_CONFLICT",severity:"error",message:"Armored and Ultra-Light chassis modifications may not be combined."});
  if(modSet.has("BICYCLE")&&modSet.has("MONOCYCLE")) validation.push({code:"CHASSIS_MOD_CONFLICT",severity:"error",message:"Bicycle and Monocycle chassis modifications may not be combined."});
  if(modSet.has("SNOWMOBILE")&&(modSet.has("DUNE_BUGGY")||modSet.has("AMPHIBIOUS")||modSet.has("OFF_ROAD"))) validation.push({code:"CHASSIS_MOD_CONFLICT",severity:"error",message:"Snowmobile may not be combined with Dune Buggy, Amphibious, or Off-Road."});

  let weightMod=1,costMod=1;
  for(const mod of mods){
    const rule=SUPPORT_CHASSIS_MODS[mod];
    if(!rule){validation.push({code:"CHASSIS_MOD_UNKNOWN",severity:"error",field:"chassis.properties.chassisModifications",message:`Unknown chassis modification "${mod}".`});continue;}
    weightMod*=rule.weight; costMod*=rule.cost;
    if(!techAtLeast(p.structuralTechRating,rule.minTech)) validation.push({code:"CHASSIS_MOD_TECH",severity:"error",message:`${prettyMod(mod)} requires Structural Tech Rating ${rule.minTech} or higher.`});
    if(rule.legal && !rule.legal(p.vehicleType,sizeClass)) validation.push({code:"CHASSIS_MOD_ILLEGAL",severity:"error",message:`${prettyMod(mod)} is not legal for this Support Vehicle type/size.`});
  }

  const chassisRaw=mass*data.chassis[sizeIndex]*STRUCTURE_TECH_MULTIPLIER[p.structuralTechRating]*weightMod;
  const chassisWeight=supportRoundUp(chassisRaw,sizeClass);
  const engMult=SUPPORT_ENGINE_MULTIPLIER[p.engineType][p.engineTechRating];
  if(p.engineType!=="NONE"&&engMult===0) validation.push({code:"ENGINE_TECH_INVALID",severity:"error",field:"chassis.properties.engineTechRating",message:`${prettyEngine(p.engineType)} is unavailable at Tech Rating ${p.engineTechRating}.`});
  const adjustedMP=p.vehicleType==="RAIL"?Math.max(0,mp-2):mp;
  // MegaMek derives the effective Support Vehicle rating from original
  // cruising/safe-thrust MP × tonnage, capped at 500. Rail's -2 MP
  // adjustment applies to engine mass, not to the displayed rating.
  const effectiveEngineRating=Math.min(500,mp*mass);
  const movementFactor=4+adjustedMP*adjustedMP;
  let engineRaw=data.engine[sizeIndex]*movementFactor*engMult*mass;
  if(p.engineType==="FUSION") engineRaw=Math.max(engineRaw,techAtLeast(p.engineTechRating,"D")?0.25:5);
  if(p.engineType==="FISSION") engineRaw=Math.max(engineRaw,5);
  if(p.vehicleType==="HOVERCRAFT") engineRaw=Math.max(engineRaw,mass*.20);
  if(p.engineType==="NONE") engineRaw=0;
  const engineWeight=supportRoundUp(engineRaw,sizeClass);

  const bar=Math.trunc(p.armorBAR), armorTech=p.armorTechRating, armorPoints=Math.max(0,Math.trunc(p.armorPoints));
  let armorMass=0, armorCost=0;
  if(bar!==0){
    if(bar<2||bar>10||!ARMOR_KG_PER_POINT[bar]) validation.push({code:"ARMOR_INVALID",severity:"error",field:"chassis.properties.armorBAR",message:"Support Vehicle BAR must be 2 through 10 (or 0 for no armor)."});
    else {
      const kg=ARMOR_KG_PER_POINT[bar][armorTech];
      if(kg===null) validation.push({code:"ARMOR_INVALID",severity:"error",message:`BAR ${bar} armor is unavailable at Tech Rating ${armorTech}.`});
      else {
        armorMass=supportRoundUp((kg*armorPoints)/1000,sizeClass);
        armorCost=armorPoints*({2:50,3:100,4:150,5:200,6:250,7:300,8:400,9:500,10:625}[bar]??0);
      }
      if(!techAtLeast(p.structuralTechRating,armorTech)) validation.push({code:"ARMOR_TECH_INVALID",severity:"error",message:"Armor Tech Rating may not exceed the chassis Structural Tech Rating."});
      if(ARMORED_REQUIRED.has(`${bar}:${armorTech}`)&&!modSet.has("ARMORED")) validation.push({code:"ARMOR_CHASSIS_REQUIRED",severity:"error",message:`BAR ${bar}/Tech ${armorTech} armor requires the Armored chassis modification.`});
    }
  }
  const maxArmor=Math.floor(4+mass*(["AIRSHIP","NAVAL","WIGE"].includes(p.vehicleType)?0.334:["FIXED_WING","HOVERCRAFT","VTOL"].includes(p.vehicleType)?1:2));
  if(armorPoints>maxArmor) validation.push({code:"ARMOR_OVER_LIMIT",severity:"error",message:`${armorPoints} armor points exceed this Support Vehicle's ${maxArmor}-point maximum.`});
  if(["ARMORED","AMPHIBIOUS","ENVIRONMENTAL_SEALING","SUBMERSIBLE"].some(x=>modSet.has(x))&&armorPoints===0) validation.push({code:"ARMOR_REQUIRED",severity:"error",message:"The selected chassis modification requires at least 1 armor point per location."});

  const rawChassisCost=2500*chassisWeight*costMod;
  const rawEngineCost=5000*engineWeight*SUPPORT_ENGINE_COST_MULTIPLIER[p.engineType];
  const structuralTechMultiplier=SUPPORT_STRUCTURE_COST_MULTIPLIER[p.structuralTechRating];
  const structuralCost=(rawChassisCost+rawEngineCost+armorCost)*structuralTechMultiplier;

  const heatSinks=Math.max(0,Math.trunc(p.heatSinks)), amps=Math.max(0,p.powerAmplifierTons), turret=Math.max(0,p.turretTons);
  const massEntries:LedgerEntry[]=[
    entry("support-chassis",`${prettyType(p.vehicleType)} chassis (Tech ${p.structuralTechRating})`,chassisWeight,"structure",`Base ${data.chassis[sizeIndex]} × Tech ${STRUCTURE_TECH_MULTIPLIER[p.structuralTechRating]} × chassis mods ${weightMod}.`),
    entry("support-engine",`${prettyEngine(p.engineType)} (Tech ${p.engineTechRating})`,engineWeight,"engine",`Base ${data.engine[sizeIndex]} × movement ${movementFactor} × engine ${engMult}.`),
    ...(armorMass>0?[entry("support-armor",`BAR ${bar} armor (${armorPoints} points)`,armorMass,"armor",`${ARMOR_KG_PER_POINT[bar][armorTech]} kg/point at Tech ${armorTech}.`)]:[]),
    ...(turret>0?[entry("support-turret","Turret mechanism",turret,"structure","Explicit turret mechanism tonnage.")]:[]),
    ...(amps>0?[entry("support-amps","Power amplifiers",amps,"equipment","Power-amplifier tonnage.")]:[])
  ];
  const costEntries:LedgerEntry[]=[
    costEntry("support-structure","Final Structural Cost (chassis + engine + armor)",structuralCost,"chassis",`(${rawChassisCost.toFixed(2)} + ${rawEngineCost.toFixed(2)} + ${armorCost.toFixed(2)}) × Tech ${p.structuralTechRating} ${structuralTechMultiplier}.`),
    ...(heatSinks?[costEntry("support-heat","Heat Sinks",heatSinks*2000,"heat","2,000 C-bills per heat sink.")]:[]),
    ...(turret?[costEntry("support-turret","Turret",turret*5000,"structure","5,000 C-bills per ton.")]:[]),
    ...(amps?[costEntry("support-amps","Power Amplifiers",amps*20000,"equipment","20,000 C-bills per ton.")]:[])
  ];

  const advancedCrewMatrix=p.vehicleType==="RAIL"||p.vehicleType==="SATELLITE"||
    (sizeClass==="LARGE"&&(p.vehicleType==="AIRSHIP"||p.vehicleType==="NAVAL"));
  let baseCrew:number;
  if(p.unmanned && p.vehicleType==="SATELLITE") baseCrew=0;
  else if(modSet.has("TRAILER") && p.engineType==="NONE") baseCrew=0;
  else if(advancedCrewMatrix){
    if(p.vehicleType==="AIRSHIP"&&sizeClass==="LARGE") baseCrew=3+Math.ceil(mass/500);
    else if(p.vehicleType==="NAVAL"&&sizeClass==="LARGE") baseCrew=3+Math.ceil(mass/5000);
    else baseCrew=sizeClass==="SMALL"?1:sizeClass==="MEDIUM"?2:3;
  } else baseCrew=sizeClass==="SMALL"?1:(sizeClass==="MEDIUM"&&(p.vehicleType==="AIRSHIP"||p.vehicleType==="NAVAL")?4:sizeClass==="MEDIUM"?2:3);

  const nonGunner=Math.ceil(Math.max(0,p.communicationsTons))
    +3*Math.max(0,Math.trunc(p.fieldKitchens))+5*Math.max(0,Math.trunc(p.mashTheaters))
    +(advancedCrewMatrix?20*Math.max(0,Math.trunc(p.flightDecks))+5*Math.max(0,Math.trunc(p.helipads))+5*Math.max(0,Math.trunc(p.mobileFieldBases)):0);
  let gunners:number;
  if(advancedCrewMatrix){
    const weaponTons=Math.max(0,p.weaponTons);
    const facings=Math.max(0,Math.trunc(p.weaponFacings));
    if(p.unmanned&&p.vehicleType==="SATELLITE"&&weaponTons>0)
      validation.push({code:"CREW_INVALID",severity:"error",message:"Unmanned Satellites may not be armed."});
    if(sizeClass==="SMALL") gunners=p.fireControl==="NONE"?Math.max(0,Math.trunc(p.lightWeapons+p.mediumWeapons)):facings;
    else if(p.fireControl==="NONE") gunners=Math.ceil(weaponTons/2);
    else if(p.fireControl==="BASIC") gunners=Math.ceil(weaponTons/3);
    else {
      const divisor=p.structuralTechRating==="F"?6:p.structuralTechRating==="E"?5:4;
      gunners=Math.ceil(weaponTons/divisor);
    }
  }else{
    const light=Math.max(0,Math.trunc(p.lightWeapons));
    const med=Math.max(0,Math.trunc(p.mediumWeapons));
    const heavy=Math.ceil(Math.max(0,p.heavyWeaponTons)/3);
    gunners=light+(p.fireControl==="NONE"?Math.ceil(med/2):med)+heavy;
  }
  const nonOfficer=baseCrew+nonGunner+gunners;
  let officers=advancedCrewMatrix?(nonOfficer>=4?Math.ceil(nonOfficer/6):0):(nonOfficer>=5?Math.ceil(nonOfficer/5):0);
  if(!advancedCrewMatrix&&(p.vehicleType==="AIRSHIP"||p.vehicleType==="NAVAL")&&mass>=5) officers=Math.max(1,officers);
  const minCrew=nonOfficer+officers;

  const tonnageMultiplier=supportVehiclePriceMultiplier(mass,p.vehicleType);
  const costModifiers:CostModifier[]=[{id:"support-vehicle-tonnage",label:"Support Vehicle tonnage/motive multiplier",multiplier:tonnageMultiplier,explanation:`${prettyType(p.vehicleType)} final-price multiplier at ${mass} tons.`}];
  return {massEntries,costEntries,costModifiers,validation,derived:{
    vehicleType:prettyType(p.vehicleType),sizeClass,cruisingMP:mp,flankMP:Math.ceil(mp*1.5),
    structuralTechRating:p.structuralTechRating,engineTechRating:p.engineTechRating,engineType:prettyEngine(p.engineType),
    chassisModifications:mods.join(", ")||"None",chassisWeight,engineWeight,effectiveEngineRating,movementFactor,armorBAR:bar,
    armorTechRating:armorTech,armorPoints,armorMass,maxArmorPoints:maxArmor,minimumCrew:minCrew,
    baseCrew,gunners,officers,advancedCrewMatrix,
    rawChassisCost,rawEngineCost,armorCost,
    structuralCostMultiplier:structuralTechMultiplier,
    finalStructuralCost:structuralCost,
    structuralCost,finalPriceMultiplier:tonnageMultiplier
  }};
}

export function supportRoundUp(value:number,sizeClass:SupportSizeClass):number{
  if(!Number.isFinite(value)||value<=0)return 0;
  return sizeClass==="SMALL"?Math.ceil(value*1000-1e-9)/1000:Math.ceil((value-Number.EPSILON)*2)/2;
}
export function supportVehiclePriceMultiplier(mass:number,type:SupportVehicleType):number{
  switch(type){
    case"NAVAL":return 1+mass/100000; case"HOVERCRAFT":return 1+mass/50; case"WHEELED":return 1+mass/200;
    case"TRACKED":return 1+mass/100; case"VTOL":return 1+mass/30; case"WIGE":return 1+mass/25;
    case"FIXED_WING":return 1+mass/50; case"AIRSHIP":return 1+mass/10000; case"RAIL":return 1+mass/250;
    default:return 1;
  }
}
function parseMods(v:string):string[]{return [...new Set(v.split(/[,;\n]+/).map(x=>x.trim().toUpperCase().replace(/[\s-]+/g,"_")).filter(Boolean))];}
function prettyMod(v:string):string{return v.toLowerCase().replaceAll("_"," ").replace(/\b\w/g,x=>x.toUpperCase());}
function costEntry(id:string,label:string,value:number,category:string,explanation:string):LedgerEntry{return{id:`derived:${id}:cost`,label,quantity:1,unitValue:value,totalValue:value,category,explanation};}
function entry(id:string,label:string,value:number,category:string,explanation:string):LedgerEntry{return{id:`derived:${id}:mass`,label,quantity:1,unitValue:value,totalValue:value,category,explanation};}
function prettyType(type:SupportVehicleType):string{return{AIRSHIP:"Airship",FIXED_WING:"Fixed-Wing",HOVERCRAFT:"Hovercraft",NAVAL:"Naval",TRACKED:"Tracked",VTOL:"VTOL",WHEELED:"Wheeled",WIGE:"WiGE",RAIL:"Rail",SATELLITE:"Satellite"}[type];}
function prettyEngine(type:SupportEngineType):string{return{ICE:"Internal Combustion Engine",FUSION:"Fusion Engine",FUEL_CELL:"Fuel Cell",FISSION:"Fission Engine",MAGLEV:"MagLev",STEAM:"Steam Engine",BATTERY:"Battery",SOLAR:"Solar",EXTERNAL:"External Power",NONE:"No Engine"}[type];}
function techAtLeast(value:TechRating,minimum:TechRating):boolean{const r:Record<TechRating,number>={A:0,B:1,C:2,D:3,E:4,F:5};return r[value]>=r[minimum];}
function numberOr(value:string|number|boolean|undefined,fallback:number):number{return typeof value==="number"&&Number.isFinite(value)?value:fallback;}
function enumOr<T extends string>(value:string|number|boolean|undefined,allowed:readonly T[],fallback:T):T{return typeof value==="string"&&allowed.includes(value as T)?value as T:fallback;}
