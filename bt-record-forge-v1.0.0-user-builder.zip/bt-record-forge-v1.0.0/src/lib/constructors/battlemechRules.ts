import type {
  CostModifier,
  Design,
  LedgerEntry,
  TechBase,
  ValidationIssue
} from "../core/types";

export type MechEngineType =
  | "STANDARD_FUSION"
  | "LIGHT_FUSION"
  | "IS_XL_FUSION"
  | "CLAN_XL_FUSION"
  | "COMPACT_FUSION";

export type MechGyroType =
  | "STANDARD"
  | "XL"
  | "COMPACT"
  | "HEAVY_DUTY";

export type MechCockpitType =
  | "STANDARD"
  | "SMALL"
  | "TORSO_MOUNTED"
  | "COMMAND_CONSOLE";

export type MechHeatSinkType = "SINGLE" | "DOUBLE";
export type MechStructureType =
  | "STANDARD"
  | "ENDO_STEEL"
  | "COMPOSITE"
  | "ENDO_COMPOSITE"
  | "REINFORCED";
export type MechArmorType =
  | "STANDARD"
  | "IS_FERRO_FIBROUS"
  | "CLAN_FERRO_FIBROUS"
  | "LIGHT_FERRO_FIBROUS"
  | "HEAVY_FERRO_FIBROUS"
  | "STEALTH";

export interface BattleMechProperties {
  configuration: "biped";
  structureType: MechStructureType;
  armorType: MechArmorType;
  walkMP: number;
  jumpMP: number;
  engineType: MechEngineType;
  gyroType: MechGyroType;
  cockpitType: MechCockpitType;
  armorTons: number;
  heatSinks: number;
  heatSinkType: MechHeatSinkType;
  leftLowerArmActuator: boolean;
  leftHandActuator: boolean;
  rightLowerArmActuator: boolean;
  rightHandActuator: boolean;
  armorHead: number;
  armorCTFront: number;
  armorCTRear: number;
  armorLTFront: number;
  armorLTRear: number;
  armorRTFront: number;
  armorRTRear: number;
  armorLA: number;
  armorRA: number;
  armorLL: number;
  armorRL: number;
}

/**
 * Current MegaMek Engine.ENGINE_RATINGS values for ratings 0..400.
 * Array index = ceil(engine rating / 5).
 *
 * Source compatibility target:
 * megamek/common/equipment/Engine.java (GPL-3.0-or-later)
 */
export const STANDARD_FUSION_ENGINE_WEIGHTS = [
  0.0, 0.25, 0.5, 0.5, 0.5, 0.5, 1.0, 1.0, 1.0, 1.0,
  1.5, 1.5, 1.5, 2.0, 2.0, 2.0, 2.5, 2.5, 3.0, 3.0,
  3.0, 3.5, 3.5, 4.0, 4.0, 4.0, 4.5, 4.5, 5.0, 5.0,
  5.5, 5.5, 6.0, 6.0, 6.0, 7.0, 7.0, 7.5, 7.5, 8.0,
  8.5, 8.5, 9.0, 9.5, 10.0, 10.0, 10.5, 11.0, 11.5, 12.0,
  12.5, 13.0, 13.5, 14.0, 14.5, 15.5, 16.0, 16.5, 17.5, 18.0,
  19.0, 19.5, 20.5, 21.5, 22.5, 23.5, 24.5, 25.5, 27.0, 28.5,
  29.5, 31.5, 33.0, 34.5, 36.5, 38.5, 41.0, 43.5, 46.0, 49.0,
  52.5
] as const;

export interface BipedInternalStructure {
  head: number;
  centerTorso: number;
  sideTorso: number;
  arm: number;
  leg: number;
}

export const BIPED_INTERNAL_STRUCTURE: Record<number, BipedInternalStructure> = {
  20:  { head: 3, centerTorso: 6,  sideTorso: 5,  arm: 3,  leg: 4 },
  25:  { head: 3, centerTorso: 8,  sideTorso: 6,  arm: 4,  leg: 6 },
  30:  { head: 3, centerTorso: 10, sideTorso: 7,  arm: 5,  leg: 7 },
  35:  { head: 3, centerTorso: 11, sideTorso: 8,  arm: 6,  leg: 8 },
  40:  { head: 3, centerTorso: 12, sideTorso: 10, arm: 6,  leg: 10 },
  45:  { head: 3, centerTorso: 14, sideTorso: 11, arm: 7,  leg: 11 },
  50:  { head: 3, centerTorso: 16, sideTorso: 12, arm: 8,  leg: 12 },
  55:  { head: 3, centerTorso: 18, sideTorso: 13, arm: 9,  leg: 13 },
  60:  { head: 3, centerTorso: 20, sideTorso: 14, arm: 10, leg: 14 },
  65:  { head: 3, centerTorso: 21, sideTorso: 15, arm: 10, leg: 15 },
  70:  { head: 3, centerTorso: 22, sideTorso: 15, arm: 11, leg: 15 },
  75:  { head: 3, centerTorso: 23, sideTorso: 16, arm: 12, leg: 16 },
  80:  { head: 3, centerTorso: 25, sideTorso: 17, arm: 13, leg: 17 },
  85:  { head: 3, centerTorso: 27, sideTorso: 18, arm: 14, leg: 18 },
  90:  { head: 3, centerTorso: 29, sideTorso: 19, arm: 15, leg: 19 },
  95:  { head: 3, centerTorso: 30, sideTorso: 20, arm: 16, leg: 20 },
  100: { head: 3, centerTorso: 31, sideTorso: 21, arm: 17, leg: 21 }
};

export function getBipedInternalStructure(mass: number): BipedInternalStructure | undefined {
  return BIPED_INTERNAL_STRUCTURE[mass];
}

export function getBipedMaxArmorPoints(mass: number): number | undefined {
  const s = getBipedInternalStructure(mass);
  if (!s) return undefined;
  return 9
    + (2 * s.centerTorso)
    + (4 * s.sideTorso)
    + (4 * s.arm)
    + (4 * s.leg);
}

const ENGINE_WEIGHT_MULTIPLIER: Record<MechEngineType, number> = {
  STANDARD_FUSION: 1,
  LIGHT_FUSION: 0.75,
  IS_XL_FUSION: 0.5,
  CLAN_XL_FUSION: 0.5,
  COMPACT_FUSION: 1.5
};

const ENGINE_COST_BASE: Record<MechEngineType, number> = {
  STANDARD_FUSION: 5000,
  LIGHT_FUSION: 15000,
  IS_XL_FUSION: 20000,
  CLAN_XL_FUSION: 20000,
  COMPACT_FUSION: 10000
};

export function getBattleMechProperties(design: Design): BattleMechProperties {
  const p = design.chassis.properties;
  return {
    configuration: "biped",
    structureType: enumOr<MechStructureType>(
      p.structureType,
      ["STANDARD", "ENDO_STEEL", "COMPOSITE", "ENDO_COMPOSITE", "REINFORCED"],
      "STANDARD"
    ),
    armorType: enumOr<MechArmorType>(
      p.armorType,
      ["STANDARD", "IS_FERRO_FIBROUS", "CLAN_FERRO_FIBROUS", "LIGHT_FERRO_FIBROUS", "HEAVY_FERRO_FIBROUS", "STEALTH"],
      "STANDARD"
    ),
    walkMP: numberOr(p.walkMP, 4),
    jumpMP: numberOr(p.jumpMP, 0),
    engineType: enumOr<MechEngineType>(
      p.engineType,
      ["STANDARD_FUSION", "LIGHT_FUSION", "IS_XL_FUSION", "CLAN_XL_FUSION", "COMPACT_FUSION"],
      "STANDARD_FUSION"
    ),
    gyroType: enumOr<MechGyroType>(
      p.gyroType,
      ["STANDARD", "XL", "COMPACT", "HEAVY_DUTY"],
      "STANDARD"
    ),
    cockpitType: enumOr<MechCockpitType>(
      p.cockpitType,
      ["STANDARD", "SMALL", "TORSO_MOUNTED", "COMMAND_CONSOLE"],
      "STANDARD"
    ),
    armorTons: numberOr(p.armorTons, 8),
    heatSinks: numberOr(p.heatSinks, 10),
    heatSinkType: enumOr<MechHeatSinkType>(
      p.heatSinkType,
      ["SINGLE", "DOUBLE"],
      "SINGLE"
    ),
    leftLowerArmActuator: booleanOr(p.leftLowerArmActuator, true),
    leftHandActuator: booleanOr(p.leftHandActuator, true),
    rightLowerArmActuator: booleanOr(p.rightLowerArmActuator, true),
    rightHandActuator: booleanOr(p.rightHandActuator, true),
    armorHead: numberOr(p.armorHead, 9),
    armorCTFront: numberOr(p.armorCTFront, 21),
    armorCTRear: numberOr(p.armorCTRear, 6),
    armorLTFront: numberOr(p.armorLTFront, 15),
    armorLTRear: numberOr(p.armorLTRear, 4),
    armorRTFront: numberOr(p.armorRTFront, 15),
    armorRTRear: numberOr(p.armorRTRear, 4),
    armorLA: numberOr(p.armorLA, 13),
    armorRA: numberOr(p.armorRA, 13),
    armorLL: numberOr(p.armorLL, 14),
    armorRL: numberOr(p.armorRL, 14)
  };
}

export function setBattleMechProperty(
  design: Design,
  key: keyof BattleMechProperties,
  value: string | number | boolean
): void {
  design.chassis.properties[key] = value;
}

export function calculateBattleMechBase(design: Design): {
  massEntries: LedgerEntry[];
  costEntries: LedgerEntry[];
  slotEntries: LedgerEntry[];
  modifiers: CostModifier[];
  validation: ValidationIssue[];
  derived: Record<string, string | number | boolean>;
} {
  const mass = design.chassis.massLimit;
  const p = getBattleMechProperties(design);
  const validation: ValidationIssue[] = [];

  const walkMP = integerAtLeast(p.walkMP, 0);
  const jumpMP = integerAtLeast(p.jumpMP, 0);
  const engineRating = mass * walkMP;
  const runMP = Math.ceil(walkMP * 1.5);

  if (!Number.isInteger(p.walkMP) || walkMP < 1) {
    validation.push({
      code: "MOVEMENT_INVALID",
      severity: "error",
      field: "chassis.properties.walkMP",
      message: "Walking MP must be a positive whole number for this BattleMech constructor."
    });
  }

  if (!Number.isInteger(p.jumpMP) || jumpMP < 0 || jumpMP > walkMP) {
    validation.push({
      code: "MOVEMENT_INVALID",
      severity: "error",
      field: "chassis.properties.jumpMP",
      message: "Standard Jump MP must be a whole number from 0 through Walking MP."
    });
  }

  if (
    engineRating < 10 ||
    engineRating > 400 ||
    engineRating % 5 !== 0
  ) {
    validation.push({
      code: "ENGINE_RATING_INVALID",
      severity: "error",
      field: "chassis.properties.walkMP",
      message: `Engine rating ${engineRating} is outside the standard 10–400, 5-point BattleMech engine table.`
    });
  }

  validation.push(...engineLegality(design, p.engineType));

  const baseEngineWeight = fusionEngineBaseWeight(engineRating);
  const engineWeight = roundUpHalf(
    baseEngineWeight * ENGINE_WEIGHT_MULTIPLIER[p.engineType]
  );

  const structureWeight = structureWeightFor(mass, p.structureType);
  const structureSlots = structureCriticalSlots(p.structureType, design.rules.techBase);
  validateStructureLegality(validation, p.structureType, design.rules.techBase);
  const baseGyroWeight = Math.ceil(Math.max(0, engineRating) / 100);
  const gyroWeight = gyroWeightFor(baseGyroWeight, p.gyroType);
  const cockpitWeight = cockpitWeightFor(p.cockpitType);

  const heatSinkCount = Math.max(0, Math.floor(p.heatSinks));
  if (!Number.isInteger(p.heatSinks) || heatSinkCount < 10) {
    validation.push({
      code: "HEAT_SINK_INVALID",
      severity: "error",
      field: "chassis.properties.heatSinks",
      message: "This BattleMech slice requires at least 10 whole heat sinks."
    });
  }

  const paidHeatSinks = Math.max(0, heatSinkCount - 10);
  const heatSinkWeight = paidHeatSinks; // single and double sinks are 1 ton each
  const jumpJetWeight = jumpMP * jumpJetWeightEach(mass);

  const armorTons = Math.max(0, roundToHalf(p.armorTons));
  const armorMultiplier = armorPointMultiplier(p.armorType);
  const armorPoints = Math.floor(armorTons * 16 * armorMultiplier);
  const armorSlots = armorCriticalSlots(p.armorType);
  validateArmorTypeLegality(validation, p.armorType, design.rules.techBase);
  const maxArmorPoints = getBipedMaxArmorPoints(mass);

  if (maxArmorPoints !== undefined && armorPoints > maxArmorPoints) {
    validation.push({
      code: "ARMOR_OVER_LIMIT",
      severity: "error",
      field: "chassis.properties.armorTons",
      message: `${armorTons.toFixed(1)} tons of ${armorLabel(p.armorType)} provides ${armorPoints} points, above the ${maxArmorPoints}-point biped maximum for a ${mass}-ton BattleMech.`
    });
  }


  const armorAllocation = {
    head: nonNegativeWhole(p.armorHead),
    centerTorsoFront: nonNegativeWhole(p.armorCTFront),
    centerTorsoRear: nonNegativeWhole(p.armorCTRear),
    leftTorsoFront: nonNegativeWhole(p.armorLTFront),
    leftTorsoRear: nonNegativeWhole(p.armorLTRear),
    rightTorsoFront: nonNegativeWhole(p.armorRTFront),
    rightTorsoRear: nonNegativeWhole(p.armorRTRear),
    leftArm: nonNegativeWhole(p.armorLA),
    rightArm: nonNegativeWhole(p.armorRA),
    leftLeg: nonNegativeWhole(p.armorLL),
    rightLeg: nonNegativeWhole(p.armorRL)
  };

  const allocatedArmorPoints = Object.values(armorAllocation)
    .reduce((sum, value) => sum + value, 0);

  if (allocatedArmorPoints > armorPoints) {
    validation.push({
      code: "ARMOR_OVER_LIMIT",
      severity: "error",
      field: "chassis.properties.armorTons",
      message: `Armor allocation uses ${allocatedArmorPoints} points, but ${armorTons.toFixed(1)} tons of ${armorLabel(p.armorType)} only provides ${armorPoints}.`
    });
  }

  const internal = getBipedInternalStructure(mass);
  if (internal) {
    validateArmorLocation(
      validation,
      "Head",
      armorAllocation.head,
      9,
      "chassis.properties.armorHead"
    );
    validateArmorLocation(
      validation,
      "Center Torso (front + rear)",
      armorAllocation.centerTorsoFront + armorAllocation.centerTorsoRear,
      internal.centerTorso * 2,
      "chassis.properties.armorCTFront"
    );
    validateArmorLocation(
      validation,
      "Left Torso (front + rear)",
      armorAllocation.leftTorsoFront + armorAllocation.leftTorsoRear,
      internal.sideTorso * 2,
      "chassis.properties.armorLTFront"
    );
    validateArmorLocation(
      validation,
      "Right Torso (front + rear)",
      armorAllocation.rightTorsoFront + armorAllocation.rightTorsoRear,
      internal.sideTorso * 2,
      "chassis.properties.armorRTFront"
    );
    validateArmorLocation(
      validation,
      "Left Arm",
      armorAllocation.leftArm,
      internal.arm * 2,
      "chassis.properties.armorLA"
    );
    validateArmorLocation(
      validation,
      "Right Arm",
      armorAllocation.rightArm,
      internal.arm * 2,
      "chassis.properties.armorRA"
    );
    validateArmorLocation(
      validation,
      "Left Leg",
      armorAllocation.leftLeg,
      internal.leg * 2,
      "chassis.properties.armorLL"
    );
    validateArmorLocation(
      validation,
      "Right Leg",
      armorAllocation.rightLeg,
      internal.leg * 2,
      "chassis.properties.armorRL"
    );
  }

  const massEntries: LedgerEntry[] = [
    massEntry("structure", `${structureLabel(p.structureType)} Internal Structure`, structureWeight, "structure"),
    massEntry("engine", `${engineLabel(p.engineType)} (${engineRating})`, engineWeight, "engine"),
    massEntry("gyro", `${gyroLabel(p.gyroType)} Gyro`, gyroWeight, "controls"),
    massEntry("cockpit", `${cockpitLabel(p.cockpitType)} Cockpit`, cockpitWeight, "controls"),
    massEntry("armor", `${armorLabel(p.armorType)} (${armorPoints} points)`, armorTons, "armor"),
    massEntry("heat-sinks", `${p.heatSinkType === "DOUBLE" ? "Double" : "Single"} Heat Sinks above free 10`, heatSinkWeight, "heat"),
    massEntry("jump-jets", `Standard Jump Jets (${jumpMP})`, jumpJetWeight, "movement")
  ];

  const costEntries: LedgerEntry[] = [
    costEntry("cockpit", `${cockpitLabel(p.cockpitType)} Cockpit`, cockpitCostFor(p.cockpitType), "controls"),
    costEntry("life-support", "Life Support", 50000, "controls"),
    costEntry("sensors", "Sensors", mass * 2000, "controls"),
    costEntry("myomer", "Standard Musculature", mass * 2000, "structure"),
    costEntry("structure", `${structureLabel(p.structureType)} Internal Structure`, mass * structureCostPerTon(p.structureType), "structure"),
    costEntry("actuators", "Biped Actuators", actuatorCost(design, mass), "structure"),
    costEntry(
      "engine",
      `${engineLabel(p.engineType)} (${engineRating})`,
      (ENGINE_COST_BASE[p.engineType] * engineRating * mass) / 75,
      "engine"
    ),
    costEntry("gyro", `${gyroLabel(p.gyroType)} Gyro`, gyroCostFor(baseGyroWeight, p.gyroType), "controls"),
    costEntry("jump-jets", `Standard Jump Jets (${jumpMP})`, mass * jumpMP * jumpMP * 200, "movement"),
    costEntry(
      "heat-sinks",
      `${p.heatSinkType === "DOUBLE" ? "Double" : "Single"} Heat Sinks`,
      p.heatSinkType === "DOUBLE"
        ? heatSinkCount * 6000
        : Math.max(0, heatSinkCount - 10) * 2000,
      "heat"
    ),
    costEntry("armor", armorLabel(p.armorType), armorTons * armorCostPerTon(p.armorType), "armor")
  ];

  const slotEntries: LedgerEntry[] = [
    slotEntry("engine-crits", "Engine critical slots", engineCriticalSlots(p.engineType)),
    slotEntry("gyro-crits", "Gyro critical slots", gyroCriticalSlots(p.gyroType)),
    slotEntry("head-systems", "Cockpit / sensors / life support", 5),
    slotEntry("arm-actuators", "Arm actuators", armActuatorSlotCount(p)),
    slotEntry("leg-actuators", "Leg actuators", 8),
    ...(structureSlots > 0 ? [slotEntry("structure-crits", `${structureLabel(p.structureType)} critical slots`, structureSlots)] : []),
    ...(armorSlots > 0 ? [slotEntry("armor-crits", `${armorLabel(p.armorType)} critical slots`, armorSlots)] : [])
  ];

  const integralHeatSinkCapacity = Math.floor(engineRating / 25);
  const externalFreeHeatSinkCrits = Math.max(0, Math.min(10, heatSinkCount) - integralHeatSinkCapacity);
  const additionalHeatSinkCrits = Math.max(0, heatSinkCount - Math.max(10, integralHeatSinkCapacity));
  const heatSinkCritSize =
    p.heatSinkType === "SINGLE"
      ? 1
      : design.rules.techBase === "CLAN"
        ? 2
        : 3;

  if (externalFreeHeatSinkCrits > 0) {
    slotEntries.push(slotEntry(
      "free-external-heat-sinks",
      "Free heat sinks outside engine",
      externalFreeHeatSinkCrits * heatSinkCritSize
    ));
  }
  if (additionalHeatSinkCrits > 0) {
    slotEntries.push(slotEntry(
      "additional-heat-sinks",
      "Additional heat sinks outside engine",
      additionalHeatSinkCrits * heatSinkCritSize
    ));
  }
  if (jumpMP > 0) {
    slotEntries.push(slotEntry("jump-jet-crits", "Standard Jump Jets", jumpMP));
  }

  const modifiers: CostModifier[] = [
    {
      id: "battlemech-weight",
      label: "BattleMech weight multiplier",
      multiplier: 1 + mass / 100,
      explanation: "Final BattleMech cost multiplier: 1 + unit tonnage / 100."
    }
  ];

  return {
    massEntries,
    costEntries,
    slotEntries,
    modifiers,
    validation,
    derived: {
      engineRating,
      engineWeight,
      walkMP,
      runMP,
      jumpMP,
      armorPoints,
      armorAllocated: allocatedArmorPoints,
      armorUnallocated: Math.max(0, armorPoints - allocatedArmorPoints),
      maxArmorPoints: maxArmorPoints ?? "n/a",
      integralHeatSinkCapacity,
      heatSinks: heatSinkCount,
      structureWeight,
      structureType: structureLabel(p.structureType),
      structureCriticalSlots: structureSlots,
      armorType: armorLabel(p.armorType),
      armorCriticalSlots: armorSlots,
      armorPointMultiplier: armorMultiplier,
      gyroWeight,
      cockpitWeight
    }
  };
}


export function structureWeightFor(mass: number, type: MechStructureType): number {
  const standard = mass * 0.1;
  switch (type) {
    case "ENDO_STEEL": return roundUpHalf(standard * 0.5);
    case "COMPOSITE": return roundUpHalf(standard * 0.5);
    case "ENDO_COMPOSITE": return roundUpHalf(standard * 0.75);
    case "REINFORCED": return roundUpHalf(standard * 2);
    default: return roundUpHalf(standard);
  }
}

export function structureCriticalSlots(type: MechStructureType, tech: TechBase): number {
  switch (type) {
    case "ENDO_STEEL": return tech === "CLAN" ? 7 : 14;
    case "ENDO_COMPOSITE": return tech === "CLAN" ? 4 : 7;
    default: return 0;
  }
}

export function armorPointMultiplier(type: MechArmorType): number {
  switch (type) {
    case "LIGHT_FERRO_FIBROUS": return 1.06;
    case "IS_FERRO_FIBROUS": return 1.12;
    case "CLAN_FERRO_FIBROUS": return 1.2;
    case "HEAVY_FERRO_FIBROUS": return 1.24;
    default: return 1;
  }
}

export function armorCriticalSlots(type: MechArmorType): number {
  switch (type) {
    case "LIGHT_FERRO_FIBROUS": return 7;
    case "IS_FERRO_FIBROUS": return 14;
    case "CLAN_FERRO_FIBROUS": return 7;
    case "HEAVY_FERRO_FIBROUS": return 21;
    case "STEALTH": return 12;
    default: return 0;
  }
}

export function structureCostPerTon(type: MechStructureType): number {
  // TechManual gives Standard=400 and Endo-Steel=1,600 C/ton.
  // Advanced structures use their published relative structural pricing where
  // available in Tactical Operations; values are explicit rather than inferred.
  switch (type) {
    case "ENDO_STEEL": return 1600;
    case "COMPOSITE": return 1600;
    case "ENDO_COMPOSITE": return 3200;
    case "REINFORCED": return 6400;
    default: return 400;
  }
}

export function armorCostPerTon(type: MechArmorType): number {
  switch (type) {
    case "IS_FERRO_FIBROUS":
    case "CLAN_FERRO_FIBROUS": return 20000;
    case "LIGHT_FERRO_FIBROUS": return 15000;
    case "HEAVY_FERRO_FIBROUS": return 25000;
    case "STEALTH": return 50000;
    default: return 10000;
  }
}

export function structureLabel(type: MechStructureType): string {
  return {
    STANDARD: "Standard",
    ENDO_STEEL: "Endo Steel",
    COMPOSITE: "Composite",
    ENDO_COMPOSITE: "Endo-Composite",
    REINFORCED: "Reinforced"
  }[type];
}

export function armorLabel(type: MechArmorType): string {
  return {
    STANDARD: "Standard Armor",
    IS_FERRO_FIBROUS: "Inner Sphere Ferro-Fibrous Armor",
    CLAN_FERRO_FIBROUS: "Clan Ferro-Fibrous Armor",
    LIGHT_FERRO_FIBROUS: "Light Ferro-Fibrous Armor",
    HEAVY_FERRO_FIBROUS: "Heavy Ferro-Fibrous Armor",
    STEALTH: "Stealth Armor"
  }[type];
}

function validateStructureLegality(
  issues: ValidationIssue[],
  type: MechStructureType,
  tech: TechBase
): void {
  if ((type === "COMPOSITE" || type === "REINFORCED") && tech === "CLAN") {
    issues.push({
      code: "TECH_BASE_CONFLICT",
      severity: "warning",
      field: "chassis.properties.structureType",
      message: `${structureLabel(type)} is an Inner Sphere BattleMech structural technology.`
    });
  }
}

function validateArmorTypeLegality(
  issues: ValidationIssue[],
  type: MechArmorType,
  tech: TechBase
): void {
  if (tech === "CLAN" && ["IS_FERRO_FIBROUS", "LIGHT_FERRO_FIBROUS", "HEAVY_FERRO_FIBROUS", "STEALTH"].includes(type)) {
    issues.push({
      code: "TECH_BASE_CONFLICT",
      severity: "warning",
      field: "chassis.properties.armorType",
      message: `${armorLabel(type)} is not a Clan-tech BattleMech armor type.`
    });
  }
  if (tech === "INNER_SPHERE" && type === "CLAN_FERRO_FIBROUS") {
    issues.push({
      code: "TECH_BASE_CONFLICT",
      severity: "warning",
      field: "chassis.properties.armorType",
      message: "Clan Ferro-Fibrous Armor conflicts with an Inner Sphere tech base."
    });
  }
}

function armActuatorSlotCount(p: BattleMechProperties): number {
  return 4 // shoulders + upper arms
    + (p.leftLowerArmActuator ? 1 : 0)
    + (p.leftHandActuator ? 1 : 0)
    + (p.rightLowerArmActuator ? 1 : 0)
    + (p.rightHandActuator ? 1 : 0);
}

function actuatorCost(design: Design, mass: number): number {
  const p = getBattleMechProperties(design);
  const arms =
    2 * 100 * mass +
    (p.leftLowerArmActuator ? 50 * mass : 0) +
    (p.leftHandActuator ? 80 * mass : 0) +
    (p.rightLowerArmActuator ? 50 * mass : 0) +
    (p.rightHandActuator ? 80 * mass : 0);
  const legs = 2 * (150 + 80 + 120) * mass;
  return arms + legs;
}

export function fusionEngineBaseWeight(engineRating: number): number {
  if (!Number.isFinite(engineRating) || engineRating <= 0) return 0;
  const index = Math.ceil(engineRating / 5);
  return STANDARD_FUSION_ENGINE_WEIGHTS[index] ?? 0;
}

function engineLegality(design: Design, type: MechEngineType): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  const tech = design.rules.techBase;
  const year = design.rules.year;

  const techConflict = (message: string) => issues.push({
    code: "TECH_BASE_CONFLICT",
    severity: "warning",
    field: "chassis.properties.engineType",
    message
  });

  const eraConflict = (message: string) => issues.push({
    code: "ERA_ILLEGAL",
    severity: "warning",
    field: "chassis.properties.engineType",
    message
  });

  if (type === "LIGHT_FUSION" || type === "COMPACT_FUSION" || type === "IS_XL_FUSION") {
    if (tech === "CLAN") {
      techConflict(`${engineLabel(type)} is an Inner Sphere engine on a Clan-tech design.`);
    }
  }

  if (type === "CLAN_XL_FUSION" && tech === "INNER_SPHERE") {
    techConflict("Clan XL Fusion Engine conflicts with an Inner Sphere tech base.");
  }

  if (year !== undefined) {
    if (type === "LIGHT_FUSION" && year < 3055) {
      eraConflict(`Light Fusion Engine is not available by ${year}; MegaMek's current tech progression begins in 3055.`);
    }
    if (type === "COMPACT_FUSION" && year < 3060) {
      eraConflict(`Compact Fusion Engine is not available by ${year}; MegaMek's current tech progression begins in 3060.`);
    }
    if (type === "CLAN_XL_FUSION" && year < 2824) {
      eraConflict(`Clan XL Fusion Engine is not available by ${year}; MegaMek's current tech progression begins in 2824.`);
    }
    if (type === "IS_XL_FUSION") {
      if (year < 2556) {
        eraConflict(`Inner Sphere XL Fusion Engine is not available by ${year}; MegaMek's current tech progression begins in 2556.`);
      } else if (year >= 2865 && year < 3035) {
        eraConflict(`Inner Sphere XL Fusion Engine is extinct/unavailable in ${year}; MegaMek's current reintroduction date is 3035.`);
      }
    }
  }

  return issues;
}

function engineCriticalSlots(type: MechEngineType): number {
  switch (type) {
    case "COMPACT_FUSION": return 3;
    case "LIGHT_FUSION": return 10;
    case "IS_XL_FUSION": return 12;
    case "CLAN_XL_FUSION": return 10;
    default: return 6;
  }
}

function gyroCriticalSlots(type: MechGyroType): number {
  switch (type) {
    case "COMPACT": return 2;
    case "XL": return 6;
    case "HEAVY_DUTY": return 4;
    default: return 4;
  }
}

function gyroWeightFor(base: number, type: MechGyroType): number {
  switch (type) {
    case "XL": return roundUpHalf(base * 0.5);
    case "COMPACT": return roundUpHalf(base * 1.5);
    case "HEAVY_DUTY": return roundUpHalf(base * 2);
    default: return roundUpHalf(base);
  }
}

function gyroCostFor(base: number, type: MechGyroType): number {
  switch (type) {
    case "XL": return 750000 * base * 0.5;
    case "COMPACT": return 400000 * base * 1.5;
    case "HEAVY_DUTY": return 500000 * base * 2;
    default: return 300000 * base;
  }
}

function cockpitWeightFor(type: MechCockpitType): number {
  switch (type) {
    case "SMALL": return 2;
    case "TORSO_MOUNTED": return 4;
    case "COMMAND_CONSOLE": return 6;
    default: return 3;
  }
}

function cockpitCostFor(type: MechCockpitType): number {
  switch (type) {
    case "SMALL": return 175000;
    case "TORSO_MOUNTED": return 750000;
    case "COMMAND_CONSOLE": return 700000;
    default: return 200000;
  }
}

function jumpJetWeightEach(unitMass: number): number {
  if (unitMass <= 55) return 0.5;
  if (unitMass <= 85) return 1;
  return 2;
}

function massEntry(id: string, label: string, value: number, category: string): LedgerEntry {
  return {
    id: `derived:${id}:mass`,
    label,
    quantity: 1,
    unitValue: value,
    totalValue: value,
    category,
    explanation: "Constructor-derived mass."
  };
}

function costEntry(id: string, label: string, value: number, category: string): LedgerEntry {
  return {
    id: `derived:${id}:cost`,
    label,
    quantity: 1,
    unitValue: value,
    totalValue: value,
    category,
    explanation: "Constructor-derived C-bill cost."
  };
}

function slotEntry(id: string, label: string, value: number): LedgerEntry {
  return {
    id: `derived:${id}:slots`,
    label,
    quantity: 1,
    unitValue: value,
    totalValue: value,
    category: "critical"
  };
}

function engineLabel(type: MechEngineType): string {
  return {
    STANDARD_FUSION: "Standard Fusion Engine",
    LIGHT_FUSION: "Light Fusion Engine",
    IS_XL_FUSION: "Inner Sphere XL Fusion Engine",
    CLAN_XL_FUSION: "Clan XL Fusion Engine",
    COMPACT_FUSION: "Compact Fusion Engine"
  }[type];
}

function gyroLabel(type: MechGyroType): string {
  return {
    STANDARD: "Standard",
    XL: "XL",
    COMPACT: "Compact",
    HEAVY_DUTY: "Heavy-Duty"
  }[type];
}

function cockpitLabel(type: MechCockpitType): string {
  return {
    STANDARD: "Standard",
    SMALL: "Small",
    TORSO_MOUNTED: "Torso-Mounted",
    COMMAND_CONSOLE: "Command Console"
  }[type];
}

function roundUpHalf(value: number): number {
  return Math.ceil((value - Number.EPSILON) * 2) / 2;
}

function roundToHalf(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.round(value * 2) / 2;
}


function nonNegativeWhole(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.floor(value));
}

function validateArmorLocation(
  issues: ValidationIssue[],
  label: string,
  allocated: number,
  maximum: number,
  field: string
): void {
  if (allocated > maximum) {
    issues.push({
      code: "ARMOR_OVER_LIMIT",
      severity: "error",
      field,
      message: `${label} has ${allocated} armor points; its maximum is ${maximum}.`
    });
  }
}

function numberOr(value: string | number | boolean | undefined, fallback: number): number {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

function enumOr<T extends string>(
  value: string | number | boolean | undefined,
  allowed: readonly T[],
  fallback: T
): T {
  return typeof value === "string" && allowed.includes(value as T)
    ? (value as T)
    : fallback;
}

function integerAtLeast(value: number, min: number): number {
  if (!Number.isFinite(value)) return min;
  return Math.max(min, Math.floor(value));
}

function booleanOr(value: unknown, fallback: boolean): boolean {
  return typeof value === "boolean" ? value : fallback;
}
