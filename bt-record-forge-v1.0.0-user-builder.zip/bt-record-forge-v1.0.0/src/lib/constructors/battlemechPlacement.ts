import type {
  ComponentDefinition,
  ConstructionResult,
  Design,
  LedgerEntry,
  LocationSlotLedger,
  ValidationIssue
} from "../core/types";
import {
  buildDesignValueContext,
  evaluateConstructionValue
} from "../core/valueExpression";
import {
  getBattleMechProperties,
  structureCriticalSlots,
  armorCriticalSlots,
  type BattleMechProperties,
  type MechEngineType,
  type MechGyroType
} from "./battlemechRules";

export const BATTLEMECH_LOCATIONS = [
  { id: "HEAD", label: "Head", capacity: 6 },
  { id: "CT", label: "Center Torso", capacity: 12 },
  { id: "LT", label: "Left Torso", capacity: 12 },
  { id: "RT", label: "Right Torso", capacity: 12 },
  { id: "LA", label: "Left Arm", capacity: 12 },
  { id: "RA", label: "Right Arm", capacity: 12 },
  { id: "LL", label: "Left Leg", capacity: 6 },
  { id: "RL", label: "Right Leg", capacity: 6 }
] as const;

export type BattleMechLocationId =
  (typeof BATTLEMECH_LOCATIONS)[number]["id"];

interface FixedReservation {
  location: BattleMechLocationId;
  label: string;
  slots: number[];
}

const ADJACENT_SPLIT: Record<BattleMechLocationId, readonly BattleMechLocationId[]> = {
  HEAD: ["CT"],
  CT: ["HEAD", "LT", "RT"],
  LT: ["CT", "LA", "LL"],
  RT: ["CT", "RA", "RL"],
  LA: ["LT"],
  RA: ["RT"],
  LL: ["LT"],
  RL: ["RT"]
};

export function buildBattleMechLocationLedgers(
  design: Design,
  catalog: Map<string, ComponentDefinition>
): {
  locations: LocationSlotLedger[];
  validation: ValidationIssue[];
} {
  const p = getBattleMechProperties(design);
  const byLocation = new Map<BattleMechLocationId, LocationSlotLedger>(
    BATTLEMECH_LOCATIONS.map((location) => [
      location.id,
      {
        id: location.id,
        label: location.label,
        capacity: location.capacity,
        reserved: 0,
        equipmentUsed: 0,
        used: 0,
        remaining: location.capacity,
        entries: []
      }
    ])
  );
  const occupancy = new Map<BattleMechLocationId, Map<number, string>>(
    BATTLEMECH_LOCATIONS.map((x) => [x.id, new Map()])
  );
  const validation: ValidationIssue[] = [];

  for (const reservation of fixedReservations(p)) {
    reserveExact(reservation.location, reservation.slots, reservation.label, occupancy, validation);
    const ledger = byLocation.get(reservation.location)!;
    ledger.reserved += reservation.slots.length;
    ledger.entries.push(entry(
      `fixed:${reservation.location}:${reservation.label}`,
      `${reservation.label} [${reservation.slots.join(", ")}]`,
      reservation.slots.length,
      "fixed-system"
    ));
  }

  // Endo/ferro-family criticals may be placed in any legal locations. The
  // constructor deterministically fills currently free numbered slots so the
  // record is complete and collision-checkable; equipment may still be placed
  // exactly by the user and any collision is reported.
  const structureSlots = structureCriticalSlots(p.structureType, design.rules.techBase);
  autoReserveDistributed(
    structureSlots,
    `${p.structureType.replaceAll("_", " ")} structure`,
    occupancy,
    byLocation,
    validation
  );
  const armorSlots = armorCriticalSlots(p.armorType);
  autoReserveDistributed(
    armorSlots,
    `${p.armorType.replaceAll("_", " ")} armor`,
    occupancy,
    byLocation,
    validation
  );

  for (const installed of design.components) {
    const definition = catalog.get(installed.componentId);
    if (!definition || definition.slots === undefined) continue;

    let unitSlots = 0;
    try {
      unitSlots = evaluateConstructionValue(
        definition.slots,
        buildDesignValueContext(design)
      );
    } catch {
      continue;
    }
    if (unitSlots <= 0) continue;

    const locationId = installed.placement?.location;
    if (!locationId) {
      validation.push({
        code: "UNALLOCATED_COMPONENT",
        severity: "error",
        componentId: installed.componentId,
        message: `${definition.name} uses critical space but has no BattleMech location assigned.`
      });
      continue;
    }
    if (!isBattleMechLocation(locationId)) {
      validation.push({
        code: "INVALID_LOCATION",
        severity: "error",
        componentId: installed.componentId,
        message: `${definition.name} is assigned to unknown BattleMech location ${locationId}.`
      });
      continue;
    }

    const quantity = Number.isFinite(installed.quantity)
      ? Math.max(0, installed.quantity)
      : 0;
    const totalRequired = Math.ceil(unitSlots * quantity);
    const primary = sanitizeSlots(installed.placement?.criticalSlots);
    const splitLocationRaw = installed.placement?.splitLocation;
    const split = sanitizeSlots(installed.placement?.splitCriticalSlots);
    let splitLocation: BattleMechLocationId | undefined;
    if (splitLocationRaw) {
      if (!isBattleMechLocation(splitLocationRaw)) {
        validation.push({
          code: "INVALID_LOCATION",
          severity: "error",
          componentId: installed.componentId,
          message: `${definition.name} has unknown split location ${splitLocationRaw}.`
        });
      } else {
        splitLocation = splitLocationRaw;
        if (!ADJACENT_SPLIT[locationId].includes(splitLocation)) {
          validation.push({
            code: "INVALID_LOCATION",
            severity: "error",
            componentId: installed.componentId,
            message: `${definition.name} may only split between adjacent BattleMech locations; ${locationId} and ${splitLocation} are not adjacent.`
          });
        }
      }
    }
    if (split.length && !splitLocation) {
      validation.push({
        code: "INVALID_LOCATION",
        severity: "error",
        componentId: installed.componentId,
        message: `${definition.name} has split critical numbers without a split location.`
      });
    }

    let primarySlots = primary;
    let splitSlots = split;
    if (primarySlots.length + splitSlots.length === 0) {
      // Backward-compatible designs are upgraded deterministically in-memory.
      primarySlots = firstFreeSlots(locationId, totalRequired, occupancy);
      if (primarySlots.length < totalRequired) {
        validation.push({
          code: "LOCATION_OVER_CAPACITY",
          severity: "error",
          componentId: installed.componentId,
          message: `${definition.name} needs ${totalRequired} critical slots in ${locationId}, but only ${primarySlots.length} numbered slots remain.`
        });
      } else {
        validation.push({
          code: "CRITICAL_ALLOCATION_AUTO",
          severity: "warning",
          componentId: installed.componentId,
          message: `${definition.name} had no numbered critical allocation; slots ${primarySlots.join(", ")} in ${locationId} were used for validation. Save an explicit allocation for a canonical record sheet.`
        });
      }
    } else if (primarySlots.length + splitSlots.length !== totalRequired) {
      validation.push({
        code: "CRITICAL_ALLOCATION_INVALID",
        severity: "error",
        componentId: installed.componentId,
        message: `${definition.name} needs ${totalRequired} critical slots total, but ${primarySlots.length + splitSlots.length} numbered slots were assigned.`
      });
    }

    reserveExact(locationId, primarySlots, definition.name, occupancy, validation, installed.componentId);
    if (splitLocation) {
      reserveExact(splitLocation, splitSlots, `${definition.name} (split)`, occupancy, validation, installed.componentId);
    }

    addEquipmentLedger(byLocation.get(locationId)!, installed.id, definition, quantity, primarySlots.length);
    if (splitLocation && splitSlots.length) {
      addEquipmentLedger(byLocation.get(splitLocation)!, `${installed.id}:split`, definition, quantity, splitSlots.length, " (split)");
    }
  }

  const locations = [...byLocation.values()];
  for (const ledger of locations) {
    ledger.used = ledger.reserved + ledger.equipmentUsed;
    ledger.remaining = ledger.capacity - ledger.used;
    if (ledger.remaining < 0) {
      validation.push({
        code: "LOCATION_OVER_CAPACITY",
        severity: "error",
        field: `location.${ledger.id}`,
        message: `${ledger.label} uses ${ledger.used} critical slots but only has ${ledger.capacity}.`
      });
    }
  }

  return { locations, validation };
}

export function applyBattleMechPlacement(
  result: ConstructionResult,
  design: Design,
  catalog: Map<string, ComponentDefinition>
): ConstructionResult {
  const placement = buildBattleMechLocationLedgers(design, catalog);
  return {
    ...result,
    locations: placement.locations,
    validation: [...result.validation, ...placement.validation]
  };
}

export function isBattleMechLocation(
  value: string
): value is BattleMechLocationId {
  return BATTLEMECH_LOCATIONS.some((location) => location.id === value);
}

function fixedReservations(p: BattleMechProperties): FixedReservation[] {
  const reservations: FixedReservation[] = [];

  // Printed biped arm/leg actuator rows.
  reservations.push(
    { location: "LA", label: "Shoulder / Upper Arm", slots: [1, 2] },
    { location: "RA", label: "Shoulder / Upper Arm", slots: [1, 2] },
    { location: "LL", label: "Hip / Upper Leg / Lower Leg / Foot", slots: [1, 2, 3, 4] },
    { location: "RL", label: "Hip / Upper Leg / Lower Leg / Foot", slots: [1, 2, 3, 4] }
  );
  if (p.leftLowerArmActuator) reservations.push({ location: "LA", label: "Lower Arm Actuator", slots: [3] });
  if (p.leftHandActuator) reservations.push({ location: "LA", label: "Hand Actuator", slots: [4] });
  if (p.rightLowerArmActuator) reservations.push({ location: "RA", label: "Lower Arm Actuator", slots: [3] });
  if (p.rightHandActuator) reservations.push({ location: "RA", label: "Hand Actuator", slots: [4] });

  // Standard and small cockpit printed head arrangements. Advanced cockpit
  // types use their published aggregate demand but remain collision checked.
  if (p.cockpitType === "SMALL") {
    reservations.push(
      { location: "HEAD", label: "Life Support", slots: [1] },
      { location: "HEAD", label: "Sensors", slots: [2, 4] },
      { location: "HEAD", label: "Small Cockpit", slots: [3] }
    );
  } else if (p.cockpitType === "TORSO_MOUNTED") {
    // TacOps moves the cockpit plus an added sensor package into the CT,
    // keeps only the two head sensors, and moves one Life Support critical
    // into each side torso. Side-torso critical numbers are not prescribed;
    // use the last printed row deterministically so the record is explicit.
    reservations.push(
      { location: "HEAD", label: "Sensors", slots: [2, 5] },
      { location: "CT", label: "Torso-Mounted Cockpit / Sensor", slots: [11, 12] },
      { location: "LT", label: "Life Support", slots: [12] },
      { location: "RT", label: "Life Support", slots: [12] }
    );
  } else if (p.cockpitType === "COMMAND_CONSOLE") {
    reservations.push(
      { location: "HEAD", label: "Life Support", slots: [1, 6] },
      { location: "HEAD", label: "Sensors", slots: [2, 5] },
      { location: "HEAD", label: "Cockpit", slots: [3] },
      { location: "HEAD", label: "Cockpit Command Console", slots: [4] }
    );
  } else {
    reservations.push(
      { location: "HEAD", label: "Life Support", slots: [1, 6] },
      { location: "HEAD", label: "Sensors", slots: [2, 5] },
      { location: "HEAD", label: "Cockpit", slots: [3] }
    );
  }

  reservations.push(...engineReservations(p.engineType));

  const gyro = gyroReservation(p.gyroType);
  reservations.push(gyro);
  return reservations;
}

function engineReservations(type: MechEngineType): FixedReservation[] {
  const ctStandard = [1, 2, 3, 8, 9, 10];
  switch (type) {
    case "COMPACT_FUSION":
      return [{ location: "CT", label: "Compact fusion engine", slots: [1, 2, 3] }];
    case "LIGHT_FUSION":
      return [
        { location: "CT", label: "Light fusion engine", slots: ctStandard },
        { location: "LT", label: "Light fusion engine", slots: [1, 2] },
        { location: "RT", label: "Light fusion engine", slots: [1, 2] }
      ];
    case "IS_XL_FUSION":
      return [
        { location: "CT", label: "Inner Sphere XL fusion engine", slots: ctStandard },
        { location: "LT", label: "Inner Sphere XL fusion engine", slots: [1, 2, 3] },
        { location: "RT", label: "Inner Sphere XL fusion engine", slots: [1, 2, 3] }
      ];
    case "CLAN_XL_FUSION":
      return [
        { location: "CT", label: "Clan XL fusion engine", slots: ctStandard },
        { location: "LT", label: "Clan XL fusion engine", slots: [1, 2] },
        { location: "RT", label: "Clan XL fusion engine", slots: [1, 2] }
      ];
    default:
      return [{ location: "CT", label: "Standard fusion engine", slots: ctStandard }];
  }
}

function gyroReservation(type: MechGyroType): FixedReservation {
  switch (type) {
    case "COMPACT":
      return { location: "CT", label: "Compact gyro", slots: [4, 5] };
    case "XL":
      // The XL gyro occupies six CT criticals. The constructor reserves the
      // canonical free CT rows around the standard engine; collision messages
      // make incompatible engine/gyro combinations explicit.
      return { location: "CT", label: "XL gyro", slots: [4, 5, 6, 7, 11, 12] };
    case "HEAVY_DUTY":
      return { location: "CT", label: "Heavy-Duty gyro", slots: [4, 5, 6, 7] };
    default:
      return { location: "CT", label: "Standard gyro", slots: [4, 5, 6, 7] };
  }
}

function reserveExact(
  location: BattleMechLocationId,
  slots: number[],
  label: string,
  occupancy: Map<BattleMechLocationId, Map<number, string>>,
  validation: ValidationIssue[],
  componentId?: string
): void {
  const cap = BATTLEMECH_LOCATIONS.find((x) => x.id === location)!.capacity;
  const seen = new Set<number>();
  for (const slot of slots) {
    if (!Number.isInteger(slot) || slot < 1 || slot > cap) {
      validation.push({
        code: "CRITICAL_ALLOCATION_INVALID",
        severity: "error",
        componentId,
        field: `location.${location}`,
        message: `${label} uses invalid ${location} critical slot ${slot}; valid numbered slots are 1–${cap}.`
      });
      continue;
    }
    if (seen.has(slot)) {
      validation.push({
        code: "CRITICAL_ALLOCATION_INVALID",
        severity: "error",
        componentId,
        message: `${label} repeats ${location} critical slot ${slot}.`
      });
      continue;
    }
    seen.add(slot);
    const previous = occupancy.get(location)!.get(slot);
    if (previous) {
      validation.push({
        code: "CRITICAL_SLOT_COLLISION",
        severity: "error",
        componentId,
        field: `location.${location}.${slot}`,
        message: `${location} critical slot ${slot} is occupied by both ${previous} and ${label}.`
      });
    } else {
      occupancy.get(location)!.set(slot, label);
    }
  }
}

function autoReserveDistributed(
  count: number,
  label: string,
  occupancy: Map<BattleMechLocationId, Map<number, string>>,
  byLocation: Map<BattleMechLocationId, LocationSlotLedger>,
  validation: ValidationIssue[]
): void {
  let remaining = Math.max(0, Math.ceil(count));
  if (!remaining) return;
  const order: BattleMechLocationId[] = ["LT", "RT", "LA", "RA", "LL", "RL", "CT", "HEAD"];
  for (const location of order) {
    if (!remaining) break;
    const free = firstFreeSlots(location, remaining, occupancy);
    if (!free.length) continue;
    reserveExact(location, free, label, occupancy, validation);
    const ledger = byLocation.get(location)!;
    ledger.reserved += free.length;
    ledger.entries.push(entry(
      `fixed:${label}:${location}`,
      `${label} [${free.join(", ")}]`,
      free.length,
      "fixed-system"
    ));
    remaining -= free.length;
  }
  if (remaining) {
    validation.push({
      code: "LOCATION_OVER_CAPACITY",
      severity: "error",
      message: `${label} requires ${count} critical slots, but ${remaining} could not be allocated after fixed systems.`
    });
  }
}

function firstFreeSlots(
  location: BattleMechLocationId,
  count: number,
  occupancy: Map<BattleMechLocationId, Map<number, string>>
): number[] {
  const cap = BATTLEMECH_LOCATIONS.find((x) => x.id === location)!.capacity;
  const used = occupancy.get(location)!;
  const result: number[] = [];
  for (let n = 1; n <= cap && result.length < count; n += 1) {
    if (!used.has(n)) result.push(n);
  }
  return result;
}

function sanitizeSlots(value: number[] | undefined): number[] {
  if (!Array.isArray(value)) return [];
  return value.filter((x) => Number.isFinite(x)).map((x) => Math.trunc(x));
}

function addEquipmentLedger(
  ledger: LocationSlotLedger,
  installedId: string,
  definition: ComponentDefinition,
  quantity: number,
  slots: number,
  suffix = ""
): void {
  ledger.equipmentUsed += slots;
  ledger.entries.push({
    id: `equipment:${installedId}`,
    label: `${definition.name}${suffix}`,
    quantity,
    unitValue: quantity > 0 ? slots / quantity : 0,
    totalValue: slots,
    category: "equipment",
    sourceComponentId: definition.id
  });
}

function entry(id: string, label: string, slots: number, category: string): LedgerEntry {
  return {
    id,
    label,
    quantity: 1,
    unitValue: slots,
    totalValue: slots,
    category
  };
}
