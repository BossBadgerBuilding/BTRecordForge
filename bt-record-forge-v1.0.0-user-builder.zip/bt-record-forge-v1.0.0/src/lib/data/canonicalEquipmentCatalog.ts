import type { ComponentDefinition } from "../core/types";

/**
 * Generated canon equipment snapshot.
 *
 * Numeric values come from the user-supplied official construction/cost tables.
 * MegaMek/MegaMekLab are used as compatibility/errata cross-check references,
 * not copied wholesale into this GPL project.
 *
 * When an official table cell is a special-rule formula that cannot be
 * represented safely by the current expression engine, the exact cell text is
 * preserved in attributes.manualMassFormula/manualCostFormula and the common
 * calculator emits a warning rather than inventing a value.
 */
export const canonicalEquipmentComponents: ComponentDefinition[] = 
[
  {
    "id": "toaue.100-to-250-meter-diameter.is-clan",
    "name": "(100- to 250-meter diameter)",
    "categories": [
      "equipment"
    ],
    "mass": 100,
    "cost": 10000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/C-C-C",
      "rawMass": "100",
      "rawCost": "10,000,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "0",
      "slotsWarShip": "0",
      "slotsSpaceStation": "0"
    }
  },
  {
    "id": "tm.added-theater.is-clan",
    "name": "(Added Theater)",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "1",
      "rawCost": "25,000",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "228",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "0*",
      "slotsSupportVehicle": "0*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    }
  },
  {
    "id": "tm.aerospace.is-clan",
    "name": "(Aerospace)",
    "categories": [
      "weapon"
    ],
    "mass": 7,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "D",
      "rawMass": "7",
      "rawCost": "25,000",
      "heat": "NA (0)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "OS",
      "ref": "216",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "0*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "0",
      "slotsDropShip": "0"
    }
  },
  {
    "id": "tm.atmospheric.is-clan",
    "name": "(Atmospheric)",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "1",
      "rawCost": "25,000",
      "heat": "NA (0)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "227",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "0*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "0",
      "slotsDropShip": "0"
    }
  },
  {
    "id": "tm.combat-vehicle.is-clan",
    "name": "(Combat Vehicle)",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "Var*",
      "rawCost": "25,000",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "216",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "0",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "manualMassFormula": "Var*"
    }
  },
  {
    "id": "tm.core-unit.is-clan",
    "name": "(Core Unit)",
    "categories": [
      "weapon"
    ],
    "mass": 3.5,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "3.5",
      "rawCost": "25,000",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "228",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    }
  },
  {
    "id": "tm.industrialmech.is-clan",
    "name": "(IndustrialMech)",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "0.5",
      "rawCost": "25,000",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "213",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 1
  },
  {
    "id": "tm.industrialmech.is-clan.2",
    "name": "(IndustrialMech)",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "Var*",
      "rawCost": "25,000",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "216",
      "slotsBattleMech": "8*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "manualMassFormula": "Var*"
    },
    "slots": 8
  },
  {
    "id": "toaue.less-then-100-meter-diameter.is-clan",
    "name": "(less then 100-meter diameter)",
    "categories": [
      "equipment"
    ],
    "mass": 50,
    "cost": 5000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/C-C-C",
      "rawMass": "50",
      "rawCost": "5,000,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "0",
      "slotsWarShip": "0",
      "slotsSpaceStation": "0",
      "slotsMobileStructure": "NA"
    }
  },
  {
    "id": "tm.maritime.is-clan",
    "name": "(Maritime)",
    "categories": [
      "weapon"
    ],
    "mass": 7,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "7",
      "rawCost": "25,000",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "OS",
      "ref": "216",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "0*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    }
  },
  {
    "id": "tm.maritime.is-clan.2",
    "name": "(Maritime)",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "1",
      "rawCost": "25,000",
      "heat": "NA (0)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "227",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "0*",
      "slotsSupportVehicle": "0*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    }
  },
  {
    "id": "toaue.over-250-meter-diameter.is-clan",
    "name": "(over 250-meter diameter)",
    "categories": [
      "equipment"
    ],
    "mass": 500,
    "cost": 40000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/C-C-C",
      "rawMass": "500",
      "rawCost": "40,000,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "0",
      "slotsMobileStructure": "NA"
    }
  },
  {
    "id": "tm.support-vehicle.is-clan",
    "name": "(Support Vehicle)",
    "categories": [
      "weapon"
    ],
    "mass": 0.1,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "0.1",
      "rawCost": "25,000",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "213",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "0*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    }
  },
  {
    "id": "tm.support-vehicle.is-clan.2",
    "name": "(Support Vehicle)",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "*",
      "rawCost": "25,000",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "216",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "0",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "tm.item.is-clan",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 208,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "208",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS",
      "ammoPerTon": "C",
      "ref": "207",
      "slotsBattleMech": "LB-X Autocannons (Standard)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "As Standard AC",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS / Clan"
    }
  },
  {
    "id": "tm.item.is-clan.10",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 219,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "219",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS",
      "ammoPerTon": "E",
      "ref": "219",
      "slotsBattleMech": "Gauss Rifl es",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS / Clan"
    }
  },
  {
    "id": "tm.item.is-clan.11",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 219,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "219",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS / Clan",
      "ammoPerTon": "E",
      "ref": "218",
      "slotsBattleMech": "Heavy Gauss Rifl e",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS"
    }
  },
  {
    "id": "tm.item.is-clan.12",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 218,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "218",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS",
      "ammoPerTon": "E",
      "ref": "219",
      "slotsBattleMech": "Hyper-Assault Gauss Rifl e",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "Clan"
    }
  },
  {
    "id": "tm.item.is-clan.13",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 234,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "234",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "Clan",
      "ammoPerTon": "F",
      "ref": "234",
      "slotsBattleMech": "Plasma Rifl e",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS"
    }
  },
  {
    "id": "tm.item.is-clan.14",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 229,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "229",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "Clan",
      "ammoPerTon": "F",
      "ref": "229",
      "slotsBattleMech": "LRMs (Standard Ammo)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS / Clan"
    }
  },
  {
    "id": "tm.item.is-clan.15",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 229,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "229",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS / Clan",
      "ammoPerTon": "C",
      "ref": "229",
      "slotsBattleMech": "MMLs (Standard LRM Ammo)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS"
    }
  },
  {
    "id": "tm.item.is-clan.16",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 229,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "229",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS",
      "ammoPerTon": "E",
      "ref": "229",
      "slotsBattleMech": "MMLs (Standard SRM Ammo)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS"
    }
  },
  {
    "id": "tm.item.is-clan.17",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 229,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "229",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS",
      "ammoPerTon": "E",
      "ref": "229",
      "slotsBattleMech": "MRMs (Standard Ammo)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS"
    }
  },
  {
    "id": "tm.item.is-clan.18",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 229,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "229",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS",
      "ammoPerTon": "C",
      "ref": "229",
      "slotsBattleMech": "Rocket Launchers (Standard Ammo)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS"
    }
  },
  {
    "id": "tm.item.is-clan.19",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 229,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "229",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS",
      "ammoPerTon": "B",
      "ref": "229",
      "slotsBattleMech": "SRMs (Standard Ammo)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS / Clan"
    }
  },
  {
    "id": "tm.item.is-clan.2",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 207,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "207",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS / Clan",
      "ammoPerTon": "E",
      "ref": "208",
      "slotsBattleMech": "(Cluster)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS / Clan"
    }
  },
  {
    "id": "tm.item.is-clan.20",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 229,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "229",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS / Clan",
      "ammoPerTon": "C",
      "ref": "230",
      "slotsBattleMech": "Streak SRMs (Standard Ammo)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS / Clan"
    }
  },
  {
    "id": "tm.item.is-clan.21",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 230,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "230",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS / Clan",
      "ammoPerTon": "E",
      "ref": "229",
      "slotsBattleMech": "ER Ammo (ATMs)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "1/Msl (x 0.5**)",
      "slotsSupportVehicle": "9/18/27 (Extreme)",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "Clan"
    }
  },
  {
    "id": "tm.item.is-clan.22",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "206/230",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS / Clan",
      "ammoPerTon": "F",
      "ref": "230",
      "slotsBattleMech": "Flare (LRM)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "0",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS / Clan",
      "manualMassFormula": "206/230"
    }
  },
  {
    "id": "tm.item.is-clan.23",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 230,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "D",
      "rawMass": "230",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS / Clan",
      "ammoPerTon": "C",
      "ref": "230",
      "slotsBattleMech": "Fragmentation (LRM/SRM/MML)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "Var†",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS / Clan"
    }
  },
  {
    "id": "tm.item.is-clan.24",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 230,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "D",
      "rawMass": "230",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS / Clan",
      "ammoPerTon": "D",
      "ref": "230",
      "slotsBattleMech": "Harpoon (SRM)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "1/Msl (x 0.5**)",
      "slotsSupportVehicle": "0/2/4/6 (Short)",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS / Clan"
    }
  },
  {
    "id": "tm.item.is-clan.26",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 231,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "231",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS / Clan",
      "ammoPerTon": "B",
      "ref": "231",
      "slotsBattleMech": "Semi-Guided (LRM)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*†",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS"
    }
  },
  {
    "id": "tm.item.is-clan.27",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 231,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "231",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS",
      "ammoPerTon": "E",
      "ref": "231",
      "slotsBattleMech": "Swarm (LRM)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*†",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS / Clan"
    }
  },
  {
    "id": "tm.item.is-clan.28",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 231,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "231",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS / Clan",
      "ammoPerTon": "E",
      "ref": "231",
      "slotsBattleMech": "Swarm-I (LRM)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*†",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS"
    }
  },
  {
    "id": "tm.item.is-clan.29",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 231,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "231",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS",
      "ammoPerTon": "E",
      "ref": "231",
      "slotsBattleMech": "Tear Gas (SRM)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "Var†",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS / Clan"
    }
  },
  {
    "id": "tm.item.is-clan.3",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 208,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "D",
      "rawMass": "208",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS / Clan",
      "ammoPerTon": "E",
      "ref": "207",
      "slotsBattleMech": "Light Autocannons (Standard)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS"
    }
  },
  {
    "id": "tm.item.is-clan.30",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 231,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "231",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS / Clan",
      "ammoPerTon": "B",
      "ref": "231",
      "slotsBattleMech": "Thunder (LRM)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "0†",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS / Clan"
    }
  },
  {
    "id": "tm.item.is-clan.31",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 231,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "231",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS / Clan",
      "ammoPerTon": "E",
      "ref": "231",
      "slotsBattleMech": "Thunder-Augmented (LRM)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "0†",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 0.5**",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS"
    }
  },
  {
    "id": "tm.item.is-clan.32",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 231,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "231",
      "rawCost": "25,000",
      "heat": "x 0.5**",
      "damage": "x 1",
      "range": "IS",
      "ammoPerTon": "E",
      "ref": "231",
      "slotsBattleMech": "Thunder-Inferno (LRM)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "0†",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 0.5**",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS"
    }
  },
  {
    "id": "tm.item.is-clan.4",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 207,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "207",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS",
      "ammoPerTon": "D",
      "ref": "207",
      "slotsBattleMech": "Rotary Autocannons (Standard)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS"
    }
  },
  {
    "id": "tm.item.is-clan.5",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 207,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "207",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS",
      "ammoPerTon": "E",
      "ref": "208",
      "slotsBattleMech": "Ultra Autocannons (Standard)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS / Clan"
    }
  },
  {
    "id": "tm.item.is-clan.6",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 208,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "208",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS / Clan",
      "ammoPerTon": "E",
      "ref": "208",
      "slotsBattleMech": "Armor-Piercing (Standard/Light ACs)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 0.5**",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS"
    }
  },
  {
    "id": "tm.item.is-clan.7",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 208,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "208",
      "rawCost": "25,000",
      "heat": "x 0.5**",
      "damage": "x 1",
      "range": "IS",
      "ammoPerTon": "E",
      "ref": "208",
      "slotsBattleMech": "Flechette (Standard/Light ACs)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "Var†",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS"
    }
  },
  {
    "id": "tm.item.is-clan.8",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 208,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "208",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS",
      "ammoPerTon": "E",
      "ref": "208",
      "slotsBattleMech": "Precision (Standard/Light ACs)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 0.5**",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS"
    }
  },
  {
    "id": "tm.item.is-clan.9",
    "name": "*",
    "categories": [
      "weapon"
    ],
    "mass": 218,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "218",
      "rawCost": "25,000",
      "heat": "x 1",
      "damage": "x 1",
      "range": "Clan",
      "ammoPerTon": "F",
      "ref": "219",
      "slotsBattleMech": "Light Gauss Rifl e",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS"
    }
  },
  {
    "id": "tm.item.is-clan.25",
    "name": "*‡",
    "categories": [
      "weapon"
    ],
    "mass": 230,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "230",
      "rawCost": "25,000",
      "heat": "‡",
      "damage": "‡",
      "range": "IS",
      "ammoPerTon": "E",
      "ref": "231",
      "slotsBattleMech": "Inferno (SRM)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*†",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS / Clan"
    }
  },
  {
    "id": "tm.0-2-4-6-short.is-clan",
    "name": "0/2/4/6 (Short)",
    "categories": [
      "weapon"
    ],
    "mass": 230,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "230",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "x 1",
      "damage": "x 1",
      "range": "IS / Clan",
      "ammoPerTon": "D",
      "ref": "230",
      "slotsBattleMech": "Incendiary (LRM)",
      "slotsProtoMech": "*‡",
      "slotsCombatVehicle": "*‡",
      "slotsSupportVehicle": "*‡",
      "slotsFighter": "‡",
      "slotsSmallCraft": "‡",
      "slotsDropShip": "IS",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    }
  },
  {
    "id": "tm.9-18-27-extreme.is-clan",
    "name": "9/18/27 (Extreme)",
    "categories": [
      "weapon"
    ],
    "mass": 229,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "229",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "x 1",
      "damage": "x 1",
      "range": "Clan",
      "ammoPerTon": "F",
      "ref": "229",
      "slotsBattleMech": "HE Ammo (ATMs)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "3/Msl (x 1.5**)",
      "slotsSupportVehicle": "0/3/6/9 (Short)",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "Clan",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    }
  },
  {
    "id": "tm.a-pods.clan",
    "name": "A-Pods [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 1500,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2850
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "0.5",
      "rawCost": "1,500",
      "heat": "0 (NA)",
      "damage": "**",
      "range": "** (NA)",
      "ammoPerTon": "OS",
      "ref": "204",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 1
  },
  {
    "id": "tm.a-pods.is",
    "name": "A-Pods [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 1500,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3055
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "0.5",
      "rawCost": "1,500",
      "heat": "0 (NA)",
      "damage": "**",
      "range": "** (NA)",
      "ammoPerTon": "OS",
      "ref": "204",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 1
  },
  {
    "id": "tm.active-probe.clan",
    "name": "Active Probe [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 200000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "1",
      "rawCost": "200,000",
      "heat": "0 (0)",
      "damage": "NA",
      "range": "0/0/0/5 (**)",
      "ammoPerTon": "NA",
      "ref": "204",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "toaue.actuator-enhancement-sys-arm.is-clan",
    "name": "Actuator Enhancement Sys. (Arm)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": {
      "op": "multiply",
      "args": [
        500.0,
        {
          "var": "unit.mass"
        }
      ]
    },
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3070
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "*",
      "rawCost": "500xTT",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "toaue.actuator-enhancement-sys-leg.is-clan",
    "name": "Actuator Enhancement Sys. (Leg)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": {
      "op": "multiply",
      "args": [
        700.0,
        {
          "var": "unit.mass"
        }
      ]
    },
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3070
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "*",
      "rawCost": "700xTT",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "tm.advanced-sv.is-clan",
    "name": "Advanced (SV)",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2439
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "D",
      "rawMass": "Var*",
      "rawCost": "10% Weapon Cost",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "217",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "0*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "manualMassFormula": "Var*",
      "manualCostFormula": "10% Weapon Cost"
    }
  },
  {
    "id": "tm.advanced-mech.is-clan",
    "name": "Advanced (’Mech)",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2439
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "D",
      "rawMass": "0",
      "rawCost": "10% Weapon Cost",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "217",
      "slotsBattleMech": "0*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "manualCostFormula": "10% Weapon Cost"
    },
    "slots": 0
  },
  {
    "id": "io.advanced-robotic-transport-system.is-clan",
    "name": "Advanced Robotic Transport System",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 1000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 3068
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/D-E-E",
      "rawMass": "Var*",
      "rawCost": "+1,000,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "1*",
      "slotsDropShip": "1*",
      "slotsJumpShip": "NA",
      "slotsWarShip": "1*",
      "slotsSpaceStation": "1*",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "Var*"
    }
  },
  {
    "id": "toaue.angel-ecm.is-clan",
    "name": "Angel ECM",
    "categories": [
      "equipment"
    ],
    "mass": 2,
    "cost": 750000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3057
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "2",
      "rawCost": "750,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "0",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1"
    },
    "slots": 2
  },
  {
    "id": "tm.anti-missile-system.clan",
    "name": "Anti-Missile System [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 100000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "0.5",
      "rawCost": "100,000",
      "heat": "1 (1)",
      "damage": "**",
      "range": "** (Point Defense)",
      "ammoPerTon": "24",
      "ref": "204",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.anti-missile-system.is",
    "name": "Anti-Missile System [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 100000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2617
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "0.5",
      "rawCost": "100,000",
      "heat": "1 (1)",
      "damage": "**",
      "range": "** (Point Defense)",
      "ammoPerTon": "12",
      "ref": "204",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "io.anti-penetrative-ablation-armor.is",
    "name": "Anti-Penetrative Ablation Armor [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3114
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-X-E",
      "rawMass": "*",
      "rawCost": "15,000xAT",
      "slotsBattleMech": "6",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "1*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "15,000xAT"
    },
    "slots": 6
  },
  {
    "id": "tm.ap-gauss-rifle.clan",
    "name": "AP Gauss Rifle [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "0.5",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "1 (1)",
      "damage": "3 (3)",
      "range": "0/3/6/9 (Short-PD)",
      "ammoPerTon": "40",
      "ref": "218",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    },
    "slots": 1
  },
  {
    "id": "tm.ar-10-launcher.clan",
    "name": "AR-10 Launcher [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 250,
    "cost": 250000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "250",
      "rawCost": "250,000",
      "heat": "NA (††)",
      "damage": "NA (††)",
      "range": "NA (††)",
      "ammoPerTon": "††",
      "ref": "210",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1"
    }
  },
  {
    "id": "tm.ar-10-launcher.is",
    "name": "AR-10 Launcher [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 250,
    "cost": 250000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "250",
      "rawCost": "250,000",
      "heat": "NA (††)",
      "damage": "NA (††)",
      "range": "NA (††)",
      "ammoPerTon": "††",
      "ref": "210",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1"
    }
  },
  {
    "id": "toaue.armored-components.is-clan",
    "name": "Armored Components",
    "categories": [
      "equipment"
    ],
    "mass": 0.5,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3061
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "+0.5**",
      "rawCost": "150,000xCS",
      "slotsBattleMech": "0",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualCostFormula": "150,000xCS"
    },
    "slots": 0
  },
  {
    "id": "toaue.armored-motive-system-clan.clan",
    "name": "Armored Motive System (Clan) [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3057
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "0.10xTT*",
      "rawCost": "100,000xIT",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "0",
      "slotsSupportVehicle": "0",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "0.10xTT*",
      "manualCostFormula": "100,000xIT"
    }
  },
  {
    "id": "toaue.armored-motive-system-is.is",
    "name": "Armored Motive System (IS) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3071
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "0.15xTT*",
      "rawCost": "100,000xIT",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "0",
      "slotsSupportVehicle": "0",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualMassFormula": "0.15xTT*",
      "manualCostFormula": "100,000xIT"
    }
  },
  {
    "id": "tm.arresting-hoist.is-clan",
    "name": "Arresting Hoist",
    "categories": [
      "weapon"
    ],
    "mass": 3,
    "cost": 90000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "3",
      "rawCost": "90,000",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "PHYS (NA)",
      "ammoPerTon": "NA",
      "ref": "245",
      "slotsBattleMech": "3*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 3
  },
  {
    "id": "toaue.arrow-iv-missile-clan.clan",
    "name": "Arrow IV Missile (Clan) [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 12,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2850
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/E-F-E",
      "rawMass": "12",
      "rawCost": "450,000 / 10,000",
      "slotsBattleMech": "12",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "6",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1",
      "manualCostFormula": "450,000 / 10,000"
    },
    "slots": 12
  },
  {
    "id": "toaue.arrow-iv-missile-is.is",
    "name": "Arrow IV Missile (IS) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 15,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 3044
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/E-F-E",
      "rawMass": "15",
      "rawCost": "450,000 / 10,000",
      "slotsBattleMech": "15",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "7",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualCostFormula": "450,000 / 10,000"
    },
    "slots": 15
  },
  {
    "id": "toaue.artemis-v-fcs.clan",
    "name": "Artemis V FCS [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 1.5,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3061
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "+1.5**",
      "rawCost": "250,000 / x5",
      "slotsBattleMech": "+2**",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "+0",
      "slotsSupportVehicle": "+2**",
      "slotsFighter": "+0",
      "slotsSmallCraft": "+0",
      "slotsDropShip": "+0",
      "slotsJumpShip": "+0",
      "slotsWarShip": "+0",
      "slotsSpaceStation": "+0",
      "manualCostFormula": "250,000 / x5"
    },
    "slots": 2
  },
  {
    "id": "io.artificial-pain-shunt.is-clan",
    "name": "Artificial Pain Shunt",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 500000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/F-F-F",
      "rawMass": "*",
      "rawCost": "500,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "tm.atm-12.clan",
    "name": "ATM 12 [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 7,
    "cost": 350000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3055
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "7",
      "rawCost": "350,000",
      "heat": "8 (8)",
      "damage": "2/Msl (16)",
      "range": "4/5/10/15 (Medium)",
      "ammoPerTon": "5",
      "ref": "229",
      "slotsBattleMech": "5",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "5",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 5
  },
  {
    "id": "tm.atm-3.clan",
    "name": "ATM 3 [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 1.5,
    "cost": 50000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3054
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "1.5",
      "rawCost": "50,000",
      "heat": "2 (2)",
      "damage": "2/Msl (4)",
      "range": "4/5/10/15 (Medium)",
      "ammoPerTon": "20",
      "ref": "229",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 2
  },
  {
    "id": "tm.atm-6.clan",
    "name": "ATM 6 [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 3.5,
    "cost": 125000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3054
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "3.5",
      "rawCost": "125,000",
      "heat": "4 (4)",
      "damage": "2/Msl (8)",
      "range": "4/5/10/15 (Medium)",
      "ammoPerTon": "10",
      "ref": "229",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 3
  },
  {
    "id": "tm.atm-9.clan",
    "name": "ATM 9 [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 5,
    "cost": 225000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3054
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "5",
      "rawCost": "225,000",
      "heat": "6 (6)",
      "damage": "2/Msl (10)",
      "range": "4/5/10/15 (Medium)",
      "ammoPerTon": "7",
      "ref": "229",
      "slotsBattleMech": "4",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "4",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 4
  },
  {
    "id": "tm.autocannon-10.is",
    "name": "Autocannon/10 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 12,
    "cost": 200000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2460
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "12",
      "rawCost": "200,000",
      "heat": "3 (3)",
      "damage": "10 (10)",
      "range": "0/5/10/15 (Medium)",
      "ammoPerTon": "10",
      "ref": "208",
      "slotsBattleMech": "7",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "7",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 7
  },
  {
    "id": "tm.autocannon-2.is",
    "name": "Autocannon/2 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 6,
    "cost": 75000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2300
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "6",
      "rawCost": "75,000",
      "heat": "1 (1)",
      "damage": "2 (2)",
      "range": "4/8/16/24 (Long)",
      "ammoPerTon": "45",
      "ref": "208",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.autocannon-20.is",
    "name": "Autocannon/20 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 14,
    "cost": 300000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2500
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "14",
      "rawCost": "300,000",
      "heat": "7 (7)",
      "damage": "20 (20)",
      "range": "0/3/6/9 (Short)",
      "ammoPerTon": "5",
      "ref": "208",
      "slotsBattleMech": "10",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "10",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 10
  },
  {
    "id": "tm.autocannon-5.is",
    "name": "Autocannon/5 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 8,
    "cost": 125000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2250
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "8",
      "rawCost": "125,000",
      "heat": "1 (1)",
      "damage": "5 (5)",
      "range": "3/6/12/18 (Medium)",
      "ammoPerTon": "20",
      "ref": "208",
      "slotsBattleMech": "4",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 4
  },
  {
    "id": "io.autonomous-tactical-analysis-comp.is-clan",
    "name": "Autonomous Tactical Analysis Comp.",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2705
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-X-F",
      "rawMass": "Var*",
      "rawCost": "100,000xIT",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "0*",
      "slotsSpaceStation": "0*",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "Var*",
      "manualCostFormula": "100,000xIT"
    }
  },
  {
    "id": "tm.b-pods.clan",
    "name": "B-Pods [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 2500,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3068
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "1",
      "rawCost": "2,500",
      "heat": "0 (NA)",
      "damage": "**",
      "range": "** (NA)",
      "ammoPerTon": "OS",
      "ref": "204",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 1
  },
  {
    "id": "tm.b-pods.is",
    "name": "B-Pods [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 2500,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3069
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "1",
      "rawCost": "2,500",
      "heat": "0 (NA)",
      "damage": "**",
      "range": "** (NA)",
      "ammoPerTon": "OS",
      "ref": "204",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 1
  },
  {
    "id": "tm.backhoe.is-clan",
    "name": "Backhoe",
    "categories": [
      "weapon"
    ],
    "mass": 5,
    "cost": 50000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "5",
      "rawCost": "50,000",
      "heat": "0 (NA)",
      "damage": "6 (NA)",
      "range": "PHYS (NA)",
      "ammoPerTon": "NA",
      "ref": "241",
      "slotsBattleMech": "6*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 6
  },
  {
    "id": "io.ballistic-reinforced-armor.is",
    "name": "Ballistic-Reinforced Armor [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3131
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-X-E",
      "rawMass": "*",
      "rawCost": "25,000xAT",
      "slotsBattleMech": "10",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "2*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "25,000xAT"
    },
    "slots": 10
  },
  {
    "id": "tm.barracuda.clan",
    "name": "Barracuda [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 90,
    "cost": 90000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "90",
      "rawCost": "90,000",
      "heat": "NA (10)",
      "damage": "NA (20)",
      "range": "NA (Extreme)",
      "ammoPerTon": "30 t/Msl",
      "ref": "210",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1"
    }
  },
  {
    "id": "tm.barracuda.is",
    "name": "Barracuda [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 90,
    "cost": 90000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "90",
      "rawCost": "90,000",
      "heat": "NA (10)",
      "damage": "NA (20)",
      "range": "NA (Extreme)",
      "ammoPerTon": "30 t/Msl",
      "ref": "210",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1"
    }
  },
  {
    "id": "tm.barracuda-t.is",
    "name": "Barracuda-T [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 100,
    "cost": 100000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3056
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "100",
      "rawCost": "100,000",
      "heat": "NA (10)",
      "damage": "NA (20)",
      "range": "NA (Extreme)",
      "ammoPerTon": "30 t/Msl",
      "ref": "210",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1"
    }
  },
  {
    "id": "tm.basic-sv.is-clan",
    "name": "Basic (SV)",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2400
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "Var*",
      "rawCost": "5% Weapon Cost",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "217",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "0*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "manualMassFormula": "Var*",
      "manualCostFormula": "5% Weapon Cost"
    }
  },
  {
    "id": "tm.battle-armor-bay.is-clan",
    "name": "Battle Armor, Bay",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 15000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2868
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "D",
      "rawMass": "Var*",
      "rawCost": "15,000",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "239",
      "slotsBattleMech": "Var*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "0",
      "slotsSmallCraft": "0",
      "slotsDropShip": "0",
      "manualMassFormula": "Var*"
    }
  },
  {
    "id": "tm.battle-armor-comp.is-clan",
    "name": "Battle Armor, Comp.",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "D",
      "rawMass": "Var*",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "239",
      "slotsBattleMech": "Var*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "0",
      "slotsSmallCraft": "0",
      "slotsDropShip": "0",
      "manualMassFormula": "Var*",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    }
  },
  {
    "id": "io.battlemech-interface-cockpit.is",
    "name": "BattleMech Interface Cockpit [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 4,
    "cost": 1500000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3078
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-F",
      "rawMass": "4",
      "rawCost": "1,500,000",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    }
  },
  {
    "id": "io.battlemech-neural-interface-unit.is",
    "name": "BattleMech Neural Interface Unit [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0.1,
    "cost": 650000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3078
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-F",
      "rawMass": "0.1*",
      "rawCost": "650,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    }
  },
  {
    "id": "toaue.battlemech-turret-head.is",
    "name": "BattleMech Turret (Head) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3055
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/X-X-F",
      "rawMass": "TE÷10",
      "rawCost": "10,000xIT",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "TE÷10",
      "manualCostFormula": "10,000xIT"
    },
    "slots": 1
  },
  {
    "id": "toaue.battlemech-turret-quad.is-clan",
    "name": "BattleMech Turret (Quad)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2320
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/F-F-F",
      "rawMass": "TE÷10",
      "rawCost": "10,000xIT",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualMassFormula": "TE÷10",
      "manualCostFormula": "10,000xIT"
    },
    "slots": 1
  },
  {
    "id": "toaue.battlemech-turret-shoulder.is-clan",
    "name": "BattleMech Turret (Shoulder)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2450
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/F-X-F",
      "rawMass": "TE÷10",
      "rawCost": "10,000xIT",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualMassFormula": "TE÷10",
      "manualCostFormula": "10,000xIT"
    },
    "slots": 1
  },
  {
    "id": "toaue.battlemech-vehicle-harjel.is-clan",
    "name": "BattleMech/Vehicle HarJel",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3059
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E-X-X-E",
      "rawMass": "1*",
      "rawCost": "120,000xCS",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualCostFormula": "120,000xCS"
    },
    "slots": 1
  },
  {
    "id": "tm.bay-door.is-clan",
    "name": "Bay Door",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 1000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "0",
      "rawCost": "1,000",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "209",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "0*",
      "slotsSupportVehicle": "0*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "0*",
      "slotsDropShip": "0*"
    }
  },
  {
    "id": "tm.beagle-active-probe.is",
    "name": "Beagle Active Probe [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 1.5,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "1.5",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "0 (0)",
      "damage": "NA",
      "range": "0/0/0/4 (**)",
      "ammoPerTon": "NA",
      "ref": "204",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    },
    "slots": 2
  },
  {
    "id": "io.belter-fighter-pilot-package.is",
    "name": "Belter Fighter Pilot Package [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2570
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/D-D-E",
      "rawMass": "*",
      "rawCost": "25,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "io.belter-infantry-package.is",
    "name": "Belter Infantry Package [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 200000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2570
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/E-D-D",
      "rawMass": "*",
      "rawCost": "200,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "io.belter-vacuum-resistance-package.is",
    "name": "Belter Vacuum-Resistance Package [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 20000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2570
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/C-C-C",
      "rawMass": "*",
      "rawCost": "20,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "toaue.binary-laser-blazer-cannon.is",
    "name": "Binary Laser (Blazer) Cannon [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 9,
    "cost": 200000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2812
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-E-E",
      "rawMass": "9",
      "rawCost": "200,000",
      "slotsBattleMech": "4",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "4",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 4
  },
  {
    "id": "io.biological-weapon-class-iv.is-clan",
    "name": "Biological Weapon (Class IV)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 10000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/D-D-D",
      "rawMass": "*",
      "rawCost": "10M",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "io.biological-weapon-class-v.is-clan",
    "name": "Biological Weapon (Class V)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/E-F-F",
      "rawMass": "*",
      "rawCost": "† / 50M",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "† / 50M"
    }
  },
  {
    "id": "toaue.bloodhound-ap.is",
    "name": "Bloodhound AP [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 2,
    "cost": 500000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3058
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "2",
      "rawCost": "500,000",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "0",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1"
    },
    "slots": 3
  },
  {
    "id": "toaue.blue-shield-pfd.is",
    "name": "Blue Shield PFD [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 3,
    "cost": 1000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3053
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "3",
      "rawCost": "1,000,000",
      "slotsBattleMech": "7*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "Var*",
      "slotsSupportVehicle": "Var*",
      "slotsFighter": "4*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    },
    "slots": 7
  },
  {
    "id": "toaue.bombast-laser.is",
    "name": "Bombast Laser [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 7,
    "cost": 200000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3064
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-E",
      "rawMass": "7",
      "rawCost": "200,000",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1"
    },
    "slots": 3
  },
  {
    "id": "toaue.booby-trap.is",
    "name": "Booby Trap [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 100000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/D-F-D",
      "rawMass": "Var*",
      "rawCost": "100,000",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "1*",
      "slotsSmallCraft": "1*",
      "slotsDropShip": "0*",
      "slotsJumpShip": "0*",
      "slotsWarShip": "0*",
      "slotsSpaceStation": "0*",
      "slotsMobileStructure": "0*",
      "manualMassFormula": "Var*"
    },
    "slots": 1
  },
  {
    "id": "io.boosted-communications-implant.is",
    "name": "Boosted Communications Implant [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 8000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3060
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-D",
      "rawMass": "*",
      "rawCost": "8,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "io.buffered-vdni.is",
    "name": "Buffered VDNI [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 2000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3065
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "*",
      "rawCost": "2,000,000",
      "slotsBattleMech": "*",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "tm.bulldozer.is-clan",
    "name": "Bulldozer",
    "categories": [
      "weapon"
    ],
    "mass": 2,
    "cost": 50000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "2",
      "rawCost": "50,000",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "243",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    }
  },
  {
    "id": "toaue.c3-boosted-master.is",
    "name": "C3 Boosted Master [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 6,
    "cost": 3000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3073
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "6",
      "rawCost": "3,000,000",
      "slotsBattleMech": "6*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "6*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1"
    },
    "slots": 6
  },
  {
    "id": "toaue.c3-boosted-slave.is",
    "name": "C3 Boosted Slave [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 3,
    "cost": 500000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3073
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "3",
      "rawCost": "500,000",
      "slotsBattleMech": "2*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "2*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    },
    "slots": 2
  },
  {
    "id": "tm.c3-computer-master.is",
    "name": "C3 Computer (Master) [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 5,
    "cost": 1500000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3050
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "5",
      "rawCost": "1,500,000",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "209",
      "slotsBattleMech": "5*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 5
  },
  {
    "id": "tm.c3-computer-slave.is",
    "name": "C3 Computer (Slave) [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 1500000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3050
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "1",
      "rawCost": "1,500,000",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "209",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 1
  },
  {
    "id": "toaue.c3-emergency-master.is",
    "name": "C3 Emergency Master [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 2,
    "cost": 2800000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3071
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "2",
      "rawCost": "2,800,000",
      "slotsBattleMech": "2*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "2*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1"
    },
    "slots": 2
  },
  {
    "id": "toaue.c3-remote-sensor-launcher.is",
    "name": "C3 Remote Sensor Launcher [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 4,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3072
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "4",
      "rawCost": "400,000 / 100,000",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualCostFormula": "400,000 / 100,000"
    },
    "slots": 3
  },
  {
    "id": "toaue.camouflage-vdc.is-clan",
    "name": "Camouflage VDC",
    "categories": [
      "equipment"
    ],
    "mass": 2,
    "cost": 3000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2351
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/D-E-C",
      "rawMass": "2*",
      "rawCost": "3,000",
      "slotsBattleMech": "0",
      "slotsProtoMech": "0",
      "slotsCombatVehicle": "0",
      "slotsSupportVehicle": "0",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    },
    "slots": 0
  },
  {
    "id": "tm.cargo-container.is-clan",
    "name": "Cargo, Container",
    "categories": [
      "weapon"
    ],
    "mass": 10,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "10",
      "rawCost": "0",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "239",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "0",
      "slotsSmallCraft": "0",
      "slotsDropShip": "0"
    },
    "slots": 1
  },
  {
    "id": "tm.cargo-other.is-clan",
    "name": "Cargo, Other",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "Var*",
      "rawCost": "0",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "239",
      "slotsBattleMech": "Var*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "0",
      "slotsSmallCraft": "0",
      "slotsDropShip": "0",
      "manualMassFormula": "Var*"
    }
  },
  {
    "id": "tm.case.is",
    "name": "CASE [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 50000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2476
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "D",
      "rawMass": "0.5",
      "rawCost": "50,000",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "210",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "0",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 1
  },
  {
    "id": "toaue.case-ii-clan.clan",
    "name": "CASE II (Clan) [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0.5,
    "cost": 175000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3062
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "0.5",
      "rawCost": "175,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "0",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    },
    "slots": 1
  },
  {
    "id": "toaue.case-ii-is.is",
    "name": "CASE II (IS) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 175000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3064
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "1",
      "rawCost": "175,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "0",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 1
  },
  {
    "id": "io.caspar-ii-advanced-srcs.is",
    "name": "Caspar II Advanced SRCS [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3082
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-F",
      "rawMass": "Var*",
      "rawCost": "50,000+(20,000xIT)*",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "0*",
      "slotsDropShip": "0*",
      "slotsJumpShip": "NA",
      "slotsWarShip": "0*",
      "slotsSpaceStation": "0*",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "Var*",
      "manualCostFormula": "50,000+(20,000xIT)*"
    }
  },
  {
    "id": "io.centurion-weapon-system.is",
    "name": "Centurion Weapon System [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 5,
    "cost": 1000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2762
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-F-F",
      "rawMass": "5",
      "rawCost": "1,000,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 2
  },
  {
    "id": "toaue.chaff-pod.is",
    "name": "Chaff Pod [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 2000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3069
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/X-X-E",
      "rawMass": "1",
      "rawCost": "2,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1"
    },
    "slots": 1
  },
  {
    "id": "toaue.chain-whip.is",
    "name": "Chain Whip [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 3,
    "cost": 120000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3071
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/X-X-F",
      "rawMass": "3",
      "rawCost": "120,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    },
    "slots": 2
  },
  {
    "id": "tm.chainsaw.is-clan",
    "name": "Chainsaw",
    "categories": [
      "weapon"
    ],
    "mass": 5,
    "cost": 100000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "5",
      "rawCost": "100,000",
      "heat": "0 (NA)",
      "damage": "5 (NA)",
      "range": "PHYS (NA)",
      "ammoPerTon": "NA",
      "ref": "242",
      "slotsBattleMech": "5*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 5
  },
  {
    "id": "toaue.chameleon-lps.is",
    "name": "Chameleon LPS [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 600000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2630
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/F-X-X",
      "rawMass": "0",
      "rawCost": "600,000",
      "slotsBattleMech": "6*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    },
    "slots": 6
  },
  {
    "id": "toaue.chemical-laser-large.clan",
    "name": "Chemical Laser, Large [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 5,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3059
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-E",
      "rawMass": "5",
      "rawCost": "75,000 / 30,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "75,000 / 30,000"
    },
    "slots": 2
  },
  {
    "id": "toaue.chemical-laser-medium.clan",
    "name": "Chemical Laser, Medium [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3059
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-E",
      "rawMass": "1",
      "rawCost": "30,000 / 30,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "manualCostFormula": "30,000 / 30,000"
    },
    "slots": 1
  },
  {
    "id": "toaue.chemical-laser-small.clan",
    "name": "Chemical Laser, Small [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0.5,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3059
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-E",
      "rawMass": "0.5",
      "rawCost": "10,000 / 30,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "10,000 / 30,000"
    },
    "slots": 1
  },
  {
    "id": "io.chemical-weapon-class-i.is-clan",
    "name": "Chemical Weapon (Class I)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 1000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "A/C-C-C",
      "rawMass": "†",
      "rawCost": "1K",
      "slotsBattleMech": "†",
      "slotsProtoMech": "†",
      "slotsCombatVehicle": "†",
      "slotsSupportVehicle": "†",
      "slotsFighter": "†",
      "slotsSmallCraft": "†",
      "slotsDropShip": "†",
      "slotsJumpShip": "†",
      "slotsWarShip": "†",
      "slotsSpaceStation": "†",
      "slotsMobileStructure": "†",
      "manualMassFormula": "†"
    }
  },
  {
    "id": "io.chemical-weapon-class-ii.is-clan",
    "name": "Chemical Weapon (Class II)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 10000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "B/C-C-C",
      "rawMass": "†",
      "rawCost": "10K",
      "slotsBattleMech": "†",
      "slotsProtoMech": "†",
      "slotsCombatVehicle": "†",
      "slotsSupportVehicle": "†",
      "slotsFighter": "†",
      "slotsSmallCraft": "†",
      "slotsDropShip": "†",
      "slotsJumpShip": "†",
      "slotsWarShip": "†",
      "slotsSpaceStation": "†",
      "slotsMobileStructure": "†",
      "manualMassFormula": "†"
    }
  },
  {
    "id": "io.chemical-weapon-class-iii.is-clan",
    "name": "Chemical Weapon (Class III)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 250000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "B/C-D-C",
      "rawMass": "†",
      "rawCost": "250K",
      "slotsBattleMech": "†",
      "slotsProtoMech": "†",
      "slotsCombatVehicle": "†",
      "slotsSupportVehicle": "†",
      "slotsFighter": "†",
      "slotsSmallCraft": "†",
      "slotsDropShip": "†",
      "slotsJumpShip": "†",
      "slotsWarShip": "†",
      "slotsSpaceStation": "†",
      "slotsMobileStructure": "†",
      "manualMassFormula": "†"
    }
  },
  {
    "id": "io.chemical-weapon-class-iv.is-clan",
    "name": "Chemical Weapon (Class IV)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 1000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/D-D-D",
      "rawMass": "*",
      "rawCost": "1M",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "io.chemical-weapon-class-v.is-clan",
    "name": "Chemical Weapon (Class V)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/E-F-F",
      "rawMass": "*",
      "rawCost": "† / 5M",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "† / 5M"
    }
  },
  {
    "id": "io.clan-battlemech-interface-cockpit.clan",
    "name": "Clan BattleMech Interface Cockpit [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 4,
    "cost": 1500000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3083
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "4",
      "rawCost": "1,500,000",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    }
  },
  {
    "id": "io.clan-battlemech-neural-interface-unit.clan",
    "name": "Clan BattleMech Neural Interface Unit [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0.1,
    "cost": 650000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3083
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "0.1*",
      "rawCost": "650,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    }
  },
  {
    "id": "toaue.claws.is",
    "name": "Claws [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": {
      "op": "multiply",
      "args": [
        200.0,
        {
          "var": "unit.mass"
        }
      ]
    },
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3060
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/X-F-E",
      "rawMass": "TT÷15*",
      "rawCost": "200xTT",
      "slotsBattleMech": "TT÷15*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "TT÷15*"
    }
  },
  {
    "id": "toaue.cockpit-command-console.is-clan",
    "name": "Cockpit Command Console",
    "categories": [
      "equipment"
    ],
    "mass": 3,
    "cost": 500000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2631
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/C-F-E",
      "rawMass": "3*",
      "rawCost": "500,000",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "1*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    },
    "slots": 1
  },
  {
    "id": "toaue.collapsible-command-module.is-clan",
    "name": "Collapsible Command Module",
    "categories": [
      "equipment"
    ],
    "mass": 16,
    "cost": 500000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2710
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/E-F-E",
      "rawMass": "16",
      "rawCost": "500,000",
      "slotsBattleMech": "12",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 12
  },
  {
    "id": "toaue.combat-vehicle-escape-pod.is",
    "name": "Combat Vehicle Escape Pod [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 4,
    "cost": 10000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3038
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-X-E",
      "rawMass": "4",
      "rawCost": "10,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    }
  },
  {
    "id": "toaue.combat-vehicle-fission.is",
    "name": "Combat Vehicle Fission [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2470
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/E-E-D",
      "rawMass": "*",
      "rawCost": "(7,500xERxTT)÷75",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "(7,500xERxTT)÷75"
    }
  },
  {
    "id": "toaue.combat-vehicle-fuel-cell.is-clan",
    "name": "Combat Vehicle Fuel Cell",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/C-D-D",
      "rawMass": "*",
      "rawCost": "(3,500xERxTT)÷75",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "(3,500xERxTT)÷75"
    }
  },
  {
    "id": "tm.combine.is-clan",
    "name": "Combine",
    "categories": [
      "weapon"
    ],
    "mass": 2.5,
    "cost": 75000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "2.5",
      "rawCost": "75,000",
      "heat": "0 (NA)",
      "damage": "3** (NA)",
      "range": "PHYS (NA)",
      "ammoPerTon": "NA",
      "ref": "243",
      "slotsBattleMech": "4*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 4
  },
  {
    "id": "tm.comm-equipment.is-clan",
    "name": "Comm. Equipment",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "D",
      "rawMass": "Var*",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "212",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "0",
      "slotsSmallCraft": "0",
      "slotsDropShip": "0",
      "manualMassFormula": "Var*",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    },
    "slots": 1
  },
  {
    "id": "io.communications-implant.is-clan",
    "name": "Communications Implant",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 8000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2600
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/E-F-D",
      "rawMass": "*",
      "rawCost": "8,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "toaue.compact-heat-sinks.is",
    "name": "Compact Heat Sinks [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 1.5,
    "cost": 3000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3058
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "1.5",
      "rawCost": "3,000",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 1
  },
  {
    "id": "toaue.composite.is",
    "name": "Composite [IS]",
    "categories": [
      "equipment"
    ],
    "mass": {
      "op": "divide",
      "args": [
        {
          "var": "unit.mass"
        },
        20.0
      ]
    },
    "cost": {
      "op": "multiply",
      "args": [
        1600.0,
        {
          "var": "unit.mass"
        }
      ]
    },
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3061
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-E",
      "rawMass": "TT÷20",
      "rawCost": "1,600xTT",
      "slotsBattleMech": "0",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    },
    "slots": 0
  },
  {
    "id": "tm.concealed-weapon.is-clan",
    "name": "Concealed Weapon",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "Var*",
      "rawCost": "5% Weapon Cost",
      "heat": "NA",
      "damage": "NA",
      "range": "NA",
      "ammoPerTon": "NA",
      "ref": "213",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "0*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "manualMassFormula": "Var*",
      "manualCostFormula": "5% Weapon Cost"
    }
  },
  {
    "id": "toaue.coolant-pod.is-clan",
    "name": "Coolant Pod",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 50000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3049
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-X-E",
      "rawMass": "1",
      "rawCost": "50,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "1",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    },
    "slots": 1
  },
  {
    "id": "tm.crew-2nd-class.is-clan",
    "name": "Crew/2nd Class",
    "categories": [
      "weapon"
    ],
    "mass": 7,
    "cost": 15000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "7",
      "rawCost": "15,000",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "236",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "0*",
      "slotsDropShip": "0*"
    }
  },
  {
    "id": "toaue.cruise-missile-120.is",
    "name": "Cruise Missile/120 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 135,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3065
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "135",
      "rawCost": "3,000,000 / 140,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "60",
      "slotsFighter": "NA",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualCostFormula": "3,000,000 / 140,000"
    }
  },
  {
    "id": "toaue.cruise-missile-50.is",
    "name": "Cruise Missile/50 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 55,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3065
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "55",
      "rawCost": "900,000 / 20,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "25",
      "slotsFighter": "NA",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1",
      "manualCostFormula": "900,000 / 20,000"
    }
  },
  {
    "id": "toaue.cruise-missile-70.is",
    "name": "Cruise Missile/70 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 80,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3065
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "80",
      "rawCost": "1,250,000 / 50,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "35",
      "slotsFighter": "NA",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualCostFormula": "1,250,000 / 50,000"
    }
  },
  {
    "id": "toaue.cruise-missile-90.is",
    "name": "Cruise Missile/90 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 100,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3065
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "100",
      "rawCost": "2,550,000 / 90,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "45",
      "slotsFighter": "NA",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1",
      "manualCostFormula": "2,550,000 / 90,000"
    }
  },
  {
    "id": "io.damage-interrupt-circuit.is",
    "name": "Damage Interrupt Circuit [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 150,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3055
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-F",
      "rawMass": "0*",
      "rawCost": "150",
      "slotsBattleMech": "0*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 0
  },
  {
    "id": "io.dermal-armor-implants.is",
    "name": "Dermal Armor Implants [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 1500000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2950
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-E-E",
      "rawMass": "*",
      "rawCost": "1,500,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "io.dermal-camouflage-implants.is",
    "name": "Dermal Camouflage Implants [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 1100000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3065
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "*",
      "rawCost": "1,100,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "io.direct-neural-interface-modification.is",
    "name": "Direct Neural Interface Modification [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 500000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3055
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-F",
      "rawMass": "0*",
      "rawCost": "500,000",
      "slotsBattleMech": "0*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "0*",
      "slotsSupportVehicle": "0*",
      "slotsFighter": "0*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 0
  },
  {
    "id": "io.direct-tactical-analysis-control-sys.is",
    "name": "Direct Tactical Analysis Control Sys. [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3082
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "Var*",
      "rawCost": "50,000xIT",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "0*",
      "slotsSpaceStation": "0*",
      "slotsMobileStructure": "0*",
      "manualMassFormula": "Var*",
      "manualCostFormula": "50,000xIT"
    }
  },
  {
    "id": "toaue.docking-hardpoint.is-clan",
    "name": "Docking Hardpoint",
    "categories": [
      "equipment"
    ],
    "mass": 1000,
    "cost": 100000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2304
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/C-C-C",
      "rawMass": "1,000",
      "rawCost": "100,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "0",
      "slotsWarShip": "0",
      "slotsSpaceStation": "0",
      "slotsMobileStructure": "1"
    }
  },
  {
    "id": "toaue.docking-thrusters.is-clan",
    "name": "Docking Thrusters",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/C-C-C",
      "rawMass": "TT÷50*",
      "rawCost": "15,000xIT",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "3*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualMassFormula": "TT÷50*",
      "manualCostFormula": "15,000xIT"
    }
  },
  {
    "id": "io.dragon-s-breath-mcm-launch-system.is",
    "name": "Dragon’s Breath MCM Launch System [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 5000,
    "cost": 15000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3077
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-F",
      "rawMass": "5,000*",
      "rawCost": "15,000,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "0*",
      "slotsSpaceStation": "0*",
      "slotsMobileStructure": "NA"
    }
  },
  {
    "id": "toaue.drone-carrier-control-system.is-clan",
    "name": "Drone Carrier Control System",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/E-F-F",
      "rawMass": "Var*",
      "rawCost": "10,000xIT",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "NA",
      "slotsSmallCraft": "0",
      "slotsDropShip": "0",
      "slotsJumpShip": "0",
      "slotsWarShip": "0",
      "slotsSpaceStation": "0",
      "manualMassFormula": "Var*",
      "manualCostFormula": "10,000xIT"
    }
  },
  {
    "id": "toaue.drone-operating-system.is-clan",
    "name": "Drone Operating System",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/E-F-F",
      "rawMass": "Var*",
      "rawCost": "5,000+(10,000xIT)",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "1*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "Var*",
      "manualCostFormula": "5,000+(10,000xIT)"
    },
    "slots": 1
  },
  {
    "id": "io.dropshuttle-bays.is",
    "name": "DropShuttle Bays [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 11000,
    "cost": 150000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2120
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/C-X-X",
      "rawMass": "11,000",
      "rawCost": "150,000,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "0*",
      "slotsWarShip": "0*",
      "slotsSpaceStation": "0*",
      "slotsMobileStructure": "NA"
    }
  },
  {
    "id": "tm.dual-saw.is-clan",
    "name": "Dual Saw",
    "categories": [
      "weapon"
    ],
    "mass": 7,
    "cost": 100000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "7",
      "rawCost": "100,000",
      "heat": "0 (NA)",
      "damage": "7 (NA)",
      "range": "PHYS (NA)",
      "ammoPerTon": "NA",
      "ref": "243",
      "slotsBattleMech": "7*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 7
  },
  {
    "id": "toaue.dual-turret-vehicular.is-clan",
    "name": "Dual Turret (Vehicular)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/F-F-F",
      "rawMass": "TE÷10",
      "rawCost": "5,000xIT",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "0*",
      "slotsSupportVehicle": "0*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "TE÷10",
      "manualCostFormula": "5,000xIT"
    }
  },
  {
    "id": "tm.dumper.is-clan",
    "name": "Dumper",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 5000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "Var*",
      "rawCost": "5,000",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "243",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "manualMassFormula": "Var*"
    },
    "slots": 1
  },
  {
    "id": "toaue.dune-buggy.is-clan",
    "name": "Dune Buggy",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2470
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/B-B-B",
      "rawMass": "0*",
      "rawCost": "10xTTxTT",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "0*",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualCostFormula": "10xTTxTT"
    }
  },
  {
    "id": "tm.ecm-suite.clan",
    "name": "ECM Suite [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 200000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "1",
      "rawCost": "200,000",
      "heat": "0 (0)",
      "damage": "NA",
      "range": "0/0/0/6 (**)",
      "ammoPerTon": "NA",
      "ref": "213",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "io.edp-armor.clan",
    "name": "EDP Armor [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3071
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "*",
      "rawCost": "1,250xAP",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "1*",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "1,250xAP"
    }
  },
  {
    "id": "toaue.electronic-warfare-equipment.is",
    "name": "Electronic Warfare Equipment [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 7.5,
    "cost": 500000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3025
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-F-E",
      "rawMass": "7.5",
      "rawCost": "500,000",
      "slotsBattleMech": "4",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "4",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "0",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    },
    "slots": 4
  },
  {
    "id": "toaue.endo-composite-clan.clan",
    "name": "Endo-Composite (Clan) [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": {
      "op": "divide",
      "args": [
        {
          "var": "unit.mass"
        },
        13.33
      ]
    },
    "cost": {
      "op": "multiply",
      "args": [
        3200.0,
        {
          "var": "unit.mass"
        }
      ]
    },
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3073
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "TT÷13.33",
      "rawCost": "3,200xTT",
      "slotsBattleMech": "4",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    },
    "slots": 4
  },
  {
    "id": "toaue.endo-composite-inner-sphere.is",
    "name": "Endo-Composite (Inner Sphere) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": {
      "op": "divide",
      "args": [
        {
          "var": "unit.mass"
        },
        13.33
      ]
    },
    "cost": {
      "op": "multiply",
      "args": [
        3200.0,
        {
          "var": "unit.mass"
        }
      ]
    },
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3067
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "TT÷13.33",
      "rawCost": "3,200xTT",
      "slotsBattleMech": "7",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 7
  },
  {
    "id": "toaue.energy-storage-battery.is-clan",
    "name": "Energy Storage Battery",
    "categories": [
      "equipment"
    ],
    "mass": 100000,
    "cost": 1000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2131
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/C-E-D",
      "rawMass": "100,000",
      "rawCost": "1,000,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "0"
    }
  },
  {
    "id": "io.enhanced-imaging-implants.clan",
    "name": "Enhanced Imaging Implants [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 1500000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3040
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-D",
      "rawMass": "*",
      "rawCost": "1,500,000",
      "slotsBattleMech": "*",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "io.enhanced-imagining-interface.clan",
    "name": "Enhanced Imagining Interface [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 400000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3048
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "*",
      "rawCost": "400,000",
      "slotsBattleMech": "0",
      "slotsProtoMech": "0",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    },
    "slots": 0
  },
  {
    "id": "toaue.enhanced-lrm-10-nlrm-10.is",
    "name": "Enhanced LRM-10 (NLRM 10) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 6,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3058
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "6",
      "rawCost": "125,000 / 31,000",
      "slotsBattleMech": "4",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "4",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "manualCostFormula": "125,000 / 31,000"
    },
    "slots": 4
  },
  {
    "id": "toaue.enhanced-lrm-15-nlrm-15.is",
    "name": "Enhanced LRM-15 (NLRM 15) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 9,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3058
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "9",
      "rawCost": "218,750 / 31,000",
      "slotsBattleMech": "6",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "6",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "218,750 / 31,000"
    },
    "slots": 6
  },
  {
    "id": "toaue.enhanced-lrm-20-nlrm-20.is",
    "name": "Enhanced LRM-20 (NLRM 20) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 12,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3058
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "12",
      "rawCost": "312,500 / 31,000",
      "slotsBattleMech": "9",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "9",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "manualCostFormula": "312,500 / 31,000"
    },
    "slots": 9
  },
  {
    "id": "toaue.enhanced-lrm-5-nlrm-5.is",
    "name": "Enhanced LRM-5 (NLRM 5) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 3,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3058
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "3",
      "rawCost": "37,500 / 31,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "37,500 / 31,000"
    },
    "slots": 2
  },
  {
    "id": "io.enhanced-m-m-sensory-implants.is",
    "name": "Enhanced M-M Sensory Implants [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 1600000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3060
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-E",
      "rawMass": "*",
      "rawCost": "1,600,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "io.enhanced-ppc.clan",
    "name": "Enhanced PPC [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 7,
    "cost": 300000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2823
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-E-X",
      "rawMass": "7",
      "rawCost": "300,000",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 3
  },
  {
    "id": "toaue.enviro-vacuum-sealing.is-clan",
    "name": "Enviro (Vacuum) Sealing",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2470
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/C-D-C",
      "rawMass": "TT÷10*",
      "rawCost": "1.25xTC",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "0*",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "TT÷10*",
      "manualCostFormula": "1.25xTC"
    }
  },
  {
    "id": "toaue.er-flamer.is-clan",
    "name": "ER Flamer",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 15000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3067
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-X-E",
      "rawMass": "1",
      "rawCost": "15,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.er-large-laser.clan",
    "name": "ER Large Laser [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 4,
    "cost": 200000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "4",
      "rawCost": "200,000",
      "heat": "12 (12)",
      "damage": "10 (10)",
      "range": "0/8/15/25 (Extreme)",
      "ammoPerTon": "NA",
      "ref": "226",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.er-large-laser.is",
    "name": "ER Large Laser [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 5,
    "cost": 200000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2620
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "5",
      "rawCost": "200,000",
      "heat": "12 (12)",
      "damage": "8 (8)",
      "range": "0/7/14/19 (Long)",
      "ammoPerTon": "NA",
      "ref": "226",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 2
  },
  {
    "id": "tm.er-medium-laser.clan",
    "name": "ER Medium Laser [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 80000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2824
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "1",
      "rawCost": "80,000",
      "heat": "5 (5)",
      "damage": "7 (7)",
      "range": "0/5/10/15 (Medium)",
      "ammoPerTon": "NA",
      "ref": "226",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.er-medium-laser.is",
    "name": "ER Medium Laser [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 80000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3058
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "1",
      "rawCost": "80,000",
      "heat": "5 (5)",
      "damage": "5 (5)",
      "range": "0/4/8/12 (Medium)",
      "ammoPerTon": "NA",
      "ref": "226",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.er-micro-laser.clan",
    "name": "ER Micro Laser [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 0.25,
    "cost": 10000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3060
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "0.25",
      "rawCost": "10,000",
      "heat": "1 (1)",
      "damage": "2 (2)",
      "range": "0/1/2/3-4 (Short)",
      "ammoPerTon": "NA",
      "ref": "226",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.er-ppc.clan",
    "name": "ER PPC [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 6,
    "cost": 300000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "6",
      "rawCost": "300,000",
      "heat": "15 (15)",
      "damage": "15 (15)",
      "range": "0/7/14/23 (Long)",
      "ammoPerTon": "NA",
      "ref": "233",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 2
  },
  {
    "id": "tm.er-ppc.is",
    "name": "ER PPC [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 7,
    "cost": 300000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2760
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "7",
      "rawCost": "300,000",
      "heat": "15 (15)",
      "damage": "10 (10)",
      "range": "0/7/14/23 (Long)",
      "ammoPerTon": "NA",
      "ref": "233",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 3
  },
  {
    "id": "toaue.er-pulse-laser-large.clan",
    "name": "ER Pulse Laser, Large [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 6,
    "cost": 400000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3057
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-E",
      "rawMass": "6",
      "rawCost": "400,000",
      "slotsBattleMech": "3",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1"
    },
    "slots": 3
  },
  {
    "id": "toaue.er-pulse-laser-medium.clan",
    "name": "ER Pulse Laser, Medium [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 2,
    "cost": 150000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3057
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-E",
      "rawMass": "2",
      "rawCost": "150,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 2
  },
  {
    "id": "toaue.er-pulse-laser-small.clan",
    "name": "ER Pulse Laser, Small [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 1.5,
    "cost": 30000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3057
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-E",
      "rawMass": "1.5",
      "rawCost": "30,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.er-small-laser.clan",
    "name": "ER Small Laser [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 11250,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2825
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "0.5",
      "rawCost": "11,250",
      "heat": "2 (2)",
      "damage": "5 (5)",
      "range": "0/2/4/6 (Short)",
      "ammoPerTon": "NA",
      "ref": "226",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.er-small-laser.is",
    "name": "ER Small Laser [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 11250,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3058
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "0.5",
      "rawCost": "11,250",
      "heat": "2 (2)",
      "damage": "3 (3)",
      "range": "0/2/4/5 (Short)",
      "ammoPerTon": "NA",
      "ref": "226",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "io.explosive-suicide-implant.is-clan",
    "name": "Explosive Suicide Implant",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 250,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/B-B-B",
      "rawMass": "*",
      "rawCost": "250",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "tm.ext-stores-hardpoint.is-clan",
    "name": "Ext. Stores Hardpoint",
    "categories": [
      "weapon"
    ],
    "mass": 0.2,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "0.2",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "216",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    }
  },
  {
    "id": "tm.extended-fuel-tanks.is-clan",
    "name": "Extended Fuel Tanks",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 500,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "Var*",
      "rawCost": "500",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "244",
      "slotsBattleMech": "Var*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "manualMassFormula": "Var*"
    }
  },
  {
    "id": "io.extended-jump-jet-system.clan",
    "name": "Extended Jump Jet System [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3075
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "*",
      "rawCost": "TTx500x(Jump)^2",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "0",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "TTx500x(Jump)^2"
    }
  },
  {
    "id": "toaue.extended-lrm-10-elrm-10.is",
    "name": "Extended LRM-10 (ELRM 10) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 8,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3054
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "8",
      "rawCost": "200,000 / 35,000",
      "slotsBattleMech": "4",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "4",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "manualCostFormula": "200,000 / 35,000"
    },
    "slots": 4
  },
  {
    "id": "toaue.extended-lrm-15-elrm-15.is",
    "name": "Extended LRM-15 (ELRM 15) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 12,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3054
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "12",
      "rawCost": "350,000 / 35,000",
      "slotsBattleMech": "6",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "6",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "350,000 / 35,000"
    },
    "slots": 6
  },
  {
    "id": "toaue.extended-lrm-20-elrm-20.is",
    "name": "Extended LRM-20 (ELRM 20) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 18,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3054
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "18",
      "rawCost": "500,000 / 35,000",
      "slotsBattleMech": "8",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "8",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "manualCostFormula": "500,000 / 35,000"
    },
    "slots": 8
  },
  {
    "id": "toaue.extended-lrm-5-elrm-5.is",
    "name": "Extended LRM-5 (ELRM 5) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 6,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3054
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "6",
      "rawCost": "60,000 / 35,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "60,000 / 35,000"
    },
    "slots": 1
  },
  {
    "id": "toaue.ferro-lamellor.clan",
    "name": "Ferro-Lamellor [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3070
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "*",
      "rawCost": "35,000xAT",
      "slotsBattleMech": "12",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "2*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "35,000xAT"
    },
    "slots": 12
  },
  {
    "id": "tm.field-kitchen.is-clan",
    "name": "Field Kitchen",
    "categories": [
      "weapon"
    ],
    "mass": 3,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "3",
      "rawCost": "25,000",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "217",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    }
  },
  {
    "id": "tm.fighter-cubicle.is-clan",
    "name": "Fighter (Cubicle)",
    "categories": [
      "weapon"
    ],
    "mass": 150,
    "cost": 20000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2050
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "150",
      "rawCost": "20,000",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "239",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1**",
      "slotsSupportVehicle": "1**",
      "slotsFighter": "NA",
      "slotsSmallCraft": "0",
      "slotsDropShip": "0"
    }
  },
  {
    "id": "io.filtration-implants.is-clan",
    "name": "Filtration Implants",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 60000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2580
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/A-A-A",
      "rawMass": "*",
      "rawCost": "60,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "toaue.flail.is",
    "name": "Flail [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 5,
    "cost": 110000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3057
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/X-X-E",
      "rawMass": "5",
      "rawCost": "110,000",
      "slotsBattleMech": "4*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    },
    "slots": 4
  },
  {
    "id": "tm.flamer-vehicle.clan",
    "name": "Flamer (Vehicle) [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 7500,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "0.5",
      "rawCost": "7,500",
      "heat": "3 (3)",
      "damage": "2 (2)",
      "range": "0/1/2/3 (Short)",
      "ammoPerTon": "20",
      "ref": "218",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.flamer-vehicle.is",
    "name": "Flamer (Vehicle) [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 7500,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2025
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "0.5",
      "rawCost": "7,500",
      "heat": "3 (3)",
      "damage": "2 (2)",
      "range": "0/1/2/3 (Short)",
      "ammoPerTon": "20",
      "ref": "218",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.flamer.clan",
    "name": "Flamer [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 7500,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "0.5",
      "rawCost": "7,500",
      "heat": "3 (3)",
      "damage": "2 (2)",
      "range": "0/1/2/3 (Short)",
      "ammoPerTon": "NA",
      "ref": "218",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.flamer.is",
    "name": "Flamer [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 7500,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2025
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "1",
      "rawCost": "7,500",
      "heat": "3 (3)",
      "damage": "2 (2)",
      "range": "0/1/2/3 (Short)",
      "ammoPerTon": "NA",
      "ref": "218",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "toaue.flight-deck.is-clan",
    "name": "Flight Deck",
    "categories": [
      "equipment"
    ],
    "mass": 1500,
    "cost": 1000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/A-A-A",
      "rawMass": "1,500",
      "rawCost": "1,000,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "10",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1"
    }
  },
  {
    "id": "toaue.flotation-hull.is-clan",
    "name": "Flotation Hull",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2470
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/B-B-B",
      "rawMass": "0*",
      "rawCost": "1.25xTC",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "0*",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "0*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualCostFormula": "1.25xTC"
    }
  },
  {
    "id": "toaue.fluid-gun.is-clan",
    "name": "Fluid Gun",
    "categories": [
      "equipment"
    ],
    "mass": 2,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/B-B-B",
      "rawMass": "2",
      "rawCost": "35,000 / 500",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1",
      "manualCostFormula": "35,000 / 500"
    },
    "slots": 2
  },
  {
    "id": "io.fuel-air-bomb-large.is-clan",
    "name": "Fuel-Air Bomb (Large)",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 35000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/E-F-E-E",
      "rawMass": "1",
      "rawCost": "35,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    }
  },
  {
    "id": "io.fuel-air-bomb-small.is-clan",
    "name": "Fuel-Air Bomb (Small)",
    "categories": [
      "equipment"
    ],
    "mass": 0.5,
    "cost": 18000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/E-F-E-E",
      "rawMass": "0.5",
      "rawCost": "18,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    }
  },
  {
    "id": "io.fuel-air-missile-arrow-iv-clan.clan",
    "name": "Fuel-Air Missile (Arrow IV, Clan) [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/X-E-E-E",
      "rawMass": "x1",
      "rawCost": "x3",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "x1",
      "manualCostFormula": "x3"
    }
  },
  {
    "id": "io.fuel-air-missile-arrow-iv-is.is",
    "name": "Fuel-Air Missile (Arrow IV, IS) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/E-F-E-E",
      "rawMass": "x1",
      "rawCost": "x3",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "x1",
      "manualCostFormula": "x3"
    }
  },
  {
    "id": "io.fuel-air-shell-long-tom-cannon.is-clan",
    "name": "Fuel-Air Shell (Long Tom Cannon)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/E-F-E-E",
      "rawMass": "x1",
      "rawCost": "x3",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "x1",
      "manualCostFormula": "x3"
    }
  },
  {
    "id": "io.fuel-air-shell-long-tom.is-clan",
    "name": "Fuel-Air Shell (Long Tom)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/E-F-E-E",
      "rawMass": "x1",
      "rawCost": "x3",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "x1",
      "manualCostFormula": "x3"
    }
  },
  {
    "id": "io.fuel-air-shell-sniper-cannon.is-clan",
    "name": "Fuel-Air Shell (Sniper Cannon)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/E-F-E-E",
      "rawMass": "x1",
      "rawCost": "x3",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "x1",
      "manualCostFormula": "x3"
    }
  },
  {
    "id": "io.fuel-air-shell-sniper.is-clan",
    "name": "Fuel-Air Shell (Sniper)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/E-F-E-E",
      "rawMass": "x1",
      "rawCost": "x3",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "x1",
      "manualCostFormula": "x3"
    }
  },
  {
    "id": "io.fuel-air-shell-thumper-cannon.is-clan",
    "name": "Fuel-Air Shell (Thumper Cannon)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/E-F-E-E",
      "rawMass": "x1",
      "rawCost": "x3",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "x1",
      "manualCostFormula": "x3"
    }
  },
  {
    "id": "io.fuel-air-shell-thumper.is-clan",
    "name": "Fuel-Air Shell (Thumper)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/E-F-E-E",
      "rawMass": "x1",
      "rawCost": "x3",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "x1",
      "manualCostFormula": "x3"
    }
  },
  {
    "id": "toaue.full-head-ejection-system.is-clan",
    "name": "Full-Head Ejection System",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 1725000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3023
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-X-E",
      "rawMass": "0",
      "rawCost": "1,725,000",
      "slotsBattleMech": "0*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 0
  },
  {
    "id": "toaue.fully-amphibious.is-clan",
    "name": "Fully Amphibious",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2470
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/B-B-B",
      "rawMass": "TT÷10*",
      "rawCost": "10,000xIT",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "0*",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "TT÷10*",
      "manualCostFormula": "10,000xIT"
    }
  },
  {
    "id": "io.fusillade-launcher.clan",
    "name": "Fusillade Launcher [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 1.5,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3072
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "1.5",
      "rawCost": "100,000 / 400",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualCostFormula": "100,000 / 400"
    }
  },
  {
    "id": "io.gas-effuser-implant-pheromone.is",
    "name": "Gas Effuser Implant, Pheromone [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 40000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3060
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-F",
      "rawMass": "*",
      "rawCost": "40,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "io.gas-effuser-implant-toxin.is",
    "name": "Gas Effuser Implant, Toxin [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 10000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3060
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "*",
      "rawCost": "10,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "tm.gauss-rifl-e.is",
    "name": "Gauss Rifl e [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 15,
    "cost": 300000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2590
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "15",
      "rawCost": "300,000",
      "heat": "1 (1)",
      "damage": "15 (15)",
      "range": "2/7/15/22 (Long)",
      "ammoPerTon": "8",
      "ref": "219",
      "slotsBattleMech": "7",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "7",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 7
  },
  {
    "id": "tm.gauss-rifle.clan",
    "name": "Gauss Rifle [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 12,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "12",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "1 (1)",
      "damage": "15 (15)",
      "range": "2/7/15/22 (Long)",
      "ammoPerTon": "8",
      "ref": "219",
      "slotsBattleMech": "6",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "6",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    },
    "slots": 6
  },
  {
    "id": "io.glider-protomech-structure.clan",
    "name": "Glider ProtoMech Structure [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": {
      "op": "multiply",
      "args": [
        {
          "var": "unit.mass"
        },
        0.1
      ]
    },
    "cost": {
      "op": "multiply",
      "args": [
        600.0,
        {
          "var": "unit.mass"
        }
      ]
    },
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3084
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-E",
      "rawMass": "TTx0.1",
      "rawCost": "600xTT",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "0",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    }
  },
  {
    "id": "toaue.grenade-launcher-vehicular.is-clan",
    "name": "Grenade Launcher, Vehicular",
    "categories": [
      "equipment"
    ],
    "mass": 0.5,
    "cost": 10000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/D-E-F",
      "rawMass": "0.5",
      "rawCost": "10,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    },
    "slots": 1
  },
  {
    "id": "toaue.ground-mobile-hpg.is-clan",
    "name": "Ground-Mobile HPG",
    "categories": [
      "equipment"
    ],
    "mass": 12,
    "cost": 4000000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2751
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/F-X-F",
      "rawMass": "12",
      "rawCost": "4,000,000,000",
      "slotsBattleMech": "12",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "12",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1"
    },
    "slots": 12
  },
  {
    "id": "tm.guardian-ecm-suite.is",
    "name": "Guardian ECM Suite [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 1.5,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "1.5",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "0 (0)",
      "damage": "NA",
      "range": "0/0/0/6 (**)",
      "ammoPerTon": "NA",
      "ref": "213",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    },
    "slots": 2
  },
  {
    "id": "tm.handheld.is-clan",
    "name": "Handheld",
    "categories": [
      "weapon"
    ],
    "mass": 0.005,
    "cost": 500,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "0.005*",
      "rawCost": "500",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "0/0/0/9 (Short)",
      "ammoPerTon": "NA",
      "ref": "237",
      "slotsBattleMech": "0",
      "slotsProtoMech": "0",
      "slotsCombatVehicle": "0*",
      "slotsSupportVehicle": "0*",
      "slotsFighter": "0",
      "slotsSmallCraft": "0",
      "slotsDropShip": "0"
    },
    "slots": 0
  },
  {
    "id": "toaue.handheld-weapon.is-clan",
    "name": "Handheld Weapon",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2490
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/E-E-F",
      "rawMass": "*",
      "rawCost": "2xIC††",
      "slotsBattleMech": "*",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "2xIC††"
    }
  },
  {
    "id": "toaue.hardened.is-clan",
    "name": "Hardened",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3047
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-X-F",
      "rawMass": "*",
      "rawCost": "15,000xAT",
      "slotsBattleMech": "0",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "15,000xAT"
    },
    "slots": 0
  },
  {
    "id": "io.harjel-ii-self-repair-system.clan",
    "name": "HarJel II Self-Repair System [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 2,
    "cost": 240000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3136
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-X-F",
      "rawMass": "2*",
      "rawCost": "240,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 1
  },
  {
    "id": "io.harjel-iii-self-repair-system.clan",
    "name": "HarJel III Self-Repair System [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 3,
    "cost": 360000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3139
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-X-F",
      "rawMass": "3*",
      "rawCost": "360,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 2
  },
  {
    "id": "tm.hatchet.is",
    "name": "Hatchet [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 5000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3022
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "Var*",
      "rawCost": "5,000",
      "heat": "0 (NA)",
      "damage": "** (NA)",
      "range": "PHYS (NA)",
      "ammoPerTon": "NA",
      "ref": "220",
      "slotsBattleMech": "Var*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "manualMassFormula": "Var*"
    }
  },
  {
    "id": "io.heat-dissipating-armor.is-clan",
    "name": "Heat-Dissipating Armor",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3123
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-X-E",
      "rawMass": "*",
      "rawCost": "25,000xAT",
      "slotsBattleMech": "6",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "25,000xAT"
    },
    "slots": 6
  },
  {
    "id": "tm.heavy.is-clan",
    "name": "Heavy",
    "categories": [
      "weapon"
    ],
    "mass": 6,
    "cost": 100000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "D",
      "rawMass": "6",
      "rawCost": "100,000",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "242",
      "slotsBattleMech": "12*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 12
  },
  {
    "id": "tm.heavy-duty-pile-driver.is-clan",
    "name": "Heavy Duty Pile-Driver",
    "categories": [
      "weapon"
    ],
    "mass": 10,
    "cost": 100000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "10",
      "rawCost": "100,000",
      "heat": "0 (NA)",
      "damage": "9 (NA)",
      "range": "PHYS (NA)",
      "ammoPerTon": "NA",
      "ref": "244",
      "slotsBattleMech": "8",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 8
  },
  {
    "id": "toaue.heavy-flamer.is-clan",
    "name": "Heavy Flamer",
    "categories": [
      "equipment"
    ],
    "mass": 1.5,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3067
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/X-X-E",
      "rawMass": "1.5",
      "rawCost": "11,250 / 2,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1",
      "manualCostFormula": "11,250 / 2,000"
    },
    "slots": 1
  },
  {
    "id": "tm.heavy-gauss-rifl-e.is",
    "name": "Heavy Gauss Rifl e [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 18,
    "cost": 500000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3061
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "18",
      "rawCost": "500,000",
      "heat": "2 (2)",
      "damage": "25/20/10 (25/20/10)",
      "range": "4/6/13/20 (Long)",
      "ammoPerTon": "4",
      "ref": "218",
      "slotsBattleMech": "11",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "11",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 11
  },
  {
    "id": "tm.heavy-large-laser.clan",
    "name": "Heavy Large Laser [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 4,
    "cost": 250000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3059
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "4",
      "rawCost": "250,000",
      "heat": "18 (18)",
      "damage": "16 (16)",
      "range": "0/5/10/15 (Medium)",
      "ammoPerTon": "NA",
      "ref": "226",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 3
  },
  {
    "id": "tm.heavy-machine-gun.clan",
    "name": "Heavy Machine Gun [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 7500,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3059
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "0.5",
      "rawCost": "7,500",
      "heat": "0 (0)",
      "damage": "3 (3)",
      "range": "0/1/2/— (Short)",
      "ammoPerTon": "100",
      "ref": "228",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.heavy-machine-gun.is",
    "name": "Heavy Machine Gun [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 1.0,
    "cost": 7500,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3068
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "1.0",
      "rawCost": "7,500",
      "heat": "0 (0)",
      "damage": "3 (3)",
      "range": "0/1/2/— (Short)",
      "ammoPerTon": "100",
      "ref": "228",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "toaue.heavy-mass-driver.is",
    "name": "Heavy Mass Driver [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 100000,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2715
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-X-F",
      "rawMass": "100,000",
      "rawCost": "500M / 600,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "1*",
      "slotsSpaceStation": "1*",
      "manualCostFormula": "500M / 600,000"
    }
  },
  {
    "id": "tm.heavy-medium-laser.clan",
    "name": "Heavy Medium Laser [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 100000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3059
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "1",
      "rawCost": "100,000",
      "heat": "7 (7)",
      "damage": "10 (10)",
      "range": "0/3/6/9 (Short)",
      "ammoPerTon": "NA",
      "ref": "226",
      "slotsBattleMech": "2",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 2
  },
  {
    "id": "toaue.heavy-n-gauss.is-clan",
    "name": "Heavy N-Gauss",
    "categories": [
      "equipment"
    ],
    "mass": 7000,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2449
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "*",
      "rawMass": "7,000",
      "rawCost": "50.05M / 90,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*",
      "slotsMobileStructure": "1*",
      "manualCostFormula": "50.05M / 90,000"
    }
  },
  {
    "id": "toaue.heavy-n-ppc.is-clan",
    "name": "Heavy N-PPC",
    "categories": [
      "equipment"
    ],
    "mass": 3000,
    "cost": 9050000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2356
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "*",
      "rawMass": "3,000",
      "rawCost": "9,050,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*",
      "slotsMobileStructure": "1*"
    }
  },
  {
    "id": "tm.heavy-ppc.is",
    "name": "Heavy PPC [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 10,
    "cost": 250000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3067
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "10",
      "rawCost": "250,000",
      "heat": "15 (15)",
      "damage": "15 (15)",
      "range": "3/6/12/18 (Medium)",
      "ammoPerTon": "NA",
      "ref": "234",
      "slotsBattleMech": "4",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "4",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 4
  },
  {
    "id": "toaue.heavy-rifle.is",
    "name": "Heavy Rifle [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 8,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/C-F-X",
      "rawMass": "8",
      "rawCost": "90,000 / 3,000",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1",
      "manualCostFormula": "90,000 / 3,000"
    },
    "slots": 3
  },
  {
    "id": "toaue.heavy-scc.is",
    "name": "Heavy SCC [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 700,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3073
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "700",
      "rawCost": "1,300,000 / 25,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "60",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1-C*",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*",
      "slotsMobileStructure": "1",
      "manualCostFormula": "1,300,000 / 25,000"
    }
  },
  {
    "id": "tm.heavy-small-laser.clan",
    "name": "Heavy Small Laser [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 20000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3059
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "0.5",
      "rawCost": "20,000",
      "heat": "3 (3)",
      "damage": "6 (6)",
      "range": "0/1/2/3 (Short)",
      "ammoPerTon": "NA",
      "ref": "226",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "toaue.helipad.is-clan",
    "name": "Helipad",
    "categories": [
      "equipment"
    ],
    "mass": 500,
    "cost": 200000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/A-A-A",
      "rawMass": "500",
      "rawCost": "200,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "5",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    }
  },
  {
    "id": "toaue.hi-res-imager.is-clan",
    "name": "Hi-Res Imager",
    "categories": [
      "equipment"
    ],
    "mass": 2.5,
    "cost": 150000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/D-E-D",
      "rawMass": "2.5",
      "rawCost": "150,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1*"
    }
  },
  {
    "id": "tm.hvy-vehicle-cub.is-clan",
    "name": "Hvy. Vehicle (Cub.)",
    "categories": [
      "weapon"
    ],
    "mass": 100,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "100",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "239",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1**",
      "slotsSupportVehicle": "1**",
      "slotsFighter": "NA",
      "slotsSmallCraft": "0",
      "slotsDropShip": "0",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    }
  },
  {
    "id": "tm.hyper-assault-gauss-20.clan",
    "name": "Hyper-Assault Gauss 20 [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 10,
    "cost": 400000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3068
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "10",
      "rawCost": "400,000",
      "heat": "4 (4)",
      "damage": "20** (16/12/12)",
      "range": "2/8/16/24 (Long)",
      "ammoPerTon": "6",
      "ref": "219",
      "slotsBattleMech": "6",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "6",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 6
  },
  {
    "id": "tm.hyper-assault-gauss-30.clan",
    "name": "Hyper-Assault Gauss 30 [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 13,
    "cost": 500000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3068
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "13",
      "rawCost": "500,000",
      "heat": "6 (6)",
      "damage": "30** (24/18/18)",
      "range": "2/8/16/24 (Long)",
      "ammoPerTon": "4",
      "ref": "219",
      "slotsBattleMech": "8",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "8",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 8
  },
  {
    "id": "tm.hyper-assault-gauss-40.clan",
    "name": "Hyper-Assault Gauss 40 [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 16,
    "cost": 600000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3069
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "16",
      "rawCost": "600,000",
      "heat": "8 (8)",
      "damage": "40** (32/24/24)",
      "range": "2/8/16/24 (Long)",
      "ammoPerTon": "3",
      "ref": "219",
      "slotsBattleMech": "10",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "10",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 10
  },
  {
    "id": "toaue.hyper-velocity-ac-10.is",
    "name": "Hyper-Velocity AC/10 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 14,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3060
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-X-F",
      "rawMass": "14",
      "rawCost": "230,000 / 20,000",
      "slotsBattleMech": "6",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "6",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "manualCostFormula": "230,000 / 20,000"
    },
    "slots": 6
  },
  {
    "id": "toaue.hyper-velocity-ac-2.is",
    "name": "Hyper-Velocity AC/2 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 8,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3059
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-X-F",
      "rawMass": "8",
      "rawCost": "100,000 / 3,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "manualCostFormula": "100,000 / 3,000"
    },
    "slots": 2
  },
  {
    "id": "toaue.hyper-velocity-ac-5.is",
    "name": "Hyper-Velocity AC/5 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 12,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3059
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-X-F",
      "rawMass": "12",
      "rawCost": "160,000 / 10,000",
      "slotsBattleMech": "4",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "4",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "160,000 / 10,000"
    },
    "slots": 4
  },
  {
    "id": "toaue.hyperspectral-imager.is",
    "name": "Hyperspectral Imager [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 7.5,
    "cost": 550000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3055
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-X-F",
      "rawMass": "7.5",
      "rawCost": "550,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "2*",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1"
    }
  },
  {
    "id": "tm.imp-narc-launcher.is",
    "name": "Imp. Narc Launcher [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 5,
    "cost": 250000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3062
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "5",
      "rawCost": "250,000",
      "heat": "0 (**)",
      "damage": "**",
      "range": "0/4/9/15 (**)",
      "ammoPerTon": "4",
      "ref": "232",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 3
  },
  {
    "id": "io.impact-resistant-armor.is",
    "name": "Impact-Resistant Armor [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3103
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-X-E",
      "rawMass": "*",
      "rawCost": "20,000xAT",
      "slotsBattleMech": "10",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "20,000xAT"
    },
    "slots": 10
  },
  {
    "id": "io.improved-atm-12.clan",
    "name": "Improved ATM 12 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 7,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3070
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "7",
      "rawCost": "700,000 / 15,000",
      "slotsBattleMech": "5",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "5",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "700,000 / 15,000"
    },
    "slots": 5
  },
  {
    "id": "io.improved-atm-3.clan",
    "name": "Improved ATM 3 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 1.5,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3070
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "1.5",
      "rawCost": "100,000 / 3,750",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "100,000 / 3,750"
    },
    "slots": 2
  },
  {
    "id": "io.improved-atm-6.clan",
    "name": "Improved ATM 6 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 3.5,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3070
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "3.5",
      "rawCost": "250,000 / 7,500",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "250,000 / 7,500"
    },
    "slots": 3
  },
  {
    "id": "io.improved-atm-9.clan",
    "name": "Improved ATM 9 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 5,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3070
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "5",
      "rawCost": "450,000 / 10,715",
      "slotsBattleMech": "4",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "4",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "450,000 / 10,715"
    },
    "slots": 4
  },
  {
    "id": "io.improved-autocannon-10.clan",
    "name": "Improved Autocannon/10 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 11,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2818
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-C-X",
      "rawMass": "11",
      "rawCost": "200,000 / 6,000",
      "slotsBattleMech": "6",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "6",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "200,000 / 6,000"
    },
    "slots": 6
  },
  {
    "id": "io.improved-autocannon-2.clan",
    "name": "Improved Autocannon/2 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 5,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2818
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-C-X",
      "rawMass": "5",
      "rawCost": "75,000 / 1,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "75,000 / 1,000"
    },
    "slots": 1
  },
  {
    "id": "io.improved-autocannon-20.clan",
    "name": "Improved Autocannon/20 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 13,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2818
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-D-X",
      "rawMass": "13",
      "rawCost": "300,000 / 10,000",
      "slotsBattleMech": "9",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "9",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "300,000 / 10,000"
    },
    "slots": 9
  },
  {
    "id": "io.improved-autocannon-5.clan",
    "name": "Improved Autocannon/5 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 7,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2818
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-C-X",
      "rawMass": "7",
      "rawCost": "125,000 / 4,500",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "125,000 / 4,500"
    },
    "slots": 2
  },
  {
    "id": "tm.improved-c3-computer.is",
    "name": "Improved C3 Computer [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 2.5,
    "cost": 750000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3062
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "2.5",
      "rawCost": "750,000",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "209",
      "slotsBattleMech": "2*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 2
  },
  {
    "id": "io.improved-gauss-rifle.clan",
    "name": "Improved Gauss Rifle [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 13,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2822
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-E-X",
      "rawMass": "13",
      "rawCost": "300,000 / 20,000",
      "slotsBattleMech": "6",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "6",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "300,000 / 20,000"
    },
    "slots": 6
  },
  {
    "id": "toaue.improved-heavy-gauss.is",
    "name": "Improved Heavy Gauss [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 20,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3065
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "20",
      "rawCost": "700,000 / 20,000",
      "slotsBattleMech": "11",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "11",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "700,000 / 20,000"
    },
    "slots": 11
  },
  {
    "id": "toaue.improved-heavy-laser-large.clan",
    "name": "Improved Heavy Laser, Large [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 4,
    "cost": 350000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3069
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "4",
      "rawCost": "350,000",
      "slotsBattleMech": "3",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 3
  },
  {
    "id": "toaue.improved-heavy-laser-medium.clan",
    "name": "Improved Heavy Laser, Medium [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 150000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3069
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "1",
      "rawCost": "150,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1"
    },
    "slots": 2
  },
  {
    "id": "toaue.improved-heavy-laser-small.clan",
    "name": "Improved Heavy Laser, Small [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0.5,
    "cost": 30000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3069
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "0.5",
      "rawCost": "30,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 1
  },
  {
    "id": "io.improved-large-laser.clan",
    "name": "Improved Large Laser [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 4,
    "cost": 100000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2818
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-D-X",
      "rawMass": "4",
      "rawCost": "100,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 1
  },
  {
    "id": "io.improved-large-pulse-laser.clan",
    "name": "Improved Large Pulse Laser [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 6,
    "cost": 175000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2820
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-E-X",
      "rawMass": "6",
      "rawCost": "175,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 2
  },
  {
    "id": "io.improved-lrm-10.clan",
    "name": "Improved LRM 10 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 2.5,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2818
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-D-X",
      "rawMass": "2.5",
      "rawCost": "100,000 / 30,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "100,000 / 30,000"
    },
    "slots": 1
  },
  {
    "id": "io.improved-lrm-15.clan",
    "name": "Improved LRM 15 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 3.5,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2818
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-D-X",
      "rawMass": "3.5",
      "rawCost": "175,000 / 30,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "175,000 / 30,000"
    },
    "slots": 2
  },
  {
    "id": "io.improved-lrm-20.clan",
    "name": "Improved LRM 20 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 5,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2818
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-D-X",
      "rawMass": "5",
      "rawCost": "250,000 / 30,000",
      "slotsBattleMech": "4",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "4",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "250,000 / 30,000"
    },
    "slots": 4
  },
  {
    "id": "io.improved-lrm-5.clan",
    "name": "Improved LRM 5 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2818
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-D-X",
      "rawMass": "1",
      "rawCost": "30,000 / 30,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "30,000 / 30,000"
    },
    "slots": 1
  },
  {
    "id": "toaue.improved-one-shot-launcher.is-clan",
    "name": "Improved One-Shot Launcher",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3056
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/X-X-F",
      "rawMass": "–0.5**",
      "rawCost": "0.8xIC",
      "slotsBattleMech": "+0",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "+0",
      "slotsSupportVehicle": "+0",
      "slotsFighter": "+0",
      "slotsSmallCraft": "+0",
      "slotsDropShip": "+0",
      "slotsJumpShip": "+0",
      "slotsWarShip": "+0",
      "slotsSpaceStation": "+0",
      "slotsMobileStructure": "+0",
      "manualMassFormula": "–0.5**",
      "manualCostFormula": "0.8xIC"
    },
    "slots": 0
  },
  {
    "id": "io.improved-ppc.clan",
    "name": "Improved PPC [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 6,
    "cost": 200000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2820
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-D-X",
      "rawMass": "6",
      "rawCost": "200,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 2
  },
  {
    "id": "io.improved-srm-2.clan",
    "name": "Improved SRM 2 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2817
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-D-X",
      "rawMass": "1",
      "rawCost": "15,000 / 27,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "15,000 / 27,000"
    },
    "slots": 1
  },
  {
    "id": "io.improved-srm-4.clan",
    "name": "Improved SRM 4 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 2,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2817
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-D-X",
      "rawMass": "2",
      "rawCost": "90,000 / 27,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "90,000 / 27,000"
    },
    "slots": 1
  },
  {
    "id": "io.improved-srm-6.clan",
    "name": "Improved SRM 6 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 3,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2817
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-D-X",
      "rawMass": "3",
      "rawCost": "120,000 / 27,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "120,000 / 27,000"
    },
    "slots": 2
  },
  {
    "id": "tm.infantry-bay.is-clan",
    "name": "Infantry, Bay",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 15000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "Var*",
      "rawCost": "15,000",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "239",
      "slotsBattleMech": "Var*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "0",
      "slotsSmallCraft": "0",
      "slotsDropShip": "0",
      "manualMassFormula": "Var*"
    }
  },
  {
    "id": "tm.infantry-compart.is-clan",
    "name": "Infantry, Compart.",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "Var*",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "239",
      "slotsBattleMech": "Var*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "0",
      "slotsSmallCraft": "0",
      "slotsDropShip": "0",
      "manualMassFormula": "Var*",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    }
  },
  {
    "id": "toaue.infrared-imager.is-clan",
    "name": "Infrared Imager",
    "categories": [
      "equipment"
    ],
    "mass": 5,
    "cost": 250000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/D-E-D",
      "rawMass": "5",
      "rawCost": "250,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1*"
    }
  },
  {
    "id": "toaue.jump-pack-drop-pack.is-clan",
    "name": "Jump Pack / Drop Pack",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2457
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/C-D-C",
      "rawMass": "Var*",
      "rawCost": "20,000xIT",
      "slotsBattleMech": "0",
      "slotsProtoMech": "0",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualMassFormula": "Var*",
      "manualCostFormula": "20,000xIT"
    },
    "slots": 0
  },
  {
    "id": "tm.killer-whale.clan",
    "name": "Killer Whale [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 150,
    "cost": 150000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "150",
      "rawCost": "150,000",
      "heat": "NA (20)",
      "damage": "NA (40)",
      "range": "NA (Extreme)",
      "ammoPerTon": "50 t/Msl",
      "ref": "210",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1"
    }
  },
  {
    "id": "tm.killer-whale.is",
    "name": "Killer Whale [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 150,
    "cost": 150000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "150",
      "rawCost": "150,000",
      "heat": "NA (20)",
      "damage": "NA (40)",
      "range": "NA (Extreme)",
      "ammoPerTon": "50 t/Msl",
      "ref": "210",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1"
    }
  },
  {
    "id": "tm.killer-whale-t.is",
    "name": "Killer Whale-T [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 160,
    "cost": 165000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3056
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "160",
      "rawCost": "165,000",
      "heat": "NA (20)",
      "damage": "NA (40)",
      "range": "NA (Extreme)",
      "ammoPerTon": "50 t/Msl",
      "ref": "210",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1"
    }
  },
  {
    "id": "tm.kraken-t.is",
    "name": "Kraken-T [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 220,
    "cost": 500000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3057
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "220",
      "rawCost": "500,000",
      "heat": "NA (50)",
      "damage": "NA (100)",
      "range": "NA (Extreme)",
      "ammoPerTon": "100 t/Msl",
      "ref": "210",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1"
    }
  },
  {
    "id": "tm.ladder.is-clan",
    "name": "Ladder",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 5,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "Var*",
      "rawCost": "5",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "245",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "manualMassFormula": "Var*"
    },
    "slots": 1
  },
  {
    "id": "io.lam-bomb-bay.is-clan",
    "name": "LAM Bomb Bay",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 5000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2680
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "B/E-E-E",
      "rawMass": "1",
      "rawCost": "5,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 1
  },
  {
    "id": "io.lam-conversion-bimodal.is",
    "name": "LAM Conversion (Bimodal) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": {
      "op": "multiply",
      "args": [
        {
          "var": "unit.mass"
        },
        0.15
      ]
    },
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2680
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/E-F-X",
      "rawMass": "TTx0.15",
      "rawCost": "WSCx0.65",
      "slotsBattleMech": "6*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualCostFormula": "WSCx0.65"
    },
    "slots": 6
  },
  {
    "id": "io.lam-conversion-standard.is",
    "name": "LAM Conversion (Standard) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": {
      "op": "multiply",
      "args": [
        {
          "var": "unit.mass"
        },
        0.1
      ]
    },
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2688
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/D-E-F",
      "rawMass": "TTx0.1",
      "rawCost": "WSCx0.75",
      "slotsBattleMech": "6*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualCostFormula": "WSCx0.75"
    },
    "slots": 6
  },
  {
    "id": "io.lam-fuel-tanks.is-clan",
    "name": "LAM Fuel Tanks",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 200,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "B/A-A-A",
      "rawMass": "1",
      "rawCost": "200",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 1
  },
  {
    "id": "toaue.lance.is",
    "name": "Lance [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": {
      "op": "multiply",
      "args": [
        150.0,
        {
          "var": "unit.mass"
        }
      ]
    },
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3064
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/X-X-F",
      "rawMass": "TT÷20*",
      "rawCost": "150xTT",
      "slotsBattleMech": "TT÷20*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "TT÷20*"
    }
  },
  {
    "id": "toaue.landing-deck.is-clan",
    "name": "Landing Deck",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/C-C-C",
      "rawMass": "500xHX*",
      "rawCost": "500,000xHX",
      "slotsBattleMech": "1xHX*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1*",
      "manualMassFormula": "500xHX*",
      "manualCostFormula": "500,000xHX"
    }
  },
  {
    "id": "toaue.large-fusion.is-clan",
    "name": "Large (Fusion)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2630
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/C-E-D",
      "rawMass": "*",
      "rawCost": "(10,000xERxTT)÷75",
      "slotsBattleMech": "+2*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "+1*",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "+1*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "(10,000xERxTT)÷75"
    },
    "slots": 2
  },
  {
    "id": "toaue.large-ice.is-clan",
    "name": "Large (ICE)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2630
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/A-A-A",
      "rawMass": "*",
      "rawCost": "(2,500xERxTT)÷75",
      "slotsBattleMech": "+2*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "+1*",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "+1*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "(2,500xERxTT)÷75"
    },
    "slots": 2
  },
  {
    "id": "toaue.large-light-fusion.is",
    "name": "Large (Light Fusion) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3065
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-E",
      "rawMass": "*",
      "rawCost": "(30,000xERxTT)÷75",
      "slotsBattleMech": "+6*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "+2*",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "+2*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "(30,000xERxTT)÷75"
    },
    "slots": 6
  },
  {
    "id": "toaue.large-xl-clan.clan",
    "name": "Large (XL – Clan) [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2840
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/D-F-E",
      "rawMass": "*",
      "rawCost": "(40,000xERxTT)÷75",
      "slotsBattleMech": "+6*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "+2*",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "+2*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "(40,000xERxTT)÷75"
    },
    "slots": 6
  },
  {
    "id": "toaue.large-xl-inner-sphere.is",
    "name": "Large (XL – Inner Sphere) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 3045
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/D-F-E",
      "rawMass": "*",
      "rawCost": "(40,000xERxTT)÷75",
      "slotsBattleMech": "+8*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "+3*",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "+3*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "(40,000xERxTT)÷75"
    },
    "slots": 8
  },
  {
    "id": "toaue.large-xxl-clan.clan",
    "name": "Large (XXL – Clan) [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2970
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "*",
      "rawCost": "(200,000xERxTT)÷75",
      "slotsBattleMech": "+10*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "+3*",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "+3*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "(200,000xERxTT)÷75"
    },
    "slots": 10
  },
  {
    "id": "toaue.large-xxl-inner-sphere.is",
    "name": "Large (XXL – Inner Sphere) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3057
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "*",
      "rawCost": "(200,000xERxTT)÷75",
      "slotsBattleMech": "+14*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "+5*",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "+5*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "(200,000xERxTT)÷75"
    },
    "slots": 14
  },
  {
    "id": "tm.large-laser.is",
    "name": "Large Laser [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 5,
    "cost": 100000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2430
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "5",
      "rawCost": "100,000",
      "heat": "8 (8)",
      "damage": "8 (8)",
      "range": "0/5/10/15 (Medium)",
      "ammoPerTon": "NA",
      "ref": "227",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "5",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 2
  },
  {
    "id": "toaue.large-ncss.is-clan",
    "name": "Large NCSS",
    "categories": [
      "equipment"
    ],
    "mass": 500,
    "cost": 250000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2200
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/D-E-E",
      "rawMass": "500",
      "rawCost": "250,000,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "0*",
      "slotsDropShip": "0*",
      "slotsJumpShip": "0*",
      "slotsWarShip": "0*",
      "slotsSpaceStation": "0*",
      "slotsMobileStructure": "NA"
    }
  },
  {
    "id": "tm.large-pulse-laser.clan",
    "name": "Large Pulse Laser [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 6,
    "cost": 175000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "6",
      "rawCost": "175,000",
      "heat": "10 (10)",
      "damage": "10 (10)",
      "range": "0/6/14/20 (Long)",
      "ammoPerTon": "NA",
      "ref": "226",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 2
  },
  {
    "id": "tm.large-pulse-laser.is",
    "name": "Large Pulse Laser [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 7,
    "cost": 175000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2609
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "7",
      "rawCost": "175,000",
      "heat": "10 (10)",
      "damage": "9 (9)",
      "range": "0/3/7/10 (Medium)",
      "ammoPerTon": "NA",
      "ref": "226",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 2
  },
  {
    "id": "io.large-re-engineered-laser.is",
    "name": "Large Re-Engineered Laser [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 8,
    "cost": 250000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3130
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-X-E",
      "rawMass": "8",
      "rawCost": "250,000",
      "slotsBattleMech": "5",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "5",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 5
  },
  {
    "id": "toaue.laser-anti-missile-system-clan.clan",
    "name": "Laser Anti-Missile System (Clan) [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 225000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3048
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-E",
      "rawMass": "1",
      "rawCost": "225,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 1
  },
  {
    "id": "toaue.laser-anti-missile-system-is.is",
    "name": "Laser Anti-Missile System (IS) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 1.5,
    "cost": 225000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3059
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-E",
      "rawMass": "1.5",
      "rawCost": "225,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1"
    },
    "slots": 2
  },
  {
    "id": "toaue.laser-heat-sinks.clan",
    "name": "Laser Heat Sinks [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 6000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3051
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-E",
      "rawMass": "1",
      "rawCost": "6,000",
      "slotsBattleMech": "2*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    },
    "slots": 2
  },
  {
    "id": "toaue.laser-insulator.is-clan",
    "name": "Laser Insulator",
    "categories": [
      "equipment"
    ],
    "mass": 0.5,
    "cost": 3000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2575
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "*",
      "rawMass": "+0.5**",
      "rawCost": "3,000",
      "slotsBattleMech": "+1**",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "0",
      "slotsSupportVehicle": "0",
      "slotsFighter": "0",
      "slotsSmallCraft": "0",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    },
    "slots": 1
  },
  {
    "id": "toaue.laser-reflective-clan.clan",
    "name": "Laser-Reflective (Clan) [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3061
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "*",
      "rawCost": "30,000xAT",
      "slotsBattleMech": "5",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "1*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "30,000xAT"
    },
    "slots": 5
  },
  {
    "id": "toaue.laser-reflective-is.is",
    "name": "Laser-Reflective (IS) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3058
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "*",
      "rawCost": "30,000xAT",
      "slotsBattleMech": "10",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "2*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "30,000xAT"
    },
    "slots": 10
  },
  {
    "id": "tm.lb-10-x-ac.clan",
    "name": "LB 10-X AC [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 10,
    "cost": 400000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "10",
      "rawCost": "400,000",
      "heat": "2 (2)",
      "damage": "10 (6)",
      "range": "0/6/12/18 (Medium)",
      "ammoPerTon": "10",
      "ref": "207",
      "slotsBattleMech": "5",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "5",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 5
  },
  {
    "id": "tm.lb-10-x-ac.is",
    "name": "LB 10-X AC [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 11,
    "cost": 400000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2595
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "11",
      "rawCost": "400,000",
      "heat": "2 (2)",
      "damage": "10 (6)",
      "range": "0/6/12/18 (Medium)",
      "ammoPerTon": "10",
      "ref": "207",
      "slotsBattleMech": "6",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "6",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 6
  },
  {
    "id": "tm.lb-2-x-ac.clan",
    "name": "LB 2-X AC [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 5,
    "cost": 150000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2826
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "5",
      "rawCost": "150,000",
      "heat": "1 (1)",
      "damage": "2 (2)",
      "range": "4/10/20/30 (Extreme)",
      "ammoPerTon": "45",
      "ref": "207",
      "slotsBattleMech": "3",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 3
  },
  {
    "id": "tm.lb-2-x-ac.is",
    "name": "LB 2-X AC [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 6,
    "cost": 150000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3058
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "6",
      "rawCost": "150,000",
      "heat": "1 (1)",
      "damage": "2 (2)",
      "range": "4/9/18/27 (Extreme)",
      "ammoPerTon": "45",
      "ref": "207",
      "slotsBattleMech": "4",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "4",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 4
  },
  {
    "id": "tm.lb-20-x-ac.clan",
    "name": "LB 20-X AC [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 12,
    "cost": 600000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2826
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "12",
      "rawCost": "600,000",
      "heat": "6 (6)",
      "damage": "20 (12)",
      "range": "0/4/8/12 (Medium)",
      "ammoPerTon": "5",
      "ref": "207",
      "slotsBattleMech": "9",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "9",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 9
  },
  {
    "id": "tm.lb-20-x-ac.is",
    "name": "LB 20-X AC [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 14,
    "cost": 600000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3058
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "14",
      "rawCost": "600,000",
      "heat": "6 (6)",
      "damage": "20 (12)",
      "range": "0/4/8/12 (Medium)",
      "ammoPerTon": "5",
      "ref": "207",
      "slotsBattleMech": "11",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "11",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 11
  },
  {
    "id": "tm.lb-5-x-ac.clan",
    "name": "LB 5-X AC [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 7,
    "cost": 250000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2825
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "7",
      "rawCost": "250,000",
      "heat": "1 (1)",
      "damage": "5 (3)",
      "range": "3/8/15/24 (Long)",
      "ammoPerTon": "20",
      "ref": "207",
      "slotsBattleMech": "4",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "4",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 4
  },
  {
    "id": "tm.lb-5-x-ac.is",
    "name": "LB 5-X AC [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 8,
    "cost": 250000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3058
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "8",
      "rawCost": "250,000",
      "heat": "1 (1)",
      "damage": "5 (3)",
      "range": "5/3/7/14/21 (Long)",
      "ammoPerTon": "20",
      "ref": "207",
      "slotsBattleMech": "5",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "5",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 5
  },
  {
    "id": "tm.lift-hoist.is-clan",
    "name": "Lift Hoist",
    "categories": [
      "weapon"
    ],
    "mass": 3,
    "cost": 50000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "3",
      "rawCost": "50,000",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "PHYS (NA)",
      "ammoPerTon": "NA",
      "ref": "245",
      "slotsBattleMech": "3*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 3
  },
  {
    "id": "tm.light.is-clan",
    "name": "Light",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 40000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "1",
      "rawCost": "40,000",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "242",
      "slotsBattleMech": "2*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 2
  },
  {
    "id": "tm.light-vehicular.is-clan",
    "name": "Light (Vehicular)",
    "categories": [
      "weapon"
    ],
    "mass": 0.015,
    "cost": 40000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "0.015",
      "rawCost": "40,000",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "PHYS (NA)",
      "ammoPerTon": "10*",
      "ref": "247",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "1*",
      "slotsSmallCraft": "1*",
      "slotsDropShip": "NA"
    }
  },
  {
    "id": "tm.light-mech.is-clan",
    "name": "Light (’Mech)",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 40000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "0.5",
      "rawCost": "40,000",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "PHYS (NA)",
      "ammoPerTon": "10*",
      "ref": "247",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 1
  },
  {
    "id": "tm.light-ac-2.is",
    "name": "Light AC/2 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 4,
    "cost": 100000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3068
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "D",
      "rawMass": "4",
      "rawCost": "100,000",
      "heat": "1 (1)",
      "damage": "2 (2)",
      "range": "0/6/12/18 (Medium)",
      "ammoPerTon": "45",
      "ref": "207",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.light-ac-5.is",
    "name": "Light AC/5 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 5,
    "cost": 150000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3068
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "D",
      "rawMass": "5",
      "rawCost": "150,000",
      "heat": "1 (1)",
      "damage": "5 (5)",
      "range": "0/5/10/15 (Medium)",
      "ammoPerTon": "20",
      "ref": "207",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 2
  },
  {
    "id": "tm.light-active-probe.clan",
    "name": "Light Active Probe [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "0.5",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "0 (0)",
      "damage": "NA",
      "range": "0/0/0/3 (**)",
      "ammoPerTon": "NA",
      "ref": "204",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    },
    "slots": 1
  },
  {
    "id": "tm.light-gauss-rifl-e.is",
    "name": "Light Gauss Rifl e [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 12,
    "cost": 275000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3056
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "12",
      "rawCost": "275,000",
      "heat": "1 (1)",
      "damage": "8 (8)",
      "range": "3/8/17/25 (Extreme)",
      "ammoPerTon": "16",
      "ref": "219",
      "slotsBattleMech": "5",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "5",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 5
  },
  {
    "id": "tm.light-machine-gun.clan",
    "name": "Light Machine Gun [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 0.25,
    "cost": 5000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3060
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "0.25",
      "rawCost": "5,000",
      "heat": "0 (0)",
      "damage": "1 (1)",
      "range": "0/2/4/6 (Short)",
      "ammoPerTon": "200",
      "ref": "228",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.light-machine-gun.is",
    "name": "Light Machine Gun [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 5000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3068
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "0.5",
      "rawCost": "5,000",
      "heat": "0 (0)",
      "damage": "1 (1)",
      "range": "0/2/4/6 (Short)",
      "ammoPerTon": "200",
      "ref": "228",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "toaue.light-mass-driver.is",
    "name": "Light Mass Driver [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 30000,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2715
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-X-F",
      "rawMass": "30,000",
      "rawCost": "150M / 150,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "1*",
      "slotsSpaceStation": "1*",
      "manualCostFormula": "150M / 150,000"
    }
  },
  {
    "id": "toaue.light-n-gauss.is-clan",
    "name": "Light N-Gauss",
    "categories": [
      "equipment"
    ],
    "mass": 4500,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2448
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "*",
      "rawMass": "4,500",
      "rawCost": "20.3M / 45,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*",
      "slotsMobileStructure": "1*",
      "manualCostFormula": "20.3M / 45,000"
    }
  },
  {
    "id": "toaue.light-n-ppc.is-clan",
    "name": "Light N-PPC",
    "categories": [
      "equipment"
    ],
    "mass": 1400,
    "cost": 2000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2358
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "*",
      "rawMass": "1,400",
      "rawCost": "2,000,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*",
      "slotsMobileStructure": "1*"
    }
  },
  {
    "id": "tm.light-ppc.is",
    "name": "Light PPC [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 3,
    "cost": 150000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3067
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "3",
      "rawCost": "150,000",
      "heat": "5 (5)",
      "damage": "5 (5)",
      "range": "3/6/12/18 (Medium)",
      "ammoPerTon": "NA",
      "ref": "234",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 2
  },
  {
    "id": "toaue.light-rifle.is",
    "name": "Light Rifle [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 3,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/C-F-X",
      "rawMass": "3",
      "rawCost": "37,750 / 800",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1",
      "manualCostFormula": "37,750 / 800"
    },
    "slots": 1
  },
  {
    "id": "toaue.light-sail.is-clan",
    "name": "Light Sail",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2165
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/C-E-D",
      "rawMass": "TT÷10*",
      "rawCost": "100,000xIT",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "TT÷10*",
      "manualCostFormula": "100,000xIT"
    }
  },
  {
    "id": "toaue.light-scc.is",
    "name": "Light SCC [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 200,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3073
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "200",
      "rawCost": "330,000 / 10,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "30",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1-C*",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*",
      "slotsMobileStructure": "1",
      "manualCostFormula": "330,000 / 10,000"
    }
  },
  {
    "id": "tm.light-tag.clan",
    "name": "Light TAG [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 40000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3054
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "0.5",
      "rawCost": "40,000",
      "heat": "0 (0)",
      "damage": "**",
      "range": "0/3/6/9 (**)",
      "ammoPerTon": "NA",
      "ref": "238",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "toaue.limited-amphibious.is-clan",
    "name": "Limited Amphibious",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2470
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/B-B-B",
      "rawMass": "TT÷25*",
      "rawCost": "10,000xIT",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "0*",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualMassFormula": "TT÷25*",
      "manualCostFormula": "10,000xIT"
    }
  },
  {
    "id": "toaue.lithium-fusion-battery.is-clan",
    "name": "Lithium-Fusion Battery",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2531
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "*",
      "rawMass": "TT÷100*",
      "rawCost": "3xKF",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "0",
      "slotsWarShip": "0",
      "slotsSpaceStation": "NA",
      "manualMassFormula": "TT÷100*",
      "manualCostFormula": "3xKF"
    }
  },
  {
    "id": "toaue.long-tom.is-clan",
    "name": "Long Tom",
    "categories": [
      "equipment"
    ],
    "mass": 30,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/C-C-C",
      "rawMass": "30",
      "rawCost": "450,000 / 10,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "15",
      "slotsFighter": "NA",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualCostFormula": "450,000 / 10,000"
    }
  },
  {
    "id": "toaue.long-tom.is-clan.2",
    "name": "Long Tom",
    "categories": [
      "equipment"
    ],
    "mass": 20,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3012
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/X-F-E",
      "rawMass": "20",
      "rawCost": "650,000 / 20,000",
      "slotsBattleMech": "15",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "15",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "manualCostFormula": "650,000 / 20,000"
    },
    "slots": 15
  },
  {
    "id": "tm.look-down-radar.is-clan",
    "name": "Look-Down Radar",
    "categories": [
      "weapon"
    ],
    "mass": 5,
    "cost": 400000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "5",
      "rawCost": "400,000",
      "heat": "NA (0)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "227",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "0*",
      "slotsSmallCraft": "0*",
      "slotsDropShip": "0*"
    }
  },
  {
    "id": "toaue.look-down-radar.is-clan",
    "name": "Look-Down Radar",
    "categories": [
      "equipment"
    ],
    "mass": 5,
    "cost": 400000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/D-E-D",
      "rawMass": "5",
      "rawCost": "400,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1"
    }
  },
  {
    "id": "tm.lrm-10.clan",
    "name": "LRM 10 [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 2.5,
    "cost": 100000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "2.5",
      "rawCost": "100,000",
      "heat": "4 (4)",
      "damage": "1/Msl (6)",
      "range": "0/7/14/21 (Long)",
      "ammoPerTon": "12",
      "ref": "229",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.lrm-10.is",
    "name": "LRM 10 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 5,
    "cost": 100000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2400
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "5",
      "rawCost": "100,000",
      "heat": "4 (4)",
      "damage": "1/Msl (6)",
      "range": "6/7/14/21 (Long)",
      "ammoPerTon": "12",
      "ref": "229",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 2
  },
  {
    "id": "tm.lrm-15.clan",
    "name": "LRM 15 [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 3.5,
    "cost": 175000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "3.5",
      "rawCost": "175,000",
      "heat": "5 (5)",
      "damage": "1/Msl (9)",
      "range": "0/7/14/21 (Long)",
      "ammoPerTon": "8",
      "ref": "229",
      "slotsBattleMech": "2",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 2
  },
  {
    "id": "tm.lrm-15.is",
    "name": "LRM 15 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 7,
    "cost": 175000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2400
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "7",
      "rawCost": "175,000",
      "heat": "5 (5)",
      "damage": "1/Msl (9)",
      "range": "6/7/14/21 (Long)",
      "ammoPerTon": "8",
      "ref": "229",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 3
  },
  {
    "id": "tm.lrm-20.clan",
    "name": "LRM 20 [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 5,
    "cost": 250000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "5",
      "rawCost": "250,000",
      "heat": "6 (6)",
      "damage": "1/Msl (12)",
      "range": "0/7/14/21 (Long)",
      "ammoPerTon": "6",
      "ref": "229",
      "slotsBattleMech": "4",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "4",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 4
  },
  {
    "id": "tm.lrm-20.is",
    "name": "LRM 20 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 10,
    "cost": 250000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2400
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "10",
      "rawCost": "250,000",
      "heat": "6 (6)",
      "damage": "1/Msl (12)",
      "range": "6/7/14/21 (Long)",
      "ammoPerTon": "6",
      "ref": "229",
      "slotsBattleMech": "5",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "5",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 5
  },
  {
    "id": "tm.lrm-5.clan",
    "name": "LRM 5 [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 30000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "1",
      "rawCost": "30,000",
      "heat": "2 (2)",
      "damage": "1/Msl (3)",
      "range": "0/7/14/21 (Long)",
      "ammoPerTon": "24",
      "ref": "229",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.lrm-5.is",
    "name": "LRM 5 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 2,
    "cost": 30000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2400
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "2",
      "rawCost": "30,000",
      "heat": "2 (2)",
      "damage": "1/Msl (3)",
      "range": "6/7/14/21 (Long)",
      "ammoPerTon": "24",
      "ref": "229",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.lt-vehicle-cub.is-clan",
    "name": "Lt. Vehicle (Cub.)",
    "categories": [
      "weapon"
    ],
    "mass": 50,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "50",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "239",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1**",
      "slotsSupportVehicle": "1**",
      "slotsFighter": "NA",
      "slotsSmallCraft": "0",
      "slotsDropShip": "0",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    }
  },
  {
    "id": "toaue.m-pod.is",
    "name": "M-Pod [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 6000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3064
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/X-X-E",
      "rawMass": "1",
      "rawCost": "6,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1"
    },
    "slots": 1
  },
  {
    "id": "toaue.mace.is",
    "name": "Mace [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 130000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3061
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/X-F-D",
      "rawMass": "TT÷10*",
      "rawCost": "130,000",
      "slotsBattleMech": "TT÷10*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualMassFormula": "TT÷10*"
    }
  },
  {
    "id": "tm.machine-gun.clan",
    "name": "Machine Gun [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 0.25,
    "cost": 5000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "0.25",
      "rawCost": "5,000",
      "heat": "0 (0)",
      "damage": "2 (2)",
      "range": "0/1/2/3 (Short)",
      "ammoPerTon": "200",
      "ref": "228",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.machine-gun.is",
    "name": "Machine Gun [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 5000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "0.5",
      "rawCost": "5,000",
      "heat": "0 (0)",
      "damage": "2 (2)",
      "range": "0/1/2/3 (Short)",
      "ammoPerTon": "200",
      "ref": "228",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.machine-gun-array.clan",
    "name": "Machine Gun Array [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 0.25,
    "cost": 1250,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3069
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "+0.25",
      "rawCost": "1,250",
      "heat": "NA",
      "damage": "**",
      "range": "** (**)",
      "ammoPerTon": "**",
      "ref": "228",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.machine-gun-array.is",
    "name": "Machine Gun Array [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 1250,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3068
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "+0.5",
      "rawCost": "1,250",
      "heat": "NA",
      "damage": "**",
      "range": "** (**)",
      "ammoPerTon": "**",
      "ref": "228",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "io.magnetic-clamp-system.clan",
    "name": "Magnetic Clamp System [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 25000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3075
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "*",
      "rawCost": "25,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "1*",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "toaue.magshot.is",
    "name": "MagShot [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0.5,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3072
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-D",
      "rawMass": "0.5",
      "rawCost": "8,500 / 1,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "manualCostFormula": "8,500 / 1,000"
    },
    "slots": 2
  },
  {
    "id": "tm.manipulator.is-clan",
    "name": "Manipulator",
    "categories": [
      "weapon"
    ],
    "mass": 0.01,
    "cost": 7500,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "0.01",
      "rawCost": "7,500",
      "heat": "0 (NA)",
      "damage": "0 (NA)",
      "range": "PHYS (NA)",
      "ammoPerTon": "NA",
      "ref": "245",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    }
  },
  {
    "id": "toaue.manta-ray.is-clan",
    "name": "Manta Ray",
    "categories": [
      "equipment"
    ],
    "mass": 160,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3072
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "160",
      "rawCost": "150,000 / 30,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "38",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1-C*",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*",
      "manualCostFormula": "150,000 / 30,000"
    }
  },
  {
    "id": "tm.masc.clan",
    "name": "MASC [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "Var*",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "NA",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "232",
      "slotsBattleMech": "Var*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "manualMassFormula": "Var*",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    }
  },
  {
    "id": "tm.masc.is",
    "name": "MASC [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "Var*",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "NA",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "232",
      "slotsBattleMech": "Var*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "manualMassFormula": "Var*",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    }
  },
  {
    "id": "toaue.mechanical-jump-boosters.is",
    "name": "Mechanical Jump Boosters [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3060
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "Var*",
      "rawCost": "†",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "Var*",
      "manualCostFormula": "†"
    }
  },
  {
    "id": "toaue.mechwarrior-aquatic-survival-system.is-clan",
    "name": "MechWarrior Aquatic Survival System",
    "categories": [
      "equipment"
    ],
    "mass": 1.5,
    "cost": 4000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3048
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-X-D",
      "rawMass": "1.5",
      "rawCost": "4,000",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 1
  },
  {
    "id": "tm.medium.is-clan",
    "name": "Medium",
    "categories": [
      "weapon"
    ],
    "mass": 2,
    "cost": 75000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "2",
      "rawCost": "75,000",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "242",
      "slotsBattleMech": "4*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 4
  },
  {
    "id": "tm.medium-laser.is",
    "name": "Medium Laser [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 40000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2400
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "1",
      "rawCost": "40,000",
      "heat": "3 (3)",
      "damage": "5 (5)",
      "range": "0/3/6/9 (Short)",
      "ammoPerTon": "NA",
      "ref": "227",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "toaue.medium-mass-driver.is",
    "name": "Medium Mass Driver [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 50000,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2715
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-X-F",
      "rawMass": "50,000",
      "rawCost": "280M / 300,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "1*",
      "slotsSpaceStation": "1*",
      "slotsMobileStructure": "NA",
      "manualCostFormula": "280M / 300,000"
    }
  },
  {
    "id": "toaue.medium-n-gauss.is-clan",
    "name": "Medium N-Gauss",
    "categories": [
      "equipment"
    ],
    "mass": 5500,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2448
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "*",
      "rawMass": "5,500",
      "rawCost": "30.35M / 75,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*",
      "manualCostFormula": "30.35M / 75,000"
    }
  },
  {
    "id": "toaue.medium-n-ppc.is-clan",
    "name": "Medium N-PPC",
    "categories": [
      "equipment"
    ],
    "mass": 1800,
    "cost": 3250000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2358
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "*",
      "rawMass": "1,800",
      "rawCost": "3,250,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*"
    }
  },
  {
    "id": "tm.medium-pulse-laser.clan",
    "name": "Medium Pulse Laser [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 2,
    "cost": 60000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "2",
      "rawCost": "60,000",
      "heat": "4 (4)",
      "damage": "7 (7)",
      "range": "0/4/8/12 (Medium)",
      "ammoPerTon": "NA",
      "ref": "226",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.medium-pulse-laser.is",
    "name": "Medium Pulse Laser [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 2,
    "cost": 60000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2609
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "2",
      "rawCost": "60,000",
      "heat": "4 (4)",
      "damage": "6 (6)",
      "range": "0/2/4/6 (Short)",
      "ammoPerTon": "NA",
      "ref": "226",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "io.medium-re-engineered-laser.is",
    "name": "Medium Re-Engineered Laser [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 2.5,
    "cost": 100000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3130
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-X-E",
      "rawMass": "2.5",
      "rawCost": "100,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 2
  },
  {
    "id": "toaue.medium-rifle.is",
    "name": "Medium Rifle [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 5,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/C-F-X",
      "rawMass": "5",
      "rawCost": "75,500 / 1,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualCostFormula": "75,500 / 1,000"
    },
    "slots": 2
  },
  {
    "id": "toaue.medium-scc.is",
    "name": "Medium SCC [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 500,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3073
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "500",
      "rawCost": "780,000 / 18,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "50",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1-C*",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*",
      "manualCostFormula": "780,000 / 18,000"
    }
  },
  {
    "id": "tm.micro-pulse-laser.clan",
    "name": "Micro Pulse Laser [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 12500,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3060
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "0.5",
      "rawCost": "12,500",
      "heat": "1 (1)",
      "damage": "3 (3)",
      "range": "0/1/2/3 (Short)",
      "ammoPerTon": "NA",
      "ref": "226",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "toaue.minesweeper.is-clan",
    "name": "Minesweeper",
    "categories": [
      "equipment"
    ],
    "mass": 3,
    "cost": 40000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/D-D-D",
      "rawMass": "3",
      "rawCost": "40,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1"
    }
  },
  {
    "id": "tm.mining-drill.is-clan",
    "name": "Mining Drill",
    "categories": [
      "weapon"
    ],
    "mass": 3,
    "cost": 100000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "3",
      "rawCost": "100,000",
      "heat": "0 (NA)",
      "damage": "4 (NA)",
      "range": "PHYS (NA)",
      "ammoPerTon": "NA",
      "ref": "246",
      "slotsBattleMech": "4*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 4
  },
  {
    "id": "tm.mml-3-lrm.is",
    "name": "MML 3 (LRM) [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 1.5,
    "cost": 45000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3068
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "1.5",
      "rawCost": "45,000",
      "heat": "2 (2)",
      "damage": "1/Msl (2)",
      "range": "6/7/14/21 (Long)",
      "ammoPerTon": "40",
      "ref": "229",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 2
  },
  {
    "id": "tm.mml-3-srm.is",
    "name": "MML 3 (SRM) [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 1.5,
    "cost": 45000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3068
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "1.5",
      "rawCost": "45,000",
      "heat": "2 (2)",
      "damage": "2/Msl (4)",
      "range": "0/3/6/9 (Short)",
      "ammoPerTon": "33",
      "ref": "229",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 2
  },
  {
    "id": "tm.mml-5-lrm.is",
    "name": "MML 5 (LRM) [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 3,
    "cost": 75000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3068
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "3",
      "rawCost": "75,000",
      "heat": "3 (3)",
      "damage": "1/Msl (3)",
      "range": "6/7/14/21 (Long)",
      "ammoPerTon": "24",
      "ref": "229",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 3
  },
  {
    "id": "tm.mml-5-srm.is",
    "name": "MML 5 (SRM) [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 3,
    "cost": 75000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3068
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "3",
      "rawCost": "75,000",
      "heat": "3 (3)",
      "damage": "2/Msl (6)",
      "range": "0/3/6/9 (Short)",
      "ammoPerTon": "20",
      "ref": "229",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 3
  },
  {
    "id": "tm.mml-7-lrm.is",
    "name": "MML 7 (LRM) [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 4.5,
    "cost": 105000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3068
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "4.5",
      "rawCost": "105,000",
      "heat": "4 (4)",
      "damage": "1/Msl (4)",
      "range": "6/7/14/21 (Long)",
      "ammoPerTon": "17",
      "ref": "229",
      "slotsBattleMech": "4",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "4",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 4
  },
  {
    "id": "tm.mml-7-srm.is",
    "name": "MML 7 (SRM) [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 4.5,
    "cost": 105000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3068
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "4.5",
      "rawCost": "105,000",
      "heat": "4 (4)",
      "damage": "2/Msl (8)",
      "range": "0/3/6/9 (Short)",
      "ammoPerTon": "14",
      "ref": "229",
      "slotsBattleMech": "4",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "4",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 4
  },
  {
    "id": "tm.mml-9-lrm.is",
    "name": "MML 9 (LRM) [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 6,
    "cost": 125000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3068
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "6",
      "rawCost": "125,000",
      "heat": "5 (5)",
      "damage": "1/Msl (5)",
      "range": "6/7/14/21 (Long)",
      "ammoPerTon": "13",
      "ref": "229",
      "slotsBattleMech": "5",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "5",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 5
  },
  {
    "id": "tm.mml-9-srm.is",
    "name": "MML 9 (SRM) [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 6,
    "cost": 125000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3068
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "6",
      "rawCost": "125,000",
      "heat": "5 (5)",
      "damage": "2/Msl (10)",
      "range": "0/3/6/9 (Short)",
      "ammoPerTon": "11",
      "ref": "229",
      "slotsBattleMech": "5",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "5",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 5
  },
  {
    "id": "toaue.mobile-field-base.is-clan",
    "name": "Mobile Field Base",
    "categories": [
      "equipment"
    ],
    "mass": 20,
    "cost": 150000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3059
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-X-E",
      "rawMass": "20",
      "rawCost": "150,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1"
    }
  },
  {
    "id": "toaue.mobile-hpg.is-clan",
    "name": "Mobile HPG",
    "categories": [
      "equipment"
    ],
    "mass": 50,
    "cost": 1000000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2655
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/E-X-F",
      "rawMass": "50",
      "rawCost": "1,000,000,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "50",
      "slotsFighter": "NA",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    }
  },
  {
    "id": "toaue.modular.is-clan",
    "name": "Modular",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3072
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-X-F",
      "rawMass": "1*",
      "rawCost": "10,000xAT",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "2",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualCostFormula": "10,000xAT"
    },
    "slots": 1
  },
  {
    "id": "io.modular-space-stations.is-clan",
    "name": "Modular Space Stations",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2585
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "D/E-X-X",
      "rawMass": "*",
      "rawCost": "FCx50",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "0",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "FCx50"
    }
  },
  {
    "id": "tm.mounted.is-clan",
    "name": "Mounted",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 2000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "0.5",
      "rawCost": "2,000",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "0/0/0/170 (Extreme)",
      "ammoPerTon": "NA",
      "ref": "237",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "0",
      "slotsSmallCraft": "0",
      "slotsDropShip": "0"
    },
    "slots": 1
  },
  {
    "id": "tm.mrm-10.is",
    "name": "MRM 10 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 3,
    "cost": 50000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3058
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "3",
      "rawCost": "50,000",
      "heat": "4 (4)",
      "damage": "1/Msl (6)",
      "range": "0/3/8/15 (Medium)",
      "ammoPerTon": "24",
      "ref": "229",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 2
  },
  {
    "id": "tm.mrm-20.is",
    "name": "MRM 20 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 7,
    "cost": 125000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3058
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "7",
      "rawCost": "125,000",
      "heat": "6 (6)",
      "damage": "1/Msl (12)",
      "range": "0/3/8/15 (Medium)",
      "ammoPerTon": "12",
      "ref": "229",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 3
  },
  {
    "id": "tm.mrm-30.is",
    "name": "MRM 30 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 10,
    "cost": 225000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3058
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "10",
      "rawCost": "225,000",
      "heat": "10 (10)",
      "damage": "1/Msl (18)",
      "range": "0/3/8/15 (Medium)",
      "ammoPerTon": "8",
      "ref": "229",
      "slotsBattleMech": "5",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "5",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 5
  },
  {
    "id": "tm.mrm-40.is",
    "name": "MRM 40 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 12,
    "cost": 350000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3058
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "12",
      "rawCost": "350,000",
      "heat": "12 (12)",
      "damage": "1/Msl (24)",
      "range": "0/3/8/15 (Medium)",
      "ammoPerTon": "6",
      "ref": "229",
      "slotsBattleMech": "7",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "7",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 7
  },
  {
    "id": "toaue.mrm-apollo-fcs.is",
    "name": "MRM “Apollo” FCS [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 125000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3071
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-X-E",
      "rawMass": "+1**",
      "rawCost": "125,000",
      "slotsBattleMech": "+1**",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "+0**",
      "slotsSupportVehicle": "+1**",
      "slotsFighter": "+0**",
      "slotsSmallCraft": "+0**",
      "slotsDropShip": "+0**",
      "slotsJumpShip": "+0**",
      "slotsWarShip": "+0**",
      "slotsSpaceStation": "+0**"
    },
    "slots": 1
  },
  {
    "id": "io.multi-modal-sensory-implants.is",
    "name": "Multi-Modal Sensory Implants [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 900000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3055
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-D",
      "rawMass": "*",
      "rawCost": "900,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "toaue.nac-10.is-clan",
    "name": "NAC/10",
    "categories": [
      "equipment"
    ],
    "mass": 2000,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2195
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/E-X-E",
      "rawMass": "2,000",
      "rawCost": "2M / 30,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*",
      "manualCostFormula": "2M / 30,000"
    }
  },
  {
    "id": "toaue.nac-20.is-clan",
    "name": "NAC/20",
    "categories": [
      "equipment"
    ],
    "mass": 2500,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2197
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/E-X-E",
      "rawMass": "2,500",
      "rawCost": "5M / 60,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*",
      "slotsMobileStructure": "1*",
      "manualCostFormula": "5M / 60,000"
    }
  },
  {
    "id": "toaue.nac-25.is-clan",
    "name": "NAC/25",
    "categories": [
      "equipment"
    ],
    "mass": 3000,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2200
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/E-X-E",
      "rawMass": "3,000",
      "rawCost": "7.5M / 75,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*",
      "manualCostFormula": "7.5M / 75,000"
    }
  },
  {
    "id": "toaue.nac-30.is-clan",
    "name": "NAC/30",
    "categories": [
      "equipment"
    ],
    "mass": 3500,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2200
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/E-X-E",
      "rawMass": "3,500",
      "rawCost": "10.5M / 90,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*",
      "slotsMobileStructure": "1*",
      "manualCostFormula": "10.5M / 90,000"
    }
  },
  {
    "id": "toaue.nac-35.is-clan",
    "name": "NAC/35",
    "categories": [
      "equipment"
    ],
    "mass": 4000,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2201
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/E-X-E",
      "rawMass": "4,000",
      "rawCost": "14M / 105,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*",
      "manualCostFormula": "14M / 105,000"
    }
  },
  {
    "id": "toaue.nac-40.is-clan",
    "name": "NAC/40",
    "categories": [
      "equipment"
    ],
    "mass": 4500,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2202
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/E-X-E",
      "rawMass": "4,500",
      "rawCost": "18M / 120,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*",
      "slotsMobileStructure": "1*",
      "manualCostFormula": "18M / 120,000"
    }
  },
  {
    "id": "tm.nail-rivet-gun.is-clan",
    "name": "Nail/Rivet Gun",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 7000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2310
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "0.5",
      "rawCost": "7,000",
      "heat": "0 (0)",
      "damage": "0 (NA)",
      "range": "0/1/—/— (NA)",
      "ammoPerTon": "300",
      "ref": "246",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1**",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 1
  },
  {
    "id": "tm.narc-missile-beacon.clan",
    "name": "Narc Missile Beacon [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 2,
    "cost": 100000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "2",
      "rawCost": "100,000",
      "heat": "0 (**)",
      "damage": "**",
      "range": "0/4/8/12 (**)",
      "ammoPerTon": "6",
      "ref": "232",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.narc-missile-beacon.is",
    "name": "Narc Missile Beacon [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 3,
    "cost": 100000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2587
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "3",
      "rawCost": "100,000",
      "heat": "0 (**)",
      "damage": "**",
      "range": "0/3/6/9 (**)",
      "ammoPerTon": "6",
      "ref": "232",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 2
  },
  {
    "id": "toaue.naval-c3.is",
    "name": "Naval C3 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3065
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "*",
      "rawCost": "100,000xIT",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "0*",
      "slotsJumpShip": "0*",
      "slotsWarShip": "0*",
      "slotsSpaceStation": "0*",
      "manualMassFormula": "*",
      "manualCostFormula": "100,000xIT"
    }
  },
  {
    "id": "toaue.naval-tug-adaptor.is-clan",
    "name": "Naval Tug Adaptor",
    "categories": [
      "equipment"
    ],
    "mass": 100,
    "cost": 100000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/C-C-C",
      "rawMass": "100*",
      "rawCost": "100,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "0*",
      "slotsDropShip": "0*",
      "slotsJumpShip": "NA",
      "slotsWarShip": "0*",
      "slotsSpaceStation": "NA"
    }
  },
  {
    "id": "toaue.nl35.is-clan",
    "name": "NL35",
    "categories": [
      "equipment"
    ],
    "mass": 700,
    "cost": 500000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2305
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "*",
      "rawMass": "700",
      "rawCost": "500,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*",
      "slotsMobileStructure": "1*"
    }
  },
  {
    "id": "toaue.nl45.is-clan",
    "name": "NL45",
    "categories": [
      "equipment"
    ],
    "mass": 900,
    "cost": 850000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2305
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "*",
      "rawMass": "900",
      "rawCost": "850,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*"
    }
  },
  {
    "id": "toaue.nl55.is-clan",
    "name": "NL55",
    "categories": [
      "equipment"
    ],
    "mass": 1100,
    "cost": 1250000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2307
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "*",
      "rawMass": "1,100",
      "rawCost": "1,250,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*",
      "slotsMobileStructure": "1*"
    }
  },
  {
    "id": "io.nova-cews.clan",
    "name": "Nova CEWS [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 1.5,
    "cost": 1110000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3065
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "1.5",
      "rawCost": "1,110,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 1
  },
  {
    "id": "io.nuclear-weapon-amw.is",
    "name": "Nuclear Weapon (AMW) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2790
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-F-F",
      "rawMass": "† / [1/30]",
      "rawCost": "† / 100M",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "†",
      "slotsDropShip": "†",
      "slotsJumpShip": "†",
      "slotsWarShip": "†",
      "slotsSpaceStation": "†",
      "slotsMobileStructure": "†",
      "manualMassFormula": "† / [1/30]",
      "manualCostFormula": "† / 100M"
    }
  },
  {
    "id": "io.nuclear-weapon-custom-strategic.is",
    "name": "Nuclear Weapon (Custom Strategic) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/F-F-F",
      "rawMass": "*",
      "rawCost": "† / [10M/Megaton]",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "*",
      "slotsSmallCraft": "*",
      "slotsDropShip": "*",
      "slotsJumpShip": "*",
      "slotsWarShip": "*",
      "slotsSpaceStation": "*",
      "slotsMobileStructure": "*",
      "manualMassFormula": "*",
      "manualCostFormula": "† / [10M/Megaton]"
    }
  },
  {
    "id": "io.nuclear-weapon-custom-tactical.is",
    "name": "Nuclear Weapon (Custom Tactical) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/F-F-F",
      "rawMass": "*",
      "rawCost": "† / [1M/Kiloton]",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "*",
      "slotsSmallCraft": "*",
      "slotsDropShip": "*",
      "slotsJumpShip": "*",
      "slotsWarShip": "*",
      "slotsSpaceStation": "*",
      "slotsMobileStructure": "*",
      "manualMassFormula": "*",
      "manualCostFormula": "† / [1M/Kiloton]"
    }
  },
  {
    "id": "io.nuclear-weapon-elias.is",
    "name": "Nuclear Weapon (Elias) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0.005,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-F-F",
      "rawMass": "0.005",
      "rawCost": "NA / 10K",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualCostFormula": "NA / 10K"
    }
  },
  {
    "id": "io.nuclear-weapon-type-ia.is",
    "name": "Nuclear Weapon (Type Ia) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 3,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2412
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-F-F",
      "rawMass": "3*",
      "rawCost": "1M / 500K",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualCostFormula": "1M / 500K"
    }
  },
  {
    "id": "io.nuclear-weapon-type-ib-arrow-iv.is",
    "name": "Nuclear Weapon (Type Ib [Arrow IV]) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2480
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-F-F",
      "rawMass": "† / 1",
      "rawCost": "† / 500K",
      "slotsBattleMech": "†",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "†",
      "slotsSupportVehicle": "†",
      "slotsFighter": "†",
      "slotsSmallCraft": "†",
      "slotsDropShip": "†",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "†",
      "manualMassFormula": "† / 1",
      "manualCostFormula": "† / 500K"
    }
  },
  {
    "id": "io.nuclear-weapon-type-ib-long-tom.is",
    "name": "Nuclear Weapon (Type Ib [Long Tom]) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2595
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-F-F",
      "rawMass": "† / 1",
      "rawCost": "† / 500K",
      "slotsBattleMech": "†",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "†",
      "slotsSupportVehicle": "†",
      "slotsFighter": "†",
      "slotsSmallCraft": "†",
      "slotsDropShip": "†",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "†",
      "manualMassFormula": "† / 1",
      "manualCostFormula": "† / 500K"
    }
  },
  {
    "id": "io.nuclear-weapon-type-ii.is",
    "name": "Nuclear Weapon (Type II) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2200
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-F-F",
      "rawMass": "† / 5",
      "rawCost": "† / 1M",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "†",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "† / 5",
      "manualCostFormula": "† / 1M"
    }
  },
  {
    "id": "io.nuclear-weapon-type-iii-c-missile.is",
    "name": "Nuclear Weapon (Type III [C-Missile]) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2300
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-F-F",
      "rawMass": "† / [1/40]",
      "rawCost": "† / 15M",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "†",
      "slotsFighter": "NA",
      "slotsSmallCraft": "†",
      "slotsDropShip": "†",
      "slotsJumpShip": "†",
      "slotsWarShip": "†",
      "slotsSpaceStation": "†",
      "slotsMobileStructure": "†",
      "manualMassFormula": "† / [1/40]",
      "manualCostFormula": "† / 15M"
    }
  },
  {
    "id": "io.nuclear-weapon-type-iii-launcher.is",
    "name": "Nuclear Weapon (Type III [Launcher]) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2300
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-F-F",
      "rawMass": "160 / [1/40]",
      "rawCost": "250K / 15M",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "15",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1",
      "manualMassFormula": "160 / [1/40]",
      "manualCostFormula": "250K / 15M"
    }
  },
  {
    "id": "io.nuclear-weapon-type-iv-c-missile.is",
    "name": "Nuclear Weapon (Type IV [C-Missile]) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2220
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-F-F",
      "rawMass": "† / [1/50]",
      "rawCost": "† / 40M",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "†",
      "slotsFighter": "NA",
      "slotsSmallCraft": "†",
      "slotsDropShip": "†",
      "slotsJumpShip": "†",
      "slotsWarShip": "†",
      "slotsSpaceStation": "†",
      "slotsMobileStructure": "†",
      "manualMassFormula": "† / [1/50]",
      "manualCostFormula": "† / 40M"
    }
  },
  {
    "id": "io.nuclear-weapon-type-iv-launcher.is",
    "name": "Nuclear Weapon (Type IV [Launcher]) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2220
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-F-F",
      "rawMass": "210 / [1/50]",
      "rawCost": "500K / 40M",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "20",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1",
      "manualMassFormula": "210 / [1/50]",
      "manualCostFormula": "500K / 40M"
    }
  },
  {
    "id": "toaue.null-signature-system.is",
    "name": "Null-Signature System [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 1400000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2630
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/E-X-X",
      "rawMass": "0*",
      "rawCost": "1,400,000",
      "slotsBattleMech": "7*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 7
  },
  {
    "id": "tm.offi-cer-1st-class.is-clan",
    "name": "Offi cer/1st Class",
    "categories": [
      "weapon"
    ],
    "mass": 10,
    "cost": 30000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "10",
      "rawCost": "30,000",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "236",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "0*",
      "slotsDropShip": "0*"
    }
  },
  {
    "id": "tm.paramedic-equipment.is-clan",
    "name": "Paramedic Equipment",
    "categories": [
      "weapon"
    ],
    "mass": 0.25,
    "cost": 7500,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "0.25",
      "rawCost": "7,500",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "233",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    }
  },
  {
    "id": "toaue.partial-wing-protomech.clan",
    "name": "Partial Wing (ProtoMech) [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3070
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-E",
      "rawMass": "TT÷5*",
      "rawCost": "50,000xIT",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "1*",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "TT÷5*",
      "manualCostFormula": "50,000xIT"
    }
  },
  {
    "id": "toaue.partial-wing-mech.is-clan",
    "name": "Partial Wing (’Mech)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3067
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-E",
      "rawMass": "*",
      "rawCost": "50,000xIT",
      "slotsBattleMech": "8/6*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "50,000xIT"
    }
  },
  {
    "id": "toaue.pcmt-equipment-low-density.is-clan",
    "name": "PCMT Equipment, Low-Density",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2200
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/C-C-C",
      "rawMass": "Var*",
      "rawCost": "200,000xIT",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "1*",
      "manualMassFormula": "Var*",
      "manualCostFormula": "200,000xIT"
    }
  },
  {
    "id": "tm.pintle.is-clan",
    "name": "Pintle",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "Var*",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "235",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "0",
      "slotsSupportVehicle": "0",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "manualMassFormula": "Var*",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    }
  },
  {
    "id": "toaue.piranha.is-clan",
    "name": "Piranha",
    "categories": [
      "equipment"
    ],
    "mass": 100,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3072
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "100",
      "rawCost": "75,000 / 15,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "18",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1-C*",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*",
      "slotsMobileStructure": "1",
      "manualCostFormula": "75,000 / 15,000"
    }
  },
  {
    "id": "tm.plasma-cannon.clan",
    "name": "Plasma Cannon [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 3,
    "cost": 320000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3069
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "3",
      "rawCost": "320,000",
      "heat": "7 (7)",
      "damage": "0** (**)",
      "range": "0/6/12/18 (Medium)",
      "ammoPerTon": "10",
      "ref": "234",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.plasma-rifl-e.is",
    "name": "Plasma Rifl e [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 6,
    "cost": 260000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3068
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "6",
      "rawCost": "260,000",
      "heat": "10 (10)",
      "damage": "10 (10)",
      "range": "0/5/10/15 (Medium)",
      "ammoPerTon": "10",
      "ref": "234",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 2
  },
  {
    "id": "tm.ppc.is",
    "name": "PPC [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 7,
    "cost": 200000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2460
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "D",
      "rawMass": "7",
      "rawCost": "200,000",
      "heat": "10 (10)",
      "damage": "10 (10)",
      "range": "3/6/12/18 (Medium)",
      "ammoPerTon": "NA",
      "ref": "234",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 3
  },
  {
    "id": "toaue.ppc-capacitor.is",
    "name": "PPC Capacitor [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 150000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3060
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-E",
      "rawMass": "+1**",
      "rawCost": "150,000",
      "slotsBattleMech": "+1**",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "+0**",
      "slotsSupportVehicle": "+1**",
      "slotsFighter": "+0**",
      "slotsSmallCraft": "+0**",
      "slotsDropShip": "+0**",
      "slotsJumpShip": "+0**",
      "slotsWarShip": "+0**",
      "slotsSpaceStation": "+0**",
      "slotsMobileStructure": "+0**"
    },
    "slots": 1
  },
  {
    "id": "toaue.pressurized.is-clan",
    "name": "Pressurized",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/C-E-D",
      "rawMass": "0.075xC",
      "rawCost": "10,000xC",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "0*",
      "slotsWarShip": "0*",
      "slotsSpaceStation": "0*",
      "manualMassFormula": "0.075xC",
      "manualCostFormula": "10,000xC"
    }
  },
  {
    "id": "io.primitive-aerospace-fighter-armor.is",
    "name": "Primitive Aerospace Fighter Armor [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2315
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/B-C-B",
      "rawMass": "*",
      "rawCost": "5,000xAT",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "0",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "5,000xAT"
    }
  },
  {
    "id": "io.primitive-aerospace-fighter-cockpit.is",
    "name": "Primitive Aerospace Fighter Cockpit [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 5,
    "cost": 100000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "D/D-X-X",
      "rawMass": "5",
      "rawCost": "100,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "0*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    }
  },
  {
    "id": "io.primitive-battlemech-cockpit.is",
    "name": "Primitive BattleMech Cockpit [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 5,
    "cost": 100000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2449
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "D/D-X-X",
      "rawMass": "5",
      "rawCost": "100,000",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 1
  },
  {
    "id": "io.primitive-industrialmech-cockpit.is",
    "name": "Primitive IndustrialMech Cockpit [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 5,
    "cost": 50000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2300
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/C-X-X",
      "rawMass": "5",
      "rawCost": "50,000",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 1
  },
  {
    "id": "io.primitive-prototype-autocannon-10.is",
    "name": "Primitive Prototype Autocannon/10 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 12,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2450
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/F-X-X",
      "rawMass": "12",
      "rawCost": "200,000 / 6,000",
      "slotsBattleMech": "7",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "7",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "200,000 / 6,000"
    },
    "slots": 7
  },
  {
    "id": "io.primitive-prototype-autocannon-2.is",
    "name": "Primitive Prototype Autocannon/2 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 6,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2290
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/F-X-X",
      "rawMass": "6",
      "rawCost": "75,000 / 1,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "75,000 / 1,000"
    },
    "slots": 1
  },
  {
    "id": "io.primitive-prototype-autocannon-20.is",
    "name": "Primitive Prototype Autocannon/20 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 14,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2488
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/F-X-X",
      "rawMass": "14",
      "rawCost": "300,000 / 10,000",
      "slotsBattleMech": "10",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "10",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "300,000 / 10,000"
    },
    "slots": 10
  },
  {
    "id": "io.primitive-prototype-autocannon-5.is",
    "name": "Primitive Prototype Autocannon/5 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 8,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2240
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/F-X-X",
      "rawMass": "8",
      "rawCost": "125,000 / 4,500",
      "slotsBattleMech": "4",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "4",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "125,000 / 4,500"
    },
    "slots": 4
  },
  {
    "id": "io.primitive-prototype-large-laser.is",
    "name": "Primitive Prototype Large Laser [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 5,
    "cost": 100000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2306
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/F-X-X",
      "rawMass": "5",
      "rawCost": "100,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 2
  },
  {
    "id": "io.primitive-prototype-lrm-10.is",
    "name": "Primitive Prototype LRM 10 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 5,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2295
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/F-X-X",
      "rawMass": "5",
      "rawCost": "100,000 / 30,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "100,000 / 30,000"
    },
    "slots": 2
  },
  {
    "id": "io.primitive-prototype-lrm-15.is",
    "name": "Primitive Prototype LRM 15 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 7,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2295
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/F-X-X",
      "rawMass": "7",
      "rawCost": "175,000 / 30,000",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "175,000 / 30,000"
    },
    "slots": 3
  },
  {
    "id": "io.primitive-prototype-lrm-20.is",
    "name": "Primitive Prototype LRM 20 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 10,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2295
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/F-X-X",
      "rawMass": "10",
      "rawCost": "250,000 / 30,000",
      "slotsBattleMech": "5",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "5",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "250,000 / 30,000"
    },
    "slots": 5
  },
  {
    "id": "io.primitive-prototype-lrm-5.is",
    "name": "Primitive Prototype LRM 5 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 2,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2295
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/F-X-X",
      "rawMass": "2",
      "rawCost": "30,000 / 30,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "30,000 / 30,000"
    },
    "slots": 1
  },
  {
    "id": "io.primitive-prototype-medium-laser.is",
    "name": "Primitive Prototype Medium Laser [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 40000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2290
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/F-X-X",
      "rawMass": "1",
      "rawCost": "40,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 1
  },
  {
    "id": "io.primitive-prototype-ppc.is",
    "name": "Primitive Prototype PPC [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 7,
    "cost": 200000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2439
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "D/C-X-X",
      "rawMass": "7",
      "rawCost": "200,000",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 3
  },
  {
    "id": "io.primitive-prototype-small-laser.is",
    "name": "Primitive Prototype Small Laser [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0.5,
    "cost": 11250,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2290
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/F-X-X",
      "rawMass": "0.5",
      "rawCost": "11,250",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 1
  },
  {
    "id": "io.primitive-prototype-srm-2.is",
    "name": "Primitive Prototype SRM 2 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2365
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/F-X-X",
      "rawMass": "1",
      "rawCost": "10,000 / 27,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "10,000 / 27,000"
    },
    "slots": 1
  },
  {
    "id": "io.primitive-prototype-srm-4.is",
    "name": "Primitive Prototype SRM 4 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 2,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2365
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/F-X-X",
      "rawMass": "2",
      "rawCost": "60,000 / 27,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "60,000 / 27,000"
    },
    "slots": 1
  },
  {
    "id": "io.primitive-prototype-srm-6.is",
    "name": "Primitive Prototype SRM 6 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 3,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2365
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/F-X-X",
      "rawMass": "3",
      "rawCost": "80,000 / 27,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "80,000 / 27,000"
    },
    "slots": 2
  },
  {
    "id": "io.primitive-mech-musculature.is",
    "name": "Primitive ’Mech Musculature [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": {
      "op": "multiply",
      "args": [
        1000.0,
        {
          "var": "unit.mass"
        }
      ]
    },
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2300
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "D/D-X-X",
      "rawMass": "x1",
      "rawCost": "1,000xTT",
      "slotsBattleMech": "0",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "x1"
    },
    "slots": 0
  },
  {
    "id": "io.primitive-mech-industrial-armor.is-clan",
    "name": "Primitive ’Mech/Industrial Armor",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2430
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/B-C-B",
      "rawMass": "*",
      "rawCost": "5,000xAT",
      "slotsBattleMech": "0",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "0",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "0",
      "slotsSmallCraft": "0",
      "slotsDropShip": "0",
      "slotsJumpShip": "0",
      "slotsWarShip": "0",
      "slotsSpaceStation": "0",
      "slotsMobileStructure": "0",
      "manualMassFormula": "*",
      "manualCostFormula": "5,000xAT"
    },
    "slots": 0
  },
  {
    "id": "io.prosthetic-glider-wings.is",
    "name": "Prosthetic Glider Wings [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 90000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3069
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-E",
      "rawMass": "*",
      "rawCost": "90,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "io.prosthetic-leg-masc.is",
    "name": "Prosthetic Leg MASC [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 255000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3065
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-F",
      "rawMass": "*",
      "rawCost": "255,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "io.prosthetic-limb-enhanced.is-clan",
    "name": "Prosthetic Limb, Enhanced",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 100000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-F-E",
      "rawMass": "*",
      "rawCost": "100,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "io.prosthetic-limb-extraneous.is",
    "name": "Prosthetic Limb, Extraneous [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 400000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3068
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "*",
      "rawCost": "400,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "io.prosthetic-limb-improved-enhanced.is-clan",
    "name": "Prosthetic Limb, Improved Enhanced",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 202000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2650
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-F-F",
      "rawMass": "*",
      "rawCost": "202,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "io.prosthetic-powered-flight-wings.is",
    "name": "Prosthetic Powered Flight Wings [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 120000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3070
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "*",
      "rawCost": "120,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "io.prosthetic-tail-enhanced.is",
    "name": "Prosthetic Tail, Enhanced [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 60000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3068
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-F",
      "rawMass": "*",
      "rawCost": "60,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "tm.protomech-5-cub.is-clan",
    "name": "ProtoMech (5 Cub.)",
    "categories": [
      "weapon"
    ],
    "mass": 50,
    "cost": 10000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3066
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "50",
      "rawCost": "10,000",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "239",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1**",
      "slotsSupportVehicle": "1**",
      "slotsFighter": "NA",
      "slotsSmallCraft": "0",
      "slotsDropShip": "0"
    }
  },
  {
    "id": "toaue.protomech-ac-2.clan",
    "name": "ProtoMech AC/2 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 3.5,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3073
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "3.5",
      "rawCost": "95,000 / 1,200",
      "slotsBattleMech": "2",
      "slotsProtoMech": "1*",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "95,000 / 1,200"
    },
    "slots": 2
  },
  {
    "id": "toaue.protomech-ac-4.clan",
    "name": "ProtoMech AC/4 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 4.5,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3073
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "4.5",
      "rawCost": "133,000 / 4,800",
      "slotsBattleMech": "3",
      "slotsProtoMech": "1*",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "manualCostFormula": "133,000 / 4,800"
    },
    "slots": 3
  },
  {
    "id": "toaue.protomech-ac-8.clan",
    "name": "ProtoMech AC/8 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 5.5,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3073
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "5.5",
      "rawCost": "175,000 / 6,300",
      "slotsBattleMech": "4",
      "slotsProtoMech": "1*",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "4",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "175,000 / 6,300"
    },
    "slots": 4
  },
  {
    "id": "io.protomech-interface-cockpit.is",
    "name": "ProtoMech Interface Cockpit [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 1000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3071
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-F",
      "rawMass": ".5",
      "rawCost": "1,000,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "0",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": ".5"
    }
  },
  {
    "id": "toaue.protomech-melee-weapon.clan",
    "name": "ProtoMech Melee Weapon [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0.5,
    "cost": 50000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3067
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/X-X-E",
      "rawMass": "0.5*",
      "rawCost": "50,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "1*",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    }
  },
  {
    "id": "io.protomech-quad-melee-system.clan",
    "name": "ProtoMech Quad Melee System [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 70000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3072
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "1",
      "rawCost": "70,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "1*",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    }
  },
  {
    "id": "io.prototype-arrow-iv.is",
    "name": "Prototype Arrow IV [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 16,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2593
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-X-X",
      "rawMass": "16",
      "rawCost": "1,800,000 / 40,000",
      "slotsBattleMech": "16",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "16",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1",
      "manualCostFormula": "1,800,000 / 40,000"
    },
    "slots": 16
  },
  {
    "id": "io.prototype-artemis-iv-fcs.is",
    "name": "Prototype Artemis IV FCS [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 300000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2592
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-X-X",
      "rawMass": "+1",
      "rawCost": "300,000",
      "slotsBattleMech": "+1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "+0",
      "slotsSupportVehicle": "+1",
      "slotsFighter": "+0",
      "slotsSmallCraft": "+0",
      "slotsDropShip": "+0",
      "slotsJumpShip": "+0",
      "slotsWarShip": "+0",
      "slotsSpaceStation": "+0",
      "slotsMobileStructure": "+0"
    },
    "slots": 1
  },
  {
    "id": "io.prototype-beagle-active-probe.is",
    "name": "Prototype Beagle Active Probe [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 2,
    "cost": 600000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2560
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-X-X",
      "rawMass": "2",
      "rawCost": "600,000",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 3
  },
  {
    "id": "io.prototype-case.is",
    "name": "Prototype CASE [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 150000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2452
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-X-X",
      "rawMass": ".5",
      "rawCost": "150,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "0",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": ".5"
    },
    "slots": 1
  },
  {
    "id": "io.prototype-direct-neural-interface.is",
    "name": "Prototype Direct Neural Interface [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 2500000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3052
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "*",
      "rawCost": "2,500,000",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "io.prototype-double-heat-sink.is",
    "name": "Prototype Double Heat Sink [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 18000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2559
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-X-X",
      "rawMass": "1*",
      "rawCost": "18,000",
      "slotsBattleMech": "3*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "0*",
      "slotsSmallCraft": "0*",
      "slotsDropShip": "0*",
      "slotsJumpShip": "0*",
      "slotsWarShip": "0*",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 3
  },
  {
    "id": "io.prototype-double-heat-sink.is.2",
    "name": "Prototype Double Heat Sink [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 30000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3022
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-F-X",
      "rawMass": "1*",
      "rawCost": "30,000",
      "slotsBattleMech": "3*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "0*",
      "slotsSmallCraft": "0*",
      "slotsDropShip": "0*",
      "slotsJumpShip": "0*",
      "slotsWarShip": "0*",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 3
  },
  {
    "id": "io.prototype-endo-steel-structure.is",
    "name": "Prototype Endo Steel Structure [IS]",
    "categories": [
      "equipment"
    ],
    "mass": {
      "op": "divide",
      "args": [
        {
          "var": "unit.mass"
        },
        20.0
      ]
    },
    "cost": {
      "op": "multiply",
      "args": [
        4800.0,
        {
          "var": "unit.mass"
        }
      ]
    },
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2471
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-X-X",
      "rawMass": "TT÷20",
      "rawCost": "4,800xTT",
      "slotsBattleMech": "16",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 16
  },
  {
    "id": "io.prototype-endo-steel-structure.is.2",
    "name": "Prototype Endo Steel Structure [IS]",
    "categories": [
      "equipment"
    ],
    "mass": {
      "op": "divide",
      "args": [
        {
          "var": "unit.mass"
        },
        20.0
      ]
    },
    "cost": {
      "op": "multiply",
      "args": [
        4800.0,
        {
          "var": "unit.mass"
        }
      ]
    },
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3035
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-F-X",
      "rawMass": "TT÷20",
      "rawCost": "4,800xTT",
      "slotsBattleMech": "16",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 16
  },
  {
    "id": "io.prototype-er-large-laser.is",
    "name": "Prototype ER Large Laser [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 5,
    "cost": 600000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3030
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-F-X",
      "rawMass": "5",
      "rawCost": "600,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 2
  },
  {
    "id": "io.prototype-er-medium-laser.clan",
    "name": "Prototype ER Medium Laser [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 1.5,
    "cost": 80000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2819
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-D-X",
      "rawMass": "1.5",
      "rawCost": "80,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 1
  },
  {
    "id": "io.prototype-er-small-laser.clan",
    "name": "Prototype ER Small Laser [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0.5,
    "cost": 11250,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2819
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-D-X",
      "rawMass": "0.5",
      "rawCost": "11,250",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 1
  },
  {
    "id": "io.prototype-extralight-engine.is",
    "name": "Prototype Extralight Engine [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2556
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-X-X",
      "rawMass": "*",
      "rawCost": "(100,000xERxTT)÷75",
      "slotsBattleMech": "+6*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "2",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "+0",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "(100,000xERxTT)÷75"
    },
    "slots": 6
  },
  {
    "id": "io.prototype-ferro-fibrous-armor.is",
    "name": "Prototype Ferro-Fibrous Armor [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2557
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-X-X",
      "rawMass": "*",
      "rawCost": "60,000xAT",
      "slotsBattleMech": "16",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "3",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "3*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "60,000xAT"
    },
    "slots": 16
  },
  {
    "id": "io.prototype-ferro-fibrous-armor.is.2",
    "name": "Prototype Ferro-Fibrous Armor [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3034
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-F-X",
      "rawMass": "*",
      "rawCost": "60,000xAT",
      "slotsBattleMech": "16",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "3",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "3*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "60,000xAT"
    },
    "slots": 16
  },
  {
    "id": "io.prototype-gauss-rifle.is",
    "name": "Prototype Gauss Rifle [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 15,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2587
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-X-X",
      "rawMass": "15",
      "rawCost": "1,200,000 / 80,000",
      "slotsBattleMech": "8",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "8",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "1,200,000 / 80,000"
    },
    "slots": 8
  },
  {
    "id": "io.prototype-gauss-rifle.is.2",
    "name": "Prototype Gauss Rifle [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 15,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3038
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-F-X",
      "rawMass": "15",
      "rawCost": "1,200,000 / 80,000",
      "slotsBattleMech": "8",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "8",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "1,200,000 / 80,000"
    },
    "slots": 8
  },
  {
    "id": "io.prototype-guardian-ecm-suite.is",
    "name": "Prototype Guardian ECM Suite [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 2,
    "cost": 1000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2595
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-X-X",
      "rawMass": "2",
      "rawCost": "1,000,000",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1"
    },
    "slots": 3
  },
  {
    "id": "io.prototype-large-pulse-laser.is",
    "name": "Prototype Large Pulse Laser [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 7,
    "cost": 875000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2595
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-X-X",
      "rawMass": "7",
      "rawCost": "875,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 2
  },
  {
    "id": "io.prototype-lb-10-x-autocannon.is",
    "name": "Prototype LB 10-X Autocannon [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 11,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2590
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-X-X",
      "rawMass": "11",
      "rawCost": "1,600,000 / 80,000",
      "slotsBattleMech": "7",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "7",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "1,600,000 / 80,000"
    },
    "slots": 7
  },
  {
    "id": "io.prototype-lb-10-x-autocannon.is.2",
    "name": "Prototype LB 10-X Autocannon [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 11,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3030
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-F-X",
      "rawMass": "11",
      "rawCost": "2,000,000 / 80,000",
      "slotsBattleMech": "7",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "7",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "2,000,000 / 80,000"
    },
    "slots": 7
  },
  {
    "id": "io.prototype-lb-2-x-autocannon.clan",
    "name": "Prototype LB 2-X Autocannon [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 6,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2820
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-D-X",
      "rawMass": "6",
      "rawCost": "150,000 / 3,300",
      "slotsBattleMech": "5",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "5",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "150,000 / 3,300"
    },
    "slots": 5
  },
  {
    "id": "io.prototype-lb-20-x-autocannon.clan",
    "name": "Prototype LB 20-X Autocannon [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 14,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2820
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-D-X",
      "rawMass": "14",
      "rawCost": "600,000 / 34,000",
      "slotsBattleMech": "12",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "12",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "600,000 / 34,000"
    },
    "slots": 12
  },
  {
    "id": "io.prototype-lb-5-x-autocannon.clan",
    "name": "Prototype LB 5-X Autocannon [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 8,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2820
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-D-X",
      "rawMass": "8",
      "rawCost": "250,000 / 15,000",
      "slotsBattleMech": "6",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "6",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "250,000 / 15,000"
    },
    "slots": 6
  },
  {
    "id": "io.prototype-medium-pulse-laser.is",
    "name": "Prototype Medium Pulse Laser [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 2,
    "cost": 300000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2595
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-X-X",
      "rawMass": "2",
      "rawCost": "300,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 1
  },
  {
    "id": "io.prototype-medium-pulse-laser.is.2",
    "name": "Prototype Medium Pulse Laser [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 2,
    "cost": 240000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3031
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-F-X",
      "rawMass": "2",
      "rawCost": "240,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 1
  },
  {
    "id": "io.prototype-narc-missile-beacon.is",
    "name": "Prototype Narc Missile Beacon [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 3,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2580
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-X-X",
      "rawMass": "3",
      "rawCost": "300,000 / 18,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "300,000 / 18,000"
    },
    "slots": 2
  },
  {
    "id": "io.prototype-remote-sensors.is",
    "name": "Prototype Remote Sensors [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2586
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-X-X",
      "rawMass": ".5",
      "rawCost": "60,000 / 42,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualMassFormula": ".5",
      "manualCostFormula": "60,000 / 42,000"
    },
    "slots": 1
  },
  {
    "id": "io.prototype-rocket-launcher-10.is-clan",
    "name": "Prototype Rocket Launcher 10",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 15000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2320
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "B/D-F-X",
      "rawMass": ".5",
      "rawCost": "15,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualMassFormula": ".5"
    },
    "slots": 1
  },
  {
    "id": "io.prototype-rocket-launcher-15.is-clan",
    "name": "Prototype Rocket Launcher 15",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 30000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2320
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "B/D-F-X",
      "rawMass": "1",
      "rawCost": "30,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 2
  },
  {
    "id": "io.prototype-rocket-launcher-20.is-clan",
    "name": "Prototype Rocket Launcher 20",
    "categories": [
      "equipment"
    ],
    "mass": 1.5,
    "cost": 45000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2320
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "B/D-F-X",
      "rawMass": "1.5",
      "rawCost": "45,000",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 3
  },
  {
    "id": "io.prototype-small-pulse-laser.is",
    "name": "Prototype Small Pulse Laser [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 80000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2595
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-X-X",
      "rawMass": "1",
      "rawCost": "80,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 1
  },
  {
    "id": "io.prototype-streak-srm-4.clan",
    "name": "Prototype Streak SRM 4 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 3,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2819
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-D-X",
      "rawMass": "3",
      "rawCost": "90,000 / 54,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "90,000 / 54,000"
    },
    "slots": 2
  },
  {
    "id": "io.prototype-streak-srm-6.clan",
    "name": "Prototype Streak SRM 6 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 4.5,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2819
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-D-X",
      "rawMass": "4.5",
      "rawCost": "120,000 / 54,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "120,000 / 54,000"
    },
    "slots": 2
  },
  {
    "id": "io.prototype-tag.is",
    "name": "Prototype TAG [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 1.5,
    "cost": 150000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2593
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-X-X",
      "rawMass": "1.5",
      "rawCost": "150,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 1
  },
  {
    "id": "io.prototype-triple-strength-myomer.is",
    "name": "Prototype Triple-Strength Myomer [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": {
      "op": "multiply",
      "args": [
        32000.0,
        {
          "var": "unit.mass"
        }
      ]
    },
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3028
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-F-X",
      "rawMass": "0",
      "rawCost": "32,000xTT",
      "slotsBattleMech": "6",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 6
  },
  {
    "id": "io.prototype-ultra-autocannon-10.clan",
    "name": "Prototype Ultra Autocannon/10 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 13,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2820
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-D-X",
      "rawMass": "13",
      "rawCost": "320,000 / 12,000",
      "slotsBattleMech": "8",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "8",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "320,000 / 12,000"
    },
    "slots": 8
  },
  {
    "id": "io.prototype-ultra-autocannon-2.clan",
    "name": "Prototype Ultra Autocannon/2 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 7,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2820
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-D-X",
      "rawMass": "7",
      "rawCost": "120,000 / 1,000",
      "slotsBattleMech": "4",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "4",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "120,000 / 1,000"
    },
    "slots": 4
  },
  {
    "id": "io.prototype-ultra-autocannon-20.clan",
    "name": "Prototype Ultra Autocannon/20 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 15,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2820
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-D-X",
      "rawMass": "15",
      "rawCost": "480,000 / 20,000",
      "slotsBattleMech": "11",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "11",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "480,000 / 20,000"
    },
    "slots": 11
  },
  {
    "id": "io.prototype-ultra-autocannon-5.is",
    "name": "Prototype Ultra Autocannon/5 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 7,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3029
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-F-X",
      "rawMass": "7",
      "rawCost": "1,000,000 / 45,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "1,000,000 / 45,000"
    },
    "slots": 2
  },
  {
    "id": "io.quadruped-protomech-structure.clan",
    "name": "Quadruped ProtoMech Structure [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": {
      "op": "multiply",
      "args": [
        {
          "var": "unit.mass"
        },
        0.1
      ]
    },
    "cost": {
      "op": "multiply",
      "args": [
        500.0,
        {
          "var": "unit.mass"
        }
      ]
    },
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3083
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "D/X-X-E",
      "rawMass": "TTx0.1",
      "rawCost": "500xTT",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "0",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    }
  },
  {
    "id": "io.quadvee-cockpit.clan",
    "name": "QuadVee Cockpit [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 4,
    "cost": 375000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3135
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-X-F",
      "rawMass": "4*",
      "rawCost": "375,000",
      "slotsBattleMech": "6*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 6
  },
  {
    "id": "io.quadvee-conversion.clan",
    "name": "QuadVee Conversion [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3135
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-X-F",
      "rawMass": "TTx0.1*",
      "rawCost": "WSCx0.5",
      "slotsBattleMech": "4*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "TTx0.1*",
      "manualCostFormula": "WSCx0.5"
    },
    "slots": 4
  },
  {
    "id": "io.quadvee-wheels.clan",
    "name": "QuadVee Wheels [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3150
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-X-F",
      "rawMass": "TTx0.15*",
      "rawCost": "(750xERxTT)÷75",
      "slotsBattleMech": "4*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "TTx0.15*",
      "manualCostFormula": "(750xERxTT)÷75"
    },
    "slots": 4
  },
  {
    "id": "io.radical-heat-sink-system.is",
    "name": "Radical Heat Sink System [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 4,
    "cost": 250000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3122
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-X-E",
      "rawMass": "4*",
      "rawCost": "250,000",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "1",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 3
  },
  {
    "id": "toaue.reactive-clan.clan",
    "name": "Reactive (Clan) [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3065
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "*",
      "rawCost": "30,000xAT",
      "slotsBattleMech": "7",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "2*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "30,000xAT"
    },
    "slots": 7
  },
  {
    "id": "toaue.reactive-is.is",
    "name": "Reactive (IS) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3063
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "*",
      "rawCost": "30,000xAT",
      "slotsBattleMech": "14",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "2",
      "slotsSupportVehicle": "2*",
      "slotsFighter": "3*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "30,000xAT"
    },
    "slots": 14
  },
  {
    "id": "toaue.recon-camera.is-clan",
    "name": "Recon Camera",
    "categories": [
      "equipment"
    ],
    "mass": 0.5,
    "cost": 10000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/B-B-B",
      "rawMass": "0.5",
      "rawCost": "10,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 1
  },
  {
    "id": "tm.refueling-drogue.is-clan",
    "name": "Refueling Drogue",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "1",
      "rawCost": "25,000",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "PHYS (Same)",
      "ammoPerTon": "Var*",
      "ref": "247",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "1*",
      "slotsSmallCraft": "1*",
      "slotsDropShip": "NA"
    }
  },
  {
    "id": "toaue.reinforced.is-clan",
    "name": "Reinforced",
    "categories": [
      "equipment"
    ],
    "mass": {
      "op": "divide",
      "args": [
        {
          "var": "unit.mass"
        },
        5.0
      ]
    },
    "cost": {
      "op": "multiply",
      "args": [
        6400.0,
        {
          "var": "unit.mass"
        }
      ]
    },
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3057
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-E",
      "rawMass": "TT÷5",
      "rawCost": "6,400xTT",
      "slotsBattleMech": "0",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 0
  },
  {
    "id": "toaue.reinforced-unpressurized.is",
    "name": "Reinforced (Unpressurized) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3065
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/F-X-F",
      "rawMass": "0.010xC",
      "rawCost": "30,000xC",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "0*",
      "slotsWarShip": "0*",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "0.010xC",
      "manualCostFormula": "30,000xC"
    }
  },
  {
    "id": "io.remote-drone-command-console.is",
    "name": "Remote Drone Command Console [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 2,
    "cost": 50000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3140
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-X-F",
      "rawMass": "2",
      "rawCost": "50,000",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "1",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 1
  },
  {
    "id": "tm.remote-sensor-disp.is-clan",
    "name": "Remote Sensor Disp.",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "0.5",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "0/0/0/0 (Same)",
      "ammoPerTon": "60",
      "ref": "236",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    },
    "slots": 1
  },
  {
    "id": "tm.retractable-blade.is-clan",
    "name": "Retractable Blade",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "Var*",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "0 (NA)",
      "damage": "** (NA)",
      "range": "PHYS (NA)",
      "ammoPerTon": "NA",
      "ref": "236",
      "slotsBattleMech": "Var*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "manualMassFormula": "Var*",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    }
  },
  {
    "id": "toaue.reusable-vdc.is-clan",
    "name": "Reusable VDC",
    "categories": [
      "equipment"
    ],
    "mass": 0.5,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2353
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/F-F-E",
      "rawMass": "+0.5**",
      "rawCost": "2xIC",
      "slotsBattleMech": "2**",
      "slotsProtoMech": "1**",
      "slotsCombatVehicle": "1**",
      "slotsSupportVehicle": "2**",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualCostFormula": "2xIC"
    },
    "slots": 2
  },
  {
    "id": "io.risc-advanced-pds-battlesuit.is",
    "name": "RISC Advanced PDS (Battlesuit) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0.35,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3134
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-X-E",
      "rawMass": "0.35",
      "rawCost": "50,000 / 500",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualCostFormula": "50,000 / 500"
    }
  },
  {
    "id": "io.risc-advanced-pds-standard.is",
    "name": "RISC Advanced PDS (Standard) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 3,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3137
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-X-E",
      "rawMass": "3",
      "rawCost": "200,000 / 2,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1",
      "manualCostFormula": "200,000 / 2,000"
    },
    "slots": 2
  },
  {
    "id": "io.risc-emergency-coolant-system.is",
    "name": "RISC Emergency Coolant System [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 2,
    "cost": 460000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3136
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-X-F",
      "rawMass": "2",
      "rawCost": "460,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 1
  },
  {
    "id": "io.risc-heat-sink-override-kit.is",
    "name": "RISC Heat Sink Override Kit [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 500,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3134
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "D/X-X-X-F",
      "rawMass": "0",
      "rawCost": "500",
      "slotsBattleMech": "0",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 0
  },
  {
    "id": "io.risc-hyper-laser.is",
    "name": "RISC Hyper Laser [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 8,
    "cost": 750000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3134
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-X-F",
      "rawMass": "8",
      "rawCost": "750,000",
      "slotsBattleMech": "6",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "6",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 6
  },
  {
    "id": "io.risc-laser-pulse-module.is",
    "name": "RISC Laser Pulse Module [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 200000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3137
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-X-F",
      "rawMass": "1",
      "rawCost": "200,000",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "+0* +0* +1* +0* +0* +0* +0* +0* +0*",
      "slotsCombatVehicle": "+0*",
      "slotsSupportVehicle": "RISC Emergency Coolant System",
      "slotsFighter": "IS",
      "slotsSmallCraft": "F/X-X-X-F",
      "slotsDropShip": "3136P / NA",
      "slotsJumpShip": "460,000",
      "slotsWarShip": "2",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "NA"
    },
    "slots": 1
  },
  {
    "id": "io.risc-repeating-tsemp-cannon.is",
    "name": "RISC Repeating TSEMP Cannon [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 8,
    "cost": 1200000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3133
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-X-F",
      "rawMass": "8",
      "rawCost": "1,200,000",
      "slotsBattleMech": "7",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "7",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1"
    },
    "slots": 7
  },
  {
    "id": "io.risc-super-cooled-myomer.is",
    "name": "RISC Super-Cooled Myomer [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": {
      "op": "multiply",
      "args": [
        10000.0,
        {
          "var": "unit.mass"
        }
      ]
    },
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3132
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-X-F",
      "rawMass": "0",
      "rawCost": "10,000xTT",
      "slotsBattleMech": "6*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 6
  },
  {
    "id": "io.risc-viral-jammer-decoy.is",
    "name": "RISC Viral Jammer (Decoy) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 2.5,
    "cost": 990000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3135
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-X-F",
      "rawMass": "2.5",
      "rawCost": "990,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1"
    },
    "slots": 1
  },
  {
    "id": "io.risc-viral-jammer-homing.is",
    "name": "RISC Viral Jammer (Homing) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 2.5,
    "cost": 990000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3135
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-X-F",
      "rawMass": "2.5",
      "rawCost": "990,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.rock-cutter.is-clan",
    "name": "Rock-Cutter",
    "categories": [
      "weapon"
    ],
    "mass": 5,
    "cost": 100000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "5",
      "rawCost": "100,000",
      "heat": "0 (NA)",
      "damage": "5 (NA)",
      "range": "PHYS (NA)",
      "ammoPerTon": "NA",
      "ref": "247",
      "slotsBattleMech": "5",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 5
  },
  {
    "id": "tm.rocket-launcher-10.is",
    "name": "Rocket Launcher 10 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 15000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3064
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "0.5",
      "rawCost": "15,000",
      "heat": "3 (3)",
      "damage": "1/Msl (6)",
      "range": "0/5/11/18 (Medium)",
      "ammoPerTon": "OS",
      "ref": "229",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.rocket-launcher-15.is",
    "name": "Rocket Launcher 15 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 30000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3064
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "1",
      "rawCost": "30,000",
      "heat": "4 (4)",
      "damage": "1/Msl (9)",
      "range": "0/4/9/15 (Medium)",
      "ammoPerTon": "OS",
      "ref": "229",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 2
  },
  {
    "id": "tm.rocket-launcher-20.is",
    "name": "Rocket Launcher 20 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 1.5,
    "cost": 45000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3064
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "1.5",
      "rawCost": "45,000",
      "heat": "5 (5)",
      "damage": "1/Msl (12)",
      "range": "0/3/7/12 (Medium)",
      "ammoPerTon": "OS",
      "ref": "229",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 3
  },
  {
    "id": "toaue.rotary-ac-2-clan.clan",
    "name": "Rotary AC/2 (Clan) [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 8,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3073
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "8",
      "rawCost": "175,000 / 3,000",
      "slotsBattleMech": "4",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "4",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "manualCostFormula": "175,000 / 3,000"
    },
    "slots": 4
  },
  {
    "id": "tm.rotary-ac-2.is",
    "name": "Rotary AC/2 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 8,
    "cost": 175000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3062
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "8",
      "rawCost": "175,000",
      "heat": "1/Shot (6)",
      "damage": "2/Shot (8)",
      "range": "0/6/12/18 (Medium)",
      "ammoPerTon": "45",
      "ref": "207",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 3
  },
  {
    "id": "toaue.rotary-ac-5-clan.clan",
    "name": "Rotary AC/5 (Clan) [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 10,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3073
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "10",
      "rawCost": "275,000 / 12,000",
      "slotsBattleMech": "8",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "8",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "275,000 / 12,000"
    },
    "slots": 8
  },
  {
    "id": "tm.rotary-ac-5.is",
    "name": "Rotary AC/5 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 10,
    "cost": 275000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3062
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "10",
      "rawCost": "275,000",
      "heat": "1/Shot (6)",
      "damage": "5/Shot (20)",
      "range": "0/5/10/15 (Medium)",
      "ammoPerTon": "20",
      "ref": "207",
      "slotsBattleMech": "6",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "6",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 6
  },
  {
    "id": "tm.salvage-arm.is-clan",
    "name": "Salvage Arm",
    "categories": [
      "weapon"
    ],
    "mass": 3,
    "cost": 50000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2452
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "D",
      "rawMass": "3",
      "rawCost": "50,000",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "PHYS (NA)",
      "ammoPerTon": "NA",
      "ref": "248",
      "slotsBattleMech": "2*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 2
  },
  {
    "id": "toaue.scl-1.is",
    "name": "SCL/1 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 150,
    "cost": 220000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3073
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "150",
      "rawCost": "220,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "20",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1-C*",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*",
      "slotsMobileStructure": "1"
    }
  },
  {
    "id": "toaue.scl-2.is",
    "name": "SCL/2 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 200,
    "cost": 335000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3073
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "200",
      "rawCost": "335,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "26",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1-C*",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*"
    }
  },
  {
    "id": "toaue.scl-3.is",
    "name": "SCL/3 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 250,
    "cost": 450000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3073
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "250",
      "rawCost": "450,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "32",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1-C*",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*",
      "slotsMobileStructure": "1"
    }
  },
  {
    "id": "tm.screen-launcher.is",
    "name": "Screen Launcher [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 40,
    "cost": 250000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3055
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "40",
      "rawCost": "250,000",
      "heat": "NA (10)",
      "damage": "NA (**)",
      "range": "NA (Short)",
      "ammoPerTon": "10 t/Msl",
      "ref": "237",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    }
  },
  {
    "id": "io.sds-caspar-drone-control-system.is",
    "name": "SDS (Caspar) Drone Control System [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2695
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/E-X-X",
      "rawMass": "Var*",
      "rawCost": "500,000+(50,000xIT)*",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "0*",
      "slotsDropShip": "0*",
      "slotsJumpShip": "NA",
      "slotsWarShip": "0*",
      "slotsSpaceStation": "0*",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "Var*",
      "manualCostFormula": "500,000+(50,000xIT)*"
    }
  },
  {
    "id": "io.sds-jammer-system.is",
    "name": "SDS Jammer System [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 30000,
    "cost": 800000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2776
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-F-X",
      "rawMass": "30,000",
      "rawCost": "800M",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "1*",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    }
  },
  {
    "id": "io.sds-self-destruct-system.is",
    "name": "SDS Self-Destruct System [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 1000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2695
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/D-F-X",
      "rawMass": "Var*",
      "rawCost": "1,000,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "0*",
      "slotsDropShip": "0*",
      "slotsJumpShip": "NA",
      "slotsWarShip": "0*",
      "slotsSpaceStation": "0*",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "Var*"
    }
  },
  {
    "id": "tm.seating-pillion.is-clan",
    "name": "Seating (Pillion)",
    "categories": [
      "weapon"
    ],
    "mass": 0.025,
    "cost": 100,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "0.025",
      "rawCost": "100",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "236",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "0*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    }
  },
  {
    "id": "tm.seating-standard.is-clan",
    "name": "Seating (Standard)",
    "categories": [
      "weapon"
    ],
    "mass": 0.075,
    "cost": 100,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "0.075",
      "rawCost": "100",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "236",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "0*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    }
  },
  {
    "id": "io.sensory-implants-ir-em-audio.is-clan",
    "name": "Sensory Implants (IR/EM/Audio)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 650000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2610
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/E-F-C",
      "rawMass": "*",
      "rawCost": "650,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "io.sensory-implants-laser-telescopic.is-clan",
    "name": "Sensory Implants (Laser/Telescopic)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 600000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2610
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/D-E-C",
      "rawMass": "*",
      "rawCost": "600,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "toaue.shield-large.is",
    "name": "Shield, Large [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 6,
    "cost": 300000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3067
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-X-F",
      "rawMass": "6",
      "rawCost": "300,000",
      "slotsBattleMech": "7*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 7
  },
  {
    "id": "toaue.shield-medium.is",
    "name": "Shield, Medium [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 4,
    "cost": 100000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3067
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-X-F",
      "rawMass": "4",
      "rawCost": "100,000",
      "slotsBattleMech": "5*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    },
    "slots": 5
  },
  {
    "id": "toaue.shield-small.is",
    "name": "Shield, Small [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 2,
    "cost": 50000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3067
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-X-F",
      "rawMass": "2",
      "rawCost": "50,000",
      "slotsBattleMech": "3*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 3
  },
  {
    "id": "io.shielded-aerospace-srcs.is-clan",
    "name": "Shielded Aerospace SRCS",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2755
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/E-X-F",
      "rawMass": "Var*",
      "rawCost": "6,250+(12,500xIT)*",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "0*",
      "slotsFighter": "0*",
      "slotsSmallCraft": "0*",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "0*",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "Var*",
      "manualCostFormula": "6,250+(12,500xIT)*"
    }
  },
  {
    "id": "toaue.silver-bullet-gauss.is",
    "name": "Silver Bullet Gauss [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 15,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3051
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "15",
      "rawCost": "350,000 / 25,000",
      "slotsBattleMech": "7",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "7",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "350,000 / 25,000"
    },
    "slots": 7
  },
  {
    "id": "io.sldf-advanced-neurohelmet.is",
    "name": "SLDF Advanced Neurohelmet [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 5000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2760
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/F-X-X",
      "rawMass": "0*",
      "rawCost": "5,000*",
      "slotsBattleMech": "0*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "0*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 0
  },
  {
    "id": "toaue.small-aerospace-cockpit.is",
    "name": "Small Aerospace Cockpit [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 2,
    "cost": 175000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3070
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-E",
      "rawMass": "2*",
      "rawCost": "175,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "0*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    }
  },
  {
    "id": "tm.small-craft-cub.is-clan",
    "name": "Small Craft (Cub.)",
    "categories": [
      "weapon"
    ],
    "mass": 200,
    "cost": 20000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2050
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "200",
      "rawCost": "20,000",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "239",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1**",
      "slotsSupportVehicle": "1**",
      "slotsFighter": "NA",
      "slotsSmallCraft": "0",
      "slotsDropShip": "0"
    }
  },
  {
    "id": "tm.small-laser.is",
    "name": "Small Laser [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 11250,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2400
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "0.5",
      "rawCost": "11,250",
      "heat": "1 (1)",
      "damage": "3 (3)",
      "range": "0/1/2/3 (Short)",
      "ammoPerTon": "NA",
      "ref": "227",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "toaue.small-ncss.is-clan",
    "name": "Small NCSS",
    "categories": [
      "equipment"
    ],
    "mass": 100,
    "cost": 50000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2200
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/D-E-E",
      "rawMass": "100",
      "rawCost": "50,000,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "0*",
      "slotsDropShip": "0*",
      "slotsJumpShip": "0*",
      "slotsWarShip": "0*",
      "slotsSpaceStation": "0*"
    }
  },
  {
    "id": "tm.small-pulse-laser.clan",
    "name": "Small Pulse Laser [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 16000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "1",
      "rawCost": "16,000",
      "heat": "2 (2)",
      "damage": "3 (3)",
      "range": "0/2/4/6 (Short)",
      "ammoPerTon": "NA",
      "ref": "226",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.small-pulse-laser.is",
    "name": "Small Pulse Laser [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 16000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2609
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "1",
      "rawCost": "16,000",
      "heat": "2 (2)",
      "damage": "3 (3)",
      "range": "0/1/2/3 (Short)",
      "ammoPerTon": "NA",
      "ref": "226",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "io.small-re-engineered-laser.is",
    "name": "Small Re-Engineered Laser [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 1.5,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3130
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-X-E",
      "rawMass": "1.5",
      "rawCost": "25,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 1
  },
  {
    "id": "io.smart-robotic-control-system.is-clan",
    "name": "Smart Robotic Control System",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3067
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/E-X-F",
      "rawMass": "Var*",
      "rawCost": "5,000+(10,000xIT)*",
      "slotsBattleMech": "0*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "0*",
      "slotsSupportVehicle": "0*",
      "slotsFighter": "0*",
      "slotsSmallCraft": "0*",
      "slotsDropShip": "0*",
      "slotsJumpShip": "0*",
      "slotsWarShip": "0*",
      "slotsSpaceStation": "0*",
      "slotsMobileStructure": "0*",
      "manualMassFormula": "Var*",
      "manualCostFormula": "5,000+(10,000xIT)*"
    },
    "slots": 0
  },
  {
    "id": "toaue.sniper.is-clan",
    "name": "Sniper",
    "categories": [
      "equipment"
    ],
    "mass": 20,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/C-C-C",
      "rawMass": "20",
      "rawCost": "300,000 / 6,000",
      "slotsBattleMech": "20",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "10",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1",
      "manualCostFormula": "300,000 / 6,000"
    },
    "slots": 20
  },
  {
    "id": "toaue.sniper.is-clan.2",
    "name": "Sniper",
    "categories": [
      "equipment"
    ],
    "mass": 15,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3012
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/X-F-E",
      "rawMass": "15",
      "rawCost": "475,000 / 15,000",
      "slotsBattleMech": "10",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "10",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "475,000 / 15,000"
    },
    "slots": 10
  },
  {
    "id": "tm.snub-nose-ppc.is",
    "name": "Snub-Nose PPC [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 6,
    "cost": 300000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3067
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "6",
      "rawCost": "300,000",
      "heat": "10 (10)",
      "damage": "10/8/5 (10/8)",
      "range": "0/9/13/15 (Medium)",
      "ammoPerTon": "NA",
      "ref": "234",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 2
  },
  {
    "id": "toaue.space.is-clan",
    "name": "Space",
    "categories": [
      "equipment"
    ],
    "mass": 10,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/E-F-E",
      "rawMass": "10",
      "rawCost": "15,000 / 15,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "1*",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "manualCostFormula": "15,000 / 15,000"
    }
  },
  {
    "id": "io.space-station-k-f-adapter.is-clan",
    "name": "Space Station K-F Adapter",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2375
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/D-F-D",
      "rawMass": "0",
      "rawCost": "FCx20",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "0",
      "slotsMobileStructure": "NA",
      "manualCostFormula": "FCx20"
    }
  },
  {
    "id": "io.special-munitions-anti-tsm-lrms.is",
    "name": "Special Munitions: Anti-TSM LRMs [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3027
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-F-F",
      "rawMass": "*",
      "rawCost": "x2",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "*",
      "slotsSmallCraft": "*",
      "slotsDropShip": "*",
      "slotsJumpShip": "*",
      "slotsWarShip": "*",
      "slotsSpaceStation": "*",
      "slotsMobileStructure": "*",
      "manualMassFormula": "*",
      "manualCostFormula": "x2"
    }
  },
  {
    "id": "io.special-munitions-anti-tsm-srms.is",
    "name": "Special Munitions: Anti-TSM SRMs [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3027
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-F-F",
      "rawMass": "*",
      "rawCost": "x2",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "*",
      "slotsSmallCraft": "*",
      "slotsDropShip": "*",
      "slotsJumpShip": "*",
      "slotsWarShip": "*",
      "slotsSpaceStation": "*",
      "slotsMobileStructure": "*",
      "manualMassFormula": "*",
      "manualCostFormula": "x2"
    }
  },
  {
    "id": "io.special-munitions-dead-fire-lrms.is",
    "name": "Special Munitions: Dead-Fire LRMs [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3052
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/X-X-E",
      "rawMass": "*",
      "rawCost": "x0.6",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "*",
      "slotsSmallCraft": "*",
      "slotsDropShip": "*",
      "slotsJumpShip": "*",
      "slotsWarShip": "*",
      "slotsSpaceStation": "*",
      "slotsMobileStructure": "*",
      "manualMassFormula": "*",
      "manualCostFormula": "x0.6"
    }
  },
  {
    "id": "io.special-munitions-dead-fire-srms.is",
    "name": "Special Munitions: Dead-Fire SRMs [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3052
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "C/X-X-E",
      "rawMass": "*",
      "rawCost": "x0.6",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "*",
      "slotsSmallCraft": "*",
      "slotsDropShip": "*",
      "slotsJumpShip": "*",
      "slotsWarShip": "*",
      "slotsSpaceStation": "*",
      "slotsMobileStructure": "*",
      "manualMassFormula": "*",
      "manualCostFormula": "x0.6"
    }
  },
  {
    "id": "io.special-munitions-iiw-iatms.clan",
    "name": "Special Munitions: IIW iATMs [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3070
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "*",
      "rawCost": "x1.3",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "*",
      "slotsSmallCraft": "*",
      "slotsDropShip": "*",
      "slotsJumpShip": "*",
      "slotsWarShip": "*",
      "slotsSpaceStation": "*",
      "slotsMobileStructure": "*",
      "manualMassFormula": "*",
      "manualCostFormula": "x1.3"
    }
  },
  {
    "id": "io.special-munitions-imp-iatms.clan",
    "name": "Special Munitions: IMP iATMs [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3070
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "*",
      "rawCost": "x2",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "*",
      "slotsSmallCraft": "*",
      "slotsDropShip": "*",
      "slotsJumpShip": "*",
      "slotsWarShip": "*",
      "slotsSpaceStation": "*",
      "slotsMobileStructure": "*",
      "manualMassFormula": "*",
      "manualCostFormula": "x2"
    }
  },
  {
    "id": "io.special-munitions-listen-kill-lrms.is",
    "name": "Special Munitions: Listen-Kill LRMs [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3037
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-F-X",
      "rawMass": "*",
      "rawCost": "x1.1",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "*",
      "slotsSmallCraft": "*",
      "slotsDropShip": "*",
      "slotsJumpShip": "*",
      "slotsWarShip": "*",
      "slotsSpaceStation": "*",
      "slotsMobileStructure": "*",
      "manualMassFormula": "*",
      "manualCostFormula": "x1.1"
    }
  },
  {
    "id": "io.special-munitions-listen-kill-srms.is",
    "name": "Special Munitions: Listen-Kill SRMs [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3037
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-F-X",
      "rawMass": "*",
      "rawCost": "x1.1",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "*",
      "slotsSmallCraft": "*",
      "slotsDropShip": "*",
      "slotsJumpShip": "*",
      "slotsWarShip": "*",
      "slotsSpaceStation": "*",
      "slotsMobileStructure": "*",
      "manualMassFormula": "*",
      "manualCostFormula": "x1.1"
    }
  },
  {
    "id": "io.special-munitions-rs-ssrms.is",
    "name": "Special Munitions: RS SSRMs [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3045
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-F",
      "rawMass": "*",
      "rawCost": "x1.1",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "*",
      "slotsSmallCraft": "*",
      "slotsDropShip": "*",
      "slotsJumpShip": "*",
      "slotsWarShip": "*",
      "slotsSpaceStation": "*",
      "slotsMobileStructure": "*",
      "manualMassFormula": "*",
      "manualCostFormula": "x1.1"
    }
  },
  {
    "id": "io.special-munitions-ss-narcs.is",
    "name": "Special Munitions: SS Narcs [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3046
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-F",
      "rawMass": "*",
      "rawCost": "x1.1",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "*",
      "slotsSmallCraft": "*",
      "slotsDropShip": "*",
      "slotsJumpShip": "*",
      "slotsWarShip": "*",
      "slotsSpaceStation": "*",
      "slotsMobileStructure": "*",
      "manualMassFormula": "*",
      "manualCostFormula": "x1.1"
    }
  },
  {
    "id": "toaue.spikes.is",
    "name": "Spikes [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0.5,
    "cost": {
      "op": "multiply",
      "args": [
        50.0,
        {
          "var": "unit.mass"
        }
      ]
    },
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3051
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/X-E-E",
      "rawMass": "0.5",
      "rawCost": "50xTT",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    },
    "slots": 1
  },
  {
    "id": "toaue.sponson-turret-vehicular.is-clan",
    "name": "Sponson Turret (Vehicular)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/F-F-F",
      "rawMass": "TE÷10‡‡",
      "rawCost": "4,000xIT‡‡",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "0*",
      "slotsSupportVehicle": "0*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualMassFormula": "TE÷10‡‡",
      "manualCostFormula": "4,000xIT‡‡"
    }
  },
  {
    "id": "tm.spot-welder.is-clan",
    "name": "Spot Welder",
    "categories": [
      "weapon"
    ],
    "mass": 2,
    "cost": 75000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2320
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "2",
      "rawCost": "75,000",
      "heat": "2 (NA)",
      "damage": "5 (NA)",
      "range": "PHYS (NA)",
      "ammoPerTon": "NA",
      "ref": "248",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 1
  },
  {
    "id": "tm.srm-2.clan",
    "name": "SRM 2 [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 10000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "0.5",
      "rawCost": "10,000",
      "heat": "2 (2)",
      "damage": "2/Msl (2)",
      "range": "0/3/6/9 (Short)",
      "ammoPerTon": "50",
      "ref": "229",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.srm-2.is",
    "name": "SRM 2 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 10000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2370
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "1",
      "rawCost": "10,000",
      "heat": "2 (2)",
      "damage": "2/Msl (2)",
      "range": "0/3/6/9 (Short)",
      "ammoPerTon": "50",
      "ref": "229",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.srm-4.clan",
    "name": "SRM 4 [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 60000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "1",
      "rawCost": "60,000",
      "heat": "3 (3)",
      "damage": "2/Msl (4)",
      "range": "0/3/6/9 (Short)",
      "ammoPerTon": "25",
      "ref": "229",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.srm-4.is",
    "name": "SRM 4 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 2,
    "cost": 60000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2370
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "2",
      "rawCost": "60,000",
      "heat": "3 (3)",
      "damage": "2/Msl (4)",
      "range": "0/3/6/9 (Short)",
      "ammoPerTon": "25",
      "ref": "229",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.srm-6.clan",
    "name": "SRM 6 [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 1.5,
    "cost": 80000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "1.5",
      "rawCost": "80,000",
      "heat": "4 (4)",
      "damage": "2/Msl (8)",
      "range": "0/3/6/9 (Short)",
      "ammoPerTon": "15",
      "ref": "229",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.srm-6.is",
    "name": "SRM 6 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 3,
    "cost": 80000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2370
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "3",
      "rawCost": "80,000",
      "heat": "4 (4)",
      "damage": "2/Msl (8)",
      "range": "0/3/6/9 (Short)",
      "ammoPerTon": "15",
      "ref": "229",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 2
  },
  {
    "id": "tm.standard.is-clan",
    "name": "Standard",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 25000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "1",
      "rawCost": "25,000",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "PHYS (NA)",
      "ammoPerTon": "10*",
      "ref": "247",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "1*",
      "slotsSmallCraft": "1*",
      "slotsDropShip": "NA"
    },
    "slots": 1
  },
  {
    "id": "toaue.standard-vdc.is-clan",
    "name": "Standard VDC",
    "categories": [
      "equipment"
    ],
    "mass": 2,
    "cost": 1000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2351
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/D-E-B",
      "rawMass": "2*",
      "rawCost": "1,000",
      "slotsBattleMech": "0",
      "slotsProtoMech": "0",
      "slotsCombatVehicle": "0",
      "slotsSupportVehicle": "0",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 0
  },
  {
    "id": "toaue.stealth-vdc.is-clan",
    "name": "Stealth VDC",
    "categories": [
      "equipment"
    ],
    "mass": 2.2,
    "cost": 5000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED",
      "introYear": 2355
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/E-F-D",
      "rawMass": "2.2*",
      "rawCost": "5,000",
      "slotsBattleMech": "0",
      "slotsProtoMech": "0",
      "slotsCombatVehicle": "0",
      "slotsSupportVehicle": "0",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 0
  },
  {
    "id": "tm.steerage.is-clan",
    "name": "Steerage",
    "categories": [
      "weapon"
    ],
    "mass": 5,
    "cost": 5000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "5",
      "rawCost": "5,000",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "236",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "0*",
      "slotsDropShip": "0*"
    }
  },
  {
    "id": "toaue.stingray.is-clan",
    "name": "Stingray",
    "categories": [
      "equipment"
    ],
    "mass": 120,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3072
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "120",
      "rawCost": "85,000 / 19,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "25",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1-C*",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*",
      "manualCostFormula": "85,000 / 19,000"
    }
  },
  {
    "id": "toaue.streak-lrm-protomech-per-tube.clan",
    "name": "Streak LRM (ProtoMech, per tube) [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0.4,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3065
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "0.4",
      "rawCost": "15,000 / 60,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "1*",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualCostFormula": "15,000 / 60,000"
    }
  },
  {
    "id": "toaue.streak-lrm-10.clan",
    "name": "Streak LRM-10 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 5,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3057
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "5",
      "rawCost": "225,000 / 60,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "225,000 / 60,000"
    },
    "slots": 2
  },
  {
    "id": "toaue.streak-lrm-15.clan",
    "name": "Streak LRM-15 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 7,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3057
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "7",
      "rawCost": "400,000 / 60,000",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "manualCostFormula": "400,000 / 60,000"
    },
    "slots": 3
  },
  {
    "id": "toaue.streak-lrm-20.clan",
    "name": "Streak LRM-20 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 10,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3057
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "10",
      "rawCost": "600,000 / 60,000",
      "slotsBattleMech": "5",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "5",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "600,000 / 60,000"
    },
    "slots": 5
  },
  {
    "id": "toaue.streak-lrm-5.clan",
    "name": "Streak LRM-5 [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 2,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3057
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "2",
      "rawCost": "75,000 / 60,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "manualCostFormula": "75,000 / 60,000"
    },
    "slots": 1
  },
  {
    "id": "tm.streak-srm-2.clan",
    "name": "Streak SRM 2 [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 15000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "1",
      "rawCost": "15,000",
      "heat": "2 (2)",
      "damage": "2/Msl (4)",
      "range": "0/4/8/12 (Medium)",
      "ammoPerTon": "50",
      "ref": "230",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.streak-srm-2.is",
    "name": "Streak SRM 2 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 1.5,
    "cost": 15000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2647
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "1.5",
      "rawCost": "15,000",
      "heat": "2 (2)",
      "damage": "2/Msl (4)",
      "range": "0/3/6/9 (Short)",
      "ammoPerTon": "50",
      "ref": "230",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.streak-srm-4.clan",
    "name": "Streak SRM 4 [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 2,
    "cost": 90000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2826
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "2",
      "rawCost": "90,000",
      "heat": "3 (3)",
      "damage": "2/Msl (8)",
      "range": "0/4/8/12 (Medium)",
      "ammoPerTon": "25",
      "ref": "230",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.streak-srm-4.is",
    "name": "Streak SRM 4 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 3,
    "cost": 90000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3058
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "3",
      "rawCost": "90,000",
      "heat": "3 (3)",
      "damage": "2/Msl (8)",
      "range": "0/3/6/9 (Short)",
      "ammoPerTon": "25",
      "ref": "230",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.streak-srm-6.clan",
    "name": "Streak SRM 6 [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 3,
    "cost": 120000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2826
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "3",
      "rawCost": "120,000",
      "heat": "4 (4)",
      "damage": "2/Msl (12)",
      "range": "0/4/8/12 (Medium)",
      "ammoPerTon": "15",
      "ref": "230",
      "slotsBattleMech": "2",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 2
  },
  {
    "id": "tm.streak-srm-6.is",
    "name": "Streak SRM 6 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 4.5,
    "cost": 120000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3058
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "4.5",
      "rawCost": "120,000",
      "heat": "4 (4)",
      "damage": "2/Msl (12)",
      "range": "0/3/6/9 (Short)",
      "ammoPerTon": "15",
      "ref": "230",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 2
  },
  {
    "id": "toaue.sub-compact-k-f-drive.is-clan",
    "name": "Sub-Compact K-F Drive",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2320
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/F-X-F",
      "rawMass": "TT÷2*",
      "rawCost": "16xKF",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "0*",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "TT÷2*",
      "manualCostFormula": "16xKF"
    }
  },
  {
    "id": "tm.super-hvy-vehicle.is-clan",
    "name": "Super-Hvy. Vehicle",
    "categories": [
      "weapon"
    ],
    "mass": 200,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "200",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "239",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1**",
      "slotsSupportVehicle": "1**",
      "slotsFighter": "NA",
      "slotsSmallCraft": "0",
      "slotsDropShip": "0",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    }
  },
  {
    "id": "toaue.supercharger.is-clan",
    "name": "Supercharger",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/F-F-F",
      "rawMass": "ET÷10",
      "rawCost": "10,000xER§",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualMassFormula": "ET÷10",
      "manualCostFormula": "10,000xER§"
    },
    "slots": 1
  },
  {
    "id": "io.superheavy-battlemech-cockpit.is",
    "name": "Superheavy BattleMech Cockpit [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 4,
    "cost": 300000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3076
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-F",
      "rawMass": "4*",
      "rawCost": "300,000",
      "slotsBattleMech": "5*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 5
  },
  {
    "id": "io.superheavy-industrialmech-cockpit.is",
    "name": "Superheavy IndustrialMech Cockpit [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 4,
    "cost": 200000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2940
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "D/X-F-F",
      "rawMass": "4*",
      "rawCost": "200,000",
      "slotsBattleMech": "5*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 5
  },
  {
    "id": "io.superheavy-tripod-mech-cockpit.is",
    "name": "Superheavy Tripod ’Mech Cockpit [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 5,
    "cost": 500000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2940
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-F-X-F",
      "rawMass": "5*",
      "rawCost": "500,000",
      "slotsBattleMech": "5*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 5
  },
  {
    "id": "io.superheavy-mech-actuators.is",
    "name": "Superheavy ’Mech Actuators [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2940
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "D/X-F-F",
      "rawMass": "*",
      "rawCost": "2 x Standard Cost",
      "slotsBattleMech": "0",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "2 x Standard Cost"
    },
    "slots": 0
  },
  {
    "id": "io.superheavy-mech-endo-comp-i-s.is",
    "name": "Superheavy ’Mech Endo-Comp. I.S. [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": {
      "op": "multiply",
      "args": [
        6400.0,
        {
          "var": "unit.mass"
        }
      ]
    },
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3135
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-F",
      "rawMass": "*",
      "rawCost": "6,400xTT",
      "slotsBattleMech": "14",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    },
    "slots": 14
  },
  {
    "id": "io.superheavy-mech-endo-steel-i-s.is",
    "name": "Superheavy ’Mech Endo-Steel I.S. [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": {
      "op": "multiply",
      "args": [
        16000.0,
        {
          "var": "unit.mass"
        }
      ]
    },
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3076
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-F",
      "rawMass": "*",
      "rawCost": "16,000xTT",
      "slotsBattleMech": "7",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    },
    "slots": 7
  },
  {
    "id": "io.superheavy-mech-gyro.is",
    "name": "Superheavy ’Mech Gyro [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2940
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "D/X-F-F",
      "rawMass": "ER÷50*",
      "rawCost": "500,000xIT",
      "slotsBattleMech": "2*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "ER÷50*",
      "manualCostFormula": "500,000xIT"
    },
    "slots": 2
  },
  {
    "id": "io.superheavy-mech-industrial-i-s.is",
    "name": "Superheavy ’Mech Industrial I.S. [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": {
      "op": "multiply",
      "args": [
        3000.0,
        {
          "var": "unit.mass"
        }
      ]
    },
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2940
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "D/X-F-F",
      "rawMass": "*",
      "rawCost": "3,000xTT",
      "slotsBattleMech": "0",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    },
    "slots": 0
  },
  {
    "id": "io.superheavy-mech-musculature.is",
    "name": "Superheavy ’Mech Musculature [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": {
      "op": "multiply",
      "args": [
        12000.0,
        {
          "var": "unit.mass"
        }
      ]
    },
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2940
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-F-F",
      "rawMass": "*",
      "rawCost": "12,000xTT",
      "slotsBattleMech": "0",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    },
    "slots": 0
  },
  {
    "id": "io.superheavy-mech-standard-i-s.is",
    "name": "Superheavy ’Mech Standard I.S. [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": {
      "op": "multiply",
      "args": [
        4000.0,
        {
          "var": "unit.mass"
        }
      ]
    },
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3076
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-F",
      "rawMass": "*",
      "rawCost": "4,000xTT",
      "slotsBattleMech": "0",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    },
    "slots": 0
  },
  {
    "id": "tm.sword.is",
    "name": "Sword [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 10000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3058
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "Var*",
      "rawCost": "10,000",
      "heat": "0 (NA)",
      "damage": "** (NA)",
      "range": "PHYS (NA)",
      "ammoPerTon": "NA",
      "ref": "237",
      "slotsBattleMech": "Var*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "manualMassFormula": "Var*"
    }
  },
  {
    "id": "toaue.swordfish.is-clan",
    "name": "Swordfish",
    "categories": [
      "equipment"
    ],
    "mass": 140,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3072
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "140",
      "rawCost": "110,000 / 25,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "30",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1-C*",
      "slotsJumpShip": "1-C*",
      "slotsWarShip": "1-C*",
      "slotsSpaceStation": "1-C*",
      "slotsMobileStructure": "1",
      "manualCostFormula": "110,000 / 25,000"
    }
  },
  {
    "id": "tm.tag.clan",
    "name": "TAG [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 50000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "1",
      "rawCost": "50,000",
      "heat": "0 (0)",
      "damage": "**",
      "range": "0/5/9/15 (**)",
      "ammoPerTon": "NA",
      "ref": "238",
      "slotsBattleMech": "1",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.tag.is",
    "name": "TAG [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 1,
    "cost": 50000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2600
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "1",
      "rawCost": "50,000",
      "heat": "0 (0)",
      "damage": "**",
      "range": "0/5/9/15 (**)",
      "ammoPerTon": "NA",
      "ref": "238",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 1
  },
  {
    "id": "toaue.talons.clan",
    "name": "Talons [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": {
      "op": "multiply",
      "args": [
        300.0,
        {
          "var": "unit.mass"
        }
      ]
    },
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3072
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "TT÷15*",
      "rawCost": "300xTT",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "TT÷15*"
    }
  },
  {
    "id": "tm.targeting-computer.clan",
    "name": "Targeting Computer [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 10000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2860
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "Var*",
      "rawCost": "10,000",
      "heat": "0 (0)",
      "damage": "**",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "238",
      "slotsBattleMech": "Var*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "Var*",
      "slotsFighter": "0",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "manualMassFormula": "Var*"
    }
  },
  {
    "id": "tm.targeting-computer.is",
    "name": "Targeting Computer [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 10000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3062
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "Var*",
      "rawCost": "10,000",
      "heat": "0 (0)",
      "damage": "**",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "238",
      "slotsBattleMech": "Var*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "Var*",
      "slotsFighter": "0",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "manualMassFormula": "Var*"
    }
  },
  {
    "id": "toaue.taser-battlemech.is",
    "name": "Taser (BattleMech) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 4,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3067
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "4",
      "rawCost": "200,000 / 2,000",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1",
      "manualCostFormula": "200,000 / 2,000"
    },
    "slots": 3
  },
  {
    "id": "tm.tech.is-clan",
    "name": "Tech",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "Autocannons",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "Base",
      "damage": "Tech",
      "range": "Rating",
      "ammoPerTon": "Ref",
      "ref": "208",
      "slotsBattleMech": "Standard Autocannons",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS",
      "manualMassFormula": "Autocannons",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    }
  },
  {
    "id": "toaue.thumper.is-clan",
    "name": "Thumper",
    "categories": [
      "equipment"
    ],
    "mass": 15,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/C-C-C",
      "rawMass": "15",
      "rawCost": "187,500 / 4,500",
      "slotsBattleMech": "15",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "7",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualCostFormula": "187,500 / 4,500"
    },
    "slots": 15
  },
  {
    "id": "toaue.thumper.is-clan.2",
    "name": "Thumper",
    "categories": [
      "equipment"
    ],
    "mass": 10,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3012
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/X-F-E",
      "rawMass": "10",
      "rawCost": "200,000 / 10,000",
      "slotsBattleMech": "7",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "7",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "manualCostFormula": "200,000 / 10,000"
    },
    "slots": 7
  },
  {
    "id": "toaue.thunderbolt-10.is",
    "name": "Thunderbolt-10 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 7,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3072
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "7",
      "rawCost": "175,000 / 50,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "manualCostFormula": "175,000 / 50,000"
    },
    "slots": 2
  },
  {
    "id": "toaue.thunderbolt-15.is",
    "name": "Thunderbolt-15 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 11,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3072
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "11",
      "rawCost": "325,000 / 50,000",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "325,000 / 50,000"
    },
    "slots": 3
  },
  {
    "id": "toaue.thunderbolt-20.is",
    "name": "Thunderbolt-20 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 15,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3072
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "15",
      "rawCost": "450,000 / 50,000",
      "slotsBattleMech": "5",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "5",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "manualCostFormula": "450,000 / 50,000"
    },
    "slots": 5
  },
  {
    "id": "toaue.thunderbolt-5.is",
    "name": "Thunderbolt-5 [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 3,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3072
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "3",
      "rawCost": "50,000 / 50,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1",
      "manualCostFormula": "50,000 / 50,000"
    },
    "slots": 1
  },
  {
    "id": "toaue.torso-mounted-cockpit.is-clan",
    "name": "Torso-Mounted Cockpit",
    "categories": [
      "equipment"
    ],
    "mass": 4,
    "cost": 750000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3053
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "4*",
      "rawCost": "750,000",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    },
    "slots": 1
  },
  {
    "id": "tm.track.is-clan",
    "name": "Track",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "Var*",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "249",
      "slotsBattleMech": "2*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "manualMassFormula": "Var*",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    },
    "slots": 2
  },
  {
    "id": "io.triple-core-processor-implant.is",
    "name": "Triple-Core Processor Implant [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 3000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3068
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-F",
      "rawMass": "*",
      "rawCost": "3,000,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "io.triple-strength-myomer-implants.is",
    "name": "Triple-Strength Myomer Implants [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 2500000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3060
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-E",
      "rawMass": "*",
      "rawCost": "2,500,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "io.tripod-mech-cockpit.is",
    "name": "Tripod ’Mech Cockpit [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 4,
    "cost": 400000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2602
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/F-F-X-F",
      "rawMass": "4*",
      "rawCost": "400,000",
      "slotsBattleMech": "5*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 5
  },
  {
    "id": "io.tripod-mech-structure.is",
    "name": "Tripod ’Mech Structure [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2602
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/E-F-X-E",
      "rawMass": "STx1.1*",
      "rawCost": "SCx1.2",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "STx1.1*",
      "manualCostFormula": "SCx1.2"
    }
  },
  {
    "id": "io.tsemp-cannon.is",
    "name": "TSEMP Cannon [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 6,
    "cost": 800000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3109
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-X-E",
      "rawMass": "6",
      "rawCost": "800,000",
      "slotsBattleMech": "5",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "5",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1"
    },
    "slots": 5
  },
  {
    "id": "io.tsemp-one-shot.is",
    "name": "TSEMP One-Shot [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 4,
    "cost": 500000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3095
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "E/X-X-X-E",
      "rawMass": "4",
      "rawCost": "500,000",
      "slotsBattleMech": "3",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1"
    },
    "slots": 3
  },
  {
    "id": "tm.turret.is-clan",
    "name": "Turret",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "Var*",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "239",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "0",
      "slotsSupportVehicle": "0",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "manualMassFormula": "Var*",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    }
  },
  {
    "id": "tm.ultra-ac-10.clan",
    "name": "Ultra AC/10 [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 10,
    "cost": 320000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2825
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "10",
      "rawCost": "320,000",
      "heat": "3/Shot (6)",
      "damage": "10/Shot (15)",
      "range": "0/6/12/18 (Medium)",
      "ammoPerTon": "10",
      "ref": "208",
      "slotsBattleMech": "4",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "4",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 4
  },
  {
    "id": "tm.ultra-ac-10.is",
    "name": "Ultra AC/10 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 13,
    "cost": 320000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3057
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "13",
      "rawCost": "320,000",
      "heat": "4/Shot (8)",
      "damage": "10/Shot (15)",
      "range": "0/6/12/18 (Medium)",
      "ammoPerTon": "10",
      "ref": "208",
      "slotsBattleMech": "7",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "7",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 7
  },
  {
    "id": "tm.ultra-ac-2.clan",
    "name": "Ultra AC/2 [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 5,
    "cost": 120000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2827
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "5",
      "rawCost": "120,000",
      "heat": "1/Shot (2)",
      "damage": "2/Shot (3)",
      "range": "2/9/18/27 (Extreme)",
      "ammoPerTon": "45",
      "ref": "208",
      "slotsBattleMech": "2",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 2
  },
  {
    "id": "tm.ultra-ac-2.is",
    "name": "Ultra AC/2 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 7,
    "cost": 120000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3057
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "7",
      "rawCost": "120,000",
      "heat": "1/Shot (2)",
      "damage": "2/Shot (3)",
      "range": "3/8/17/25 (Extreme)",
      "ammoPerTon": "45",
      "ref": "208",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 3
  },
  {
    "id": "tm.ultra-ac-20.clan",
    "name": "Ultra AC/20 [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 12,
    "cost": 480000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2825
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "12",
      "rawCost": "480,000",
      "heat": "7/Shot (14)",
      "damage": "20/Shot (30)",
      "range": "0/4/8/12 (Medium)",
      "ammoPerTon": "5",
      "ref": "208",
      "slotsBattleMech": "8",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "8",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 8
  },
  {
    "id": "tm.ultra-ac-20.is",
    "name": "Ultra AC/20 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 15,
    "cost": 480000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3060
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "15",
      "rawCost": "480,000",
      "heat": "8/Shot (16)",
      "damage": "20/Shot (30)",
      "range": "0/3/7/10 (Medium)",
      "ammoPerTon": "5",
      "ref": "208",
      "slotsBattleMech": "10",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "10",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 10
  },
  {
    "id": "tm.ultra-ac-5.clan",
    "name": "Ultra AC/5 [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 8,
    "cost": 200000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "8",
      "rawCost": "200,000",
      "heat": "1/Shot (2)",
      "damage": "5/Shot (7)",
      "range": "0/7/14/21 (Long)",
      "ammoPerTon": "20",
      "ref": "208",
      "slotsBattleMech": "3",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 3
  },
  {
    "id": "tm.ultra-ac-5.is",
    "name": "Ultra AC/5 [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 9,
    "cost": 200000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 2640
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "E",
      "rawMass": "9",
      "rawCost": "200,000",
      "heat": "1/Shot (2)",
      "damage": "5/Shot (7)",
      "range": "2/6/13/20 (Long)",
      "ammoPerTon": "20",
      "ref": "208",
      "slotsBattleMech": "5",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "5",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1"
    },
    "slots": 5
  },
  {
    "id": "io.ultraheavy-protomech-cockpit.clan",
    "name": "Ultraheavy ProtoMech Cockpit [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0.75,
    "cost": 800000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3083
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-D",
      "rawMass": "0.75",
      "rawCost": "800,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "0",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    }
  },
  {
    "id": "io.ultraheavy-protomech-structure.clan",
    "name": "Ultraheavy ProtoMech Structure [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": {
      "op": "multiply",
      "args": [
        {
          "var": "unit.mass"
        },
        0.1
      ]
    },
    "cost": {
      "op": "multiply",
      "args": [
        400.0,
        {
          "var": "unit.mass"
        }
      ]
    },
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3083
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "D/X-X-D",
      "rawMass": "TTx0.1",
      "rawCost": "400xTT",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "0",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    }
  },
  {
    "id": "toaue.umus-protomech.clan",
    "name": "UMUs (ProtoMech) [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3061
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-E",
      "rawMass": "Var*",
      "rawCost": "†",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "0*",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "Var*",
      "manualCostFormula": "†"
    }
  },
  {
    "id": "toaue.umus-mech.is-clan",
    "name": "UMUs (’Mech)",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3061
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-E",
      "rawMass": "Var*",
      "rawCost": "†",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualMassFormula": "Var*",
      "manualCostFormula": "†"
    }
  },
  {
    "id": "toaue.unpressurized.is-clan",
    "name": "Unpressurized",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/C-E-D",
      "rawMass": "0.025xC",
      "rawCost": "5,000xC",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "0*",
      "slotsWarShip": "0*",
      "slotsSpaceStation": "0*",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "0.025xC",
      "manualCostFormula": "5,000xC"
    }
  },
  {
    "id": "toaue.variable-speed-laser-large.is",
    "name": "Variable Speed Laser, Large [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 9,
    "cost": 465000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3070
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-E",
      "rawMass": "9",
      "rawCost": "465,000",
      "slotsBattleMech": "4",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "4",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1"
    },
    "slots": 4
  },
  {
    "id": "toaue.variable-speed-laser-medium.is",
    "name": "Variable Speed Laser, Medium [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 4,
    "cost": 200000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3070
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-E",
      "rawMass": "4",
      "rawCost": "200,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 2
  },
  {
    "id": "toaue.variable-speed-laser-small.is",
    "name": "Variable Speed Laser, Small [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 2,
    "cost": 60000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3070
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-E",
      "rawMass": "2",
      "rawCost": "60,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1"
    },
    "slots": 1
  },
  {
    "id": "tm.vehicular.is-clan",
    "name": "Vehicular",
    "categories": [
      "weapon"
    ],
    "mass": 0.015,
    "cost": 1000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "0.015",
      "rawCost": "1,000",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "0/0/0/1 (NA)",
      "ammoPerTon": "10*",
      "ref": "249",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "NA"
    }
  },
  {
    "id": "toaue.vehicular-land-or-maritime.is-clan",
    "name": "Vehicular (Land or Maritime)",
    "categories": [
      "equipment"
    ],
    "mass": 0.5,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/E-E-E",
      "rawMass": "0.5",
      "rawCost": "20,000 / 20,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1",
      "manualCostFormula": "20,000 / 20,000"
    },
    "slots": 1
  },
  {
    "id": "io.vehicular-direct-neural-interface.is",
    "name": "Vehicular Direct Neural Interface [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 1400000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3055
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-E",
      "rawMass": "*",
      "rawCost": "1,400,000",
      "slotsBattleMech": "*",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*"
    }
  },
  {
    "id": "toaue.vehicular-jump-jets.is-clan",
    "name": "Vehicular Jump Jets",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 2650
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/E-X-F",
      "rawMass": "Var*",
      "rawCost": "†",
      "slotsBattleMech": "*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "Var*",
      "manualCostFormula": "†"
    }
  },
  {
    "id": "toaue.vehicular-stealth.is",
    "name": "Vehicular Stealth [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3067
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-F",
      "rawMass": "*",
      "rawCost": "50,000xAT",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "2*",
      "slotsSupportVehicle": "2*",
      "slotsFighter": "2*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "50,000xAT"
    }
  },
  {
    "id": "toaue.vibroblade-large.is",
    "name": "Vibroblade, Large [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 7,
    "cost": 750000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3066
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-X-E",
      "rawMass": "7",
      "rawCost": "750,000",
      "slotsBattleMech": "4",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    },
    "slots": 4
  },
  {
    "id": "toaue.vibroblade-medium.is",
    "name": "Vibroblade, Medium [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 5,
    "cost": 400000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3065
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-X-E",
      "rawMass": "5",
      "rawCost": "400,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 2
  },
  {
    "id": "toaue.vibroblade-small.is",
    "name": "Vibroblade, Small [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 3,
    "cost": 150000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3065
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-X-E",
      "rawMass": "3",
      "rawCost": "150,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    },
    "slots": 1
  },
  {
    "id": "io.virtual-reality-piloting-pod.is",
    "name": "Virtual Reality Piloting Pod [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 3,
    "cost": 1250000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3052
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "3",
      "rawCost": "1,250,000",
      "slotsBattleMech": "1*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    },
    "slots": 1
  },
  {
    "id": "toaue.void-signature-system.is",
    "name": "Void-Signature System [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 2000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3070
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-E",
      "rawMass": "0*",
      "rawCost": "2,000,000",
      "slotsBattleMech": "7*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    },
    "slots": 7
  },
  {
    "id": "toaue.vtol-chin-turret.is-clan",
    "name": "VTOL Chin Turret",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/F-F-F",
      "rawMass": "TE÷10",
      "rawCost": "5,000xIT",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "0*",
      "slotsSupportVehicle": "0*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "TE÷10",
      "manualCostFormula": "5,000xIT"
    }
  },
  {
    "id": "toaue.vtol-jet-booster.is-clan",
    "name": "VTOL Jet Booster",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3009
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "D/X-F-E",
      "rawMass": "ET÷10",
      "rawCost": "10,000xER",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "ET÷10",
      "manualCostFormula": "10,000xER"
    }
  },
  {
    "id": "toaue.vtol-mast-mount.is-clan",
    "name": "VTOL Mast Mount",
    "categories": [
      "equipment"
    ],
    "mass": 0.5,
    "cost": 50000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "C/F-F-F",
      "rawMass": "0.5",
      "rawCost": "50,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "0*",
      "slotsSupportVehicle": "0*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    }
  },
  {
    "id": "toaue.watchdog-cews.clan",
    "name": "Watchdog CEWS [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 1.5,
    "cost": 600000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3059
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "1.5",
      "rawCost": "600,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "1",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "0",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA"
    },
    "slots": 2
  },
  {
    "id": "tm.white-shark.clan",
    "name": "White Shark [Clan]",
    "categories": [
      "weapon"
    ],
    "mass": 120,
    "cost": 130000,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "120",
      "rawCost": "130,000",
      "heat": "NA (15)",
      "damage": "NA (30)",
      "range": "NA (Extreme)",
      "ammoPerTon": "40 t/Msl",
      "ref": "210",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1"
    }
  },
  {
    "id": "tm.white-shark.is",
    "name": "White Shark [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 120,
    "cost": 130000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "120",
      "rawCost": "130,000",
      "heat": "NA (15)",
      "damage": "NA (30)",
      "range": "NA (Extreme)",
      "ammoPerTon": "40 t/Msl",
      "ref": "210",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1"
    }
  },
  {
    "id": "tm.white-shark-t.is",
    "name": "White Shark-T [IS]",
    "categories": [
      "weapon"
    ],
    "mass": 140,
    "cost": 145000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "STANDARD",
      "introYear": 3056
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "140",
      "rawCost": "145,000",
      "heat": "NA (15)",
      "damage": "NA (30)",
      "range": "NA (Extreme)",
      "ammoPerTon": "40 t/Msl",
      "ref": "210",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "1"
    }
  },
  {
    "id": "io.word-of-blake-super-jump-drive.is",
    "name": "Word of Blake Super-Jump Drive [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 25000000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3059
    },
    "sourceNote": "BattleTech Interstellar Operations — Alternate Eras weapons/equipment construction tables (pp. 217–225).",
    "attributes": {
      "sourceDataset": "io",
      "techRating": "F/X-X-F",
      "rawMass": "0",
      "rawCost": "25,000,000",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "0",
      "slotsWarShip": "0",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA"
    }
  },
  {
    "id": "tm.wrecking-ball.is-clan",
    "name": "Wrecking Ball",
    "categories": [
      "weapon"
    ],
    "mass": 4,
    "cost": 80000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "4",
      "rawCost": "80,000",
      "heat": "0 (NA)",
      "damage": "8 (NA)",
      "range": "PHYS (NA)",
      "ammoPerTon": "NA",
      "ref": "249",
      "slotsBattleMech": "5*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1*",
      "slotsSupportVehicle": "1*",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 5
  },
  {
    "id": "tm.x-0-5.is-clan",
    "name": "x 0.5**",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "Gauss Rifl es",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "x 1",
      "damage": "IS",
      "range": "E",
      "ammoPerTon": "208",
      "ref": "218",
      "slotsBattleMech": "AP Gauss Ammo",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "Clan",
      "manualMassFormula": "Gauss Rifl es",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    }
  },
  {
    "id": "tm.x-1.is-clan",
    "name": "x 1",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "Machine Guns",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "x 1",
      "damage": "Clan",
      "range": "F",
      "ammoPerTon": "219",
      "ref": "228",
      "slotsBattleMech": "Machine Guns (Lt, Std, Heavy)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS / Clan",
      "manualMassFormula": "Machine Guns",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    }
  },
  {
    "id": "tm.x-1.is-clan.2",
    "name": "x 1",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "A",
      "rawMass": "Flamer",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "x 1",
      "damage": "IS / Clan",
      "range": "A",
      "ammoPerTon": "228",
      "ref": "218",
      "slotsBattleMech": "Flamer (Vehicle)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "IS / Clan",
      "manualMassFormula": "Flamer",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    }
  },
  {
    "id": "tm.x-1.is-clan.3",
    "name": "x 1",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "Plasma Weapons",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "x 1",
      "damage": "IS / Clan",
      "range": "A",
      "ammoPerTon": "218",
      "ref": "234",
      "slotsBattleMech": "Plasma Cannon",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "Clan",
      "manualMassFormula": "Plasma Weapons",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    }
  },
  {
    "id": "tm.x-1.is-clan.4",
    "name": "x 1",
    "categories": [
      "weapon"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "F",
      "rawMass": "Missiles",
      "rawCost": "UNRESOLVED_FROM_COST_TABLE",
      "heat": "x 1",
      "damage": "IS",
      "range": "E",
      "ammoPerTon": "234",
      "ref": "229",
      "slotsBattleMech": "ATMs (Standard Ammo)",
      "slotsProtoMech": "*",
      "slotsCombatVehicle": "*",
      "slotsSupportVehicle": "*",
      "slotsFighter": "x 1",
      "slotsSmallCraft": "x 1",
      "slotsDropShip": "Clan",
      "manualMassFormula": "Missiles",
      "manualCostFormula": "UNRESOLVED_FROM_COST_TABLE"
    }
  },
  {
    "id": "toaue.x-pulse-laser-large.is",
    "name": "X-Pulse Laser, Large [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 7,
    "cost": 275000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3057
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-E",
      "rawMass": "7",
      "rawCost": "275,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 2
  },
  {
    "id": "toaue.x-pulse-laser-medium.is",
    "name": "X-Pulse Laser, Medium [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 2,
    "cost": 110000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3057
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-E",
      "rawMass": "2",
      "rawCost": "110,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1"
    },
    "slots": 1
  },
  {
    "id": "toaue.x-pulse-laser-small.is",
    "name": "X-Pulse Laser, Small [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 31000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3057
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "E/X-X-E",
      "rawMass": "1",
      "rawCost": "31,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "1",
      "slotsSmallCraft": "1",
      "slotsDropShip": "1",
      "slotsJumpShip": "1",
      "slotsWarShip": "1",
      "slotsSpaceStation": "1",
      "slotsMobileStructure": "1"
    },
    "slots": 1
  },
  {
    "id": "toaue.xxl-fusion-clan.clan",
    "name": "XXL Fusion (Clan) [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3030
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "*",
      "rawCost": "(100,000xERxTT)÷75",
      "slotsBattleMech": "+8*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "+3*",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "+3*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "(100,000xERxTT)÷75"
    },
    "slots": 8
  },
  {
    "id": "toaue.xxl-fusion-inner-sphere.is",
    "name": "XXL Fusion (Inner Sphere) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 0,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "EXPERIMENTAL",
      "introYear": 3055
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "F/X-X-F",
      "rawMass": "*",
      "rawCost": "(100,000xERxTT)÷75",
      "slotsBattleMech": "+12*",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "+4*",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "+4*",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "NA",
      "manualMassFormula": "*",
      "manualCostFormula": "(100,000xERxTT)÷75"
    },
    "slots": 12
  },
  {
    "id": "tm.mech.is-clan",
    "name": "’Mech",
    "categories": [
      "weapon"
    ],
    "mass": 0.5,
    "cost": 1000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "B",
      "rawMass": "0.5",
      "rawCost": "1,000",
      "heat": "0 (NA)",
      "damage": "NA (NA)",
      "range": "0/0/0/1 (NA)",
      "ammoPerTon": "10*",
      "ref": "249",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "NA",
      "slotsSupportVehicle": "NA",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA"
    },
    "slots": 1
  },
  {
    "id": "tm.mech-cubicle.is-clan",
    "name": "’Mech (Cubicle)",
    "categories": [
      "weapon"
    ],
    "mass": 150,
    "cost": 1000,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "STANDARD"
    },
    "sourceNote": "BattleTech TechManual — Heavy Weapons/Equipment construction tables (pp. 341–345) and cost/availability tables (pp. 290–296).",
    "attributes": {
      "sourceDataset": "tm",
      "techRating": "C",
      "rawMass": "150",
      "rawCost": "1,000",
      "heat": "0 (0)",
      "damage": "NA (NA)",
      "range": "NA (NA)",
      "ammoPerTon": "NA",
      "ref": "239",
      "slotsBattleMech": "NA",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1**",
      "slotsSupportVehicle": "1**",
      "slotsFighter": "NA",
      "slotsSmallCraft": "0",
      "slotsDropShip": "0"
    }
  },
  {
    "id": "toaue.mech-mortar-1-clan.clan",
    "name": "’Mech Mortar/1 (Clan) [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 1,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/D-F-E",
      "rawMass": "1",
      "rawCost": "7,000 / 28,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualCostFormula": "7,000 / 28,000"
    },
    "slots": 1
  },
  {
    "id": "toaue.mech-mortar-1-is.is",
    "name": "’Mech Mortar/1 (IS) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 2,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/D-F-E",
      "rawMass": "2",
      "rawCost": "7,000 / 28,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1",
      "manualCostFormula": "7,000 / 28,000"
    },
    "slots": 1
  },
  {
    "id": "toaue.mech-mortar-2-clan.clan",
    "name": "’Mech Mortar/2 (Clan) [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 2.5,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/D-F-E",
      "rawMass": "2.5",
      "rawCost": "15,000 / 28,000",
      "slotsBattleMech": "1",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "1",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualCostFormula": "15,000 / 28,000"
    },
    "slots": 1
  },
  {
    "id": "toaue.mech-mortar-2-is.is",
    "name": "’Mech Mortar/2 (IS) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 5,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/D-F-E",
      "rawMass": "5",
      "rawCost": "15,000 / 28,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1",
      "manualCostFormula": "15,000 / 28,000"
    },
    "slots": 2
  },
  {
    "id": "toaue.mech-mortar-4-clan.clan",
    "name": "’Mech Mortar/4 (Clan) [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 3.5,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/D-F-E",
      "rawMass": "3.5",
      "rawCost": "32,000 / 28,000",
      "slotsBattleMech": "2",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "2",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualCostFormula": "32,000 / 28,000"
    },
    "slots": 2
  },
  {
    "id": "toaue.mech-mortar-4-is.is",
    "name": "’Mech Mortar/4 (IS) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 7,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/D-F-E",
      "rawMass": "7",
      "rawCost": "32,000 / 28,000",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1",
      "manualCostFormula": "32,000 / 28,000"
    },
    "slots": 3
  },
  {
    "id": "toaue.mech-mortar-8-clan.clan",
    "name": "’Mech Mortar/8 (Clan) [Clan]",
    "categories": [
      "equipment"
    ],
    "mass": 5,
    "cost": 0,
    "availability": {
      "techBases": [
        "CLAN",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/D-F-E",
      "rawMass": "5",
      "rawCost": "70,000 / 28,000",
      "slotsBattleMech": "3",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "3",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "manualCostFormula": "70,000 / 28,000"
    },
    "slots": 3
  },
  {
    "id": "toaue.mech-mortar-8-is.is",
    "name": "’Mech Mortar/8 (IS) [IS]",
    "categories": [
      "equipment"
    ],
    "mass": 10,
    "cost": 0,
    "availability": {
      "techBases": [
        "INNER_SPHERE",
        "MIXED"
      ],
      "rulesLevel": "ADVANCED"
    },
    "sourceNote": "BattleTech Tactical Operations: Advanced Units & Equipment — Heavy Weapons and Equipment Construction Data (pp. 217, 219, 221, 223).",
    "attributes": {
      "sourceDataset": "toaue",
      "techRating": "B/D-F-E",
      "rawMass": "10",
      "rawCost": "70,000 / 28,000",
      "slotsBattleMech": "5",
      "slotsProtoMech": "NA",
      "slotsCombatVehicle": "1",
      "slotsSupportVehicle": "5",
      "slotsFighter": "NA",
      "slotsSmallCraft": "NA",
      "slotsDropShip": "NA",
      "slotsJumpShip": "NA",
      "slotsWarShip": "NA",
      "slotsSpaceStation": "NA",
      "slotsMobileStructure": "1",
      "manualCostFormula": "70,000 / 28,000"
    },
    "slots": 5
  }
];
