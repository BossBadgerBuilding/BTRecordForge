import type { ComponentDefinition } from "../core/types";
import { canonicalEquipmentComponents } from "./canonicalEquipmentCatalog";

/** Built-in release catalog. */
export const seedComponents: ComponentDefinition[] = [
  ...canonicalEquipmentComponents
];

export const seedCatalog = new Map(
  seedComponents.map((item) => [item.id, item])
);
