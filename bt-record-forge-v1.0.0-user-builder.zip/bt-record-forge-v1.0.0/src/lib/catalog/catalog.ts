import type {
  Availability,
  ComponentDefinition,
  ConstructionValue,
  RulesLevel,
  TechBase
} from "../core/types";

export interface CatalogProvenance {
  name: string;
  version?: string;
  generatedAt?: string;
  sourceUrl?: string;
  license?: string;
  notes?: string;
}

export interface CatalogDocument {
  format: "bt-record-forge-catalog";
  version: 1;
  provenance: CatalogProvenance;
  components: ComponentDefinition[];
}

export interface CatalogLoadResult {
  document: CatalogDocument;
  catalog: Map<string, ComponentDefinition>;
  warnings: string[];
}

const TECH_BASES: readonly TechBase[] = [
  "INNER_SPHERE",
  "CLAN",
  "MIXED"
];

const RULE_LEVELS: readonly RulesLevel[] = [
  "INTRODUCTORY",
  "STANDARD",
  "ADVANCED",
  "EXPERIMENTAL"
];

export function parseCatalogDocument(text: string): CatalogLoadResult {
  const raw = JSON.parse(text) as unknown;

  if (!isRecord(raw)) {
    throw new Error("Catalog root must be a JSON object.");
  }

  if (raw.format !== "bt-record-forge-catalog") {
    throw new Error("Not a BT Record Forge catalog.");
  }

  if (raw.version !== 1) {
    throw new Error(`Unsupported catalog version: ${String(raw.version)}`);
  }

  if (!isRecord(raw.provenance) || typeof raw.provenance.name !== "string") {
    throw new Error("Catalog provenance.name is required.");
  }

  if (!Array.isArray(raw.components)) {
    throw new Error("Catalog components must be an array.");
  }

  const warnings: string[] = [];
  const components = raw.components.map((value, index) =>
    parseComponent(value, index, warnings)
  );

  const duplicateIds = findDuplicateIds(components);
  if (duplicateIds.length) {
    throw new Error(
      `Catalog contains duplicate component IDs: ${duplicateIds.join(", ")}`
    );
  }

  const document: CatalogDocument = {
    format: "bt-record-forge-catalog",
    version: 1,
    provenance: {
      name: raw.provenance.name,
      version: optionalString(raw.provenance.version),
      generatedAt: optionalString(raw.provenance.generatedAt),
      sourceUrl: optionalString(raw.provenance.sourceUrl),
      license: optionalString(raw.provenance.license),
      notes: optionalString(raw.provenance.notes)
    },
    components
  };

  return {
    document,
    catalog: new Map(components.map((component) => [component.id, component])),
    warnings
  };
}

export function makeCatalogDocument(
  provenance: CatalogProvenance,
  components: ComponentDefinition[]
): CatalogDocument {
  return {
    format: "bt-record-forge-catalog",
    version: 1,
    provenance,
    components
  };
}

export function serializeCatalogDocument(document: CatalogDocument): string {
  return JSON.stringify(document, null, 2);
}

export function mergeComponents(
  base: readonly ComponentDefinition[],
  incoming: readonly ComponentDefinition[]
): ComponentDefinition[] {
  const merged = new Map<string, ComponentDefinition>();

  for (const component of base) merged.set(component.id, component);
  for (const component of incoming) merged.set(component.id, component);

  return [...merged.values()].sort((a, b) => a.name.localeCompare(b.name));
}

function parseComponent(
  value: unknown,
  index: number,
  warnings: string[]
): ComponentDefinition {
  if (!isRecord(value)) {
    throw new Error(`Component #${index + 1} must be an object.`);
  }

  const id = requiredString(value.id, `components[${index}].id`);
  const name = requiredString(value.name, `components[${index}].name`);

  if (!Array.isArray(value.categories) || value.categories.length === 0) {
    throw new Error(`${id}: categories must contain at least one string.`);
  }

  const categories = value.categories.map((category, categoryIndex) =>
    requiredString(category, `${id}.categories[${categoryIndex}]`)
  );

  const mass = parseConstructionValue(value.mass, `${id}.mass`);
  const cost = parseConstructionValue(value.cost, `${id}.cost`);

  let slots: ConstructionValue | undefined;
  if (value.slots !== undefined) {
    slots = parseConstructionValue(value.slots, `${id}.slots`);
  }

  const availability = parseAvailability(value.availability, id);

  if (mass === 0 && cost === 0) {
    warnings.push(`${name} has zero mass and zero cost.`);
  }

  return {
    id,
    name,
    categories,
    mass,
    cost,
    slots,
    availability,
    expendable: value.expendable === true,
    sourceNote: optionalString(value.sourceNote),
    attributes: parseAttributes(value.attributes, id)
  };
}

function parseAvailability(value: unknown, id: string): Availability {
  if (!isRecord(value)) {
    throw new Error(`${id}: availability must be an object.`);
  }

  if (!Array.isArray(value.techBases) || value.techBases.length === 0) {
    throw new Error(`${id}: availability.techBases is required.`);
  }

  const techBases = value.techBases.map((techBase) => {
    if (
      typeof techBase !== "string" ||
      !TECH_BASES.includes(techBase as TechBase)
    ) {
      throw new Error(`${id}: invalid tech base ${String(techBase)}.`);
    }
    return techBase as TechBase;
  });

  let rulesLevel: RulesLevel | undefined;
  if (value.rulesLevel !== undefined) {
    if (
      typeof value.rulesLevel !== "string" ||
      !RULE_LEVELS.includes(value.rulesLevel as RulesLevel)
    ) {
      throw new Error(`${id}: invalid rules level ${String(value.rulesLevel)}.`);
    }
    rulesLevel = value.rulesLevel as RulesLevel;
  }

  return {
    techBases,
    introYear: optionalYear(value.introYear, `${id}.introYear`),
    extinctYear: optionalYear(value.extinctYear, `${id}.extinctYear`),
    reintroYear: optionalYear(value.reintroYear, `${id}.reintroYear`),
    rulesLevel
  };
}

function findDuplicateIds(
  components: readonly ComponentDefinition[]
): string[] {
  const seen = new Set<string>();
  const duplicates = new Set<string>();

  for (const component of components) {
    if (seen.has(component.id)) duplicates.add(component.id);
    seen.add(component.id);
  }

  return [...duplicates];
}


function parseAttributes(
  value: unknown,
  id: string
): Record<string, string | number | boolean> | undefined {
  if (value === undefined) return undefined;
  if (!isRecord(value)) {
    throw new Error(`${id}: attributes must be an object.`);
  }

  const result: Record<string, string | number | boolean> = {};
  for (const [key, item] of Object.entries(value)) {
    if (
      typeof item !== "string" &&
      typeof item !== "number" &&
      typeof item !== "boolean"
    ) {
      throw new Error(`${id}: attribute ${key} must be string, number, or boolean.`);
    }
    result[key] = item;
  }
  return result;
}

function requiredString(value: unknown, field: string): string {
  if (typeof value !== "string" || !value.trim()) {
    throw new Error(`${field} must be a non-empty string.`);
  }
  return value.trim();
}

function optionalString(value: unknown): string | undefined {
  return typeof value === "string" && value.trim()
    ? value.trim()
    : undefined;
}


function parseConstructionValue(
  value: unknown,
  field: string,
  depth = 0
): ConstructionValue {
  if (depth > 32) {
    throw new Error(`${field}: expression nesting is too deep.`);
  }

  if (typeof value === "number") {
    return requiredNonNegativeNumber(value, field);
  }

  if (!isRecord(value)) {
    throw new Error(`${field} must be a number or construction expression.`);
  }

  if (typeof value.var === "string" && value.var.trim()) {
    return { var: value.var.trim() };
  }

  if (typeof value.op !== "string" || !Array.isArray(value.args)) {
    throw new Error(`${field}: expression requires op and args.`);
  }

  const args = value.args.map((arg, index) =>
    parseConstructionValue(arg, `${field}.args[${index}]`, depth + 1)
  );

  switch (value.op) {
    case "add":
    case "multiply":
    case "min":
    case "max":
      if (args.length < 1) {
        throw new Error(`${field}: ${value.op} requires at least one argument.`);
      }
      return { op: value.op, args };

    case "subtract":
    case "divide":
    case "ceilTo":
    case "floorTo":
    case "roundTo":
      if (args.length !== 2) {
        throw new Error(`${field}: ${value.op} requires exactly two arguments.`);
      }
      return {
        op: value.op,
        args: [args[0], args[1]]
      };

    case "ceil":
    case "floor":
      if (args.length !== 1) {
        throw new Error(`${field}: ${value.op} requires exactly one argument.`);
      }
      return {
        op: value.op,
        args: [args[0]]
      };

    default:
      throw new Error(`${field}: unsupported expression op ${value.op}.`);
  }
}

function requiredNonNegativeNumber(value: unknown, field: string): number {
  if (
    typeof value !== "number" ||
    !Number.isFinite(value) ||
    value < 0
  ) {
    throw new Error(`${field} must be a finite non-negative number.`);
  }
  return value;
}

function optionalYear(value: unknown, field: string): number | undefined {
  if (value === undefined || value === null) return undefined;
  if (
    typeof value !== "number" ||
    !Number.isInteger(value) ||
    value < 0
  ) {
    throw new Error(`${field} must be a non-negative whole year.`);
  }
  return value;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
