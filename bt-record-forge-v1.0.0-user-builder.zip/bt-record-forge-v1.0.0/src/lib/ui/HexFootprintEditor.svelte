<script lang="ts">
  import type {
    HexFootprint,
    HexFootprintCell
  } from "../core/types";
  import { hexKey } from "../constructors/structureRules";

  export let footprint: HexFootprint;
  export let onChange: (next: HexFootprint) => void = () => {};
  export let readOnly = false;
  export let radius = 2;
  export let allowOpenSpace = false;

  let displayRadius = Math.max(2, radius);

  let selectedKey = "0,0";

  function axialDistance(q: number, r: number): number {
    return Math.max(Math.abs(q), Math.abs(r), Math.abs(q + r));
  }

  $: requiredRadius = footprint.cells.reduce(
    (maxRadius, cell) => Math.max(maxRadius, axialDistance(cell.q, cell.r)),
    0
  );
  // Never hide cells from an imported/existing footprint just because the
  // editor starts on the compact grid.
  $: if (requiredRadius > displayRadius) {
    displayRadius = requiredRadius;
  }

  // Flat-top axial hex layout.
  $: canvasWidth = Math.max(300, 64 + displayRadius * 66);
  $: canvasHeight = Math.max(300, 64 + displayRadius * 76);
  $: gridCells = makeHexDisk(displayRadius, canvasWidth, canvasHeight);
  $: renderedCells = gridCells.map((grid) => ({
    ...grid,
    occupied: footprint.cells.find(
      (cell) => cell.q === grid.q && cell.r === grid.r
    ) ?? null
  }));
  $: selected =
    footprint.cells.find((cell) => hexKey(cell.q, cell.r) === selectedKey) ??
    footprint.cells[0] ??
    null;

  function clickHex(q: number, r: number) {
    if (readOnly) return;

    const key = hexKey(q, r);
    const existing = footprint.cells.find(
      (cell) => hexKey(cell.q, cell.r) === key
    );

    if (existing) {
      selectedKey = key;
      return;
    }

    const next: HexFootprintCell = {
      q,
      r,
      levels: 1,
      constructionFactor: 10,
      armor: 0
    };

    onChange({
      ...footprint,
      cells: [...footprint.cells, next]
    });
    selectedKey = key;
  }

  function patchSelected(
    patch: Partial<Pick<
      HexFootprintCell,
      "levels" | "constructionFactor" | "armor" | "openLevels" | "notes"
    >>
  ) {
    if (readOnly || !selected) return;

    const key = hexKey(selected.q, selected.r);
    onChange({
      ...footprint,
      cells: footprint.cells.map((cell) =>
        hexKey(cell.q, cell.r) === key
          ? { ...cell, ...patch }
          : cell
      )
    });
  }

  function toggleOpenLevel(level: number) {
    if (readOnly || !selected || !allowOpenSpace) return;

    const current = new Set(selected.openLevels ?? []);
    if (current.has(level)) current.delete(level);
    else current.add(level);

    patchSelected({
      openLevels: [...current].sort((a, b) => a - b)
    });
  }

  function removeSelected() {
    if (readOnly || !selected) return;

    const key = hexKey(selected.q, selected.r);
    const remaining = footprint.cells.filter(
      (cell) => hexKey(cell.q, cell.r) !== key
    );

    onChange({
      ...footprint,
      cells: remaining
    });

    selectedKey = remaining[0]
      ? hexKey(remaining[0].q, remaining[0].r)
      : "";
  }

  function makeHexDisk(
    size: number,
    canvasWidth: number,
    canvasHeight: number
  ): Array<{
    q: number;
    r: number;
    x: number;
    y: number;
  }> {
    const cells = [];
    const hexWidth = 44;
    const hexHeight = Math.sqrt(3) * (hexWidth / 2);
    const xSpacing = hexWidth * 0.75;
    const centerX = canvasWidth / 2;
    const centerY = canvasHeight / 2;

    for (let q = -size; q <= size; q++) {
      const rMin = Math.max(-size, -q - size);
      const rMax = Math.min(size, -q + size);

      for (let r = rMin; r <= rMax; r++) {
        cells.push({
          q,
          r,
          x: centerX + xSpacing * q - hexWidth / 2,
          y: centerY + hexHeight * (r + q / 2) - hexHeight / 2
        });
      }
    }

    return cells;
  }
</script>

<div class:read-only={readOnly} class="hex-editor">
  <div class="hex-scroll">
    <div
      class="hex-canvas"
      style={`width:${canvasWidth}px; height:${canvasHeight}px`}
      aria-label="Structure hex footprint"
    >
      {#each renderedCells as grid (hexKey(grid.q, grid.r))}
        {@const occupied = grid.occupied}
        <button
          type="button"
          class:occupied={!!occupied}
          class:has-open-space={!!occupied && !!occupied.openLevels?.length}
          class:selected={!!occupied && selectedKey === hexKey(grid.q, grid.r)}
          class:empty={!occupied}
          class="hex-cell"
          style={`left:${grid.x}px; top:${grid.y}px`}
          aria-label={occupied
            ? `Occupied hex ${grid.q}, ${grid.r}; ${occupied.levels} level${occupied.levels === 1 ? "" : "s"}${occupied.openLevels?.length ? `; open space on level${occupied.openLevels.length === 1 ? "" : "s"} ${occupied.openLevels.join(", ")}` : ""}`
            : `Empty hex ${grid.q}, ${grid.r}`}
          aria-pressed={occupied ? "true" : "false"}
          disabled={readOnly && !occupied}
          on:click={() => clickHex(grid.q, grid.r)}
        >
          {#if occupied}
            <strong>L{occupied.levels}</strong>
            {#if allowOpenSpace && occupied.openLevels?.length}
              <span class="open-badge">O{occupied.openLevels.length}</span>
            {/if}
          {:else if !readOnly}
            <span>+</span>
          {/if}
        </button>
      {/each}
    </div>
  </div>

  {#if !readOnly}
    <div class="hex-hint-row">
      <div class="hex-hint">
        One footprint grid. Lit hexes are part of the building footprint.
        Click an empty hex to add it; click a lit hex to edit it. L1, L2, etc.
        is that hex's height in levels.{allowOpenSpace ? " O# marks open-space levels." : ""}
      </div>
      <div class="hex-size-controls">
        <button
          type="button"
          on:click={() => displayRadius = Math.max(2, requiredRadius, displayRadius - 1)}
          disabled={displayRadius <= Math.max(2, requiredRadius)}
        >
          Smaller grid
        </button>
        <span>Radius {displayRadius}</span>
        <button type="button" on:click={() => displayRadius = Math.min(12, displayRadius + 1)} disabled={displayRadius >= 12}>
          Larger grid
        </button>
      </div>
    </div>

    {#if selected}
      <div class="hex-inspector">
        <div class="hex-inspector-head">
          <div>
            <strong>Hex {selected.q}, {selected.r}</strong>
            <span>{selected.levels} level{selected.levels === 1 ? "" : "s"}</span>
          </div>
          <button
            type="button"
            class="text-button danger"
            on:click={removeSelected}
          >
            Remove hex
          </button>
        </div>

        <div class="three">
          <label>
            Levels
            <input
              type="number"
              min="1"
              step="1"
              value={selected.levels}
              on:input={(e) => {
                const levels = Math.max(1, Math.floor(Number(e.currentTarget.value) || 1));
                patchSelected({
                  levels,
                  openLevels: selected.openLevels?.filter((level) => level <= levels)
                });
              }}
            />
          </label>

          <label>
            CF
            <input
              type="number"
              min="1"
              step="1"
              value={selected.constructionFactor}
              on:input={(e) =>
                patchSelected({
                  constructionFactor: Number(e.currentTarget.value)
                })}
            />
          </label>

          <label>
            Armor
            <input
              type="number"
              min="0"
              step="1"
              value={selected.armor}
              on:input={(e) =>
                patchSelected({
                  armor: Number(e.currentTarget.value)
                })}
            />
          </label>
        </div>

        {#if allowOpenSpace}
          <div class="open-space-editor">
            <div>
              <strong>Open-space levels</strong>
              <span>Mark the Castle Brian levels that are open volume rather than fortress floor space.</span>
            </div>
            <div class="level-toggles" aria-label="Open-space levels">
              {#each Array.from({ length: selected.levels }, (_, index) => index + 1) as level}
                <button
                  type="button"
                  class:active={selected.openLevels?.includes(level)}
                  aria-pressed={selected.openLevels?.includes(level) ? "true" : "false"}
                  on:click={() => toggleOpenLevel(level)}
                >
                  {level}
                </button>
              {/each}
            </div>
          </div>
        {/if}

        <label>
          Hex notes
          <input
            value={selected.notes ?? ""}
            placeholder="Optional"
            on:input={(e) =>
              patchSelected({
                notes: e.currentTarget.value || undefined
              })}
          />
        </label>
      </div>
    {:else}
      <p class="empty">Add a hex to begin the footprint.</p>
    {/if}
  {/if}
</div>

<style>
  .hex-editor {
    min-width: 0;
  }

  .hex-scroll {
    width: 100%;
    overflow: auto;
    max-height: min(52vh, 520px);
    padding: 4px 0 10px;
    overscroll-behavior: contain;
  }

  .hex-canvas {
    position: relative;
    margin: 0 auto;
    max-width: none;
  }

  .hex-cell {
    position: absolute;
    width: 44px;
    height: 39px;
    border: 1px solid #3a4a55;
    background: #10171c;
    color: #778791;
    cursor: pointer;
    clip-path: polygon(
      25% 0,
      75% 0,
      100% 50%,
      75% 100%,
      25% 100%,
      0 50%
    );
    display: grid;
    place-content: center;
    line-height: 1;
    padding: 0;
  }

  .hex-cell span {
    font-size: .62rem;
    margin-top: 2px;
  }

  .hex-cell.occupied {
    background: var(--viz-accent-bg, #8db4cc);
    color: #0d1419;
    border-color: #d5e3ec;
    font-weight: 700;
  }

  /* The inspector selection is outlined; occupancy controls the fill. */
  .hex-cell.has-open-space {
    box-shadow: inset 0 0 0 3px #d5a44c;
  }

  .hex-cell .open-badge {
    display: block;
    font-size: .52rem;
    line-height: 1;
    margin-top: 2px;
    color: #4a3308;
  }

  .hex-cell.selected {
    outline: 3px solid #ffffff;
    outline-offset: -6px;
    box-shadow: 0 0 0 2px #10171c;
  }

  .hex-cell:focus-visible {
    outline: 3px solid #b6d3e4;
    outline-offset: 2px;
  }

  .read-only .hex-cell.empty {
    opacity: 0;
    pointer-events: none;
  }

  .read-only .hex-cell.occupied {
    cursor: default;
  }

  .hex-hint-row {
    display: flex;
    justify-content: space-between;
    gap: 8px;
    flex-wrap: wrap;
    margin: 4px 0 12px;
  }

  .hex-hint {
    color: #8d9ca7;
    font-size: .78rem;
    flex: 1 1 220px;
  }

  .hex-size-controls {
    display: flex;
    align-items: center;
    gap: 6px;
    color: #8d9ca7;
    font-size: .72rem;
  }

  .hex-size-controls button {
    min-height: 32px;
    border: 1px solid #34434e;
    border-radius: 5px;
    background: #172027;
    color: #c8d3da;
    padding: 4px 7px;
  }

  .hex-inspector {
    border-top: 1px solid #2d3a43;
    padding-top: 12px;
  }

  .hex-inspector-head {
    display: flex;
    justify-content: space-between;
    gap: 12px;
    align-items: start;
    margin-bottom: 10px;
  }

  .hex-inspector-head strong,
  .hex-inspector-head span {
    display: block;
  }

  .hex-inspector-head span {
    color: #8e9da8;
    font-size: .78rem;
    margin-top: 2px;
  }

  .open-space-editor {
    display: grid;
    gap: 8px;
    margin: 10px 0;
    padding: 10px;
    border: 1px solid #3b4650;
    border-radius: 6px;
    background: #141c22;
  }

  .open-space-editor > div:first-child strong,
  .open-space-editor > div:first-child span {
    display: block;
  }

  .open-space-editor > div:first-child span {
    color: #8e9da8;
    font-size: .76rem;
    margin-top: 2px;
  }

  .level-toggles {
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
  }

  .level-toggles button {
    min-width: 32px;
    min-height: 30px;
    border: 1px solid #42525d;
    border-radius: 5px;
    background: #172027;
    color: #b9c6ce;
  }

  .level-toggles button.active {
    background: #d5a44c;
    color: #171109;
    border-color: #f0c66c;
    font-weight: 700;
  }

  .three {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 8px;
  }

  @media (max-width: 400px) {
    .three {
      grid-template-columns: 1fr;
    }
  }

  @media print {
    .hex-cell.occupied {
      background: #eee;
      color: #000;
      border-color: #555;
    }
  }
</style>
