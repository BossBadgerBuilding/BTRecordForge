import type { ConstructorDefinition } from "../core/types";

export type RecordLayoutFamily =
  | "MEK"
  | "PROTOMECH"
  | "VEHICLE"
  | "INFANTRY"
  | "AEROSPACE"
  | "STRUCTURE"
  | "MISCELLANEOUS";

export interface RecordLayout {
  family: RecordLayoutFamily;
  title: string;
  subtitle: string;
  cssClass: string;
}

export function getRecordLayout(
  constructor: ConstructorDefinition
): RecordLayout {
  switch (constructor.family) {
    case "Meks":
      return { family: "MEK", title: "’Mech Construction Record", subtitle: "Chassis, critical-space, armor and equipment record", cssClass: "record-mek" };
    case "ProtoMechs":
      return { family: "PROTOMECH", title: "ProtoMech Construction Record", subtitle: "Chassis, armor and equipment record", cssClass: "record-protomech" };
    case "Vehicles":
      return { family: "VEHICLE", title: "Vehicle Construction Record", subtitle: "Motive, structural, armor, crew and equipment record", cssClass: "record-vehicle" };
    case "Infantry":
      return { family: "INFANTRY", title: "Infantry Construction Record", subtitle: "Platoon/squad equipment and cost record", cssClass: "record-infantry" };
    case "Aerospace":
      return { family: "AEROSPACE", title: "Aerospace Construction Record", subtitle: "Structure, drive, armor, heat and transport record", cssClass: "record-aerospace" };
    case "Structures":
      return { family: "STRUCTURE", title: "Structure Construction Record", subtitle: "Hex footprint, CF, armor, motive and equipment record", cssClass: "record-structure" };
    default:
      return { family: "MISCELLANEOUS", title: "BattleTech Construction Record", subtitle: constructor.name, cssClass: "record-misc" };
  }
}

export function familySummaryKeys(family: RecordLayoutFamily): string[] {
  switch (family) {
    case "MEK":
      return ["engineRating", "walkMP", "runMP", "jumpMP", "armorPoints", "structureType"];
    case "PROTOMECH":
      return ["walkMP", "runMP", "jumpMP", "armorPoints", "engineRating"];
    case "VEHICLE":
      return ["cruiseMP", "flankMP", "engineRating", "armorPoints", "minimumCrew", "desiredRangeKm"];
    case "INFANTRY":
      return ["troopers", "squadSize", "platoonStrength", "antiMechSkill", "armorDivisor"];
    case "AEROSPACE":
      return ["safeThrust", "maximumThrust", "structuralIntegrity", "armorPoints", "fuelTons", "heatSinks"];
    case "STRUCTURE":
      return ["occupiedHexes", "maxLevels", "totalConstructionFactor", "totalArmor", "minimumCrew", "selectedMP"];
    default:
      return [];
  }
}
