export type ConstructorId =
  | "mech.battlemech"
  | "mech.primitive"
  | "mech.omni"
  | "mech.industrial"
  | "mech.quad"
  | "mech.tripod"
  | "mech.superheavy"
  | "mech.lam"
  | "mech.quadvee"
  | "protomech.standard"
  | "vehicle.combat"
  | "vehicle.support"
  | "aero.aerospace-fighter"
  | "aero.conventional-fighter"
  | "aero.small-craft"
  | "aero.dropship"
  | "aero.jumpship"
  | "aero.warship"
  | "aero.space-station"
  | "infantry.conventional"
  | "infantry.battle-armor"
  | "structure.building"
  | "structure.mobile"
  | "emplacement.gun"
  | "weapon.handheld"
  | "battlefield-support.asset";

export type TechBase = "INNER_SPHERE" | "CLAN" | "MIXED";
export type RulesLevel =
  | "INTRODUCTORY"
  | "STANDARD"
  | "ADVANCED"
  | "EXPERIMENTAL";

export interface DesignRules {
  year?: number;
  techBase: TechBase;
  rulesLevel: RulesLevel;
}

export interface DesignImage {
  mimeType: "image/png" | "image/jpeg";
  fileName: string;
  dataUrl: string;
}


export type ValueExpression =
  | {
      var: string;
    }
  | {
      op: "add" | "multiply" | "min" | "max";
      args: ConstructionValue[];
    }
  | {
      op: "subtract" | "divide";
      args: [ConstructionValue, ConstructionValue];
    }
  | {
      op: "ceil" | "floor";
      args: [ConstructionValue];
    }
  | {
      op: "ceilTo" | "floorTo" | "roundTo";
      args: [ConstructionValue, ConstructionValue];
    };

export type ConstructionValue = number | ValueExpression;

export interface Availability {
  techBases: TechBase[];
  introYear?: number;
  extinctYear?: number;
  reintroYear?: number;
  rulesLevel?: RulesLevel;
}

export interface ComponentDefinition {
  id: string;
  name: string;
  categories: string[];
  mass: ConstructionValue;
  cost: ConstructionValue;
  slots?: ConstructionValue;
  availability: Availability;
  expendable?: boolean;
  sourceNote?: string;
  attributes?: Record<string, string | number | boolean>;
}

export interface ComponentPlacement {
  location?: string;
  level?: number;
  rearMounted?: boolean;
  facing?: string;
  bay?: string;
  section?: string;
  /**
   * Exact numbered critical slots used in the primary location.
   * BattleMech locations are numbered from 1 through their printed capacity.
   */
  criticalSlots?: number[];
  /**
   * Optional second location/slot allocation for BattleMech equipment that may
   * legally be split across adjacent locations.
   */
  splitLocation?: string;
  splitCriticalSlots?: number[];
}

export interface InstalledComponent {
  id: string;
  componentId: string;
  quantity: number;
  placement?: ComponentPlacement;
  notes?: string;
}


export interface HexFootprintCell {
  q: number;
  r: number;
  levels: number;
  constructionFactor: number;
  armor: number;
  /**
   * Castle Brian only: specific vertical levels in this map hex that are
   * intentionally left as open-space construction.
   */
  openLevels?: number[];
  notes?: string;
}

export interface HexFootprint {
  kind: "hex-footprint";
  cells: HexFootprintCell[];
}


export type EmbeddedBuildingClassification =
  | "TENT"
  | "HANGAR"
  | "STANDARD"
  | "FENCE"
  | "WALL"
  | "BRIDGE"
  | "GUN_EMPLACEMENT"
  | "FORTRESS"
  | "CASTLE_BRIAN";

export type EmbeddedStructureClass =
  | "LIGHT"
  | "MEDIUM"
  | "HEAVY"
  | "HARDENED"
  | "RAIL";

/**
 * A structure physically placed inside Castle Brian open-space volume.
 * Its footprint coordinates are relative to originQ/originR in the parent.
 */
export interface EmbeddedStructure {
  id: string;
  name: string;
  buildingClassification: EmbeddedBuildingClassification;
  constructionType: EmbeddedStructureClass;
  originQ: number;
  originR: number;
  baseLevel: number;
  footprint: HexFootprint;
  notes?: string;
}

export interface ChassisDefinition {
  massLimit: number;
  properties: Record<string, string | number | boolean>;
}

export interface Design {
  format: "bt-record-forge";
  formatVersion: 1;
  id: string;
  constructorId: ConstructorId;
  identity: {
    name: string;
    model?: string;
    description?: string;
  };
  rules: DesignRules;
  chassis: ChassisDefinition;
  components: InstalledComponent[];
  embeddedComponents?: ComponentDefinition[];
  embeddedStructures?: EmbeddedStructure[];
  footprint?: HexFootprint;
  image?: DesignImage;
  notes?: string;
}

export type ValidationSeverity = "info" | "warning" | "error";

export type ValidationCode =
  | "ERA_ILLEGAL"
  | "TECH_BASE_CONFLICT"
  | "RULES_LEVEL_CONFLICT"
  | "UNKNOWN_COMPONENT"
  | "MASS_OVER_LIMIT"
  | "INVALID_QUANTITY"
  | "ENGINE_RATING_INVALID"
  | "MOVEMENT_INVALID"
  | "ARMOR_OVER_LIMIT"
  | "HEAT_SINK_INVALID"
  | "SIZE_LIMIT_EXCEEDED"
  | "ENGINE_TECH_INVALID"
  | "COST_INCOMPLETE"
  | "UNALLOCATED_COMPONENT"
  | "INVALID_LOCATION"
  | "LOCATION_OVER_CAPACITY"
  | "HEX_FOOTPRINT_EMPTY"
  | "HEX_DUPLICATE"
  | "HEX_DISCONNECTED"
  | "OPEN_SPACE_LEVEL_INVALID"
  | "EMBEDDED_STRUCTURE_OUTSIDE_OPEN_SPACE"
  | "EMBEDDED_STRUCTURE_OVERLAP"
  | "LEVEL_COUNT_INVALID"
  | "CONSTRUCTION_FACTOR_INVALID"
  | "STRUCTURE_COMPONENT_RULES_INCOMPLETE"
  | "RULES_IMPLEMENTATION_PARTIAL"
  | "VALUE_INVALID"
  | "LEVEL_PLACEMENT_INVALID"
  | "CRITICAL_ALLOCATION_AUTO"
  | "CRITICAL_ALLOCATION_INVALID"
  | "CRITICAL_SLOT_COLLISION"
  | "TECH_BASE_MISMATCH"
  | "TECH_BASE_ILLEGAL"
  | "CHASSIS_MOD_UNKNOWN"
  | "CHASSIS_MOD_ILLEGAL"
  | "CHASSIS_MOD_CONFLICT"
  | "CHASSIS_MOD_TECH"
  | "ARMOR_INVALID"
  | "ARMOR_TECH_INVALID"
  | "ARMOR_CHASSIS_REQUIRED"
  | "ARMOR_REQUIRED"
  | "CREW_INVALID"
  | "MANIPULATOR_ILLEGAL"
  | "MANIPULATOR_PAIR_REQUIRED";

export interface ValidationIssue {
  code: ValidationCode;
  severity: ValidationSeverity;
  message: string;
  componentId?: string;
  field?: string;
}

export interface LedgerEntry {
  id: string;
  label: string;
  quantity: number;
  unitValue: number;
  totalValue: number;
  category: string;
  sourceComponentId?: string;
  explanation?: string;
}

export interface Ledger {
  used: number;
  limit?: number;
  remaining?: number;
  entries: LedgerEntry[];
}

export interface CostModifier {
  id: string;
  label: string;
  multiplier: number;
  explanation?: string;
}

export interface CostLedger {
  subtotal: number;
  modifiers: CostModifier[];
  total: number;
  dryTotal: number;
  entries: LedgerEntry[];
}

export interface LocationSlotLedger {
  id: string;
  label: string;
  capacity: number;
  reserved: number;
  equipmentUsed: number;
  used: number;
  remaining: number;
  entries: LedgerEntry[];
}

export interface ConstructionResult {
  mass: Ledger;
  cost: CostLedger;
  slots?: Ledger;
  locations?: LocationSlotLedger[];
  validation: ValidationIssue[];
  derived?: Record<string, string | number | boolean>;
}


export type ConstructorCoverage =
  | "RULES_IMPLEMENTED"
  | "VERIFIED_SLICE"
  | "PARTIAL_RULES"
  | "RECORD_ONLY";

export type ConstructorFamily =
  | "Meks"
  | "ProtoMechs"
  | "Vehicles"
  | "Infantry"
  | "Aerospace"
  | "Structures"
  | "Miscellaneous";

export interface ConstructorFieldOption {
  value: string;
  label: string;
}

export interface ConstructorFieldDefinition {
  key: string;
  label: string;
  kind: "number" | "select" | "text" | "boolean";
  defaultValue: string | number | boolean;
  help?: string;
  unit?: string;
  min?: number;
  max?: number;
  step?: number;
  options?: ConstructorFieldOption[];
  ledger?: "mass" | "cost";
  ledgerCategory?: string;
}

export interface ConstructorSectionDefinition {
  id: string;
  label: string;
  description?: string;
  fields: ConstructorFieldDefinition[];
}

export interface PlacementLocationDefinition {
  id: string;
  label: string;
  capacity?: number;
}

export interface ConstructorEditorSchema {
  sections: ConstructorSectionDefinition[];
  placementLocations?: PlacementLocationDefinition[];
}

export interface ConstructorDefinition {
  id: ConstructorId;
  name: string;
  description: string;
  family?: ConstructorFamily;
  coverage?: ConstructorCoverage;
  editorSchema?: ConstructorEditorSchema;
  create(): Design;
  calculate(design: Design, catalog: Map<string, ComponentDefinition>): ConstructionResult;
}
