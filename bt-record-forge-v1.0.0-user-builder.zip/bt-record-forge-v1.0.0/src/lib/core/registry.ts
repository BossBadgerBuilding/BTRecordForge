import type { ConstructorDefinition, ConstructorId } from "./types";

export class ConstructorRegistry {
  private readonly items = new Map<ConstructorId, ConstructorDefinition>();

  register(definition: ConstructorDefinition): this {
    if (this.items.has(definition.id)) {
      throw new Error(`Constructor already registered: ${definition.id}`);
    }
    this.items.set(definition.id, definition);
    return this;
  }

  get(id: ConstructorId): ConstructorDefinition {
    const definition = this.items.get(id);
    if (!definition) throw new Error(`Unknown constructor: ${id}`);
    return definition;
  }

  all(): ConstructorDefinition[] {
    return [...this.items.values()];
  }
}
