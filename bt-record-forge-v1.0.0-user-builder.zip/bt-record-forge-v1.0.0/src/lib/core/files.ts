import { invoke } from "@tauri-apps/api/core";
import type {
  ComponentDefinition,
  ConstructionResult,
  Design,
  DesignImage
} from "./types";

export const TRO_IMAGE_EXTENSION = ".png";
export const PNG_DESIGN_KEYWORD = "BTRecordForge";

export interface TroExportContext {
  constructorName: string;
  recordTitle: string;
  recordSubtitle: string;
  result: ConstructionResult;
  components: Map<string, ComponentDefinition>;
}

export interface TroSaveResult {
  fileName: string;
  location: string;
}

export function serializeDesign(design: Design): string {
  return JSON.stringify(design, null, 2);
}

export function parseDesign(text: string): Design {
  const data = JSON.parse(text) as Partial<Design>;
  if (data.format !== "bt-record-forge" || data.formatVersion !== 1) {
    throw new Error("Unsupported or invalid BT Record Forge file.");
  }
  return data as Design;
}

export async function parseDesignFile(file: File): Promise<Design> {
  const bytes = new Uint8Array(await file.arrayBuffer());
  if (isPng(bytes)) {
    const embedded = extractEmbeddedDesignText(bytes);
    if (!embedded) {
      throw new Error(
        "This PNG does not contain embedded BT Record Forge design data."
      );
    }
    return parseDesign(embedded);
  }

  return parseDesign(new TextDecoder().decode(bytes));
}

export async function imageFromFile(file: File): Promise<DesignImage> {
  if (file.type !== "image/png" && file.type !== "image/jpeg") {
    throw new Error("Only PNG and JPG/JPEG images are supported.");
  }

  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () =>
      reject(reader.error ?? new Error("Could not read image."));
    reader.onload = () => resolve(String(reader.result));
    reader.readAsDataURL(file);
  });

  return {
    mimeType: file.type as DesignImage["mimeType"],
    fileName: file.name,
    dataUrl
  };
}


export async function saveTroRecord(
  design: Design,
  context: TroExportContext
): Promise<TroSaveResult> {
  const rawPng = await renderTroPng(design, context);
  const pngWithDesign = embedDesignText(rawPng, serializeDesign(design));
  const fileName = `${safeFileStem(design.identity.name)}-TRO${TRO_IMAGE_EXTENSION}`;

  const location = await invoke<string>("save_custom_build", {
    fileName,
    bytes: Array.from(pngWithDesign)
  });
  return { fileName, location };
}

export function embedDesignText(
  pngBytes: Uint8Array,
  designText: string
): Uint8Array {
  if (!isPng(pngBytes)) {
    throw new Error("Cannot embed design data: source is not a PNG.");
  }

  const itxt = createChunk("iTXt", makeITXtData(PNG_DESIGN_KEYWORD, designText));
  const chunks: Uint8Array[] = [pngBytes.slice(0, 8)];
  let offset = 8;
  let inserted = false;

  while (offset + 12 <= pngBytes.length) {
    const length = readUint32(pngBytes, offset);
    const chunkEnd = offset + 12 + length;
    if (chunkEnd > pngBytes.length) {
      throw new Error("Cannot embed design data: malformed PNG.");
    }

    const type = asciiDecode(pngBytes.slice(offset + 4, offset + 8));
    if (type === "IEND" && !inserted) {
      chunks.push(itxt);
      inserted = true;
    }
    chunks.push(pngBytes.slice(offset, chunkEnd));
    offset = chunkEnd;
  }

  if (!inserted) {
    throw new Error("Cannot embed design data: PNG has no IEND chunk.");
  }

  return concatBytes(chunks);
}

export function extractEmbeddedDesignText(
  pngBytes: Uint8Array
): string | null {
  if (!isPng(pngBytes)) return null;

  let offset = 8;
  while (offset + 12 <= pngBytes.length) {
    const length = readUint32(pngBytes, offset);
    const dataStart = offset + 8;
    const dataEnd = dataStart + length;
    const chunkEnd = dataEnd + 4;
    if (chunkEnd > pngBytes.length) return null;

    const type = asciiDecode(pngBytes.slice(offset + 4, offset + 8));
    if (type === "iTXt") {
      const text = parseITXtData(pngBytes.slice(dataStart, dataEnd));
      if (text?.keyword === PNG_DESIGN_KEYWORD) return text.text;
    }

    offset = chunkEnd;
  }

  return null;
}

async function renderTroPng(
  design: Design,
  context: TroExportContext
): Promise<Uint8Array> {
  const derivedEntries = Object.entries(context.result.derived ?? {});
  const componentRows = design.components.length;
  const footprintRows = design.footprint?.cells.length ?? 0;
  const estimatedRows =
    Math.ceil(derivedEntries.length / 2) +
    componentRows +
    footprintRows +
    Math.ceil((design.notes?.length ?? 0) / 70);

  const width = 1800;
  const height = Math.max(2200, Math.min(6200, 1700 + estimatedRows * 44));
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not create TRO image canvas.");

  const margin = 100;
  const contentWidth = width - margin * 2;
  const ink = "#171717";
  const muted = "#555555";
  const rule = "#383838";
  const paper = "#f4f0e7";
  const panel = "#e8e1d2";

  ctx.fillStyle = paper;
  ctx.fillRect(0, 0, width, height);
  ctx.strokeStyle = rule;
  ctx.lineWidth = 3;
  ctx.strokeRect(56, 56, width - 112, height - 112);

  let y = 112;

  ctx.fillStyle = ink;
  ctx.font = "700 32px Georgia, serif";
  ctx.fillText("TECHNICAL READOUT", margin, y);
  ctx.textAlign = "right";
  ctx.font = "600 24px Arial, sans-serif";
  ctx.fillText("BT RECORD FORGE", width - margin, y);
  ctx.textAlign = "left";

  y += 34;
  drawRule(ctx, margin, width - margin, y, 5);
  y += 66;

  ctx.font = "700 64px Georgia, serif";
  drawClippedText(
    ctx,
    design.identity.name || "Untitled",
    margin,
    y,
    contentWidth,
    64
  );
  y += 54;

  ctx.fillStyle = muted;
  ctx.font = "600 28px Arial, sans-serif";
  const modelLine = [
    design.identity.model,
    context.constructorName,
    design.rules.year ? String(design.rules.year) : undefined
  ]
    .filter(Boolean)
    .join("  //  ");
  drawClippedText(ctx, modelLine, margin, y, contentWidth, 28);
  y += 56;

  ctx.fillStyle = panel;
  ctx.fillRect(margin, y, contentWidth, 82);
  ctx.fillStyle = ink;
  ctx.font = "700 24px Arial, sans-serif";
  ctx.fillText(context.recordTitle.toUpperCase(), margin + 24, y + 33);
  ctx.fillStyle = muted;
  ctx.font = "22px Arial, sans-serif";
  drawClippedText(
    ctx,
    context.recordSubtitle,
    margin + 24,
    y + 64,
    contentWidth - 48,
    22
  );
  y += 118;

  const artWidth = 560;
  const artHeight = 390;
  const statsX = margin + artWidth + 42;
  const statsWidth = contentWidth - artWidth - 42;

  ctx.strokeStyle = rule;
  ctx.lineWidth = 2;
  ctx.strokeRect(margin, y, artWidth, artHeight);
  ctx.fillStyle = "#ede7dc";
  ctx.fillRect(margin + 2, y + 2, artWidth - 4, artHeight - 4);

  if (design.image?.dataUrl) {
    try {
      const image = await loadImage(design.image.dataUrl);
      drawImageContain(ctx, image, margin + 14, y + 14, artWidth - 28, artHeight - 28);
    } catch {
      drawCenteredLabel(ctx, "ARTWORK UNAVAILABLE", margin, y, artWidth, artHeight);
    }
  } else {
    drawCenteredLabel(ctx, "NO REFERENCE ARTWORK", margin, y, artWidth, artHeight);
  }

  drawBoxTitle(ctx, statsX, y, statsWidth, "QUICK DATA");
  let sy = y + 54;
  const quickData: Array<[string, string]> = [
    ["Tech base", design.rules.techBase.replaceAll("_", " ")],
    ["Rules", design.rules.rulesLevel.replaceAll("_", " ")],
    [
      "Mass",
      `${formatNumber(context.result.mass.used)}${
        design.chassis.massLimit > 0
          ? ` / ${formatNumber(design.chassis.massLimit)}`
          : ""
      } t`
    ],
    ["Cost", `${formatNumber(context.result.cost.total)} C-bills`],
    [
      "Construction",
      `${context.result.validation.filter((x) => x.severity === "error").length} errors`
    ],
    [
      "Legality",
      `${context.result.validation.filter((x) => x.severity === "warning").length} warnings`
    ]
  ];
  for (const [label, value] of quickData) {
    drawKeyValue(ctx, statsX + 22, sy, statsWidth - 44, label, value);
    sy += 49;
  }

  y += artHeight + 54;

  if (design.identity.description || design.notes) {
    y = drawSectionHeader(ctx, margin, y, contentWidth, "OVERVIEW");
    ctx.fillStyle = ink;
    ctx.font = "24px Georgia, serif";
    const overview = [design.identity.description, design.notes]
      .filter(Boolean)
      .join("\n\n");
    y = drawWrappedText(ctx, overview, margin + 10, y, contentWidth - 20, 35, 11);
    y += 30;
  }

  if (derivedEntries.length) {
    y = drawSectionHeader(ctx, margin, y, contentWidth, "SPECIFICATIONS");
    const gap = 34;
    const colWidth = (contentWidth - gap) / 2;
    let leftY = y;
    let rightY = y;
    derivedEntries.forEach(([key, value], index) => {
      const x = index % 2 === 0 ? margin : margin + colWidth + gap;
      const currentY = index % 2 === 0 ? leftY : rightY;
      drawKeyValue(
        ctx,
        x,
        currentY,
        colWidth,
        prettyKey(key),
        String(value)
      );
      if (index % 2 === 0) leftY += 45;
      else rightY += 45;
    });
    y = Math.max(leftY, rightY) + 28;
  }

  if (design.components.length) {
    y = drawSectionHeader(ctx, margin, y, contentWidth, "ARMAMENT & EQUIPMENT");
    const colName = margin + 12;
    const colQty = margin + contentWidth - 420;
    const colLoc = margin + contentWidth - 300;
    const colNotes = margin + contentWidth - 150;
    ctx.fillStyle = muted;
    ctx.font = "700 20px Arial, sans-serif";
    ctx.fillText("ITEM", colName, y);
    ctx.fillText("QTY", colQty, y);
    ctx.fillText("LOCATION", colLoc, y);
    ctx.fillText("NOTES", colNotes, y);
    y += 18;
    drawRule(ctx, margin, width - margin, y, 2);
    y += 30;

    for (const installed of design.components) {
      const component = context.components.get(installed.componentId);
      ctx.fillStyle = ink;
      ctx.font = "23px Arial, sans-serif";
      drawClippedText(
        ctx,
        component?.name ?? installed.componentId,
        colName,
        y,
        colQty - colName - 24,
        23
      );
      ctx.fillText(String(installed.quantity), colQty, y);
      drawClippedText(
        ctx,
        installed.placement?.location ?? "—",
        colLoc,
        y,
        130,
        21
      );
      drawClippedText(
        ctx,
        installed.notes ?? "",
        colNotes,
        y,
        margin + contentWidth - colNotes,
        20
      );
      y += 38;
      if (y > height - 260) break;
    }
    y += 24;
  }

  if (design.footprint?.cells.length && y < height - 500) {
    y = drawSectionHeader(ctx, margin, y, contentWidth, "STRUCTURE FOOTPRINT");
    ctx.fillStyle = muted;
    ctx.font = "700 20px Arial, sans-serif";
    ctx.fillText("HEX", margin + 12, y);
    ctx.fillText("LEVELS", margin + 260, y);
    ctx.fillText("CF", margin + 480, y);
    ctx.fillText("ARMOR", margin + 650, y);
    ctx.fillText("OPEN LEVELS", margin + 850, y);
    y += 18;
    drawRule(ctx, margin, width - margin, y, 2);
    y += 30;

    for (const cell of [...design.footprint.cells].sort(
      (a, b) => a.r - b.r || a.q - b.q
    )) {
      ctx.fillStyle = ink;
      ctx.font = "23px Arial, sans-serif";
      ctx.fillText(`${cell.q}, ${cell.r}`, margin + 12, y);
      ctx.fillText(String(cell.levels), margin + 260, y);
      ctx.fillText(String(cell.constructionFactor), margin + 480, y);
      ctx.fillText(String(cell.armor), margin + 650, y);
      ctx.fillText(cell.openLevels?.join(", ") ?? "—", margin + 850, y);
      y += 38;
      if (y > height - 260) break;
    }
  }

  const footerY = height - 115;
  drawRule(ctx, margin, width - margin, footerY - 30, 2);
  ctx.fillStyle = muted;
  ctx.font = "18px Arial, sans-serif";
  ctx.fillText(
    "Machine-readable design embedded in PNG iTXt metadata: BTRecordForge",
    margin,
    footerY
  );
  ctx.textAlign = "right";
  ctx.fillText("BT Record Forge 1.0.0", width - margin, footerY);
  ctx.textAlign = "left";

  const blob = await canvasToBlob(canvas);
  return new Uint8Array(await blob.arrayBuffer());
}

function drawSectionHeader(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  title: string
): number {
  ctx.fillStyle = "#171717";
  ctx.fillRect(x, y, width, 46);
  ctx.fillStyle = "#f4f0e7";
  ctx.font = "700 23px Arial, sans-serif";
  ctx.fillText(title, x + 16, y + 31);
  return y + 74;
}

function drawBoxTitle(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  title: string
): void {
  ctx.strokeStyle = "#383838";
  ctx.lineWidth = 2;
  ctx.strokeRect(x, y, width, 390);
  ctx.fillStyle = "#171717";
  ctx.fillRect(x, y, width, 42);
  ctx.fillStyle = "#f4f0e7";
  ctx.font = "700 21px Arial, sans-serif";
  ctx.fillText(title, x + 16, y + 28);
}

function drawKeyValue(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  label: string,
  value: string
): void {
  ctx.fillStyle = "#555555";
  ctx.font = "700 18px Arial, sans-serif";
  ctx.fillText(label.toUpperCase(), x, y);
  ctx.fillStyle = "#171717";
  ctx.font = "23px Arial, sans-serif";
  const measured = ctx.measureText(value).width;
  if (measured > width * 0.6) {
    drawClippedText(ctx, value, x + width * 0.42, y, width * 0.58, 20);
  } else {
    ctx.textAlign = "right";
    ctx.fillText(value, x + width, y);
    ctx.textAlign = "left";
  }
  ctx.strokeStyle = "#b7afa0";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(x, y + 12);
  ctx.lineTo(x + width, y + 12);
  ctx.stroke();
}

function drawRule(
  ctx: CanvasRenderingContext2D,
  x1: number,
  x2: number,
  y: number,
  lineWidth: number
): void {
  ctx.strokeStyle = "#383838";
  ctx.lineWidth = lineWidth;
  ctx.beginPath();
  ctx.moveTo(x1, y);
  ctx.lineTo(x2, y);
  ctx.stroke();
}

function drawCenteredLabel(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  width: number,
  height: number
): void {
  ctx.fillStyle = "#777064";
  ctx.font = "700 22px Arial, sans-serif";
  ctx.textAlign = "center";
  ctx.fillText(text, x + width / 2, y + height / 2);
  ctx.textAlign = "left";
}

function drawImageContain(
  ctx: CanvasRenderingContext2D,
  image: HTMLImageElement,
  x: number,
  y: number,
  width: number,
  height: number
): void {
  const scale = Math.min(width / image.naturalWidth, height / image.naturalHeight);
  const drawWidth = image.naturalWidth * scale;
  const drawHeight = image.naturalHeight * scale;
  ctx.drawImage(
    image,
    x + (width - drawWidth) / 2,
    y + (height - drawHeight) / 2,
    drawWidth,
    drawHeight
  );
}

function drawClippedText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  _fontSize: number
): void {
  if (ctx.measureText(text).width <= maxWidth) {
    ctx.fillText(text, x, y);
    return;
  }

  let value = text;
  while (value.length > 1 && ctx.measureText(`${value}…`).width > maxWidth) {
    value = value.slice(0, -1);
  }
  ctx.fillText(`${value}…`, x, y);
}

function drawWrappedText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  lineHeight: number,
  maxLines: number
): number {
  const paragraphs = text.split(/\r?\n/);
  let lineCount = 0;
  let currentY = y;

  for (const paragraph of paragraphs) {
    const words = paragraph.split(/\s+/).filter(Boolean);
    let line = "";
    for (const word of words) {
      const test = line ? `${line} ${word}` : word;
      if (ctx.measureText(test).width > maxWidth && line) {
        ctx.fillText(line, x, currentY);
        currentY += lineHeight;
        lineCount++;
        line = word;
        if (lineCount >= maxLines) return currentY;
      } else {
        line = test;
      }
    }
    if (line && lineCount < maxLines) {
      ctx.fillText(line, x, currentY);
      currentY += lineHeight;
      lineCount++;
    }
    if (lineCount >= maxLines) return currentY;
  }

  return currentY;
}

function prettyKey(key: string): string {
  return key
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .replaceAll("_", " ")
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

function formatNumber(value: number): string {
  return new Intl.NumberFormat("en-US", {
    maximumFractionDigits: 2
  }).format(value);
}

function safeFileStem(name: string): string {
  return (
    (name || "untitled")
      .replace(/[^a-z0-9-_]+/gi, "-")
      .replace(/^-+|-+$/g, "") || "untitled"
  );
}

function loadImage(dataUrl: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("Could not render design artwork."));
    image.src = dataUrl;
  });
}

function canvasToBlob(canvas: HTMLCanvasElement): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) =>
        blob
          ? resolve(blob)
          : reject(new Error("Could not encode TRO record as PNG.")),
      "image/png"
    );
  });
}

function isPng(bytes: Uint8Array): boolean {
  const signature = [137, 80, 78, 71, 13, 10, 26, 10];
  return (
    bytes.length >= signature.length &&
    signature.every((value, index) => bytes[index] === value)
  );
}

function makeITXtData(keyword: string, text: string): Uint8Array {
  const keyBytes = asciiEncode(keyword);
  if (keyBytes.length < 1 || keyBytes.length > 79) {
    throw new Error("PNG metadata keyword must be between 1 and 79 bytes.");
  }

  const textBytes = new TextEncoder().encode(text);
  return concatBytes([
    keyBytes,
    new Uint8Array([0, 0, 0, 0, 0]),
    textBytes
  ]);
}

function parseITXtData(
  data: Uint8Array
): { keyword: string; text: string } | null {
  const keywordEnd = data.indexOf(0);
  if (keywordEnd <= 0) return null;

  const keyword = asciiDecode(data.slice(0, keywordEnd));
  let offset = keywordEnd + 1;
  if (offset + 2 > data.length) return null;

  const compressionFlag = data[offset++];
  const compressionMethod = data[offset++];
  if (compressionFlag !== 0 || compressionMethod !== 0) return null;

  const languageEnd = data.indexOf(0, offset);
  if (languageEnd < 0) return null;
  offset = languageEnd + 1;

  const translatedEnd = data.indexOf(0, offset);
  if (translatedEnd < 0) return null;
  offset = translatedEnd + 1;

  return {
    keyword,
    text: new TextDecoder().decode(data.slice(offset))
  };
}

function createChunk(type: string, data: Uint8Array): Uint8Array {
  const typeBytes = asciiEncode(type);
  if (typeBytes.length !== 4) throw new Error("Invalid PNG chunk type.");

  const chunk = new Uint8Array(12 + data.length);
  writeUint32(chunk, 0, data.length);
  chunk.set(typeBytes, 4);
  chunk.set(data, 8);

  const crcInput = new Uint8Array(typeBytes.length + data.length);
  crcInput.set(typeBytes, 0);
  crcInput.set(data, typeBytes.length);
  writeUint32(chunk, 8 + data.length, crc32(crcInput));
  return chunk;
}

function readUint32(bytes: Uint8Array, offset: number): number {
  return (
    ((bytes[offset] << 24) |
      (bytes[offset + 1] << 16) |
      (bytes[offset + 2] << 8) |
      bytes[offset + 3]) >>>
    0
  );
}

function writeUint32(bytes: Uint8Array, offset: number, value: number): void {
  bytes[offset] = (value >>> 24) & 0xff;
  bytes[offset + 1] = (value >>> 16) & 0xff;
  bytes[offset + 2] = (value >>> 8) & 0xff;
  bytes[offset + 3] = value & 0xff;
}

function crc32(bytes: Uint8Array): number {
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++) {
      crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
    }
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function asciiEncode(value: string): Uint8Array {
  return Uint8Array.from([...value].map((char) => char.charCodeAt(0) & 0xff));
}

function asciiDecode(bytes: Uint8Array): string {
  return String.fromCharCode(...bytes);
}

function concatBytes(parts: Uint8Array[]): Uint8Array {
  const length = parts.reduce((sum, part) => sum + part.length, 0);
  const output = new Uint8Array(length);
  let offset = 0;
  for (const part of parts) {
    output.set(part, offset);
    offset += part.length;
  }
  return output;
}
