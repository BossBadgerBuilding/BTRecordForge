import type {
  ConstructionValue,
  Design,
  ValueExpression
} from "./types";

export interface ValueContext {
  [key: string]: number;
}

const MAX_DEPTH = 32;

export function evaluateConstructionValue(
  value: ConstructionValue,
  context: ValueContext,
  depth = 0
): number {
  if (depth > MAX_DEPTH) {
    throw new Error("Construction expression exceeds maximum nesting depth.");
  }

  if (typeof value === "number") {
    return finite(value, "literal");
  }

  if ("var" in value) {
    const resolved = context[value.var];
    if (resolved === undefined) {
      throw new Error(`Unknown construction variable: ${value.var}`);
    }
    return finite(resolved, value.var);
  }

  const next = (item: ConstructionValue) =>
    evaluateConstructionValue(item, context, depth + 1);

  switch (value.op) {
    case "add":
      return finite(
        value.args.reduce<number>((sum, item) => sum + next(item), 0),
        "add"
      );

    case "multiply":
      return finite(
        value.args.reduce<number>((product, item) => product * next(item), 1),
        "multiply"
      );

    case "min": {
      requireArgs(value.op, value.args, 1);
      return Math.min(...value.args.map(next));
    }

    case "max": {
      requireArgs(value.op, value.args, 1);
      return Math.max(...value.args.map(next));
    }

    case "subtract":
      return finite(next(value.args[0]) - next(value.args[1]), "subtract");

    case "divide": {
      const denominator = next(value.args[1]);
      if (denominator === 0) {
        throw new Error("Construction expression attempted division by zero.");
      }
      return finite(next(value.args[0]) / denominator, "divide");
    }

    case "ceil":
      return Math.ceil(next(value.args[0]));

    case "floor":
      return Math.floor(next(value.args[0]));

    case "ceilTo":
      return roundToStep(next(value.args[0]), next(value.args[1]), "ceil");

    case "floorTo":
      return roundToStep(next(value.args[0]), next(value.args[1]), "floor");

    case "roundTo":
      return roundToStep(next(value.args[0]), next(value.args[1]), "round");

    default:
      throw new Error(
        `Unknown construction expression: ${JSON.stringify(value)}`
      );
  }
}

export function buildDesignValueContext(
  design: Design,
  derived: Record<string, string | number | boolean> = {}
): ValueContext {
  const context: ValueContext = {
    "unit.mass": design.chassis.massLimit
  };

  if (design.rules.year !== undefined) {
    context["unit.year"] = design.rules.year;
  }

  for (const [key, value] of Object.entries(design.chassis.properties)) {
    if (typeof value === "number" && Number.isFinite(value)) {
      context[`chassis.${key}`] = value;
    }
  }

  for (const [key, value] of Object.entries(derived)) {
    if (typeof value === "number" && Number.isFinite(value)) {
      context[`derived.${key}`] = value;
    }
  }

  return context;
}

export function isValueExpression(value: ConstructionValue): value is ValueExpression {
  return typeof value === "object" && value !== null;
}

export function describeConstructionValue(value: ConstructionValue): string {
  if (typeof value === "number") return String(value);
  if ("var" in value) return value.var;
  return `${value.op}(…)`;
}

function roundToStep(
  value: number,
  step: number,
  mode: "ceil" | "floor" | "round"
): number {
  if (!Number.isFinite(step) || step <= 0) {
    throw new Error("Construction rounding step must be greater than zero.");
  }

  const scaled = value / step;
  const rounded =
    mode === "ceil"
      ? Math.ceil(scaled - Number.EPSILON)
      : mode === "floor"
        ? Math.floor(scaled + Number.EPSILON)
        : Math.round(scaled);

  return finite(rounded * step, `${mode}To`);
}

function requireArgs(
  op: string,
  args: readonly ConstructionValue[],
  minimum: number
): void {
  if (args.length < minimum) {
    throw new Error(`${op} requires at least ${minimum} argument(s).`);
  }
}

function finite(value: number, label: string): number {
  if (!Number.isFinite(value)) {
    throw new Error(`Construction expression ${label} produced a non-finite value.`);
  }
  return value;
}

