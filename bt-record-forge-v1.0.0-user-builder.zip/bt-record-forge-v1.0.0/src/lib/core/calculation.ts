import type {
  ComponentDefinition,
  ConstructionResult,
  CostModifier,
  Design,
  LedgerEntry,
  ValidationIssue
} from "./types";
import { validateComponentLegality } from "./legality";
import {
  buildDesignValueContext,
  evaluateConstructionValue,
  type ValueContext
} from "./valueExpression";

export interface CommonCalculationOptions {
  massEntries?: LedgerEntry[];
  costEntries?: LedgerEntry[];
  slotEntries?: LedgerEntry[];
  costModifiers?: CostModifier[];
  validation?: ValidationIssue[];
  derived?: Record<string, string | number | boolean>;
  expressionContext?: ValueContext;
  enforceMassLimit?: boolean;
}

export function calculateCommon(
  design: Design,
  catalog: Map<string, ComponentDefinition>,
  options: CommonCalculationOptions = {}
): ConstructionResult {
  const validation: ValidationIssue[] = [...(options.validation ?? [])];
  const massEntries: LedgerEntry[] = [...(options.massEntries ?? [])];
  const costEntries: LedgerEntry[] = [...(options.costEntries ?? [])];
  const slotEntries: LedgerEntry[] = [...(options.slotEntries ?? [])];

  const expendableCostEntryIds = new Set<string>();

  for (const installed of design.components) {
    if (!Number.isFinite(installed.quantity) || installed.quantity <= 0) {
      validation.push({
        code: "INVALID_QUANTITY",
        severity: "error",
        componentId: installed.componentId,
        message: `Component ${installed.componentId} has an invalid quantity.`
      });
      continue;
    }

    const component = catalog.get(installed.componentId);
    if (!component) {
      validation.push({
        code: "UNKNOWN_COMPONENT",
        severity: "error",
        componentId: installed.componentId,
        message: `Unknown component: ${installed.componentId}`
      });
      continue;
    }

    validation.push(...validateComponentLegality(design, component));

    const manualMassFormula = component.attributes?.manualMassFormula;
    const manualCostFormula = component.attributes?.manualCostFormula;
    if (typeof manualMassFormula === "string" || typeof manualCostFormula === "string") {
      const unresolved = [
        typeof manualMassFormula === "string" ? `mass: ${manualMassFormula}` : undefined,
        typeof manualCostFormula === "string" ? `cost: ${manualCostFormula}` : undefined
      ].filter(Boolean).join("; ");
      validation.push({
        code: "RULES_IMPLEMENTATION_PARTIAL",
        severity: "warning",
        componentId: installed.componentId,
        message: `${component.name} uses a published construction formula that still requires a constructor-specific implementation (${unresolved}). The exact source formula is preserved in the catalog; no value was guessed.`
      });
    }

    const expressionContext = {
      ...buildDesignValueContext(design, options.derived),
      ...(options.expressionContext ?? {})
    };

    let componentMass: number;
    let componentCost: number;
    let componentSlots: number | undefined;

    try {
      componentMass = evaluateConstructionValue(component.mass, expressionContext);
      componentCost = evaluateConstructionValue(component.cost, expressionContext);
      componentSlots = component.slots === undefined
        ? undefined
        : evaluateConstructionValue(component.slots, expressionContext);
    } catch (error) {
      validation.push({
        code: "UNKNOWN_COMPONENT",
        severity: "error",
        componentId: installed.componentId,
        message: `${component.name} has an unevaluable construction formula: ${
          error instanceof Error ? error.message : String(error)
        }`
      });
      continue;
    }

    if (componentMass < 0 || componentCost < 0 || (componentSlots ?? 0) < 0) {
      validation.push({
        code: "UNKNOWN_COMPONENT",
        severity: "error",
        componentId: installed.componentId,
        message: `${component.name} produced a negative construction value.`
      });
      continue;
    }

    massEntries.push({
      id: `${installed.id}:mass`,
      label: component.name,
      quantity: installed.quantity,
      unitValue: componentMass,
      totalValue: componentMass * installed.quantity,
      category: component.categories[0] ?? "misc",
      sourceComponentId: component.id
    });

    const costEntryId = `${installed.id}:cost`;
    costEntries.push({
      id: costEntryId,
      label: component.name,
      quantity: installed.quantity,
      unitValue: componentCost,
      totalValue: componentCost * installed.quantity,
      category: component.categories[0] ?? "misc",
      sourceComponentId: component.id
    });

    if (component.expendable) {
      expendableCostEntryIds.add(costEntryId);
    }

    if (componentSlots !== undefined && componentSlots > 0) {
      slotEntries.push({
        id: `${installed.id}:slots`,
        label: component.name,
        quantity: installed.quantity,
        unitValue: componentSlots,
        totalValue: componentSlots * installed.quantity,
        category: component.categories[0] ?? "misc",
        sourceComponentId: component.id
      });
    }
  }

  const usedMass = sum(massEntries.map((e) => e.totalValue));
  if (
    options.enforceMassLimit !== false &&
    usedMass > design.chassis.massLimit + 1e-9
  ) {
    validation.push({
      code: "MASS_OVER_LIMIT",
      severity: "error",
      field: "chassis.massLimit",
      message: `Design is ${(usedMass - design.chassis.massLimit).toFixed(2)} tons over its ${design.chassis.massLimit}-ton mass limit.`
    });
  }

  const modifiers = [...(options.costModifiers ?? [])];
  const multiplier = modifiers.reduce((value, modifier) => value * modifier.multiplier, 1);

  const costSubtotal = sum(costEntries.map((e) => e.totalValue));
  const drySubtotal = sum(
    costEntries
      .filter((e) => !expendableCostEntryIds.has(e.id))
      .map((e) => e.totalValue)
  );

  return {
    mass: {
      used: usedMass,
      limit: options.enforceMassLimit === false ? undefined : design.chassis.massLimit,
      remaining:
        options.enforceMassLimit === false
          ? undefined
          : design.chassis.massLimit - usedMass,
      entries: massEntries
    },
    cost: {
      subtotal: costSubtotal,
      modifiers,
      total: roundCentsUp(costSubtotal * multiplier),
      dryTotal: roundCentsUp(drySubtotal * multiplier),
      entries: costEntries
    },
    slots: {
      used: sum(slotEntries.map((e) => e.totalValue)),
      entries: slotEntries
    },
    validation,
    derived: options.derived
  };
}

function sum(values: number[]): number {
  return values.reduce((total, value) => total + value, 0);
}

function roundCentsUp(value: number): number {
  const scaled = value * 100;
  // Math operations such as 42_500 * 1.1 can land a few ULPs above an
  // exact cent. Remove only floating-point noise before rounding upward.
  const tolerance =
    Number.EPSILON * Math.max(1, Math.abs(scaled)) * 4;
  return Math.ceil(scaled - tolerance) / 100;
}
