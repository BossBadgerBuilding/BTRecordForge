import type {
  ComponentDefinition,
  Design,
  RulesLevel,
  ValidationIssue
} from "./types";

const levelRank: Record<RulesLevel, number> = {
  INTRODUCTORY: 0,
  STANDARD: 1,
  ADVANCED: 2,
  EXPERIMENTAL: 3
};

export function validateComponentLegality(
  design: Design,
  component: ComponentDefinition
): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  const year = design.rules.year;
  const a = component.availability;

  if (
    design.rules.techBase !== "MIXED" &&
    !a.techBases.includes(design.rules.techBase) &&
    !a.techBases.includes("MIXED")
  ) {
    issues.push({
      code: "TECH_BASE_CONFLICT",
      severity: "warning",
      componentId: component.id,
      message: `${component.name} conflicts with the selected ${design.rules.techBase.replace("_", " ")} tech base.`
    });
  }

  if (year !== undefined) {
    const beforeIntro = a.introYear !== undefined && year < a.introYear;
    const inExtinctionWindow =
      a.extinctYear !== undefined &&
      year >= a.extinctYear &&
      (a.reintroYear === undefined || year < a.reintroYear);

    if (beforeIntro || inExtinctionWindow) {
      let detail = "";
      if (beforeIntro) detail = ` It is introduced in ${a.introYear}.`;
      if (inExtinctionWindow) {
        detail = a.reintroYear
          ? ` It is unavailable from ${a.extinctYear} until ${a.reintroYear}.`
          : ` It is unavailable beginning in ${a.extinctYear}.`;
      }

      issues.push({
        code: "ERA_ILLEGAL",
        severity: "warning",
        componentId: component.id,
        message: `${component.name} is era-illegal in ${year}.${detail}`
      });
    }
  }

  if (
    a.rulesLevel &&
    levelRank[a.rulesLevel] > levelRank[design.rules.rulesLevel]
  ) {
    issues.push({
      code: "RULES_LEVEL_CONFLICT",
      severity: "warning",
      componentId: component.id,
      message: `${component.name} requires ${a.rulesLevel} rules, but the design is set to ${design.rules.rulesLevel}.`
    });
  }

  return issues;
}
