!macro NSIS_HOOK_POSTINSTALL
  ; Keep all BT Record Forge-owned writable content inside the install folder.
  CreateDirectory "$INSTDIR\custom-builds"
  CreateDirectory "$INSTDIR\app-data"
!macroend
