use std::path::{Path, PathBuf};

fn custom_build_directory() -> Result<PathBuf, String> {
    let exe = std::env::current_exe()
        .map_err(|error| format!("Could not locate the running executable: {error}"))?;
    let parent = exe
        .parent()
        .ok_or_else(|| "Could not determine the executable directory.".to_string())?;

    // BT Record Forge is intentionally self-contained. User creations live
    // beside the executable and never fall back to Documents/AppData.
    Ok(parent.join("custom-builds"))
}

fn safe_png_file_name(file_name: &str) -> String {
    let base = Path::new(file_name)
        .file_name()
        .and_then(|name| name.to_str())
        .unwrap_or("untitled-TRO.png");

    let mut safe: String = base
        .chars()
        .map(|character| {
            if character.is_ascii_alphanumeric()
                || matches!(character, '-' | '_' | '.' | ' ')
            {
                character
            } else {
                '-'
            }
        })
        .collect();

    if !safe.to_ascii_lowercase().ends_with(".png") {
        safe.push_str(".png");
    }

    safe
}

#[tauri::command]
fn save_custom_build(
    file_name: String,
    bytes: Vec<u8>,
) -> Result<String, String> {
    let directory = custom_build_directory()?;
    std::fs::create_dir_all(&directory)
        .map_err(|error| format!("Could not create custom-builds directory: {error}"))?;

    let path = directory.join(safe_png_file_name(&file_name));
    std::fs::write(&path, bytes)
        .map_err(|error| {
            format!(
                "Could not save creation beside BT Record Forge. The install folder must be writable: {error}"
            )
        })?;

    Ok(path.display().to_string())
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    // Create the self-contained creation folder up front when possible.
    if let Ok(directory) = custom_build_directory() {
        let _ = std::fs::create_dir_all(directory);
    }

    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![save_custom_build])
        .run(tauri::generate_context!())
        .expect("error while running BT Record Forge");
}
