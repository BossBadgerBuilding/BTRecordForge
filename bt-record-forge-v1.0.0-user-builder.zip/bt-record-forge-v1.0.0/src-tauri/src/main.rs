fn main() {
    bt_record_forge_lib::run();
}
